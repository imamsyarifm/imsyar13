import 'package:get/route_manager.dart';

import '../presentation/akun/akun_feature.dart';
import '../presentation/berita/news_binding.dart';
import '../presentation/buku_induk/buku_induk_feature.dart';
import '../presentation/buku_induk/pages/preview_buku_induk_page.dart';
import '../presentation/chart/chart_binding.dart';
import '../presentation/chart/chart_page.dart';
import '../presentation/chat/chat_binding.dart';
import '../presentation/chat/chat_page.dart';
import '../presentation/home/get/home_binding.dart';
import '../presentation/home/pages/home_page.dart';
import '../presentation/identitas/get/identitas_mutasi_binding.dart';
import '../presentation/identitas/identitas_feature.dart';
import '../presentation/identitas/pages/identitas_mutasi_page.dart';
import '../presentation/identitas/widgets/filter_ternak_widget.dart';
import '../presentation/inbox/get/inbox_binding.dart';
import '../presentation/inbox/get/inbox_detail_binding.dart';
import '../presentation/inbox/get/send_inbox_binding.dart';
import '../presentation/inbox/pages/inbox_detail_page.dart';
import '../presentation/inbox/pages/inbox_page.dart';
import '../presentation/inbox/pages/send_inbox_page.dart';
import '../presentation/input_eartag/get/input_eartag_binding.dart';
import '../presentation/input_eartag/pages/input_eartag_page.dart';
import '../presentation/inseminasi/inseminasi_feature.dart';
import '../presentation/inseminasi/pages/preview_data/preview_inseminasi_alami_page.dart';
import '../presentation/inseminasi/pages/preview_data/preview_inseminasi_buatan_page.dart';
import '../presentation/inseminasi/pages/preview_data/preview_pemeriksaan_kebuntingan_page.dart';
import '../presentation/inseminasi/pages/preview_data/preview_transfer_embrio_page.dart';
import '../presentation/kandang/kandang_feature.dart';
import '../presentation/kandang_unggas/kandang_unggas_featured.dart';
import '../presentation/kegiatan/kegiatan_binding.dart';
import '../presentation/kegiatan/kegiatan_page.dart';
import '../presentation/keswan/keswan_feature.dart';
import '../presentation/keswan/pages/passcode_keswan_health_page.dart';
import '../presentation/keswan/pages/passcode_keswan_page.dart';
import '../presentation/keswan/pages/preview_keswan_health_page.dart';
import '../presentation/keswan/pages/preview_keswan_page.dart';
import '../presentation/kualitas_susu_edit/kualitas_susu_edit_binding.dart';
import '../presentation/kualitas_susu_edit/kualitas_susu_edit_page.dart';
import '../presentation/login/get/login_binding.dart';
import '../presentation/login/pages/login_page.dart';
import '../presentation/main/main_binding.dart';
import '../presentation/main/main_page.dart';
import '../presentation/mutasi/get/mutasi_aktivasi_edit_binding.dart';
import '../presentation/mutasi/get/mutasi_binding.dart';
import '../presentation/mutasi/get/mutasi_edit_binding.dart';
import '../presentation/mutasi/get/mutasi_subtitusi_eartag_edit_binding.dart';
import '../presentation/mutasi/get/mutasi_subtitusi_edit_binding.dart';
import '../presentation/mutasi/pages/mutasi_aktivasi_edit_page.dart';
import '../presentation/mutasi/pages/mutasi_detail_page.dart';
import '../presentation/mutasi/pages/mutasi_edit_page.dart';
import '../presentation/mutasi/pages/mutasi_page.dart';
import '../presentation/mutasi/pages/mutasi_subtitusi_eartag_edit_page.dart';
import '../presentation/mutasi/pages/mutasi_subtitusi_edit_page.dart';
import '../presentation/mutasi/pages/mutasi_subtitusi_show_data_page.dart';
import '../presentation/mutasi/pages/passcode/passcode_mutasi_aktivasi_page.dart';
import '../presentation/mutasi/pages/passcode/passcode_mutasi_page.dart';
import '../presentation/mutasi/pages/passcode/passcode_mutasi_subtitusi_page.dart';
import '../presentation/mutasi/pages/preview_data_page.dart';
import '../presentation/mutasi/pages/preview_mutasi_aktivasi_page.dart';
import '../presentation/mutasi/pages/preview_mutasi_subtitusi_page.dart';
import '../presentation/offline_ternak/get/offline_ternak_binding.dart';
import '../presentation/offline_ternak/pages/offline_ternak_page.dart';
import '../presentation/owner/get/add_owner_binding.dart';
import '../presentation/owner/get/owner_binding.dart';
import '../presentation/owner/get/owner_detail_binding.dart';
import '../presentation/owner/pages/add_owner_page.dart';
import '../presentation/owner/pages/owner_detail_page.dart';
import '../presentation/owner/pages/owner_page.dart';
import '../presentation/ownership/get/ownership_binding.dart';
import '../presentation/ownership/get/ownership_detail_binding.dart';
import '../presentation/ownership/page/ownership_detail_page.dart';
import '../presentation/ownership/page/ownership_page.dart';
import '../presentation/pakan/get/pakan_binding.dart';
import '../presentation/pakan/get/pakan_detail_binding.dart';
import '../presentation/pakan/get/pakan_edit_binding.dart';
import '../presentation/pakan/pages/detail_pakan_page.dart';
import '../presentation/pakan/pages/pakan_detail_page.dart';
import '../presentation/pakan/pages/pakan_edit_page.dart';
import '../presentation/pakan/pages/pakan_page.dart';
import '../presentation/panen/panen_featured.dart';
import '../presentation/passcode_edit/passcode_confirm_edit_binding.dart';
import '../presentation/passcode_edit/passcode_confirm_edit_page.dart';
import '../presentation/passcode_edit/passcode_edit_binding.dart';
import '../presentation/passcode_edit/passcode_edit_page.dart';
import '../presentation/passcode_edit/passcode_input_binding.dart';
import '../presentation/passcode_edit/passcode_input_page.dart';
import '../presentation/password_edit/password_edit_binding.dart';
import '../presentation/password_edit/password_edit_page.dart';
import '../presentation/pembenihan/pembenihan_featured.dart';
import '../presentation/pending_transaction/get/pending_transaction_binding.dart';
import '../presentation/pending_transaction/pages/pending_transaction_page.dart';
import '../presentation/pertumbuhan_ternak/get/pertumbuhan_ternak_binding.dart';
import '../presentation/pertumbuhan_ternak/page/pertumbuhan_ternak_page.dart';
import '../presentation/produksi_susu/get/produksi_susu_binding.dart';
import '../presentation/produksi_susu/get/produksi_susu_detail_binding.dart';
import '../presentation/produksi_susu/get/produksi_susu_edit_binding.dart';
import '../presentation/produksi_susu/page/passcode_produksi_susu_page.dart';
import '../presentation/produksi_susu/page/preview_produksi_susu_page.dart';
import '../presentation/produksi_susu/page/produksi_susu_detail_page.dart';
import '../presentation/produksi_susu/page/produksi_susu_edit_page.dart';
import '../presentation/produksi_susu/page/produksi_susu_page.dart';
import '../presentation/register/get/register_binding.dart';
import '../presentation/register/pages/register_kelompok_page.dart';
import '../presentation/register/pages/register_page.dart';
import '../presentation/register/pages/register_password_page.dart';
import '../presentation/rekam_medis/get/rekam_medis_binding.dart';
import '../presentation/rekam_medis/page/rekam_medis_page.dart';
import '../presentation/scan/scan_binding.dart';
import '../presentation/scan/scan_page.dart';
import '../presentation/splash/splash_binding.dart';
import '../presentation/splash/splash_page.dart';
import '../presentation/under_development/under_development_page.dart';
import '../presentation/unit_usaha/get/add_unit_usaha_binding.dart';
import '../presentation/unit_usaha/get/unit_usaha_binding.dart';
import '../presentation/unit_usaha/get/unit_usaha_detail_binding.dart';
import '../presentation/unit_usaha/pages/add_unit_usaha_page.dart';
import '../presentation/unit_usaha/pages/unit_usaha_detail_page.dart';
import '../presentation/unit_usaha/pages/unit_usaha_page.dart';
import '../presentation/update/update_major_page.dart';
import '../presentation/vaccine_ternak/get/vaccine_ternak_binding.dart';
import '../presentation/vaccine_ternak/pages/vaccine_ternak_page.dart';

const initialRoute = SplashPage.routeName;

final appRoutes = [
  GetPage(
      name: AkunPage.routeName,
      page: () => const AkunPage(),
      binding: AkunBinding()),
  GetPage(
      name: AkunEditPage.routeName,
      page: () => const AkunEditPage(),
      binding: AkunEditBinding()),
  GetPage(
      name: BukuIndukPage.routeName,
      page: () => const BukuIndukPage(),
      binding: BukuIndukBinding()),
  GetPage(
      name: PreviewBukuIndukPage.routeName,
      page: () => const PreviewBukuIndukPage(),
      binding: BukuIndukBinding()),
  GetPage(
      name: PasscodeBukuIndukPage.routeName,
      page: () => const PasscodeBukuIndukPage(),
      binding: BukuIndukBinding()),
  GetPage(
      name: BukuIndukDetailPage.routeName,
      page: () => const BukuIndukDetailPage(),
      binding: BukuIndukBinding()),
  GetPage(
      name: BukuIndukEditPage.routeName,
      page: () => const BukuIndukEditPage(),
      binding: BukuIndukEditBinding()),
  GetPage(
      name: ChatPage.routeName,
      page: () => const ChatPage(),
      binding: ChatBinding()),
  GetPage(
    name: HomePage.routeName,
    page: () => const HomePage(),
    bindings: [
      KegiatanBinding(),
      NewsBinding(),
      HomeBinding(),
    ],
  ),
  GetPage(
      name: IdentitasPage.routeName,
      page: () => const IdentitasPage(),
      binding: IdentitasBinding()),
  GetPage(
      name: IdentitasBiodataEditPage.routeName,
      page: () => const IdentitasBiodataEditPage(),
      binding: IdentitasBiodataEditBinding()),
  GetPage(
      name: IdentitasDetailPage.routeName,
      page: () => const IdentitasDetailPage(),
      binding: IdentitasDetailBinding()),
  GetPage(
      name: IdentitasHistoryEditPage.routeName,
      page: () => const IdentitasHistoryEditPage(),
      binding: IdentitasHistoryEditBinding()),
  GetPage(
      name: IdentitasKepemilikanEditPage.routeName,
      page: () => const IdentitasKepemilikanEditPage(),
      binding: IdentitasKepemilikanEditBinding()),
  GetPage(
      name: InboxPage.routeName,
      page: () => const InboxPage(),
      binding: InboxBinding()),
  GetPage(
    name: InboxDetailPage.routeName,
    page: () => const InboxDetailPage(),
    binding: InboxDetailBinding(),
  ),
  GetPage(
    name: SendInboxPage.routeName,
    page: () => const SendInboxPage(),
    binding: SendInboxBinding(),
  ),
  GetPage(
      name: InseminasiPage.routeName,
      page: () => const InseminasiPage(),
      binding: InseminasiBinding()),
  GetPage(
      name: InseminasiDetailPage.routeName,
      page: () => const InseminasiDetailPage(),
      binding: InseminasiBinding()),
  GetPage(
      name: InseminasiAlamiEditPage.routeName,
      page: () => const InseminasiAlamiEditPage(),
      binding: InseminasiAlamiEditBinding()),
  GetPage(
      name: PreviewInseminasiAlamiPage.routeName,
      page: () => const PreviewInseminasiAlamiPage(),
      binding: InseminasiAlamiEditBinding()),
  GetPage(
      name: InseminasiBuatanEditPage.routeName,
      page: () => const InseminasiBuatanEditPage(),
      binding: InseminasiBuatanEditBinding()),
  GetPage(
      name: PreviewInseminasiBuatantPage.routeName,
      page: () => const PreviewInseminasiBuatantPage(),
      binding: InseminasiBuatanEditBinding()),
  GetPage(
      name: PasscodeInseminasiBuatanPage.routeName,
      page: () => const PasscodeInseminasiBuatanPage(),
      binding: InseminasiBuatanEditBinding()),
  GetPage(
      name: PasscodeInseminasiAlamiPage.routeName,
      page: () => const PasscodeInseminasiAlamiPage(),
      binding: InseminasiBuatanEditBinding()),
  GetPage(
      name: PasscodeInseminasiTransferEmbrioPage.routeName,
      page: () => const PasscodeInseminasiTransferEmbrioPage(),
      binding: InseminasiBuatanEditBinding()),
  GetPage(
      name: PreviewInseminasiTransferEmbrioPage.routeName,
      page: () => const PreviewInseminasiTransferEmbrioPage(),
      binding: InseminasiBuatanEditBinding()),
  GetPage(
      name: InseminasiTransferEmbrioEditPage.routeName,
      page: () => const InseminasiTransferEmbrioEditPage(),
      binding: InseminasiTransferEmbrioEditBinding()),
  GetPage(
      name: KandangPage.routeName,
      page: () => const KandangPage(),
      binding: KandangBinding()),
  GetPage(
      name: KandangDetailPage.routeName,
      page: () => const KandangDetailPage(),
      binding: KandangDetailBinding()),
  GetPage(
      name: KandangEditPage.routeName,
      page: () => const KandangEditPage(),
      binding: KandangEditBinding()),
  GetPage(
      name: KegiatanPage.routeName,
      page: () => const KegiatanPage(),
      binding: KegiatanBinding()),
  GetPage(
      name: KeswanPage.routeName,
      page: () => const KeswanPage(),
      binding: KeswanBinding()),
  GetPage(
      name: KeswanBobotPage.routeName,
      page: () => const KeswanBobotPage(),
      binding: KeswanBobotBinding()),
  GetPage(
      name: KeswanEditPage.routeName,
      page: () => const KeswanEditPage(),
      binding: KeswanEditBinding()),
  GetPage(
      name: PreviewKeswanPage.routeName,
      page: () => const PreviewKeswanPage(),
      binding: KeswanEditBinding()),
  GetPage(
      name: PasscodeKeswanPage.routeName,
      page: () => const PasscodeKeswanPage(),
      binding: KeswanEditBinding()),
  GetPage(
      name: KeswanHealthEditPage.routeName,
      page: () => const KeswanHealthEditPage(),
      binding: KeswanHealthEditBinding()),
  GetPage(
      name: PreviewKeswanHealthPage.routeName,
      page: () => const PreviewKeswanHealthPage(),
      binding: KeswanHealthEditBinding()),
  GetPage(
      name: PasscodeKeswanHealthPage.routeName,
      page: () => const PasscodeKeswanHealthPage(),
      binding: KeswanHealthEditBinding()),
  GetPage(
      name: LoginPage.routeName,
      page: () => const LoginPage(),
      binding: LoginBinding()),
  GetPage(
    name: MainPage.routeName,
    page: () => const MainPage(),
    binding: MainBinding(),
  ),
  GetPage(
      name: MutasiPage.routeName,
      page: () => const MutasiPage(),
      binding: MutasiBinding()),
  GetPage(
      name: MutasiDetailPage.routeName,
      page: () => const MutasiDetailPage(),
      binding: MutasiBinding()),
  GetPage(
      name: MutasiEditPage.routeName,
      page: () => const MutasiEditPage(),
      binding: MutasiEditBinding()),
  GetPage(
      name: PreviewMutasiEditPage.routeName,
      page: () => const PreviewMutasiEditPage(),
      binding: MutasiEditBinding()),
  GetPage(
    name: PakanPage.routeName,
    page: () => const PakanPage(),
    binding: PakanBinding(),
  ),
  GetPage(
    name: PakanDetailPage.routeName,
    page: () => const PakanDetailPage(),
    binding: PakanDetailBinding(),
  ),
  GetPage(
      name: DetailPakanPage.routeName,
      page: () => const DetailPakanPage(),
      binding: PakanBinding()),
  GetPage(
      name: PakanEditPage.routeName,
      page: () => const PakanEditPage(),
      binding: PakanEditBinding()),
  GetPage(
      name: PasswordEditPage.routeName,
      page: () => const PasswordEditPage(),
      binding: PasswordEditBinding()),
  GetPage(
      name: ScanPage.routeName,
      page: () => const ScanPage(),
      binding: ScanBinding()),
  GetPage(
      name: SplashPage.routeName,
      page: () => const SplashPage(),
      binding: SplashBinding()),
  GetPage(
      name: RegisterPage.routeName,
      page: () => const RegisterPage(),
      binding: RegisterBinding()),
  GetPage(
      name: RegisterPasswordPage.routeName,
      page: () => const RegisterPasswordPage(),
      binding: RegisterBinding()),
  GetPage(
      name: RegisterKelompokPage.routeName,
      page: () => const RegisterKelompokPage(),
      binding: RegisterBinding()),
  GetPage(
      name: UnderDevelopmentPage.routeName,
      page: () => const UnderDevelopmentPage()),
  GetPage(
    name: ProduksiSusuPage.routeName,
    page: () => const ProduksiSusuPage(),
    binding: ProduksiSusuBinding(),
  ),
  GetPage(
    name: PreviewProduksiSusuPage.routeName,
    page: () => const PreviewProduksiSusuPage(),
    binding: ProduksiSusuBinding(),
  ),
  GetPage(
      name: ProduksiSusuDetailPage.routeName,
      page: () => const ProduksiSusuDetailPage(),
      binding: ProduksiSusuDetailBinding()),
  GetPage(
    name: ProduksiSusuGrafikPage.routeName,
    page: () => const ProduksiSusuGrafikPage(),
    binding: ChartBinding(),
  ),
  GetPage(
    name: IdentitasBiodataPage.routeName,
    page: () => const IdentitasBiodataPage(),
    binding: IdentitasBiodataBinding(),
  ),
  GetPage(
    name: PertumbuhanTernakPage.routeName,
    page: () => const PertumbuhanTernakPage(),
    binding: PertumbuhanTernakBinding(),
  ),
  GetPage(
    name: RekamMedisPage.routeName,
    page: () => const RekamMedisPage(),
    binding: RekamMedisBinding(),
  ),
  GetPage(
    name: OwnershipPage.routeName,
    page: () => const OwnershipPage(),
    binding: OwnershipBinding(),
  ),
  GetPage(
    name: OwnershipDetailPage.routeName,
    page: () => const OwnershipDetailPage(),
    binding: OwnershipDetailBinding(),
  ),
  GetPage(
    name: ProduksiSusuEditPage.routeName,
    page: () => const ProduksiSusuEditPage(),
    binding: ProduksiSusuEditBinding(),
  ),
  GetPage(
    name: PasscodeProduksiSusuPage.routeName,
    page: () => const PasscodeProduksiSusuPage(),
    binding: ProduksiSusuEditBinding(),
  ),
  GetPage(
    name: KualitasSusuEditPage.routeName,
    page: () => const KualitasSusuEditPage(),
    binding: KualitasSusuEditBinding(),
  ),
  GetPage(
    name: AddOwnerPage.routeName,
    page: () => const AddOwnerPage(),
    binding: AddOwnerBinding(),
  ),
  GetPage(
    name: OwnerPage.routeName,
    page: () => const OwnerPage(),
    binding: OwnerBinding(),
  ),
  GetPage(
    name: UnitUsahaPage.routeName,
    page: () => const UnitUsahaPage(),
    binding: UnitUsahaBinding(),
  ),
  GetPage(
    name: UnitUsahaDetailPage.routeName,
    page: () => const UnitUsahaDetailPage(),
    binding: UnitUsahaDetailBinding(),
  ),
  GetPage(
    name: AddUnitUsahaPage.routeName,
    page: () => const AddUnitUsahaPage(),
    binding: AddUnitUsahaBinding(),
  ),
  GetPage(
    name: OwnerDetailPage.routeName,
    page: () => const OwnerDetailPage(),
    binding: OwnerDetailBinding(),
  ),
  GetPage(
    name: VaccineTernakPage.routeName,
    page: () => const VaccineTernakPage(),
    binding: VaccineTernakBinding(),
  ),
  GetPage(
    name: IdentitasMutasiPage.routeName,
    page: () => const IdentitasMutasiPage(),
    binding: IdentitasMutasiBinding(),
  ),
  GetPage(
    name: FilterTernakWidget.routeName,
    page: () => const FilterTernakWidget(),
    binding: IdentitasBinding(),
  ),
  GetPage(
    name: OfflineTernakPage.routeName,
    page: () => const OfflineTernakPage(),
    binding: OfflineTernakBinding(),
  ),
  GetPage(
    name: PendingTransactionPage.routeName,
    page: () => const PendingTransactionPage(),
    binding: PendingTransactionBinding(),
  ),
  GetPage(
    name: InputEartagPage.routeName,
    page: () => const InputEartagPage(),
    binding: InputEartagBinding(),
  ),
  GetPage(
    name: MutasiAktivasiEditPage.routeName,
    page: () => const MutasiAktivasiEditPage(),
    binding: MutasiAktivasiEditBinding(),
  ),
  GetPage(
    name: PreviewMutasiAktivasiPage.routeName,
    page: () => const PreviewMutasiAktivasiPage(),
    binding: MutasiAktivasiEditBinding(),
  ),
  GetPage(
    name: MutasiSubtitusiEditPage.routeName,
    page: () => const MutasiSubtitusiEditPage(),
    binding: MutasiSubtitusiEditBinding(),
  ),
  GetPage(
    name: MutasiSubtitusiShowPage.routeName,
    page: () => const MutasiSubtitusiShowPage(),
    binding: MutasiSubtitusiEditBinding(),
  ),
  GetPage(
    name: PreviewMutasiSubtitusiPage.routeName,
    page: () => const PreviewMutasiSubtitusiPage(),
    binding: MutasiSubtitusiEditBinding(),
  ),
  GetPage(
    name: PasscodeMutasiSubtitusiPage.routeName,
    page: () => const PasscodeMutasiSubtitusiPage(),
    binding: MutasiSubtitusiEditBinding(),
  ),
  GetPage(
    name: PasscodeEditPage.routeName,
    page: () => const PasscodeEditPage(),
    binding: PasscodeEditBinding(),
  ),
  GetPage(
    name: PasscodeConfirmEditPage.routeName,
    page: () => const PasscodeConfirmEditPage(),
    binding: PasscodeConfirmEditBinding(),
  ),
  GetPage(
    name: PasscodeInputPage.routeName,
    page: () => const PasscodeInputPage(),
    binding: PasscodeInputBinding(),
  ),
  GetPage(
    name: PasscodeMutasiAktivasiPage.routeName,
    page: () => const PasscodeMutasiAktivasiPage(),
    binding: MutasiAktivasiEditBinding(),
  ),
  GetPage(
    name: PasscodeMutasiPage.routeName,
    page: () => const PasscodeMutasiPage(),
    binding: MutasiEditBinding(),
  ),
  GetPage(
    name: PemeriksaanKebuntinganEditPage.routeName,
    page: () => const PemeriksaanKebuntinganEditPage(),
    binding: PemeriksaanKebuntinganEditBinding(),
  ),
  GetPage(
    name: PreviewPemeriksaanKebuntinganPage.routeName,
    page: () => const PreviewPemeriksaanKebuntinganPage(),
    binding: PemeriksaanKebuntinganEditBinding(),
  ),
  GetPage(
    name: PasscodePemeriksaanKebuntingannPage.routeName,
    page: () => const PasscodePemeriksaanKebuntingannPage(),
    binding: PemeriksaanKebuntinganEditBinding(),
  ),
  GetPage(
    name: KandangUnggasPage.routeName,
    page: () => const KandangUnggasPage(),
    binding: KandangUnggasBinding(),
  ),
  GetPage(
    name: KandangUnggasDetailPage.routeName,
    page: () => const KandangUnggasDetailPage(),
    binding: KandangUnggasDetailBinding(),
  ),
  GetPage(
    name: KandangUnggasEditPage.routeName,
    page: () => const KandangUnggasEditPage(),
    binding: KandangUnggasEditBinding(),
  ),
  GetPage(
    name: PanenPage.routeName,
    page: () => const PanenPage(),
  ),
  GetPage(
    name: PreviewPanenPage.routeName,
    page: () => const PreviewPanenPage(),
  ),
  GetPage(
    name: PasscodePanenPage.routeName,
    page: () => const PreviewPanenPage(),
  ),
  GetPage(
    name: PembenihanPage.routeName,
    page: () => const PembenihanPage(),
  ),
  GetPage(
    name: PreviewPembenihanPage.routeName,
    page: () => const PreviewPembenihanPage(),
  ),
  GetPage(
    name: PasscodePembenihanPage.routeName,
    page: () => const PasscodePembenihanPage(),
  ),
  GetPage(
    name: MutasiSubtitusiEartagEditPage.routeName,
    page: () => const MutasiSubtitusiEartagEditPage(),
    binding: MutasiSubtitusiEartagEditBinding(),
  ),
  GetPage(
    name: UpdateMajorPage.routeName,
    page: () => const UpdateMajorPage(),
  ),
];
