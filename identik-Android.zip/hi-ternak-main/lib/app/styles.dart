import 'package:flutter/material.dart';
import 'consts/colors.dart';

class Styles {
  static ThemeData theme() => ThemeData(
    brightness: Brightness.light,
    primaryColor: green,
  );
}
