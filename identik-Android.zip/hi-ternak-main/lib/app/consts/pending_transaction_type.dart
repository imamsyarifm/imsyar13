import '../../data/models/buku_lahir/buku_induk_request.dart';
import '../../data/models/inseminasi/inseminasi_request.dart';
import '../../data/models/kandang/kandang_model.dart';
import '../../data/models/keswan/keswan_bobot_request_model.dart';
import '../../data/models/keswan/keswan_kesehatan_request_model.dart';
import '../../data/models/mutasi/manage_mutasi_request_model.dart';
import '../../data/models/owner/owner_model.dart';
import '../../data/models/pakan/update_pakan_request.dart';
import '../../data/models/susu/produksi_susu_request.dart';
import '../../data/models/ternak/ternak_request.dart';
import '../../data/models/unit_usaha/unit_usaha.dart';

enum PendingTransaction {
  unitUsaha('Unit Usaha', UnitUsaha.localName),
  owner('Pemilik', OwnerModel.localName),
  kandang('Kandang', KandangModel.localName),
  ternak('Ternak', TernakRequest.localName),
  pertumbuhan('Pertumbuhan', KeswanBobotRequestModel.localName),
  vaksinasi('Vaksinasi', KeswanKesehatanRequestModel.localName),
  mutasi('Mutasi', ManageMutasiRequestModel.localName),
  susu('Susu', ProduksiSusuRequest.localName),
  inseminasi('Inseminasi', InseminasiRequest.localName),
  bukuLahir('Buku Lahir', BukuIndukRequest.localName),
  pakan('Pakan', UpdatePakanRequest.localName);

  final String name;
  final String localName;

  const PendingTransaction(this.name, this.localName);
}
