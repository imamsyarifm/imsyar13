import 'package:flutter/material.dart';

const yellow = Color(0xffffef7d);
const yellowDark = Color(0xffffe001);
const green = Color(0xff2e7d32);
const greyC = Color(0xffcccccc);
const grey8 = Color(0xff888888);
const greyB = Color(0xffbbbbbb);
const greyEF = Color(0xffeff1f3);
const greyE5 = Color(0xffe5e5e5);
const greyB0 = Color(0xffb0b0b0);
const greyDF = Color(0xffdfdfdf);
const greyDA = Color(0xffdadada);
const grey9D = Color(0xff9d9d9d);
const grey9B = Color(0xff9b9b9b);
const greyF4 = Color(0xfff4f4f4);
const gold = Color(0xffc79000);
const goldDark = Color(0xffc68f00);
const black = Color(0xff444444);
