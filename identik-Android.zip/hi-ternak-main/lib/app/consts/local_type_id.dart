class LocalTypeId {
  static const province = 0;
  static const district = 1;
  static const subDistrict = 2;
  static const village = 3;
  static const identityTernak = 6;
  static const identityPertumbuhan = 7;
  static const identityRekamMedis = 8;
  static const identityInseminasi = 9;
  static const identityProduksiSusu = 10;
  static const identityKualitasSusu = 11;
  static const identityKepemilikan = 12;
  static const identityKandang = 13;
  static const identityAlamatLahirTernak = 14;
  static const identityMutasi = 15;

  static const unitUsaha = 4;
  static const unitUsahaAddress = 16;
  static const unitUsahaRequest = 17;
  static const unitUsahaAddressRequest = 18;

  static const owner = 5;
  static const ownerRequest = 19;
  static const ownerAddressRequest = 20;

  static const kandang = 21;
  static const kandangRequest = 22;
  static const kandangAddress = 23;
  static const kandangOwner = 24;

  static const categoryTernak = 25;
  static const rumpun = 26;
  static const program = 27;
  static const statusKandang = 28;
  static const asalTernak = 29;
  static const merkVaksin = 30;

  static const combo = 31;
  static const keswanGrowthRequest = 32;
  static const keswanHealthRequest = 33;
  static const mutasiRequest = 34;
  static const pakanRequest = 35;
  static const produksiSusuRequest = 36;
  static const inseminasiRequest = 37;
  static const bukuIndukRequest = 38;
  static const ternakRequest = 39;
  static const ternakBirthdayRequest = 40;

  static const ownerAddress = 41;
  static const addKandangAddress = 42;
  static const indukJantan = 43;
  static const bukuLahirInduk = 44;
  static const country = 45;
  static const kandangUnggas = 46;
  static const komoditas = 47;
}
