class LocalKeys {
  static const token = 'token';
  static const isIndividu = 'isIndividu';
  static const idProvince = 'idProvince';
  static const idDistrict = 'idDistrict';
  static const minAndroid = 'minAndroid';
  static const miniOS = 'miniOS';
  static const androidStore = 'androidStore';
  static const iOSStore = 'iOSStore';
  static const nik = 'nik';
  static const enableApp = 'enable_app';
}
