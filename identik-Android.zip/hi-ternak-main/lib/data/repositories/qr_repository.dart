import 'package:dio/dio.dart';

import '../../utils/networking_util.dart';
import '../const/endpoints.dart';
import '../models/scan/scan_request_model.dart';
import '../models/ternak/identity_ternak_model.dart';
import '../models/ternak/identity_ternak_response_model.dart';

class QrRepository {
  final Dio _client;

  QrRepository({
    required Dio client,
  }) : _client = client;

  Future<IdentityTernakModel?> scan(ScanRequestModel request) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.post(
      Endpoints.scan,
      options: Options(headers: headers),
      data: request.toJson(),
    );
    final model = TernakResponseModel.fromJson(responseJson.data);
    return model.data;
  }
}
