import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get_connect/http/src/status/http_status.dart';

import '../../utils/local_helper.dart';
import '../../utils/networking_util.dart';
import '../const/endpoints.dart';
import '../models/keswan/keswan_bobot_request_model.dart';
import '../models/keswan/keswan_kesehatan_request_model.dart';
import '../models/keswan/keswan_model.dart';
import '../models/keswan/keswan_request_model.dart';
import '../models/keswan/keswan_response_model.dart';
import '../models/simple_response_success_model.dart';

class KeswanRepository {
  final Dio _client;

  KeswanRepository({
    required Dio client,
  }) : _client = client;

  Future<KeswanModel> keswan(String productCode) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final request = KeswanRequestModel(codeProduct: productCode);
    final responseJson = await _client.post(
      Endpoints.keswan,
      options: Options(
        headers: headers,
      ),
      data: request.toJson(),
    );
    final model = KeswanResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<SimpleResponseSuccessModel> keswanBobot({
    required KeswanBobotRequestModel request,
    bool localStrategy = true,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.post(
        Endpoints.keswanBobot,
        options: Options(
          headers: headers,
        ),
        data: request.toJson(),
      );
      debugPrint(request.toJson().toString());
      return SimpleResponseSuccessModel.fromJson(responseJson.data);
    } else {
      if (localStrategy) {
        unawaited(syncKeswanGrowthRequest(request));
        return SimpleResponseSuccessModel(
          code: HttpStatus.ok,
          message: 'Success Save To Local',
        );
      } else {
        return SimpleResponseSuccessModel(
          code: HttpStatus.internalServerError,
          message: 'Failed Save To Local',
        );
      }
    }
  }

  Future<int> syncKeswanGrowthRequest(KeswanBobotRequestModel request) async {
    return await LocalHelper.insert<KeswanBobotRequestModel>(
        KeswanBobotRequestModel.localName, request);
  }

  Future<SimpleResponseSuccessModel> keswanKesehatan({
    required KeswanKesehatanRequestModel request,
    bool localStrategy = true,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.post(
        Endpoints.keswanKesehatan,
        options: Options(
          headers: headers,
        ),
        data: request.toJson(),
      );
      return SimpleResponseSuccessModel.fromJson(responseJson.data);
    } else {
      if (localStrategy) {
        unawaited(syncKeswanHealthRequest(request));
        return SimpleResponseSuccessModel(
          code: HttpStatus.ok,
          message: 'Success Save To Local',
        );
      } else {
        return SimpleResponseSuccessModel(
          code: HttpStatus.internalServerError,
          message: 'Failed Save To Local',
        );
      }
    }
  }

  Future<int> syncKeswanHealthRequest(
      KeswanKesehatanRequestModel request) async {
    return await LocalHelper.insert<KeswanKesehatanRequestModel>(
        KeswanKesehatanRequestModel.localName, request);
  }
}
