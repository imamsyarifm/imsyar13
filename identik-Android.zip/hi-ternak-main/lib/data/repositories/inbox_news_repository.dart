import 'package:dio/dio.dart';
import 'package:get/get_connect/http/src/status/http_status.dart';

import '../../utils/networking_util.dart';
import '../const/endpoints.dart';
import '../models/inbox/inbox_model.dart';
import '../models/inbox/inbox_response_model.dart';
import '../models/simple_response_success_model.dart';

class InboxNewsRepository {
  final Dio _client;

  InboxNewsRepository({
    required Dio client,
  }) : _client = client;

  Future<List<InboxModel>> allInbox(bool isReceived) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      (isReceived) ? Endpoints.inbox : Endpoints.inboxSent,
      options: Options(headers: headers),
    );
    final model = InboxResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<InboxModel>> get allActivity async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.activities,
      options: Options(
        headers: headers,
      ),
    );
    final model = InboxResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<InboxModel>> get allNews async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.news,
      options: Options(headers: headers),
    );
    final model = InboxResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<bool> sendMessage(FormData payload) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.post(
      Endpoints.sendMessage,
      options: Options(
        headers: headers,
      ),
      data: payload,
    );
    final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
    return model.code == HttpStatus.ok;
  }
}
