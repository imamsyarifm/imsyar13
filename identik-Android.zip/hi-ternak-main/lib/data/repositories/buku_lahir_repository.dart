import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart';

import '../../utils/local_helper.dart';
import '../../utils/networking_util.dart';
import '../const/endpoints.dart';
import '../models/buku_lahir/buku_induk_request.dart';
import '../models/buku_lahir/buku_lahir_induk.dart';
import '../models/buku_lahir/buku_lahir_induk_response.dart';
import '../models/simple_response_success_model.dart';

class BukuLahirRepository {
  final Dio _client;

  BukuLahirRepository({
    required Dio client,
  }) : _client = client;

  Future<List<BukuLahirInduk>> allLahirInduk({
    String? search,
    int offset = 0,
    int limit = 20,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final params = <String, dynamic>{
        'offset': offset,
        'limit': limit,
      };

      final headers = await NetworkingUtil.setupTokenHeader();

      if (search != null) params['search'] = search;

      final responseJson = await _client.get(
        Endpoints.lahirInduk,
        options: Options(
          headers: headers,
        ),
        queryParameters: params,
      );

      final model = BukuLahirIndukResponse.fromJson(responseJson.data);
      return model.data;
    } else {
      final lahirInduk =
          await LocalHelper.getTable<BukuLahirInduk>(BukuLahirInduk.localName);
      return lahirInduk.values.toList();
    }
  }

  Future<bool> save({
    required BukuIndukRequest payload,
    bool localStrategy = true,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;

    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.post(
        Endpoints.bukuLahir,
        options: Options(
          headers: headers,
        ),
        data: payload.toJson(),
      );

      final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
      return (model.code == HttpStatus.ok);
    } else {
      if (localStrategy) {
        unawaited(syncBukuIndukRequest(payload));
        return true;
      } else {
        return false;
      }
    }
  }

  Future<int> syncBukuIndukRequest(BukuIndukRequest request) async {
    return LocalHelper.insert<BukuIndukRequest>(
        BukuIndukRequest.localName, request);
  }

  Future<void> syncLahirInduk() async {
    final lahirInduk = await allLahirInduk();
    await LocalHelper.inserts<BukuLahirInduk>(
        BukuLahirInduk.localName, lahirInduk);
  }

  Future<void> unsyncLahirInduk() async {
    await LocalHelper.deleteAll<BukuLahirInduk>(BukuLahirInduk.localName);
  }
}
