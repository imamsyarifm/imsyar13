import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:scanner/peruri_scanner.dart';

import '../../utils/local_helper.dart';
import '../../utils/networking_util.dart';
import '../../utils/validation_util.dart';
import '../const/endpoints.dart';
import '../models/combo/combo_model.dart';
import '../models/combo/combo_response_model.dart';
import '../models/distribution_area/distribution_area_model.dart';
import '../models/distribution_area/distribution_area_response_model.dart';
import '../models/simple_response_success_model.dart';
import '../models/ternak/identity_ternak_model.dart';
import '../models/ternak/identity_ternak_response_model.dart';
import '../models/ternak/ternak_request.dart';
import '../models/ternak/update_history_ternak_request_model.dart';
import '../models/ternak/update_ownership_request_model.dart';
import '../models/ternak_sync_validation.dart';

class TernakRepository {
  final Dio _client;

  TernakRepository({
    required Dio client,
  }) : _client = client;

  Future<List<IdentityTernakModel>> allTernak({
    String? query,
    int offset = 0,
    int limit = 20,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final params = <String, dynamic>{
        'offset': offset,
        'limit': limit,
      };

      if (query != null && query != '') {
        params['search'] = query;
      }

      final responseJson = await _client.get(
        Endpoints.allTernak,
        options: Options(
          headers: headers,
        ),
        queryParameters: params,
      );
      final model = IdentityTernakResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      final provinceLocal = <IdentityTernakModel>[];
      try {
        final data = await LocalHelper.getTable<IdentityTernakModel>(
            IdentityTernakModel.localName);
        provinceLocal.addAll(data.values.toList());
      } catch (error) {
        debugPrint(error.toString());
      }
      return provinceLocal;
    }
  }

  Future<SimpleResponseSuccessModel> updateBiodata(
      TernakRequest request) async {
    final isConnected = await NetworkingUtil.isConnected;
    final payload = await request.toPayloadUpdate;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.post(
        Endpoints.biodataTernak,
        options: Options(
          headers: headers,
        ),
        data: payload,
      );

      return SimpleResponseSuccessModel.fromJson(responseJson.data);
    } else {
      request.isUpdate = true;
      unawaited(syncTernakRequest(request));
      return SimpleResponseSuccessModel(
        code: HttpStatus.ok,
        message: 'Updated',
      );
    }
  }

  Future<SimpleResponseSuccessModel> addTernak({
    required TernakRequest request,
    bool localStrategy = true,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;

    if (isConnected) {
      final isStartWithAlphabet =
          ValidationUtil.startWithAlphabet(request.codeProduct!);
      if (!isStartWithAlphabet) {
        final decodedValue = await PeruriScanner.decodeQR(request.scanResult!);
        request.codeProduct =
            decodedValue?.dcdPublicData ?? request.codeProduct;
      }

      try {
        final headers = await NetworkingUtil.setupTokenHeader();
        final payload = await request.toPayloadAdd;
        final responseJson = await _client.post(
          Endpoints.addTernak,
          options: Options(
            headers: headers,
          ),
          data: payload,
        );

        return SimpleResponseSuccessModel.fromJson(responseJson.data);
      } catch (error) {
        if (error is DioError) {
          if (error.response?.statusCode == 403) {
            await NetworkingUtil.syncTernakValidation(
              client: _client,
              ternak: TernakSyncValidation(
                randomCode: request.randomCode ?? '',
                eartag: request.codeProduct ?? '',
              ),
            );

            return SimpleResponseSuccessModel(
              code: 403,
              message: 'Failed',
            );
          } else {
            return SimpleResponseSuccessModel(
              code: HttpStatus.internalServerError,
              message: 'Failed',
            );
          }
        } else {
          return SimpleResponseSuccessModel(
            code: HttpStatus.internalServerError,
            message: 'Failed',
          );
        }
      }
    } else {
      if (localStrategy) {
        request.isUpdate = false;
        unawaited(syncTernakRequest(request));
        return SimpleResponseSuccessModel(
          code: HttpStatus.ok,
          message: 'Added',
        );
      } else {
        return SimpleResponseSuccessModel(
          code: HttpStatus.internalServerError,
          message: 'Failed',
        );
      }
    }
  }

  Future<int> syncTernakRequest(TernakRequest request) async {
    return await LocalHelper.insert<TernakRequest>(
        TernakRequest.localName, request);
  }

  Future<SimpleResponseSuccessModel> updateHistory(
    UpdateHistoryTernakRequest body,
  ) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.post(
      Endpoints.historyTernak,
      options: Options(
        headers: headers,
      ),
      data: body.toJson(),
    );
    return SimpleResponseSuccessModel.fromJson(responseJson.data);
  }

  Future<SimpleResponseSuccessModel> updateOwnership(
    UpdateOwnershipRequestModel body,
  ) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.post(
      Endpoints.ownerTernak,
      options: Options(
        headers: headers,
      ),
      data: body.toJson(),
    );
    return SimpleResponseSuccessModel.fromJson(responseJson.data);
  }

  Future<List<DistributionAreaModel>> get areas async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.distributionArea,
      options: Options(
        headers: headers,
      ),
    );
    final model = DistributionAreaResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<ComboModel>> get taniGroups async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.taniGroup,
      options: Options(
        headers: headers,
      ),
    );
    final model = ComboResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<String?> _findLocalPath() async {
    final directory = (Platform.isAndroid)
        ? await getExternalStorageDirectory()
        : await getApplicationDocumentsDirectory();
    return directory?.path;
  }

  Future<String?> downloadInsentif() async {
    final headers = await NetworkingUtil.setupTokenHeader();

    const baseUrl = String.fromEnvironment('BASE_URL');
    const defaultExtension = '.pdf';
    const urlPath = '$baseUrl${Endpoints.insentif}';
    final uri = Uri.parse(urlPath).pathSegments;

    // Check if url already include extension or not
    final isExtensionIncluded = extension(File(urlPath).path).isNotEmpty;

    // If extension is not included, then use .png as default image extension
    final fileName =
        isExtensionIncluded ? uri.last : '${uri.last}$defaultExtension';

    final path = await _findLocalPath();
    final savePath = '$path/$fileName';

    var response = await Dio().download(
      urlPath,
      savePath,
      options: Options(
        headers: headers,
      ),
    );
    var result = (response.statusCode == 200) ? savePath : null;
    return Future.value(result);
  }

  Future<SimpleResponseSuccessModel> addMutasiReplaceEartag({
    required TernakRequest request,
    bool localStrategy = true,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;

    if (isConnected) {
      final isStartWithAlphabet =
          ValidationUtil.startWithAlphabet(request.codeProduct!);
      if (!isStartWithAlphabet) {
        final decodedValue = await PeruriScanner.decodeQR(request.scanResult!);
        request.codeProduct =
            decodedValue?.dcdPublicData ?? request.codeProduct;
      }

      try {
        final headers = await NetworkingUtil.setupTokenHeader();
        final payload = await request.toPayloadAdd;
        final responseJson = await _client.post(
          Endpoints.mutasiReplaceEartag,
          options: Options(
            headers: headers,
          ),
          data: payload,
        );
        debugPrint(payload.toString());

        return SimpleResponseSuccessModel.fromJson(responseJson.data);
      } catch (error) {
        if (error is DioError) {
          if (error.response?.statusCode == 403) {
            await NetworkingUtil.syncTernakValidation(
              client: _client,
              ternak: TernakSyncValidation(
                randomCode: request.randomCode ?? '',
                eartag: request.codeProduct ?? '',
              ),
            );

            return SimpleResponseSuccessModel(
              code: 403,
              message: 'Failed',
            );
          } else {
            return SimpleResponseSuccessModel(
              code: HttpStatus.internalServerError,
              message: 'Failed',
            );
          }
        } else {
          return SimpleResponseSuccessModel(
            code: HttpStatus.internalServerError,
            message: 'Failed',
          );
        }
      }
    } else {
      if (localStrategy) {
        request.isUpdate = false;
        unawaited(syncTernakRequest(request));
        return SimpleResponseSuccessModel(
          code: HttpStatus.ok,
          message: 'Added',
        );
      } else {
        return SimpleResponseSuccessModel(
          code: HttpStatus.internalServerError,
          message: 'Failed',
        );
      }
    }
  }
}
