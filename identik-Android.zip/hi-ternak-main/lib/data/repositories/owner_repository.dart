import 'dart:async';

import 'package:dio/dio.dart';
import 'package:get/get_connect/http/src/status/http_status.dart';

import '../../utils/datetime_util.dart';
import '../../utils/local_helper.dart';
import '../../utils/networking_util.dart';
import '../const/endpoints.dart';
import '../models/owner/add_owner_address_request_model.dart';
import '../models/owner/add_owner_request_model.dart';
import '../models/owner/owner_address_model.dart';
import '../models/owner/owner_model.dart';
import '../models/owner/owner_response_model.dart';
import '../models/simple_response_success_model.dart';

class OwnerRepository {
  final Dio _client;

  OwnerRepository({
    required Dio client,
  }) : _client = client;

  Future<List<OwnerModel>> owners({
    String? query,
    bool isIncludeCompany = true,
    int offset = 0,
    int limit = 20,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final params = <String, dynamic>{
        'offset': offset,
        'limit': limit,
      };
      if (query != null && query != '') params['search'] = query;
      params['isIncludeCompany'] = (isIncludeCompany) ? '1' : '0';

      final responseJson = await _client.get(
        Endpoints.owners,
        options: Options(
          headers: headers,
        ),
        queryParameters: params,
      );
      final model = OwnerResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      final localRequest = await LocalHelper.getTable<AddOwnerRequestModel>(
          AddOwnerRequestModel.localName);
      final localOwner =
          await LocalHelper.getTable<OwnerModel>(OwnerModel.localName);

      final allOwner = localOwner.values.toList();

      final allRequest = localRequest.values
          .map(
            (request) => OwnerModel(
              id: request.id ?? '-',
              nik: request.nik,
              name: request.name,
              gender: request.gender,
              birthdate: DateTime.parse(request.birthdate),
              umur: '-',
              email: request.email,
              phone: request.phone,
              idAddress: '-',
              address: OwnerAddressModel(
                id: '-',
                idProvince: request.address.idProvince ?? '-',
                province: '-',
                idDistrict: request.address.idDistrict ?? '-',
                district: '-',
                idSubDistrict: request.address.idSubDistrict ?? '-',
                subDistrict: '-',
                idVillage: request.address.idVillage ?? '-',
                urbanVillage: '-',
                rt: request.address.rt ?? '-',
                rw: request.address.rw ?? '-',
                longitude: request.address.longitude,
                latitude: request.address.latitude,
                address: request.address.address ?? '-',
              ),
            ),
          )
          .toList();
      allOwner.addAll(allRequest);

      if (query != null) {
        return allOwner
            .where((element) =>
                element.name.toLowerCase().contains(query.toLowerCase()))
            .toList();
      } else {
        return allOwner;
      }
    }
  }

  Future<void> get syncOwners async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final params = <String, dynamic>{
      'isIncludeCompany': 1,
    };

    final responseJson = await _client.get(
      Endpoints.owners,
      options: Options(
        headers: headers,
      ),
      queryParameters: params,
    );
    final model = OwnerResponseModel.fromJson(responseJson.data);

    await LocalHelper.inserts<OwnerModel>(OwnerModel.localName, model.data);
  }

  Future<void> get unsycOwners async {
    await LocalHelper.deleteAll<OwnerModel>(OwnerModel.localName);
  }

  Future<bool> insert(AddOwnerRequestModel request) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.post(
        Endpoints.owners,
        options: Options(
          headers: headers,
        ),
        data: request.toJson(),
      );

      final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
      return model.code == HttpStatus.ok;
    } else {
      unawaited(syncRequest(request));
      unawaited(syncOwner(request));
      return true;
    }
  }

  Future<bool> syncUpload(OwnerModel data) async {
    final dataAddress = data.address;

    final requestAddress = AddOwnerAddressRequestModel(
      idProvince: dataAddress.idProvince,
      idDistrict: dataAddress.idDistrict,
      idSubDistrict: dataAddress.idSubDistrict,
      idVillage: dataAddress.idVillage,
      rt: dataAddress.rt,
      rw: dataAddress.rw,
      address: dataAddress.address,
      latitude: dataAddress.latitude,
      longitude: dataAddress.longitude,
    );

    final request = AddOwnerRequestModel(
      id: data.id,
      nik: data.nik,
      name: data.name,
      gender: data.gender,
      birthdate: data.birthdate.valueApi(),
      email: data.email,
      phone: data.phone,
      isPemilik: data.isPemilik.toString(),
      address: requestAddress,
    );

    final headers = await NetworkingUtil.setupTokenHeader();

    final responseJson = await _client.post(
      Endpoints.owners,
      options: Options(
        headers: headers,
      ),
      data: request.toJson(),
    );

    final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
    return model.code == HttpStatus.ok;
  }

  Future<void> syncRequest(AddOwnerRequestModel request) async {
    await LocalHelper.insert<AddOwnerRequestModel>(
        AddOwnerRequestModel.localName, request);
  }

  Future<void> syncOwner(AddOwnerRequestModel request) async {
    final address = OwnerAddressModel(
      id: request.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
      idProvince: request.address.idProvince ?? '-',
      province: '-',
      idDistrict: request.address.idDistrict ?? '-',
      district: '-',
      idSubDistrict: request.address.idSubDistrict ?? '-',
      subDistrict: '-',
      idVillage: request.address.idVillage ?? '-',
      urbanVillage: '-',
      rt: request.address.rt ?? '-',
      rw: request.address.rw ?? '-',
      longitude: request.address.longitude,
      latitude: request.address.latitude,
      address: request.address.address ?? '-',
    );

    final owner = OwnerModel(
      id: request.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
      nik: request.nik,
      name: request.name,
      gender: request.gender,
      birthdate: DateTime.parse(request.birthdate),
      umur: '-',
      email: request.email,
      phone: request.phone,
      idAddress: '-',
      address: address,
      isSynced: false,
    );

    await LocalHelper.insert<OwnerModel>(OwnerModel.localName, owner);
  }
}
