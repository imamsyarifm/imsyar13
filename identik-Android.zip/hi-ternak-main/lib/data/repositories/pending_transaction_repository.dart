import '../../utils/local_helper.dart';
import '../models/buku_lahir/buku_induk_request.dart';
import '../models/inseminasi/inseminasi_request.dart';
import '../models/kandang/kandang_model.dart';
import '../models/keswan/keswan_bobot_request_model.dart';
import '../models/keswan/keswan_kesehatan_request_model.dart';
import '../models/mutasi/manage_mutasi_request_model.dart';
import '../models/owner/owner_model.dart';
import '../models/pakan/update_pakan_request.dart';
import '../models/susu/produksi_susu_request.dart';
import '../models/ternak/ternak_request.dart';
import '../models/unit_usaha/unit_usaha.dart';

class PendingTransactionRepository {
  Future<List<UnitUsaha>> get allUnitusaha async {
    final table = await LocalHelper.getTable<UnitUsaha>(UnitUsaha.localName);
    return table.values.toList();
  }

  Future<List<OwnerModel>> get allOwner async {
    final table = await LocalHelper.getTable<OwnerModel>(OwnerModel.localName);
    return table.values.toList();
  }

  Future<List<KandangModel>> get allKandang async {
    final table =
        await LocalHelper.getTable<KandangModel>(KandangModel.localName);
    return table.values.toList();
  }

  Future<List<TernakRequest>> get allTernak async {
    final table =
        await LocalHelper.getTable<TernakRequest>(TernakRequest.localName);
    return table.values.toList();
  }

  Future<List<KeswanBobotRequestModel>> get allKeswanGrowth async {
    final table = await LocalHelper.getTable<KeswanBobotRequestModel>(
        KeswanBobotRequestModel.localName);
    return table.values.toList();
  }

  Future<List<KeswanKesehatanRequestModel>> get allKeswanHealth async {
    final table = await LocalHelper.getTable<KeswanKesehatanRequestModel>(
        KeswanKesehatanRequestModel.localName);
    return table.values.toList();
  }

  Future<List<ManageMutasiRequestModel>> get allMutasi async {
    final table = await LocalHelper.getTable<ManageMutasiRequestModel>(
        ManageMutasiRequestModel.localName);
    return table.values.toList();
  }

  Future<List<ProduksiSusuRequest>> get allProduksiSusu async {
    final table = await LocalHelper.getTable<ProduksiSusuRequest>(
        ProduksiSusuRequest.localName);
    return table.values.toList();
  }

  Future<List<InseminasiRequest>> get allInseminasi async {
    final table = await LocalHelper.getTable<InseminasiRequest>(
        InseminasiRequest.localName);
    return table.values.toList();
  }

  Future<List<BukuIndukRequest>> get allBukuLahir async {
    final table = await LocalHelper.getTable<BukuIndukRequest>(
        BukuIndukRequest.localName);
    return table.values.toList();
  }

  Future<List<UpdatePakanRequest>> get allPakan async {
    final table = await LocalHelper.getTable<UpdatePakanRequest>(
        UpdatePakanRequest.localName);
    return table.values.toList();
  }
}
