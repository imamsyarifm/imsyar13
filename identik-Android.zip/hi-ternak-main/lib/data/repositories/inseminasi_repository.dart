import 'dart:async';

import 'package:dio/dio.dart';
import 'package:get/get_connect/http/src/status/http_status.dart';

import '../../utils/local_helper.dart';
import '../../utils/networking_util.dart';
import '../const/endpoints.dart';
import '../models/combo/kode_straw_model.dart';
import '../models/combo/kode_straw_response_model.dart';
import '../models/inseminasi/check_bunting.dart';
import '../models/inseminasi/check_bunting_response.dart';
import '../models/inseminasi/induk_jantan.dart';
import '../models/inseminasi/induk_jantan_response.dart';
import '../models/inseminasi/inseminasi_request.dart';
import '../models/inseminasi/kode_embrio_model.dart';
import '../models/inseminasi/kode_embrio_response_model.dart';
import '../models/inseminasi/pemeriksaan_kebuntingan_request.dart';
import '../models/simple_response_success_model.dart';

class InseminasiRepository {
  final Dio _client;

  InseminasiRepository({required Dio client}) : _client = client;

  Future<List<IndukJantan>> allInduk({
    String? search,
    int offset = 0,
    int limit = 20,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final params = <String, dynamic>{
        'offset': offset,
        'limit': limit,
      };

      if (search != null) {
        params['search'] = search;
      }

      final responseJson = await _client.get(
        Endpoints.indukJantan,
        options: Options(
          headers: headers,
        ),
        queryParameters: params,
      );

      final model = IndukJantanResponse.fromJson(responseJson.data);
      return model.data;
    } else {
      final allIndukJantan =
          await LocalHelper.getTable<IndukJantan>(IndukJantan.localName);
      return allIndukJantan.values.toList();
    }
  }

  Future<void> syncIndukJantan() async {
    final allIndukJantan = await allInduk();
    await LocalHelper.inserts<IndukJantan>(
        IndukJantan.localName, allIndukJantan);
  }

  Future<void> unsyncIndukJantan() async {
    await LocalHelper.deleteAll<IndukJantan>(IndukJantan.localName);
  }

  Future<bool> update({
    required InseminasiRequest request,
    bool localStrategy = true,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.post(
        Endpoints.updateInseminasi,
        options: Options(
          headers: headers,
        ),
        data: request.toJson(),
      );

      final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
      return model.code == HttpStatus.ok;
    } else {
      if (localStrategy) {
        unawaited(syncInseminasiRequest(request));
        return true;
      } else {
        return false;
      }
    }
  }

  Future<List<KodeStrawModel>> strawCodesOnline({
    String? search,
    int offset = 0,
    int limit = 20,
  }) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final params = <String, dynamic>{
      'offset': offset,
      'limit': limit,
    };

    if (search != null) {
      params['search'] = search;
    }

    final responseJson = await _client.get(
      Endpoints.strawCode,
      options: Options(
        headers: headers,
      ),
      queryParameters: params,
    );

    final model = KodeStrawResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<KodeEmbrioModel>> embrioCodesOnline({
    String? search,
    int offset = 0,
    int limit = 20,
  }) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final params = <String, dynamic>{
      'offset': offset,
      'limit': limit,
    };

    if (search != null) {
      params['search'] = search;
    }

    final responseJson = await _client.get(
      Endpoints.embrioCode,
      options: Options(
        headers: headers,
      ),
      queryParameters: params,
    );

    final model = KodeEmbrioResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<bool> updatePemeriksaanKebutingan({
    required PemeriksaanKebuntinganRequest request,
    bool localStrategy = true,
  }) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.post(
      Endpoints.updatePemeriksaanKebutingan,
      options: Options(
        headers: headers,
      ),
      data: request.toJson(),
    );

    final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
    if (model.code == HttpStatus.ok) {
      return model.code == HttpStatus.ok;
    } else {
      return false;
    }
  }

  Future<CheckBuntingModel> checkBunting({String? qrCode}) async {
    final params = {
      'eartag': qrCode,
    };

    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.checkBunting,
      options: Options(
        headers: headers,
      ),
      queryParameters: params,
    );

    final model = CheckBuntingResponse.fromJson(responseJson.data);
    return model.data;
  }

  Future<int> syncInseminasiRequest(InseminasiRequest request) async {
    return await LocalHelper.insert<InseminasiRequest>(
        InseminasiRequest.localName, request);
  }
}
