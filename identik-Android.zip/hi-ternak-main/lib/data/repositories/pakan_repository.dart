import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart';

import '../../utils/local_helper.dart';
import '../../utils/networking_util.dart';
import '../const/endpoints.dart';
import '../models/pakan/pakan.dart';
import '../models/pakan/pakan_response.dart';
import '../models/pakan/update_pakan_request.dart';
import '../models/simple_response_success_model.dart';

class PakanRepository {
  PakanRepository({
    required Dio client,
  }) : _client = client;

  final Dio _client;

  Future<bool> updatePakan({
    required UpdatePakanRequest request,
    bool localStrategy = true,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;

    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final update = await _client.post(
        Endpoints.managePakan,
        options: Options(
          headers: headers,
        ),
        data: request.toJson(),
      );

      final model = SimpleResponseSuccessModel.fromJson(update.data);
      return model.code == HttpStatus.ok;
    } else {
      if (localStrategy) {
        unawaited(syncPakanRequest(request));
        return true;
      } else {
        return false;
      }
    }
  }

  Future<int> syncPakanRequest(UpdatePakanRequest request) async {
    return await LocalHelper.insert<UpdatePakanRequest>(
        UpdatePakanRequest.localName, request);
  }

  Future<List<Pakan>> list({
    String? keyword,
    int offset = 0,
    int limit = 20,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final params = <String, dynamic>{
        'offset': offset,
        'limit': limit,
      };

      if (keyword != null && keyword != '') {
        params['search'] = keyword;
      }

      final allPakan = await _client.get(
        Endpoints.allPakan,
        options: Options(
          headers: headers,
        ),
        queryParameters: params,
      );

      final model = PakanResponse.fromJson(allPakan.data);
      return model.data;
    } else {
      final allPakan = await LocalHelper.getTable<UpdatePakanRequest>(
          UpdatePakanRequest.localName);
      return allPakan.values
          .map((pakan) => Pakan(
                id: pakan.id.toString(),
                namaKandang: pakan.idKandang,
                kapasitas: '-',
                tanggalDibangun: DateTime.parse(pakan.tanggalInput),
                namaPemilikKandang: '-',
                nikPemilikKandang: '-',
                pakan: [],
              ))
          .toList();
    }
  }
}
