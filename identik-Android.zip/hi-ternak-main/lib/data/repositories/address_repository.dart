import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../../app/consts/local_keys.dart';
import '../../utils/local_helper.dart';
import '../../utils/networking_util.dart';
import '../const/endpoints.dart';
import '../models/address/country_model.dart';
import '../models/address/country_response_model.dart';
import '../models/address/district_model.dart';
import '../models/address/district_response_model.dart';
import '../models/address/province_model.dart';
import '../models/address/province_response_model.dart';
import '../models/address/subdistrict_model.dart';
import '../models/address/subdistrict_response_model.dart';
import '../models/address/village_model.dart';
import '../models/address/village_response_model.dart';

class AddressRepository {
  final Dio _client;

  AddressRepository({
    required Dio client,
  }) : _client = client;

  Future<List<CountryModel>> get countries async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.get(
        Endpoints.country,
        options: Options(
          headers: headers,
        ),
      );

      final model = CountryResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      final countryLocal = <CountryModel>[];
      try {
        final data =
            await LocalHelper.getTable<CountryModel>(CountryModel.localName);
        countryLocal.addAll(data.values.toList());
      } catch (error) {
        debugPrint(error.toString());
      }
      return countryLocal;
    }
  }

  Future<List<ProvinceModel>> provinces(int idCountry) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final params = {
        'id_country': idCountry,
      };

      final headers = await NetworkingUtil.setupTokenHeader();

      final responseJson = await _client.get(
        Endpoints.province,
        options: Options(
          headers: headers,
        ),
        queryParameters: params,
      );

      final model = ProvinceResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      final provinceLocal = <ProvinceModel>[];
      try {
        final data =
            await LocalHelper.getTable<ProvinceModel>(ProvinceModel.localName);
        final filteredData = data.values
            .toList()
            .where((element) => int.parse(element.idCountry) == idCountry);
        provinceLocal.addAll(filteredData);
      } catch (error) {
        debugPrint(error.toString());
      }
      return provinceLocal;
    }
  }

  Future<List<DistrictModel>> districts(String idProvince) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final params = {
        'id_province': idProvince,
      };
      final headers = await NetworkingUtil.setupTokenHeader();

      final responseJson = await _client.get(
        Endpoints.district,
        options: Options(
          headers: headers,
        ),
        queryParameters: params,
      );

      final model = DistrictResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      final districtLocal = <DistrictModel>[];
      try {
        final data =
            await LocalHelper.getTable<DistrictModel>(DistrictModel.localName);
        final filteredData = data.values
            .toList()
            .where((element) => element.idProvince == idProvince);
        districtLocal.addAll(filteredData);
      } catch (error) {
        debugPrint(error.toString());
      }
      return districtLocal;
    }
  }

  Future<List<SubdistrictModel>> subDistricts(String idDistrict) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final params = {
        'id_district': idDistrict,
      };
      final headers = await NetworkingUtil.setupTokenHeader();

      final responseJson = await _client.get(
        Endpoints.subdistrict,
        options: Options(
          headers: headers,
        ),
        queryParameters: params,
      );

      final model = SubdistrictResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      final subdistrictLocal = <SubdistrictModel>[];
      try {
        final data = await LocalHelper.getTable<SubdistrictModel>(
            SubdistrictModel.localName);
        final filteredData = data.values
            .toList()
            .where((element) => element.idDisctrict == idDistrict);
        subdistrictLocal.addAll(filteredData);
      } catch (error) {
        debugPrint(error.toString());
      }
      return subdistrictLocal;
    }
  }

  Future<List<VillageModel>> villages(String idSubDistrict) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final params = {
        'id_sub_district': idSubDistrict,
      };
      final headers = await NetworkingUtil.setupTokenHeader();

      final responseJson = await _client.get(
        Endpoints.village,
        options: Options(
          headers: headers,
        ),
        queryParameters: params,
      );

      final model = VillageResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      final villageLocal = <VillageModel>[];
      try {
        final data =
            await LocalHelper.getTable<VillageModel>(VillageModel.localName);
        final filteredData = data.values
            .toList()
            .where((element) => element.idSubDistrict == idSubDistrict);
        villageLocal.addAll(filteredData);
      } catch (error) {
        debugPrint(error.toString());
      }
      villageLocal.sort(
        (a, b) {
          return a.urbanVillage.compareTo(b.urbanVillage);
        },
      );
      return villageLocal;
    }
  }

  Future<List<DistrictModel>> get onlyDistricts async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.get(
        Endpoints.onlyDistrict,
        options: Options(
          headers: headers,
        ),
      );

      final model = DistrictResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      final districtLocal = <DistrictModel>[];
      try {
        final data =
            await LocalHelper.getTable<DistrictModel>(DistrictModel.localName);
        districtLocal.addAll(data.values.toList());
      } catch (error) {
        debugPrint(error.toString());
      }
      return districtLocal;
    }
  }

  Future<void> syncAddress() async {
    final provinceUser =
        await LocalHelper.getKey(LocalKeys.idProvince, defaultValue: '');
    final districtUser =
        await LocalHelper.getKey(LocalKeys.idDistrict, defaultValue: '');

    if (provinceUser.isNotEmpty && districtUser.isNotEmpty) {
      final allCountry = await countries;
      await LocalHelper.inserts<CountryModel>(
          CountryModel.localName, allCountry);

      /// Indonesian have id value 1
      /**
       * {
            "id": 1,
            "code": "ID",
            "phone_code": "+62",
            "country": "INDONESIA",
            "created_at": "2021-07-08T12:00:00.000000Z",
            "updated_at": "2021-07-08T12:00:00.000000Z"
          }
       * 
       */
      final allProvince = await provinces(1);

      await LocalHelper.inserts<ProvinceModel>(
          ProvinceModel.localName, allProvince);

      final allDistrict = await districts(provinceUser);
      await LocalHelper.inserts<DistrictModel>(
          DistrictModel.localName, allDistrict);

      final allSubdistrict = await subDistricts(districtUser);
      await LocalHelper.inserts<SubdistrictModel>(
          SubdistrictModel.localName, allSubdistrict);

      for (SubdistrictModel subDistrict in allSubdistrict) {
        final allVilage = await villages(subDistrict.id);
        await LocalHelper.inserts<VillageModel>(
            VillageModel.localName, allVilage);
      }
      return;
    }
  }

  Future<void> unsyncAddress() async {
    await LocalHelper.deleteAll<CountryModel>(CountryModel.localName);
    await LocalHelper.deleteAll<ProvinceModel>(ProvinceModel.localName);
    await LocalHelper.deleteAll<DistrictModel>(DistrictModel.localName);
    await LocalHelper.deleteAll<SubdistrictModel>(SubdistrictModel.localName);
    await LocalHelper.deleteAll<VillageModel>(VillageModel.localName);
  }
}
