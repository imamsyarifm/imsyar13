import 'package:dio/dio.dart';
import 'package:get/get_connect/http/src/status/http_status.dart';

import '../../app/consts/local_keys.dart';
import '../../utils/local_helper.dart';
import '../../utils/networking_util.dart';
import '../const/endpoints.dart';
import '../models/account/account_model.dart';
import '../models/account/account_response_model.dart';
import '../models/account/check_update_model.dart';
import '../models/account/check_update_response_model.dart';
import '../models/change_password/change_password_request.dart';
import '../models/login/login_request_model.dart';
import '../models/login/login_response_model.dart';
import '../models/register/register_request_model.dart';
import '../models/simple_response_success_model.dart';

class AuthenticationRepository {
  final Dio _client;

  AuthenticationRepository({
    required Dio dio,
  }) : _client = dio;

  Future<bool> login(LoginRequestModel request) async {
    final responseJson = await _client.post(
      Endpoints.login,
      data: request.toJson(),
    );
    final model = LoginResponseModel.fromJson(responseJson.data);
    if (responseJson.statusCode == HttpStatus.ok) {
      final type = model.tokenType;
      final access = model.accessToken;
      await LocalHelper.addKey(LocalKeys.token, '$type $access');
      await LocalHelper.addKey(LocalKeys.isIndividu, true);
      await LocalHelper.addKey(LocalKeys.nik, model.nik);
      await LocalHelper.addKey(
          LocalKeys.idProvince, model.areaKerja.idProvince);
      await LocalHelper.addKey(
          LocalKeys.idDistrict, model.areaKerja.idDistrict);
      return true;
    } else {
      return false;
    }
  }

  Future<bool> logout() async {
    LocalHelper.deleteKey(LocalKeys.token);
    LocalHelper.deleteKey(LocalKeys.isIndividu);
    return true;
  }

  Future<AccountModel> account() async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.post(
      Endpoints.profile,
      options: Options(
        headers: headers,
      ),
    );
    final model = AccountResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<bool> register(RegisterRequestModel request) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.post(
      Endpoints.register,
      options: Options(
        headers: headers,
      ),
      data: request.toJson(),
    );
    final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
    return model.code == HttpStatus.created;
  }

  Future<bool> changePassword(ChangePasswordRequest request) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.post(
      Endpoints.changePassword,
      options: Options(
        headers: headers,
      ),
      data: request.toJson(),
    );

    final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
    return model.code == HttpStatus.created;
  }

  Future<bool> changePasscode(ChangePasscodeRequest request) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.post(
      Endpoints.changePasscode,
      options: Options(
        headers: headers,
      ),
      data: request.toJson(),
    );

    final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
    return model.code == HttpStatus.created;
  }

  Future<bool> checkPasscode() async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.checkPasscode,
      options: Options(
        headers: headers,
      ),
    );

    final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
    return model.code == HttpStatus.ok;
  }

   Future<CheckUpdateModel> checkUpdate() async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.checkUpdate,
      options: Options(
        headers: headers,
      ),
    );

    final model = CheckUpdateResponse.fromJson(responseJson.data);
    return model.data;
  }
}
