import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get_connect/http/src/status/http_status.dart';

import '../../utils/local_helper.dart';
import '../../utils/networking_util.dart';
import '../const/endpoints.dart';
import '../models/simple_response_success_model.dart';
import '../models/susu/produksi_susu_request.dart';
import '../models/susu/susu_model.dart';
import '../models/susu/susu_request_model.dart';
import '../models/susu/susu_response_model.dart';

class SusuRepository {
  final Dio _client;

  SusuRepository({
    required Dio client,
  }) : _client = client;

  Future<SusuModel?> susu(String productCode) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final request = SusuRequestModel(codeProduct: productCode);
    final responseJson = await _client.post(
      Endpoints.susu,
      options: Options(
        headers: headers,
      ),
      data: request.toJson(),
    );
    final model = SusuResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<bool> manageSusu({
    required ProduksiSusuRequest request,
    bool localStrategy = true,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.post(
        Endpoints.manageSusu,
        options: Options(
          headers: headers,
        ),
        data: request.toJson(),
      );
      debugPrint(request.toJson().toString());
      final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
      return model.code == HttpStatus.ok;
    } else {
      if (localStrategy) {
        unawaited(syncProduksiSusuRequest(request));
        return true;
      } else {
        return false;
      }
    }
  }

  Future<int> syncProduksiSusuRequest(ProduksiSusuRequest request) async {
    return await LocalHelper.insert<ProduksiSusuRequest>(
        ProduksiSusuRequest.localName, request);
  }
}
