import 'dart:async';

import 'package:dio/dio.dart';

import '../../utils/local_helper.dart';
import '../../utils/networking_util.dart';
import '../const/endpoints.dart';
import '../models/kandang/add_kandang_address_request_model.dart';
import '../models/kandang/add_kandang_request_model.dart';
import '../models/kandang/kandang_address_model.dart';
import '../models/kandang/kandang_model.dart';
import '../models/kandang/kandang_response_model.dart';
import '../models/simple_response_success_model.dart';

class KandangUnggasRepository {
  final Dio _client;

  KandangUnggasRepository({
    required Dio client,
  }) : _client = client;

  Future<List<KandangModel>> all({
    String? query,
    int offset = 0,
    int limit = 20,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final params = <String, dynamic>{
        'offset': offset,
        'limit': limit,
      };

      if (query != null && query != '') {
        params['search'] = query;
      }

      final responseJson = await _client.get(
        Endpoints.kandang,
        options: Options(
          headers: headers,
        ),
        queryParameters: params,
      );
      final model = KandangResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      final localAllKandang =
          await LocalHelper.getTable<AddKandangRequestModel>(
              AddKandangRequestModel.localName);
      final allKandang = localAllKandang.values
          .map(
            (kandang) => KandangModel(
              id: kandang.id ?? '-',
              idAddress: '-',
              idUser: kandang.idPemilik,
              namaKandang: kandang.namaKandang,
              kapasitas: kandang.kapasitas,
              tanggalDibangun: kandang.tanggalDibangun,
              statusKandang: kandang.statusKandang,
              createdAt: DateTime.now(),
              komoditas: kandang.komoditasId,
              kodeFarm: '',
              address: KandangAddressModel(
                id: '-',
                idProvince: kandang.address.idProvince ?? '-',
                province: '-',
                idDistrict: kandang.address.idDistrict ?? '-',
                district: '-',
                idSubDistrict: kandang.address.idSubDistrict ?? '-',
                subDistrict: '-',
                idVillage: kandang.address.idVillage ?? '-',
                urbanVillage: '-',
                zipCode: '-',
                address: kandang.address.address,
                rt: '-',
                rw: '-',
                latitude: kandang.address.latitude,
                longitude: kandang.address.longitude,
              ),
            ),
          )
          .toList();
      if (query != null) {
        final filteredAllKandang = allKandang.where((element) =>
            element.namaKandang.toLowerCase().contains(query.toLowerCase()));
        return filteredAllKandang.toList();
      } else {
        return allKandang;
      }
    }
  }

  Future<bool> insert(AddKandangRequestModel request) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.post(
        Endpoints.kandang,
        data: request.toJson(),
        options: Options(
          headers: headers,
        ),
      );

      final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
      return model.code == 200;
    } else {
      unawaited(syncKandangRequest(request));
      unawaited(syncKandang(request));
      return true;
    }
  }

  Future<bool> syncUpload(KandangModel data) async {
    final dataAddress = data.address;
    final addressRequest = AddKandangAddressRequestModel(
      address: dataAddress.address,
      latitude: dataAddress.latitude,
      longitude: dataAddress.longitude,
    );

    final request = AddKandangRequestModel(
      id: data.id,
      namaKandang: data.namaKandang,
      idPemilik: data.idUser ?? '',
      tanggalDibangun: data.tanggalDibangun,
      kapasitas: data.kapasitas,
      statusKandang: data.statusKandang,
      isEqual: data.isEqual ?? '0',
      address: addressRequest,
      komoditasId: data.komoditas,
    );

    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.post(
      Endpoints.kandang,
      data: request.toJson(),
      options: Options(
        headers: headers,
      ),
    );

    final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
    return model.code == 200;
  }

  Future<void> get unsyncAllKandang async {
    await LocalHelper.deleteAll<AddKandangRequestModel>(
        AddKandangRequestModel.localName);
  }

  Future<void> get syncAllKandang async {
    final headers = await NetworkingUtil.setupTokenHeader();

    final responseJson = await _client.get(
      Endpoints.kandang,
      options: Options(
        headers: headers,
      ),
    );
    final model = KandangResponseModel.fromJson(responseJson.data);
    final mappedModel = model.data
        .map(
          (data) => AddKandangRequestModel(
            id: data.id,
            namaKandang: data.namaKandang,
            idPemilik: data.pemilikKandang?.id ??
                data.pemilikKandang?.nik ??
                data.idUser ??
                '-',
            tanggalDibangun: data.tanggalDibangun,
            kapasitas: data.kapasitas,
            statusKandang: data.statusKandang,
            isEqual: data.isEqual ?? '0',
            komoditasId: data.komoditas,
            address: AddKandangAddressRequestModel(
              address: data.address.address,
              latitude: data.address.latitude,
              longitude: data.address.longitude,
            ),
          ),
        )
        .toList();
    await LocalHelper.inserts<AddKandangRequestModel>(
        AddKandangRequestModel.localName, mappedModel);
  }

  Future<void> syncKandang(AddKandangRequestModel request) async {
    final kandangAddress = KandangAddressModel(
      address: request.address.address,
      latitude: request.address.latitude,
      longitude: request.address.longitude,
      district: '-',
      id: '-',
      idDistrict: request.address.idDistrict ?? '-',
      idProvince: request.address.idProvince ?? '-',
      idSubDistrict: request.address.idSubDistrict ?? '-',
      idVillage: request.address.idVillage ?? '-',
      province: '-',
      rt: '-',
      rw: '-',
      subDistrict: '-',
      urbanVillage: '-',
      zipCode: '-',
    );

    final kandang = KandangModel(
      id: request.id ?? '-',
      idAddress: '-',
      idUser: request.idPemilik,
      namaKandang: request.namaKandang,
      kapasitas: request.kapasitas,
      tanggalDibangun: request.tanggalDibangun,
      statusKandang: request.statusKandang,
      createdAt: DateTime.now(),
      address: kandangAddress,
      pemilikKandang: null,
      isSynced: false,
      komoditas: request.komoditasId,
      kodeFarm: ''
    );

    await LocalHelper.insert<KandangModel>(KandangModel.localName, kandang);
  }

  Future<void> syncKandangRequest(AddKandangRequestModel request) async {
    await LocalHelper.insert<AddKandangRequestModel>(
        AddKandangRequestModel.localName, request);
  }
}
