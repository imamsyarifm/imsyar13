import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get_connect/http/src/status/http_status.dart';

import '../../utils/local_helper.dart';
import '../../utils/networking_util.dart';
import '../const/endpoints.dart';
import '../models/simple_response_success_model.dart';
import '../models/unit_usaha/unit_usaha.dart';
import '../models/unit_usaha/unit_usaha_addres.dart';
import '../models/unit_usaha/unit_usaha_address_request.dart';
import '../models/unit_usaha/unit_usaha_request.dart';
import '../models/unit_usaha/unit_usaha_response.dart';

class UnitUsahaRepository {
  final Dio _client;

  UnitUsahaRepository({
    required Dio client,
  }) : _client = client;

  Future<List<UnitUsaha>> all({
    String? query,
    int offset = 0,
    int limit = 20,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final params = <String, dynamic>{
        'offset': offset,
        'limit': limit,
      };

      if (query != null && query != '') {
        params['search'] = query;
      }

      final responseJson = await _client.get(
        Endpoints.unitUsaha,
        options: Options(
          headers: headers,
        ),
        queryParameters: params,
      );

      final model = UnitUsahaResponse.fromJson(responseJson.data);
      return model.data;
    } else {
      final unitUsahaLocal = <UnitUsaha>[];
      try {
        final data = await LocalHelper.getTable<UnitUsaha>(UnitUsaha.localName);
        final filteredData = data.values
            .where((element) => element.companyName.contains(query ?? ''));
        unitUsahaLocal.addAll(filteredData.toList());
      } catch (error) {
        debugPrint(error.toString());
      }
      return unitUsahaLocal;
    }
  }

  Future<void> get syncAllUnitUsaha async {
    final headers = await NetworkingUtil.setupTokenHeader();

    final responseJson = await _client.get(
      Endpoints.unitUsaha,
      options: Options(
        headers: headers,
      ),
    );

    final model = UnitUsahaResponse.fromJson(responseJson.data);
    await LocalHelper.inserts<UnitUsaha>(UnitUsaha.localName, model.data);
  }

  Future<void> get unsyncAllUnitUsaha async {
    await LocalHelper.deleteAll<UnitUsaha>(UnitUsaha.localName);
  }

  Future<bool> update(UnitUsahaRequest request) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.post(
        Endpoints.addUnitUsaha,
        options: Options(
          headers: headers,
        ),
        data: request.toJson(),
      );

      final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
      return model.code == HttpStatus.ok;
    } else {
      unawaited(syncRequest(request));
      unawaited(syncUnitUsaha(request));
      return true;
    }
  }

  Future<void> syncRequest(UnitUsahaRequest request) async {
    await LocalHelper.insert<UnitUsahaRequest>(
        UnitUsahaRequest.localName, request);
  }

  Future<bool> syncUpload(UnitUsaha data) async {
    final headers = await NetworkingUtil.setupTokenHeader();

    final dataAddress = data.address;

    final addressRequest = UnitUsahaAddressRequest(
      idProvince: dataAddress.idProvince,
      idDistrict: dataAddress.idDistrict,
      idSubDistrict: dataAddress.idSubDistrict,
      idVillage: dataAddress.idVillage,
      address: dataAddress.address ?? '',
      rt: dataAddress.rt ?? '',
      rw: dataAddress.rw ?? '',
      latitude: dataAddress.latitude ?? '',
      longitude: dataAddress.longitude ?? '',
    );

    final request = UnitUsahaRequest(
      address: addressRequest,
      companyName: data.companyName,
      email: data.email,
      id: data.id,
      idIsikhnas: data.idIsikhnas,
      isGovermentOwned: data.isGovermentOwned.toString(),
      phone: data.phone,
      picAlamat: data.picAlamat,
      picBirthdate: data.picBirthdate,
      picEmail: data.picEmail,
      picGender: data.picGender,
      picName: data.picName,
      picNik: data.picNik,
      picPhone: data.picPhone,
      registrationNumber: data.registrationNumber.toString(),
    );

    final responseJson = await _client.post(
      Endpoints.addUnitUsaha,
      options: Options(
        headers: headers,
      ),
      data: request.toJson(),
    );

    final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
    return model.code == HttpStatus.ok;
  }

  Future<void> syncUnitUsaha(UnitUsahaRequest request) async {
    final address = UnitUsahaAddress(
      address: request.address.address,
      district: '-',
      id: DateTime.now().microsecond.toString(),
      idDistrict: request.address.idDistrict,
      idProvince: request.address.idProvince,
      idSubDistrict: request.address.idSubDistrict,
      idVillage: request.address.idVillage,
      latitude: request.address.latitude,
      longitude: request.address.longitude,
      province: '-',
      rt: request.address.rt,
      rw: request.address.rw,
      subDistrict: '-',
      urbanVillage: '-',
    );

    final unitUsaha = UnitUsaha(
      id: request.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
      idUser: '-',
      idAddress: '-',
      companyName: request.companyName,
      phone: request.phone,
      email: request.email,
      picName: request.picName,
      picNik: request.picNik,
      picGender: request.picGender,
      picBirthdate: request.picBirthdate ?? DateTime.now(),
      picPhone: request.picPhone,
      picEmail: request.picEmail,
      picAlamat: request.picAlamat,
      isGovermentOwned: (request.isGovermentOwned == '1') ? 1 : 0,
      address: address,
      registrationNumber: request.registrationNumber,
      isSynced: false,
    );

    await LocalHelper.insert<UnitUsaha>(UnitUsaha.localName, unitUsaha);
  }
}
