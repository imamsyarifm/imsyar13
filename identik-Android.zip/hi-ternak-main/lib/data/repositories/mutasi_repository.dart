import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart';

import '../../utils/local_helper.dart';
import '../../utils/networking_util.dart';
import '../const/endpoints.dart';
import '../models/combo/combo_model.dart';
import '../models/combo/combo_response_model.dart';
import '../models/mutasi/manage_mutasi_request_model.dart';
import '../models/mutasi/mutasi_model.dart';
import '../models/mutasi/mutasi_request_model.dart';
import '../models/mutasi/mutasi_response_model.dart';
import '../models/simple_response_success_model.dart';

class MutasiRepository {
  final Dio _client;

  MutasiRepository({
    required Dio client,
  }) : _client = client;

  Future<List<ComboModel>> allRph({
    String? keyword,
    int offset = 0,
    int limit = 20,
  }) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final params = <String, dynamic>{
      'offset': offset,
      'limit': limit,
    };

    if (keyword != null && keyword != '') {
      params['search'] = keyword;
    }
    final responseJson = await _client.get(
      Endpoints.rph,
      queryParameters: params,
      options: Options(
        headers: headers,
      ),
    );
    final model = ComboResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<MutasiModel> mutasi(String productCode) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final request = MutasiRequestModel(codeProduct: productCode);
    final responseJson = await _client.post(
      Endpoints.mutasi,
      options: Options(
        headers: headers,
      ),
      data: request.toJson(),
    );
    final model = MutasiResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<bool> manageMutasi({
    required ManageMutasiRequestModel request,
    bool localStrategy = true,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final body = await request.toFormData();
      final responseJson = await _client.post(
        Endpoints.manageMutasi,
        options: Options(
          headers: headers,
        ),
        data: body,
      );
      final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
      return model.code == HttpStatus.ok;
    } else {
      if (localStrategy) {
        unawaited(syncMutasiRequest(request));
        return true;
      } else {
        return false;
      }
    }
  }

  Future<int> syncMutasiRequest(ManageMutasiRequestModel request) async {
    return await LocalHelper.insert<ManageMutasiRequestModel>(
        ManageMutasiRequestModel.localName, request);
  }

  Future<bool> updateMutasiAktif(FormData payload) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.post(
      Endpoints.mutasiAktivasi,
      options: Options(
        headers: headers,
      ),
      data: payload,
    );

    final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
    return model.code == HttpStatus.ok;
  }

  Future<bool> updateMutasiSubtitusi(FormData payload) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.post(
      Endpoints.mutasiSubtitusi,
      options: Options(
        headers: headers,
      ),
      data: payload,
    );

    final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
    return model.code == HttpStatus.ok;
  }
}
