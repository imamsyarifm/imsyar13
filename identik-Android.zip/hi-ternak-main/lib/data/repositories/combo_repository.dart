import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../../app/consts/local_keys.dart';
import '../../utils/local_helper.dart';
import '../../utils/networking_util.dart';
import '../const/endpoints.dart';
import '../models/combo/combo_model.dart';
import '../models/combo/combo_response_model.dart';
import '../models/combo/rumpun_model.dart';
import '../models/combo/rumpun_response_model.dart';
import '../models/distribution_area/distribution_area_model.dart';
import '../models/distribution_area/distribution_area_response_model.dart';

class ComboRepository {
  final Dio _client;

  ComboRepository({required Dio client}) : _client = client;

  Future<List<ComboModel>> getComboLocal({
    required String name,
    bool Function(ComboModel)? condition,
  }) async {
    final listLocal = <ComboModel>[];
    try {
      final data = await LocalHelper.getTable<ComboModel>(name);

      if (condition != null) {
        final searchResult = data.values.where(condition);
        listLocal.addAll(searchResult.toList());
      } else {
        listLocal.addAll(data.values.toList());
      }
    } catch (error) {
      debugPrint(error.toString());
    }
    return listLocal;
  }

  Future<List<ComboModel>> gender() async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.get(
        Endpoints.gender,
        options: Options(
          headers: headers,
        ),
      );
      final model = ComboResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      return await getComboLocal(name: ComboModel.gender);
    }
  }

  Future<List<ComboModel>> comodity() async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.comodity,
      options: Options(
        headers: headers,
      ),
    );
    final model = ComboResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<ComboModel>> businessType() async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.businessType,
      options: Options(
        headers: headers,
      ),
    );
    final model = ComboResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<ComboModel>> salesProduct() async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.salesProduct,
      options: Options(
        headers: headers,
      ),
    );
    final model = ComboResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<ComboModel>> religion() async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.religion,
      options: Options(
        headers: headers,
      ),
    );
    final model = ComboResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<ComboModel>> genderTernak() async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.get(
        Endpoints.genderTernak,
        options: Options(
          headers: headers,
        ),
      );
      final model = ComboResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      return await getComboLocal(name: ComboModel.genderTernak);
    }
  }

  Future<List<ComboModel>> ternakType() async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.ternakType,
      options: Options(
        headers: headers,
      ),
    );
    final model = ComboResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<ComboModel>> programTernak() async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.get(
        Endpoints.program,
        options: Options(
          headers: headers,
        ),
      );
      final model = ComboResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      return await getComboLocal(name: ComboModel.program);
    }
  }

  Future<List<DistributionAreaModel>> distributionAreas() async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.distributionArea,
      options: Options(
        headers: headers,
      ),
    );
    final model = DistributionAreaResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<ComboModel>> taniGroup() async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.taniGroup,
      options: Options(
        headers: headers,
      ),
    );
    final model = ComboResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<ComboModel>> get ternakCategories async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.get(
        Endpoints.kategoriTernak,
        options: Options(
          headers: headers,
        ),
      );
      final model = ComboResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      return await getComboLocal(name: ComboModel.categoryTernak);
    }
  }

  Future<List<ComboModel>> get ternakOrigins async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.get(
        Endpoints.asalTernak,
        options: Options(
          headers: headers,
        ),
      );
      final model = ComboResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      return getComboLocal(name: ComboModel.asalTernak);
    }
  }

  Future<List<ComboModel>> get birthdayConfigurations async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.setBirthday,
      options: Options(
        headers: headers,
      ),
    );
    final model = ComboResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<ComboModel>> get perkawinanMethods async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.perkawinanMethods,
      options: Options(
        headers: headers,
      ),
    );
    final model = ComboResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<ComboModel>> get bornTypes async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.bornTypes,
      options: Options(
        headers: headers,
      ),
    );
    final model = ComboResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<ComboModel>> get keswanCategories async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.get(
        Endpoints.keswanCategories,
        options: Options(
          headers: headers,
        ),
      );
      final model = ComboResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      return getComboLocal(name: ComboModel.categoryKeswan);
    }
  }

  Future<List<ComboModel>> get options async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.option,
      options: Options(
        headers: headers,
      ),
    );
    final model = ComboResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<ComboModel>> get daftarPemilik async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.daftarPemilik,
      options: Options(
        headers: headers,
      ),
    );
    final model = ComboResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<ComboModel>> get statusMutasi async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.statusMutasi,
      options: Options(
        headers: headers,
      ),
    );
    final model = ComboResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<ComboModel>> kandang({
    required String statusKandang,
    required String nik,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.get(
        Endpoints.productKandang,
        queryParameters: {
          'status_kandang': statusKandang,
          'nik': nik,
        },
        options: Options(
          headers: headers,
        ),
      );
      final model = ComboResponseModel.fromJson(responseJson.data);
      final data = model.data;
      return data;
    } else {
      return await getComboLocal(name: ComboModel.kandang);
    }
  }

  Future<List<ComboModel>> get statusKandang async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.get(
        Endpoints.statusKandang,
        options: Options(
          headers: headers,
        ),
      );
      final model = ComboResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      return await getComboLocal(name: ComboModel.statusKandang);
    }
  }

  Future<List<ComboModel>> get allKelompok async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.kelompok,
      options: Options(
        headers: headers,
      ),
    );
    final model = ComboResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<ComboModel>> get kandangOwners async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.kandangOwners,
      options: Options(
        headers: headers,
      ),
    );
    final model = ComboResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<ComboModel>> get kandangStatus async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.get(
        Endpoints.kandangStatus,
        options: Options(
          headers: headers,
        ),
      );
      final model = ComboResponseModel.fromJson(responseJson.data);

      return model.data;
    } else {
      return await getComboLocal(name: ComboModel.kandangStatus);
    }
  }

  Future<List<ComboModel>> allPetugasVaksinasi({
    required String query,
  }) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(Endpoints.petugasVaksinasi,
        options: Options(
          headers: headers,
        ),
        queryParameters: {
          'search': query,
        });
    final model = ComboResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<ComboModel>> get genders async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.get(
        Endpoints.genderTernak,
        options: Options(
          headers: headers,
        ),
      );
      final model = ComboResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      return await getComboLocal(name: ComboModel.gender);
    }
  }

  Future<List<ComboModel>> get types async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.get(
      Endpoints.ternakType,
      options: Options(
        headers: headers,
      ),
    );
    final model = ComboResponseModel.fromJson(responseJson.data);
    return model.data;
  }

  Future<List<ComboModel>> get programs async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.get(
        Endpoints.program,
        options: Options(
          headers: headers,
        ),
      );
      final model = ComboResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      return await getComboLocal(name: ComboModel.program);
    }
  }

  Future<List<RumpunModel>> rumpun({String? category}) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final params = <String, dynamic>{};
      params['id_jenis_ternak'] = category;

      final responseJson = await _client.get(
        Endpoints.rumpun,
        options: Options(
          headers: headers,
        ),
        queryParameters: params,
      );
      final model = RumpunResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      final listLocal = <RumpunModel>[];
      try {
        final data =
            await LocalHelper.getTable<RumpunModel>(RumpunModel.rumpun);

        final filteredData =
            data.values.where((element) => element.idJenisTernak == category);
        listLocal.addAll(filteredData);
      } catch (error) {
        debugPrint(error.toString());
      }
      return listLocal;
    }
  }

  Future<List<ComboModel>> get catVaksins async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();

      final responseJson = await _client.get(
        Endpoints.jenisVaksin,
        options: Options(
          headers: headers,
        ),
      );
      final model = ComboResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      return await getComboLocal(name: ComboModel.jenisVaksin);
    }
  }

  Future<List<ComboModel>> obat(String category, String jenis) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final params = <String, dynamic>{
        'kategori': category,
        'jenis_vaksin': jenis,
      };

      final responseJson = await _client.get(
        Endpoints.obat,
        options: Options(
          headers: headers,
        ),
        queryParameters: params,
      );
      final model = ComboResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      return await getComboLocal(name: ComboModel.merkVaksin);
    }
  }

  Future<List<ComboModel>> allMutasiOwner({
    String? keyword,
    int offset = 0,
    int limit = 20,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final params = <String, dynamic>{
        'offset': offset,
        'limit': limit,
      };

      if (keyword != null && keyword != '') {
        params['search'] = keyword;
      }

      final responseJson = await _client.get(
        Endpoints.mutasiOwner,
        queryParameters: params,
        options: Options(
          headers: headers,
        ),
      );
      final model = ComboResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      return await getComboLocal(name: ComboModel.mutasiOwner);
    }
  }

  Future<List<ComboModel>> allMutasiKandang({
    required String idOwner,
    String? keyword,
    int offset = 0,
    int limit = 20,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final params = <String, dynamic>{
        'offset': offset,
        'limit': limit,
        'id_pemilik': idOwner,
      };

      if (keyword != null && keyword != '') {
        params['search'] = keyword;
      }

      final responseJson = await _client.get(
        Endpoints.mutasiKandang,
        queryParameters: params,
        options: Options(
          headers: headers,
        ),
      );
      final model = ComboResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      return await getComboLocal(name: ComboModel.mutasiKandang);
    }
  }

  Future<List<ComboModel>> strawCodes({
    String? search,
    int offset = 0,
    int limit = 20,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final params = <String, dynamic>{
        'offset': offset,
        'limit': limit,
      };

      if (search != null) {
        params['search'] = search;
      }

      final responseJson = await _client.get(
        Endpoints.strawCode,
        options: Options(
          headers: headers,
        ),
        queryParameters: params,
      );

      final model = ComboResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      return await getComboLocal(name: ComboModel.strawCode);
    }
  }

  Future<List<ComboModel>> employees({
    String? search,
    int offset = 0,
    int limit = 20,
  }) async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final params = <String, dynamic>{
        'offset': offset,
        'limit': limit,
      };

      if (search != null) {
        params['search'] = search;
      }

      final responseJson = await _client.get(
        Endpoints.inseminasiEmployee,
        options: Options(
          headers: headers,
        ),
        queryParameters: params,
      );

      final model = ComboResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      return await getComboLocal(name: ComboModel.inseminasiEmployee);
    }
  }

  Future<List<ComboModel>> get allKondisiTernak async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.get(
        Endpoints.kondisiTernak,
        options: Options(
          headers: headers,
        ),
      );

      final model = ComboResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      return await getComboLocal(name: ComboModel.kondisiTernak);
    }
  }

  Future<List<ComboModel>> get allJenisKelahiran async {
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      final headers = await NetworkingUtil.setupTokenHeader();
      final responseJson = await _client.get(
        Endpoints.jenisKelahiran,
        options: Options(
          headers: headers,
        ),
      );

      final model = ComboResponseModel.fromJson(responseJson.data);
      return model.data;
    } else {
      return await getComboLocal(name: ComboModel.jenisKelahiran);
    }
  }

  Future<void> syncCombo() async {
    final allCategories = await ternakCategories;
    await LocalHelper.inserts<ComboModel>(
        ComboModel.categoryTernak, allCategories);

    final allCategoryKeswan = await keswanCategories;
    await LocalHelper.inserts<ComboModel>(
        ComboModel.categoryKeswan, allCategoryKeswan);

    final allRumpun = await rumpun();
    await LocalHelper.inserts<RumpunModel>(RumpunModel.rumpun, allRumpun);

    final gender = await genders;
    await LocalHelper.inserts<ComboModel>(ComboModel.gender, gender);

    final program = await programs;
    await LocalHelper.inserts<ComboModel>(ComboModel.program, program);

    final allStatusKandang = await statusKandang;
    await LocalHelper.inserts<ComboModel>(
        ComboModel.statusKandang, allStatusKandang);

    final allKandangStatus = await kandangStatus;
    await LocalHelper.inserts<ComboModel>(
        ComboModel.kandangStatus, allKandangStatus);

    final asalTernak = await ternakOrigins;
    await LocalHelper.inserts<ComboModel>(ComboModel.asalTernak, asalTernak);

    final jenisVaksin = await catVaksins;
    await LocalHelper.inserts<ComboModel>(ComboModel.jenisVaksin, jenisVaksin);

    final merkVaksin = await obat('vaksin', '1');
    await LocalHelper.inserts<ComboModel>(ComboModel.merkVaksin, merkVaksin);

    final mutasiOwners = await allMutasiOwner();
    await LocalHelper.inserts<ComboModel>(ComboModel.mutasiOwner, mutasiOwners);

    /// For mutasi jual/pindah
    // final mutasiKandangs = await allMutasiKandang();
    // await LocalHelper.inserts<ComboModel>(ComboModel.mutasiOwner,
    //  mutasiOwners);

    final allStrawCode = await strawCodes();
    await LocalHelper.inserts<ComboModel>(ComboModel.strawCode, allStrawCode);

    final allInseminasiEmployee = await employees();
    await LocalHelper.inserts<ComboModel>(
        ComboModel.inseminasiEmployee, allInseminasiEmployee);

    final allGenderTernak = await genderTernak();
    await LocalHelper.inserts<ComboModel>(
        ComboModel.genderTernak, allGenderTernak);

    final kondisiTernak = await allKondisiTernak;
    await LocalHelper.inserts<ComboModel>(
        ComboModel.kondisiTernak, kondisiTernak);

    final jenisKelahiran = await allJenisKelahiran;
    await LocalHelper.inserts<ComboModel>(
        ComboModel.jenisKelahiran, jenisKelahiran);

    /// NIK Petugas Login
    final nik = await LocalHelper.getKey<String>(LocalKeys.nik);
    for (ComboModel statusKandang in allStatusKandang) {
      final allKandang =
          await kandang(nik: nik, statusKandang: statusKandang.value);
      await LocalHelper.inserts<ComboModel>(ComboModel.kandang, allKandang);
    }
  }

  Future<void> unsyncCombo() async {
    await LocalHelper.deleteAll<ComboModel>(ComboModel.categoryTernak);
    await LocalHelper.deleteAll<ComboModel>(ComboModel.categoryKeswan);
    await LocalHelper.deleteAll<RumpunModel>(RumpunModel.rumpun);
    await LocalHelper.deleteAll<ComboModel>(ComboModel.gender);
    await LocalHelper.deleteAll<ComboModel>(ComboModel.program);
    await LocalHelper.deleteAll<ComboModel>(ComboModel.statusKandang);
    await LocalHelper.deleteAll<ComboModel>(ComboModel.kandangStatus);
    await LocalHelper.deleteAll<ComboModel>(ComboModel.kandang);
    await LocalHelper.deleteAll<ComboModel>(ComboModel.asalTernak);
    await LocalHelper.deleteAll<ComboModel>(ComboModel.jenisVaksin);
    await LocalHelper.deleteAll<ComboModel>(ComboModel.merkVaksin);
    await LocalHelper.deleteAll<ComboModel>(ComboModel.mutasiOwner);
    await LocalHelper.deleteAll<ComboModel>(ComboModel.mutasiKandang);
    await LocalHelper.deleteAll<ComboModel>(ComboModel.strawCode);
    await LocalHelper.deleteAll<ComboModel>(ComboModel.inseminasiEmployee);
    await LocalHelper.deleteAll<ComboModel>(ComboModel.genderTernak);
    await LocalHelper.deleteAll<ComboModel>(ComboModel.kondisiTernak);
    await LocalHelper.deleteAll<ComboModel>(ComboModel.jenisKelahiran);
  }
}
