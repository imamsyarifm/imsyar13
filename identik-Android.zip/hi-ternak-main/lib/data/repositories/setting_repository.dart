import 'package:dio/dio.dart';
import 'package:get/get_connect/http/src/status/http_status.dart';

import '../../app/consts/local_keys.dart';
import '../../utils/local_helper.dart';
import '../../utils/networking_util.dart';
import '../const/endpoints.dart';
import '../models/simple_response_success_model.dart';

class SettingRepository {
  SettingRepository({
    required Dio client,
  }) : _client = client;

  final Dio _client;

  Future<String> get defaultProvince async {
    final provinceId = await LocalHelper.getKey(LocalKeys.idProvince);
    return provinceId;
  }

  Future<String> get defaultDistrict async {
    final districtId = await LocalHelper.getKey(LocalKeys.idDistrict);
    return districtId;
  }

  Future<bool> updateProfile(FormData payload) async {
    final headers = await NetworkingUtil.setupTokenHeader();
    final responseJson = await _client.post(
      Endpoints.editProfile,
      options: Options(
        headers: headers,
      ),
      data: payload,
    );

    final model = SimpleResponseSuccessModel.fromJson(responseJson.data);
    return model.code == HttpStatus.ok;
  }
}
