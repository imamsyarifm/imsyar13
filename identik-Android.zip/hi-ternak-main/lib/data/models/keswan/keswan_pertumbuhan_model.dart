class KeswanPertumbuhanModel {
    KeswanPertumbuhanModel({
        required this.idProduct,
        required this.beratBadan,
        required this.panjangBadan,
        required this.tinggiBadan,
        required this.tinggiPinggul,
        required this.lebarPinggul,
        required this.lingkarDada,
        required this.suhuTubuh,
    });

    final String idProduct;
    final String beratBadan;
    final String panjangBadan;
    final String tinggiBadan;
    final String tinggiPinggul;
    final String lebarPinggul;
    final String lingkarDada;
    final String suhuTubuh;

    factory KeswanPertumbuhanModel.fromJson(Map<String, dynamic> json)
      => KeswanPertumbuhanModel(
        idProduct: json['id_product'],
        beratBadan: json['berat_badan'],
        panjangBadan: json['panjang_badan'],
        tinggiBadan: json['tinggi_badan'],
        tinggiPinggul: json['tinggi_pinggul'],
        lebarPinggul: json['lebar_pinggul'],
        lingkarDada: json['lingkar_dada'],
        suhuTubuh: json['suhu_tubuh'],
    );

    Map<String, dynamic> toJson() => {
        'id_product': idProduct,
        'berat_badan': beratBadan,
        'panjang_badan': panjangBadan,
        'tinggi_badan': tinggiBadan,
        'tinggi_pinggul': tinggiPinggul,
        'lebar_pinggul': lebarPinggul,
        'lingkar_dada': lingkarDada,
        'suhu_tubuh': suhuTubuh,
    };
}