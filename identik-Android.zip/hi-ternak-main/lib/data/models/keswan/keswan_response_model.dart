import 'keswan_model.dart';

class KeswanResponseModel {
    KeswanResponseModel({
      required this.code,
      required this.message,
      required this.data,
    });

    final int code;
    final String message;
    final KeswanModel data;

    factory KeswanResponseModel.fromJson(Map<String, dynamic> json) 
      => KeswanResponseModel(
        code: json['code'],
        message: json['message'],
        data: KeswanModel.fromJson(json['data']),
    );

    Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
        'data': data.toJson(),
    };
}