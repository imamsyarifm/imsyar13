import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'keswan_bobot_request_model.g.dart';

@HiveType(typeId: LocalTypeId.keswanGrowthRequest)
class KeswanBobotRequestModel extends HiveObject {
  static const localName = 'keswan_growth_request';

  KeswanBobotRequestModel({
    required this.idProduct,
    required this.usia,
    required this.beratBadan,
    required this.panjangBadan,
    required this.tinggiBadan,
    required this.tinggiPinggul,
    required this.lebarPinggul,
    required this.lingkarDada,
    required this.lingkarSkrotum,
    required this.suhuTubuh,
    required this.keterangan,
    required this.id,
    this.isInput,
    this.passcode,
  });

  @HiveField(0)
  final String idProduct;

  @HiveField(1)
  final String usia;

  @HiveField(2)
  final String beratBadan;

  @HiveField(3)
  final String panjangBadan;

  @HiveField(4)
  final String tinggiBadan;

  @HiveField(5)
  final String tinggiPinggul;

  @HiveField(6)
  final String lebarPinggul;

  @HiveField(7)
  final String lingkarDada;

  @HiveField(8)
  final String lingkarSkrotum;

  @HiveField(9)
  final String suhuTubuh;

  @HiveField(10)
  final String keterangan;

  @HiveField(11)
  final int id;

  @HiveField(12)
  final int? isInput;

  @HiveField(13)
  final String? passcode;

  factory KeswanBobotRequestModel.fromJson(Map<String, dynamic> json) =>
      KeswanBobotRequestModel(
        idProduct: json['id_product'],
        usia: json['usia'],
        beratBadan: json['berat_badan'],
        panjangBadan: json['panjang_badan'],
        tinggiBadan: json['tinggi_badan'],
        tinggiPinggul: json['tinggi_pinggul'],
        lebarPinggul: json['lebar_pinggul'],
        lingkarDada: json['lingkar_dada'],
        lingkarSkrotum: json['lingkar_skrotum'],
        suhuTubuh: json['suhu_tubuh'],
        keterangan: json['keterangan'],
        id: json['id'],
        isInput: json['is_input'],
        passcode: json['passcode'],
      );

  Map<String, dynamic> toJson() => {
        'id_product': idProduct,
        'usia': usia,
        'berat_badan': beratBadan,
        'panjang_badan': panjangBadan,
        'tinggi_badan': tinggiBadan,
        'tinggi_pinggul': tinggiPinggul,
        'lebar_pinggul': lebarPinggul,
        'lingkar_dada': lingkarDada,
        'lingkar_skrotum': lingkarSkrotum,
        'suhu_tubuh': suhuTubuh,
        'keterangan': keterangan,
        'id': id,
        'is_input': isInput,
        'passcode': passcode,
      };
}
