import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'keswan_kesehatan_request_model.g.dart';

@HiveType(typeId: LocalTypeId.keswanHealthRequest)
class KeswanKesehatanRequestModel extends HiveObject {
  static const localName = 'keswan_health_request';

  KeswanKesehatanRequestModel({
    required this.idProduct,
    required this.kategori,
    required this.tanggalVaksinasi,
    this.vaksinObat,
    this.batchNumber,
    required this.jenis,
    required this.dosis,
    this.keterangan,
    required this.id,
    this.isInput,
    this.passcode,
  });

  @HiveField(0)
  final String idProduct;

  @HiveField(1)
  final String kategori;

  @HiveField(2)
  final DateTime tanggalVaksinasi;

  @HiveField(3)
  final String? vaksinObat;

  @HiveField(4)
  final String? batchNumber;

  @HiveField(5)
  final String jenis;

  @HiveField(6)
  final String dosis;

  @HiveField(7)
  final String? keterangan;

  @HiveField(8)
  final int id;

   @HiveField(9)
  final int? isInput;

  @HiveField(10)
  final String? passcode;

  factory KeswanKesehatanRequestModel.fromJson(Map<String, dynamic> json) =>
      KeswanKesehatanRequestModel(
        idProduct: json['id_product'],
        kategori: json['kategori'],
        tanggalVaksinasi: DateTime.parse(json['tanggal_vaksinasi']),
        vaksinObat: json['vaksin_obat'],
        batchNumber: json['batch_number'],
        jenis: json['jenis'],
        dosis: json['dosis'],
        keterangan: json['keterangan'],
        id: json['id'],
        isInput: json['is_input'],
        passcode: json['passcode'],
      );

  Map<String, dynamic> toJson() => {
        'id_product': idProduct,
        'kategori': kategori,
        'tanggal_vaksinasi':
            '${tanggalVaksinasi.year.toString().padLeft(4, '0')}-'
                '${tanggalVaksinasi.month.toString().padLeft(2, '0')}-'
                '${tanggalVaksinasi.day.toString().padLeft(2, '0')}',
        'vaksin_obat': vaksinObat,
        'batch_number': batchNumber,
        'jenis': jenis,
        'dosis': dosis,
        'keterangan': keterangan,
        'id': id,
        'is_input': isInput,
        'passcode': passcode,
      };
}
