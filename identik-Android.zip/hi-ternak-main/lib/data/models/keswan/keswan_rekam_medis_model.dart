class KeswanRekamMedisModel {
    KeswanRekamMedisModel({
        required this.idProduct,
        required this.kategori,
        required this.mulaiSakit,
        required this.diagnosa,
        required this.penanganan,
        required this.jenis,
        required this.dosis,
        required this.bunting,
        required this.sapih,
        required this.keterangan,
    });

    final String idProduct;
    final String kategori;
    final int? mulaiSakit;
    final String diagnosa;
    final String penanganan;
    final String jenis;
    final String dosis;
    final String bunting;
    final String sapih;
    final String keterangan;

    factory KeswanRekamMedisModel.fromJson(Map<String, dynamic> json) 
      => KeswanRekamMedisModel(
        idProduct: json['id_product'],
        kategori: json['kategori'],
        mulaiSakit: (json['mulai_sakit'] == null) 
          ? null : json['mulai_sakit'],
        diagnosa: json['diagnosa'],
        penanganan: json['penanganan'],
        jenis: json['jenis'],
        dosis: json['dosis'],
        bunting: json['bunting'],
        sapih: json['sapih'],
        keterangan: json['keterangan'],
    );

    Map<String, dynamic> toJson() => {
        'id_product': idProduct,
        'kategori': kategori,
        'mulai_sakit': (mulaiSakit == null) 
          ? null : mulaiSakit,
        'diagnosa': diagnosa,
        'penanganan': penanganan,
        'jenis': jenis,
        'dosis': dosis,
        'bunting': bunting,
        'sapih': sapih,
        'keterangan': keterangan,
    };
}
