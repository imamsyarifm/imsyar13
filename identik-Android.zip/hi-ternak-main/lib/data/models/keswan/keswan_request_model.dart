class KeswanRequestModel {
    KeswanRequestModel({
      required this.codeProduct,
    });

    final String codeProduct;

    factory KeswanRequestModel.fromJson(Map<String, dynamic> json) 
      => KeswanRequestModel(
        codeProduct: json['code_product'],
    );

    Map<String, dynamic> toJson() => {
        'code_product': codeProduct,
    };
}
