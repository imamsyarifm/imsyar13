import 'keswan_pertumbuhan_model.dart';
import 'keswan_rekam_medis_model.dart';

class KeswanModel {
    KeswanModel({
        required this.id,
        required this.codeProduct,
        required this.idEartag,
        required this.idCategory,
        required this.jenisKelamin,
        required this.pathImage,
        required this.urlImage,
        required this.name,
        required this.pertumbuhan,
        required this.rekamMedisHistory,
    });

    final String id;
    final String codeProduct;
    final String idEartag;
    final String idCategory;
    final String jenisKelamin;
    final String pathImage;
    final String urlImage;
    final String name;
    final List<KeswanPertumbuhanModel> pertumbuhan;
    final List<KeswanRekamMedisModel> rekamMedisHistory;

    factory KeswanModel.fromJson(Map<String, dynamic> json) => KeswanModel(
        id: json['id'],
        codeProduct: json['code_product'],
        idEartag: json['id_eartag'],
        idCategory: json['id_category'],
        jenisKelamin: json['jenis_kelamin'],
        pathImage: json['path_image'],
        urlImage: json['url_image'],
        name: json['name'],
        pertumbuhan: List<KeswanPertumbuhanModel>.from(json['pertumbuhan']
          .map((x) => KeswanPertumbuhanModel.fromJson(x))),
        rekamMedisHistory: List<KeswanRekamMedisModel>
          .from(json['rekam_medis_history'].map((x) 
            => KeswanRekamMedisModel.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        'id': id,
        'code_product': codeProduct,
        'id_eartag': idEartag,
        'id_category': idCategory,
        'jenis_kelamin': jenisKelamin,
        'path_image': pathImage,
        'url_image': urlImage,
        'name': name,
        'pertumbuhan': List<dynamic>.from(pertumbuhan.map((x) 
          => x.toJson())),
        'rekam_medis_history': List<dynamic>.from(rekamMedisHistory.map((x) 
          => x.toJson())),
    };
}