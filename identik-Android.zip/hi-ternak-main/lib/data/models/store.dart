class Store {
  Store({
    required this.android,
    required this.ios,
  });

  final String android;
  final String ios;

  factory Store.fromJson(Map<String, dynamic> json) => Store(
        android: json['android'],
        ios: json['ios'],
      );

  Map<String, dynamic> toJson() => {
        'android': android,
        'ios': ios,
      };
}
