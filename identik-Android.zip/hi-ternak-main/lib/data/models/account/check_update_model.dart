class CheckUpdateModel {
  CheckUpdateModel({
    this.version,
    this.isUpdate,
  });

  final String? version;
  final int? isUpdate;

  factory CheckUpdateModel.fromJson(Map<String, dynamic> json) =>
      CheckUpdateModel(
        version: json['version'],
        isUpdate: json['must_be_updated'],
      );

  Map<String, dynamic> toJson() => {
        'version': version,
        'must_be_update': isUpdate,
      };
}
