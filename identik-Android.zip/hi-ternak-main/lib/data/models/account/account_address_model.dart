class AccountAddressModel {
    AccountAddressModel({
      required this.id,
      required this.idDistrict,
      required this.district,
      required this.zipCode,
      required this.address,
    });

    final String id;
    final String idDistrict;
    final String? district;
    final String? zipCode;
    final String address;

    factory AccountAddressModel.fromJson(Map<String, dynamic> json) 
      => AccountAddressModel(
        id: json['id'],
        idDistrict: json['id_district'],
        district: json['district'],
        zipCode: json['zip_code'],
        address: json['address'],
    );

    Map<String, dynamic> toJson() => {
        'id': id,
        'id_district': idDistrict,
        'district': district,
        'zip_code': zipCode,
        'address': address,
    };
}
