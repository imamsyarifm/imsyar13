import 'check_update_model.dart';

class CheckUpdateResponse {
  CheckUpdateResponse({
    required this.success,
    required this.message,
    required this.data,
  });

  final int success;
  final String message;
  final CheckUpdateModel data;

  factory CheckUpdateResponse.fromJson(Map<String, dynamic> json) =>
      CheckUpdateResponse(
        success: json['code'],
        message: json['message'],
        data: CheckUpdateModel.fromJson(json['data']),
      );

  Map<String, dynamic> toJson() => {
        'code': success,
        'message': message,
        'data': data,
      };
}
