import 'account_model.dart';

class AccountResponseModel {
    AccountResponseModel({
      required this.code,
      required this.message,
      required this.data,
    });

    final int code;
    final String message;
    final AccountModel data;

    factory AccountResponseModel.fromJson(Map<String, dynamic> json)
      => AccountResponseModel(
        code: json['code'],
        message: json['message'],
        data: AccountModel.fromJson(json['data']),
    );

    Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
        'data': data.toJson(),
    };
}