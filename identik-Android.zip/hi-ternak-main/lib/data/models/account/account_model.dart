import 'account_address_model.dart';

class AccountModel {
    AccountModel({
      required this.id,
      required this.name,
      required this.email,
      required this.phone,
      required this.password,
      required this.pathPhoto,
      required this.idAddress,
      required this.idCompany,
      required this.urlPhoto,
      required this.address,
    });

    final String id;
    final String name;
    final String email;
    final String phone;
    final String password;
    final String? pathPhoto;
    final String idAddress;
    final String? idCompany;
    final String urlPhoto;
    final AccountAddressModel address;

    factory AccountModel.fromJson(Map<String, dynamic> json) => AccountModel(
        id: json['id'],
        name: json['name'],
        email: json['email'],
        phone: json['phone'],
        password: json['password'],
        pathPhoto: json['path_photo'],
        idAddress: json['id_address'],
        idCompany: json['id_company'],
        urlPhoto: json['url_photo'],
        address: AccountAddressModel.fromJson(json['address']),
    );

    Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'email': email,
        'phone': phone,
        'password': password,
        'path_photo': pathPhoto,
        'id_address': idAddress,
        'id_company': idCompany,
        'url_photo': urlPhoto,
        'address': address.toJson(),
    };
}