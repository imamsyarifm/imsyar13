import 'register_address_request_model.dart';
class RegisterRequestModel {
    RegisterRequestModel({
        required this.name,
        required this.username,
        required this.phone,
        required this.email,
        required this.workArea,
        required this.isOfficer,
        this.idKelompok,
        required this.address,
        required this.password,
    });

    final String name;
    final String username;
    final String phone;
    final String email;
    final String workArea;
    final String isOfficer;
    final String? idKelompok;
    final RegisterAddressRequestModel address;
    final String password;

    factory RegisterRequestModel.fromJson(Map<String, dynamic> json) 
      => RegisterRequestModel(
        name: json['name'],
        username: json['username'],
        phone: json['phone'],
        email: json['email'],
        workArea: json['work_area'],
        isOfficer: json['is_officer'],
        idKelompok: json['id_kelompok'],
        address: RegisterAddressRequestModel.fromJson(json['address']),
        password: json['password'],
    );

    Map<String, dynamic> toJson() => {
        'name': name,
        'username': username,
        'phone': phone,
        'email': email,
        'work_area': workArea,
        'is_officer': isOfficer,
        'id_kelompok': idKelompok,
        'address': address.toJson(),
        'password': password,
    };
}