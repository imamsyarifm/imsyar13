class RegisterAddressRequestModel {
    RegisterAddressRequestModel({
        this.idProvince,
        this.idDistrict,
        this.idSubDistrict,
        this.idVillage,
        required this.address,
        required this.latitude,
        required this.longitude,
    });

    final String? idProvince;
    final String? idDistrict;
    final String? idSubDistrict;
    final String? idVillage;
    final String address;
    final String latitude;
    final String longitude;

    factory RegisterAddressRequestModel.fromJson(Map<String, dynamic> json) 
      => RegisterAddressRequestModel(
        idProvince: json['id_province'],
        idDistrict: json['id_district'],
        idSubDistrict: json['id_sub_district'],
        idVillage: json['id_village'],
        address: json['address'],
        latitude: json['latitude'],
        longitude: json['longitude'],
    );

    Map<String, dynamic> toJson() => {
        'id_province': idProvince,
        'id_district': idDistrict,
        'id_sub_district': idSubDistrict,
        'id_village': idVillage,
        'address': address,
        'latitude': latitude,
        'longitude': longitude,
    };
}
