class RoleResponseModel {
  RoleResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  final int code;
  final String message;
  final List<Role> data;

  factory RoleResponseModel.fromJson(Map<String, dynamic> json) =>
      RoleResponseModel(
        code: json['code'],
        message: json['message'],
        data: List<Role>.from(json['data'].map((x) => Role.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class Role {
  Role({
    required this.idRole,
    required this.roleName,
    this.dashboardUri,
  });

  final String idRole;
  final String roleName;
  final String? dashboardUri;

  factory Role.fromJson(Map<String, dynamic> json) => Role(
        idRole: json['id_role'],
        roleName: json['role_name'],
        dashboardUri: json['dashboard_uri'],
      );

  Map<String, dynamic> toJson() => {
        'id_role': idRole,
        'role_name': roleName,
        'dashboard_uri': dashboardUri,
      };
}
