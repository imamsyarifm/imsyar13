import 'owner_model.dart';

class OwnerResponseModel {
    OwnerResponseModel({
        required this.code,
        required this.message,
        required this.data,
    });

    final int code;
    final String message;
    final List<OwnerModel> data;

    factory OwnerResponseModel.fromJson(Map<String, dynamic> json) 
      => OwnerResponseModel(
        code: json['code'],
        message: json['message'],
        data: List<OwnerModel>.from(json['data'].map((x) 
          => OwnerModel.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
    };
}