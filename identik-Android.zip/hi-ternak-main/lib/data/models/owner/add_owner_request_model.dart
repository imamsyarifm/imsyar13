import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';
import 'add_owner_address_request_model.dart';

part 'add_owner_request_model.g.dart';

@HiveType(typeId: LocalTypeId.ownerRequest)
class AddOwnerRequestModel extends HiveObject {
  static const localName = 'owner_request';

  AddOwnerRequestModel({
    required this.id,
    required this.nik,
    required this.name,
    required this.gender,
    required this.birthdate,
    required this.email,
    required this.phone,
    this.idIsikhnas,
    required this.isPemilik,
    required this.address,
  });

  @HiveField(0)
  final String? id;

  @HiveField(1)
  final String nik;

  @HiveField(2)
  final String name;

  @HiveField(3)
  final String gender;

  @HiveField(4)
  final String birthdate;

  @HiveField(5)
  final String email;

  @HiveField(6)
  final String phone;

  @HiveField(7)
  final String? idIsikhnas;

  @HiveField(8)
  final String isPemilik;

  @HiveField(9)
  final AddOwnerAddressRequestModel address;

  factory AddOwnerRequestModel.fromJson(Map<String, dynamic> json) =>
      AddOwnerRequestModel(
        id: json['id'],
        nik: json['nik'],
        name: json['name'],
        gender: json['gender'],
        birthdate: json['birthdate'],
        email: json['email'],
        phone: json['phone'],
        idIsikhnas: json['id_isikhnas'],
        isPemilik: json['is_pemilik'],
        address: AddOwnerAddressRequestModel.fromJson(json['address']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'nik': nik,
        'name': name,
        'gender': gender,
        'birthdate': birthdate,
        'email': email,
        'phone': phone,
        'id_isikhnas': idIsikhnas,
        'is_pemilik': isPemilik,
        'address': address.toJson(),
      };
}
