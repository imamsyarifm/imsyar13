import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';
import 'owner_address_model.dart';

part 'owner_model.g.dart';

@HiveType(typeId: LocalTypeId.owner)
class OwnerModel extends HiveObject {
  static const localName = 'owner';

  OwnerModel({
    required this.id,
    required this.nik,
    required this.name,
    required this.gender,
    required this.birthdate,
    required this.umur,
    required this.email,
    required this.phone,
    required this.idAddress,
    this.isPemilik,
    this.idIsikhnas,
    required this.address,
    this.isSynced = true,
  });

  @HiveField(0)
  final String id;

  @HiveField(1)
  final String nik;

  @HiveField(2)
  final String name;

  @HiveField(3)
  final String gender;

  @HiveField(4)
  final DateTime birthdate;

  @HiveField(5)
  final String umur;

  @HiveField(6)
  final String email;

  @HiveField(7)
  final String phone;

  @HiveField(8)
  final String idAddress;

  @HiveField(9)
  final int? isPemilik;

  @HiveField(10)
  final String? idIsikhnas;

  @HiveField(11)
  final OwnerAddressModel address;

  @HiveField(12)
  final bool isSynced;

  factory OwnerModel.fromJson(Map<String, dynamic> json) => OwnerModel(
        id: json['id'],
        nik: json['nik'],
        name: json['name'],
        gender: json['gender'],
        birthdate: DateTime.parse(json['birthdate']),
        umur: json['umur'],
        email: json['email'],
        phone: json['phone'],
        idAddress: json['id_address'],
        isPemilik: json['is_pemilik'],
        idIsikhnas: json['id_isikhnas'],
        address: OwnerAddressModel.fromJson(json['address']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'nik': nik,
        'name': name,
        'gender': gender,
        'birthdate': '${birthdate.year.toString().padLeft(4, '0')}-'
            '${birthdate.month.toString().padLeft(2, '0')}-'
            '${birthdate.day.toString().padLeft(2, '0')}',
        'umur': umur,
        'email': email,
        'phone': phone,
        'id_address': idAddress,
        'is_pemilik': isPemilik,
        'id_isikhnas': idIsikhnas,
        'address': address.toJson(),
      };
}
