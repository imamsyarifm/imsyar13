import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'add_owner_address_request_model.g.dart';

@HiveType(typeId: LocalTypeId.ownerAddressRequest)
class AddOwnerAddressRequestModel extends HiveObject {
  static const localName = 'owner_address_request';

  AddOwnerAddressRequestModel({
    required this.idProvince,
    required this.idDistrict,
    required this.idSubDistrict,
    required this.idVillage,
    required this.rt,
    required this.rw,
    required this.address,
    required this.latitude,
    required this.longitude,
  });

  @HiveField(0)
  final String? idProvince;

  @HiveField(1)
  final String? idDistrict;

  @HiveField(2)
  final String? idSubDistrict;

  @HiveField(3)
  final String? idVillage;

  @HiveField(4)
  final String? rt;

  @HiveField(5)
  final String? rw;

  @HiveField(6)
  final String? address;

  @HiveField(7)
  final String latitude;

  @HiveField(8)
  final String longitude;

  factory AddOwnerAddressRequestModel.fromJson(Map<String, dynamic> json) =>
      AddOwnerAddressRequestModel(
        idProvince: json['id_province'],
        idDistrict: json['id_district'],
        idSubDistrict: json['id_sub_district'],
        idVillage: json['id_village'],
        rt: json['rt'],
        rw: json['rw'],
        address: json['address'],
        latitude: json['latitude'],
        longitude: json['longitude'],
      );

  Map<String, dynamic> toJson() => {
        'id_province': idProvince,
        'id_district': idDistrict,
        'id_sub_district': idSubDistrict,
        'id_village': idVillage,
        'rt': rt,
        'rw': rw,
        'address': address,
        'latitude': latitude,
        'longitude': longitude,
      };
}
