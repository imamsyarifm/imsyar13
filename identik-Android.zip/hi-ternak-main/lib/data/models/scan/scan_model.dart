import 'scan_bobot_model.dart';

class ScanModel {
    ScanModel({
      required this.id,
      required this.codeProduct,
      required this.idEartag,
      required this.pathImage,
      required this.urlImage,
      required this.name,
      required this.bobot,
    });

    final String id;
    final String codeProduct;
    final String idEartag;
    final String pathImage;
    final String urlImage;
    final String name;
    final ScanBobotModel bobot;

    factory ScanModel.fromJson(Map<String, dynamic> json) => ScanModel(
        id: json['id'],
        codeProduct: json['code_product'],
        idEartag: json['id_eartag'],
        pathImage: json['path_image'],
        urlImage: json['url_image'],
        name: json['name'],
        bobot: ScanBobotModel.fromJson(json['bobot']),
    );

    Map<String, dynamic> toJson() => {
        'id': id,
        'code_product': codeProduct,
        'id_eartag': idEartag,
        'path_image': pathImage,
        'url_image': urlImage,
        'name': name,
        'bobot': bobot.toJson(),
    };
}