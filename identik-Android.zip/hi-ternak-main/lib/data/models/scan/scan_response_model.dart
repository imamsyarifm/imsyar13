import 'scan_model.dart';

class ScanResponseModel {
    ScanResponseModel({
      required this.code,
      required this.message,
      required this.data,
    });

    final int code;
    final String message;
    final ScanModel? data;

    factory ScanResponseModel.fromJson(Map<String, dynamic> json) 
      => ScanResponseModel(
        code: json['code'],
        message: json['message'],
        data: (json['data'] != null) ? ScanModel.fromJson(json['data']) : null,
    );

    Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
        'data': data?.toJson(),
    };
}