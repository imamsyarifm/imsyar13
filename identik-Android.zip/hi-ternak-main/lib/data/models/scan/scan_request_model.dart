class ScanRequestModel {
  ScanRequestModel({
    required this.codeProduct,
  });

  final String codeProduct;

  factory ScanRequestModel.fromJson(Map<String, dynamic> json)
    => ScanRequestModel(
      codeProduct: json['code_product'],
  );

  Map<String, dynamic> toJson() => {
      'code_product': codeProduct,
  };
}