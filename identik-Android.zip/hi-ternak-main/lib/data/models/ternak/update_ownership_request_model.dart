class UpdateOwnershipRequestModel {
    UpdateOwnershipRequestModel({
        required this.idProduct,
        required this.kepemilikan,
    });

    final String idProduct;
    final String kepemilikan;

    factory UpdateOwnershipRequestModel.fromJson(Map<String, dynamic> json) 
      => UpdateOwnershipRequestModel(
        idProduct: json['id_product'],
        kepemilikan: json['kepemilikan'],
    );

    Map<String, dynamic> toJson() => {
        'id_product': idProduct,
        'kepemilikan': kepemilikan,
    };
}