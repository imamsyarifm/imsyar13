class UpdateHistoryTernakRequest {
    UpdateHistoryTernakRequest({
      required this.idProduct,
      required this.tanggalInput,
      required this.history,
    });

    final String idProduct;
    final DateTime tanggalInput;
    final String history;

    factory UpdateHistoryTernakRequest.fromJson(Map<String, dynamic> json)
      => UpdateHistoryTernakRequest(
        idProduct: json['id_product'],
        tanggalInput: DateTime.parse(json['tanggal_input']),
        history: json['history'],
    );

    Map<String, dynamic> toJson() => {
        'id_product': idProduct,
        'tanggal_input': '${tanggalInput.year.toString().padLeft(4, "0")}-'
                         '${tanggalInput.month.toString().padLeft(2, "0")}-'
                         '${tanggalInput.day.toString().padLeft(2, "0")}',
        'history': history,
    };
}