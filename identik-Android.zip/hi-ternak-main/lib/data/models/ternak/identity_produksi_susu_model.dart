import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'identity_produksi_susu_model.g.dart';

@HiveType(typeId: LocalTypeId.identityProduksiSusu)
class IdentityProduksiSusuModel extends HiveObject {
  IdentityProduksiSusuModel({
    required this.idProduct,
    required this.laktasiKe,
    required this.tanggalSampling,
    required this.productPagiLiter,
    required this.productPagiKg,
    required this.productSoreLiter,
    required this.productSoreKg,
    required this.productTotalLiter,
    required this.productTotalKg,
    this.keterangan,
  });

  @HiveField(0)
  final String? idProduct;

  @HiveField(1)
  final int? laktasiKe;

  @HiveField(2)
  final DateTime? tanggalSampling;

  @HiveField(3)
  final String? productPagiLiter;

  @HiveField(4)
  final String? productPagiKg;

  @HiveField(5)
  final String? productSoreLiter;

  @HiveField(6)
  final String? productSoreKg;

  @HiveField(7)
  final String? productTotalLiter;

  @HiveField(8)
  final String? productTotalKg;

  @HiveField(9)
  final String? keterangan;

  factory IdentityProduksiSusuModel.fromJson(Map<String, dynamic> json) =>
      IdentityProduksiSusuModel(
        idProduct: json['id_product'],
        laktasiKe: json['laktasi_ke'],
        tanggalSampling: DateTime.parse(json['tanggal_sampling']),
        productPagiLiter: json['product_pagi_liter'],
        productPagiKg: json['product_pagi_kg'],
        productSoreLiter: json['product_sore_liter'],
        productSoreKg: json['product_sore_kg'],
        productTotalLiter: json['product_total_liter'],
        productTotalKg: json['product_total_kg'],
        keterangan: json['keterangan'],
      );

  Map<String, dynamic> toJson() => {
        'id_product': idProduct,
        'laktasi_ke': laktasiKe,
        'tanggal_sampling':
            '${tanggalSampling?.year.toString().padLeft(4, '0')}-'
                '${tanggalSampling?.month.toString().padLeft(2, '0')}-'
                '${tanggalSampling?.day.toString().padLeft(2, '0')}',
        'product_pagi_liter': productPagiLiter,
        'product_pagi_kg': productPagiKg,
        'product_sore_liter': productSoreLiter,
        'product_sore_kg': productSoreKg,
        'product_total_liter': productTotalLiter,
        'product_total_kg': productTotalKg,
        'keterangan': keterangan,
      };
}
