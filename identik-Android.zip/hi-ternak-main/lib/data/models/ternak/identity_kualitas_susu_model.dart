import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'identity_kualitas_susu_model.g.dart';

@HiveType(typeId: LocalTypeId.identityKualitasSusu)
class IdentityKualitasSusuModel extends HiveObject {
  IdentityKualitasSusuModel({
    required this.idProduct,
    required this.warna,
    required this.bau,
    required this.lemak,
    required this.protein,
    required this.ts,
    required this.snf,
    required this.laktosa,
    required this.density,
    required this.fpd,
    required this.acidity,
    required this.tpc,
    required this.ph,
  });

  @HiveField(0)
  final String? idProduct;

  @HiveField(1)
  final String? warna;

  @HiveField(2)
  final String? bau;

  @HiveField(3)
  final String? lemak;

  @HiveField(4)
  final String? protein;

  @HiveField(5)
  final String? ts;

  @HiveField(6)
  final String? snf;

  @HiveField(7)
  final String? laktosa;

  @HiveField(8)
  final String? density;

  @HiveField(9)
  final String? fpd;

  @HiveField(10)
  final String? acidity;

  @HiveField(11)
  final String? tpc;

  @HiveField(12)
  final String? ph;

  factory IdentityKualitasSusuModel.fromJson(Map<String, dynamic> json) =>
      IdentityKualitasSusuModel(
        idProduct: json['id_product'],
        warna: json['warna'],
        bau: json['bau'],
        lemak: json['lemak'],
        protein: json['protein'],
        ts: json['ts'],
        snf: json['snf'],
        laktosa: json['laktosa'],
        density: json['density'],
        fpd: json['fpd'],
        acidity: json['acidity'],
        tpc: json['tpc'],
        ph: json['ph'],
      );

  Map<String, dynamic> toJson() => {
        'id_product': idProduct,
        'warna': warna,
        'bau': bau,
        'lemak': lemak,
        'protein': protein,
        'ts': ts,
        'snf': snf,
        'laktosa': laktosa,
        'density': density,
        'fpd': fpd,
        'acidity': acidity,
        'tpc': tpc,
        'ph': ph,
      };
}
