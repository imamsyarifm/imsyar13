import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';
import 'identity_alamat_lahir_ternak.dart';
import 'identity_inseminasi_model.dart';
import 'identity_kandang_model.dart';
import 'identity_kepemilikan_model.dart';
import 'identity_kualitas_susu_model.dart';
import 'identity_pertumbuhan_model.dart';
import 'identity_produksi_susu_model.dart';
import 'identity_rekam_medis_model.dart';
import 'mutasi_identity.dart';

part 'identity_ternak_model.g.dart';

@HiveType(typeId: LocalTypeId.identityTernak)
class IdentityTernakModel extends HiveObject {
  static const localName = 'ternak';

  IdentityTernakModel({
    this.id,
    required this.codeProduct,
    required this.idEartag,
    this.idCategory,
    this.jenisTernak,
    this.asalTernak,
    this.program,
    this.jenisKelamin,
    this.idRumpun,
    this.rumpun,
    this.idPenjantan,
    this.idRumpunPejantan,
    this.rumpunPejantan,
    this.idInduk,
    this.idRumpunInduk,
    this.rumpunInduk,
    this.tempatLahirTernak,
    this.tanggalLahirTernak,
    this.penentuanTanggalLahir,
    this.bertanduk,
    this.warnaKulit,
    this.warnaDominan,
    this.metodePerkawinan,
    this.tipeKelahiran,
    this.pathImage,
    this.urlImage,
    this.profilePertumbuhanAkhir,
    this.pertumbuhan,
    this.rekamMedis,
    this.inseminasi,
    this.produksiSusu,
    this.kualitasSusu,
    this.kepemilikan,
    this.kandang,
    this.createdAt,
    this.ciriKhas,
    this.mutuBibit,
    this.programName,
    this.name,
    this.tanggalPerolehan,
    this.umur,
    this.statusTernak,
    this.idIsikhnas,
    this.alamatLahirTernak = const [],
    this.mutasi = const [],
  });

  @HiveField(0)
  final String? id;

  @HiveField(1)
  final String? codeProduct;

  @HiveField(2)
  final String? idEartag;

  @HiveField(3)
  final String? idCategory;

  @HiveField(4)
  final String? jenisTernak;

  @HiveField(5)
  final String? asalTernak;

  @HiveField(6)
  final String? program;

  @HiveField(7)
  final String? programName;

  @HiveField(8)
  final String? name;

  @HiveField(9)
  final String? jenisKelamin;

  @HiveField(10)
  final String? idRumpun;

  @HiveField(11)
  final String? rumpun;

  @HiveField(12)
  final DateTime? tanggalLahirTernak;

  @HiveField(13)
  final String? tempatLahirTernak;

  @HiveField(14)
  final String? idPenjantan;

  @HiveField(15)
  final String? idRumpunPejantan;

  @HiveField(16)
  final String? rumpunPejantan;

  @HiveField(17)
  final String? idInduk;

  @HiveField(18)
  final String? idRumpunInduk;

  @HiveField(19)
  final String? rumpunInduk;

  @HiveField(20)
  final String? penentuanTanggalLahir;

  @HiveField(21)
  final String? bertanduk;

  @HiveField(22)
  final String? warnaKulit;

  @HiveField(23)
  final String? warnaDominan;

  @HiveField(24)
  final String? metodePerkawinan;

  @HiveField(25)
  final String? tipeKelahiran;

  @HiveField(26)
  final String? pathImage;

  @HiveField(27)
  final String? ciriKhas;

  @HiveField(28)
  final String? mutuBibit;

  @HiveField(29)
  final DateTime? tanggalPerolehan;

  @HiveField(30)
  final DateTime? createdAt;

  @HiveField(31)
  final String? urlImage;

  @HiveField(32)
  final String? umur;

  @HiveField(33)
  final String? statusTernak;

  @HiveField(34)
  final String? idIsikhnas;

  @HiveField(35)
  final IdentityPertumbuhanModel? profilePertumbuhanAkhir;

  @HiveField(36)
  final List<IdentityPertumbuhanModel>? pertumbuhan;

  @HiveField(37)
  final List<IdentityRekamMedisModel>? rekamMedis;

  @HiveField(38)
  final List<IdentityInseminasiModel>? inseminasi;

  @HiveField(39)
  final List<IdentityProduksiSusuModel>? produksiSusu;

  @HiveField(40)
  final List<IdentityKualitasSusuModel>? kualitasSusu;

  @HiveField(41)
  final IdentityKepemilikanModel? kepemilikan;

  @HiveField(42)
  final List<IdentityKandangModel>? kandang;

  @HiveField(43)
  final List<AlamatLahirTernak> alamatLahirTernak;

  @HiveField(44)
  final List<MutasiIdentity> mutasi;

  factory IdentityTernakModel.fromJson(Map<String, dynamic> json) =>
      IdentityTernakModel(
        id: json['id'],
        codeProduct: json['code_product'],
        idEartag: json['id_eartag'],
        idCategory: json['id_category'],
        jenisTernak: json['jenis_ternak'],
        asalTernak: json['asal_ternak'],
        program: json['program'],
        jenisKelamin: json['jenis_kelamin'],
        idRumpun: json['id_rumpun'],
        rumpun: json['rumpun'],
        idPenjantan: json['id_penjantan'],
        idRumpunPejantan: json['id_rumpun_pejantan'],
        rumpunPejantan: json['rumpun_penjantan'],
        idInduk: json['id_induk'],
        idRumpunInduk: json['id_rumpun_induk'],
        rumpunInduk: json['rumpun_induk'],
        tempatLahirTernak: json['tempat_lahir_ternak'],
        tanggalLahirTernak: DateTime.parse(json['tanggal_lahir_ternak']),
        penentuanTanggalLahir: json['penentuan_tanggal_lahir'],
        bertanduk: json['bertanduk'],
        warnaKulit: json['warna_kulit'],
        warnaDominan: json['warna_dominan'],
        metodePerkawinan: json['metode_perkawinan'],
        tipeKelahiran: json['tipe_kelahiran'],
        pathImage: json['path_image'],
        urlImage: json['url_image'],
        profilePertumbuhanAkhir: (json['profile_pertumbuhan_akhir'] == null)
            ? null
            : IdentityPertumbuhanModel.fromJson(
                json['profile_pertumbuhan_akhir']),
        pertumbuhan: List<IdentityPertumbuhanModel>.from(json['pertumbuhan']
            .map((x) => IdentityPertumbuhanModel.fromJson(x))),
        rekamMedis: List<IdentityRekamMedisModel>.from(json['rekam_medis']
            .map((x) => IdentityRekamMedisModel.fromJson(x))),
        inseminasi: List<IdentityInseminasiModel>.from(
            json['inseminasi'].map((x) => IdentityInseminasiModel.fromJson(x))),
        produksiSusu: List<IdentityProduksiSusuModel>.from(json['produksi_susu']
            .map((x) => IdentityProduksiSusuModel.fromJson(x))),
        kualitasSusu: (json['kualitas_susu'] != null)
            ? List<IdentityKualitasSusuModel>.from(json['kualitas_susu']
                .map((x) => IdentityKualitasSusuModel.fromJson(x)))
            : null,
        kepemilikan: (json['kepemilikan'] != null)
            ? IdentityKepemilikanModel.fromJson(json['kepemilikan'])
            : null,
        kandang: List<IdentityKandangModel>.from(
            json['kandang'].map((x) => IdentityKandangModel.fromJson(x))),
        ciriKhas: json['ciri_khas'],
        mutuBibit: json['mutu_bibit'],
        programName: json['program_name'],
        name: json['name'],
        tanggalPerolehan: DateTime.parse(json['tanggal_perolehan']),
        createdAt: (json['created_at'] != null)
            ? DateTime.parse(json['created_at'])
            : null,
        umur: json['umur'],
        statusTernak: json['status_ternak'],
        idIsikhnas: json['id_isikhnas'],
        alamatLahirTernak: List<AlamatLahirTernak>.from(
            json['alamat_lahir_ternak']
                .map((x) => AlamatLahirTernak.fromJson(x))),
        mutasi: List<MutasiIdentity>.from(
          json['mutasi'].map((x) => MutasiIdentity.fromJson(x)),
        ),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'code_product': codeProduct,
        'id_eartag': idEartag,
        'id_category': idCategory,
        'jenis_ternak': jenisTernak,
        'asal_ternak': asalTernak,
        'program': program,
        'jenis_kelamin': jenisKelamin,
        'id_rumpun': idRumpun,
        'rumpun': rumpun,
        'id_penjantan': idPenjantan,
        'id_rumpun_pejantan': idRumpunPejantan,
        'rumpun_penjantan': rumpunPejantan,
        'id_induk': idInduk,
        'id_rumpun_induk': idRumpunInduk,
        'rumpun_induk': rumpunInduk,
        'tempat_lahir_ternak': tempatLahirTernak,
        'tanggal_lahir_ternak':
            '${tanggalLahirTernak?.year.toString().padLeft(4, '0')}-'
                '${tanggalLahirTernak?.month.toString().padLeft(2, '0')}-'
                '${tanggalLahirTernak?.day.toString().padLeft(2, '0')}',
        'penentuan_tanggal_lahir': penentuanTanggalLahir,
        'bertanduk': bertanduk,
        'warna_kulit': warnaKulit,
        'warna_dominan': warnaDominan,
        'metode_perkawinan': metodePerkawinan,
        'tipe_kelahiran': tipeKelahiran,
        'path_image': pathImage,
        'url_image': urlImage,
        'profile_pertumbuhan_akhir': profilePertumbuhanAkhir?.toJson(),
        'pertumbuhan': (pertumbuhan != null)
            ? List<IdentityPertumbuhanModel>.from(
                pertumbuhan!.map((x) => x.toJson()))
            : null,
        'rekam_medis': (rekamMedis != null)
            ? List<IdentityRekamMedisModel>.from(
                rekamMedis!.map((x) => x.toJson()))
            : null,
        'inseminasi': (inseminasi != null)
            ? List<IdentityInseminasiModel>.from(
                inseminasi!.map((x) => x.toJson()))
            : null,
        'produksi_susu': (produksiSusu != null)
            ? List<IdentityProduksiSusuModel>.from(
                produksiSusu!.map((x) => x.toJson()))
            : null,
        'kualitas_susu': (kualitasSusu != null)
            ? List<IdentityKualitasSusuModel>.from(
                kualitasSusu!.map((x) => x.toJson()))
            : null,
        'kepemilikan': kepemilikan?.toJson(),
        'kandang': (kandang != null)
            ? List<IdentityKandangModel>.from(kandang!.map((e) => e.toJson()))
            : null,
        'ciri_khas': ciriKhas,
        'mutu_bibit': mutuBibit,
        'program_name': programName,
        'name': name,
        'tanggal_perolehan':
            '${tanggalPerolehan?.year.toString().padLeft(4, '0')}-'
                '${tanggalPerolehan?.month.toString().padLeft(2, '0')}-'
                '${tanggalPerolehan?.day.toString().padLeft(2, '0')}',
        'created_at': createdAt,
        'umur': umur,
        'status_ternak': statusTernak,
        'id_isikhnas': idIsikhnas,
        'alamat_lahir_ternak':
            List<dynamic>.from(alamatLahirTernak.map((x) => x.toJson())),
        'mutasi': List<MutasiIdentity>.from(mutasi.map((x) => x.toJson())),
      };
}
