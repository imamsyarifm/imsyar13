class IdentityTernakBobotModel {
    IdentityTernakBobotModel({
        required this.idProduct,
        required this.usia,
        required this.beratBadan,
        required this.panjangBadan,
        required this.tinggiBadan,
        required this.suhuTubuh,
        required this.lingkarDada,
    });

    final String idProduct;
    final String usia;
    final String beratBadan;
    final String panjangBadan;
    final String tinggiBadan;
    final String? suhuTubuh;
    final String? lingkarDada;

    factory IdentityTernakBobotModel.fromJson(Map<String, dynamic> json) 
      => IdentityTernakBobotModel(
        idProduct: json['id_product'],
        usia: json['usia'],
        beratBadan: json['berat_badan'],
        panjangBadan: json['panjang_badan'],
        tinggiBadan: json['tinggi_badan'],
        suhuTubuh: json['suhu_tubuh'],
        lingkarDada: json['lingkar_dada'],
    );

    Map<String, dynamic> toJson() => {
        'id_product': idProduct,
        'usia': usia,
        'berat_badan': beratBadan,
        'panjang_badan': panjangBadan,
        'tinggi_badan': tinggiBadan,
        'suhu_tubuh': suhuTubuh,
        'lingkar_dada': lingkarDada,
    };
}