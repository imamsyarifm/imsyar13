import 'identity_ternak_model.dart';

class IdentityTernakResponseModel {
    IdentityTernakResponseModel({
      required this.code,
      required this.message,
      required this.data,
    });

    final int code;
    final String message;
    final List<IdentityTernakModel> data;

    factory IdentityTernakResponseModel.fromJson(Map<String, dynamic> json) 
      => IdentityTernakResponseModel(
        code: json['code'],
        message: json['message'],
        data: List<IdentityTernakModel>.from(json['data'].map((x) 
          => IdentityTernakModel.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
    };
}

class TernakResponseModel {
    TernakResponseModel({
      required this.code,
      required this.message,
      required this.data,
    });

    final int code;
    final String message;
    final IdentityTernakModel? data;

    factory TernakResponseModel.fromJson(Map<String, dynamic> json) 
      => TernakResponseModel(
        code: json['code'],
        message: json['message'],
        data: (json['data'] != null)
          ? IdentityTernakModel.fromJson(json['data'])
          : null,
    );

    Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
        'data': data?.toJson(),
    };
}