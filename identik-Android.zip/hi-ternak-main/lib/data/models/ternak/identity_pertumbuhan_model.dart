import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'identity_pertumbuhan_model.g.dart';

@HiveType(typeId: LocalTypeId.identityPertumbuhan)
class IdentityPertumbuhanModel extends HiveObject {
  IdentityPertumbuhanModel({
    required this.idProduct,
    required this.beratBadan,
    required this.panjangBadan,
    required this.tinggiBadan,
    required this.tinggiPinggul,
    required this.lebarPinggul,
    required this.lingkarDada,
    required this.suhuTubuh,
    required this.lingkarSkrotum,
    required this.beratBadanInduk,
    required this.tanggalInput,
    required this.usia,
  });

  @HiveField(0)
  final String? usia;

  @HiveField(1)
  final String? idProduct;

  @HiveField(2)
  final String? beratBadan;

  @HiveField(3)
  final String? panjangBadan;

  @HiveField(4)
  final String? tinggiBadan;

  @HiveField(5)
  final String? tinggiPinggul;

  @HiveField(6)
  final String? lebarPinggul;

  @HiveField(7)
  final String? lingkarDada;

  @HiveField(8)
  final DateTime? tanggalInput;

  @HiveField(9)
  final String? suhuTubuh;

  @HiveField(10)
  final String? lingkarSkrotum;

  @HiveField(11)
  final String? beratBadanInduk;

  factory IdentityPertumbuhanModel.fromJson(Map<String, dynamic> json) =>
      IdentityPertumbuhanModel(
        idProduct: json['id_product'],
        beratBadan: json['berat_badan'],
        panjangBadan: json['panjang_badan'],
        tinggiBadan: json['tinggi_badan'],
        tinggiPinggul: json['tinggi_pinggul'],
        lebarPinggul: json['lebar_pinggul'],
        lingkarDada: json['lingkar_dada'],
        suhuTubuh: (json['suhu_tubuh'] == null) ? null : json['suhu_tubuh'],
        lingkarSkrotum:
            (json['lingkar_skrotum'] == null) ? null : json['lingkar_skrotum'],
        beratBadanInduk: (json['berat_badan_induk'] == null)
            ? null
            : json['berat_badan_induk'],
        tanggalInput: (json['tanggal_input'] == null)
            ? null
            : DateTime.parse(json['tanggal_input']),
        usia: (json['usia'] == null) ? null : json['usia'],
      );

  Map<String, dynamic> toJson() => {
        'id_product': idProduct,
        'berat_badan': beratBadan,
        'panjang_badan': panjangBadan,
        'tinggi_badan': tinggiBadan,
        'tinggi_pinggul': tinggiPinggul,
        'lebar_pinggul': lebarPinggul,
        'lingkar_dada': lingkarDada,
        'suhu_tubuh': (suhuTubuh == null) ? null : suhuTubuh,
        'lingkar_skrotum': (lingkarSkrotum == null) ? null : lingkarSkrotum,
        'berat_badan_induk': (beratBadanInduk == null) ? null : beratBadanInduk,
        'tanggal_input':
            (tanggalInput == null) ? null : tanggalInput!.toIso8601String(),
        'usia': (usia == null) ? null : usia,
      };
}
