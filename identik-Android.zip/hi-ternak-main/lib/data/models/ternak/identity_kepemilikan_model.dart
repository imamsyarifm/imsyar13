import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'identity_kepemilikan_model.g.dart';

@HiveType(typeId: LocalTypeId.identityKepemilikan)
class IdentityKepemilikanModel extends HiveObject {
  IdentityKepemilikanModel({
    required this.id,
    required this.idUser,
    required this.idProduct,
    required this.nib,
    required this.nikPemilik,
    required this.nama,
    required this.gender,
    required this.birthdate,
    required this.tanggalMemilki,
    required this.email,
    required this.phone,
    required this.keterangan,
    required this.alamat,
    required this.koordinat,
    required this.umur,
    required this.phoneUnitUsaha,
    required this.emailUnitUsaha,
    required this.isCompany,
  });

  @HiveField(0)
  final String? id;

  @HiveField(1)
  final String? idUser;

  @HiveField(2)
  final String? idProduct;

  @HiveField(3)
  final String? nib;

  @HiveField(4)
  final String? nikPemilik;

  @HiveField(5)
  final String? nama;

  @HiveField(6)
  final String? gender;

  @HiveField(7)
  final DateTime? birthdate;

  @HiveField(8)
  final DateTime tanggalMemilki;

  @HiveField(9)
  final String? email;

  @HiveField(10)
  final String? phone;

  @HiveField(11)
  final String? keterangan;

  @HiveField(12)
  final String? alamat;

  @HiveField(13)
  final String? koordinat;

  @HiveField(14)
  final String? umur;

  @HiveField(15)
  final String? phoneUnitUsaha;

  @HiveField(16)
  final String? emailUnitUsaha;

  @HiveField(17)
  final int? isCompany;

  factory IdentityKepemilikanModel.fromJson(Map<String, dynamic> json) =>
      IdentityKepemilikanModel(
        id: json['id'],
        idUser: json['id_user'],
        idProduct: json['id_product'],
        nib: json['nib'],
        nikPemilik: json['nik_pemilik'],
        nama: json['name'],
        gender: json['gender'],
        birthdate: (json['birthdate'] != null)
            ? DateTime.parse(json['birthdate'])
            : null,
        tanggalMemilki: DateTime.parse(json['tanggal_memilki']),
        email: json['email'],
        phone: json['phone'],
        keterangan: json['keterangan'],
        alamat: json['alamat'],
        koordinat: json['koordinat'],
        umur: json['umur'],
        phoneUnitUsaha: json['phone_unit_usaha'],
        emailUnitUsaha: json['email_unit_usaha'],
        isCompany: json['is_company'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'id_user': idUser,
        'id_product': idProduct,
        'nib': nib,
        'nik_pemilik': nikPemilik,
        'name': nama,
        'gender': gender,
        'birthdate': birthdate,
        'tanggal_memilki': '${tanggalMemilki.year.toString().padLeft(4, '0')}-'
            '${tanggalMemilki.month.toString().padLeft(2, '0')}-'
            '${tanggalMemilki.day.toString().padLeft(2, '0')}',
        'email': email,
        'phone': phone,
        'keterangan': keterangan,
        'alamat': alamat,
        'koordinat': koordinat,
        'umur': umur,
        'phone_unit_usaha': phoneUnitUsaha,
        'email_unit_usaha': emailUnitUsaha,
        'is_company': isCompany,
      };
}
