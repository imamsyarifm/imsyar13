class IdentityTernakHistoryModel {
  IdentityTernakHistoryModel({
    required this.id,
    required this.idProduct,
    required this.tanggalInput,
    required this.history,
    required this.kepemilikan,
  });

  final String id;
  final String idProduct;
  final DateTime? tanggalInput;
  final String? history;
  final String? kepemilikan;

  factory IdentityTernakHistoryModel.fromJson(Map<String, dynamic> json) =>
      IdentityTernakHistoryModel(
        id: json['id'],
        idProduct: json['id_product'],
        tanggalInput: (json['tanggal_input'] != null)
          ? DateTime.parse(json['tanggal_input']) : null,
        history: json['history'],
        kepemilikan: json['kepemilikan'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'id_product': idProduct,
        'tanggal_input': '${tanggalInput?.year.toString().padLeft(4, "0")}-'
            '${tanggalInput?.month.toString().padLeft(2, "0")}-'
            '${tanggalInput?.day.toString().padLeft(2, "0")}',
        'history': history,
        'kepemilikan': kepemilikan,
      };
}
