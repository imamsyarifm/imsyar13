import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';
import '../../../utils/datetime_util.dart';
import 'ternak_birthday_request.dart';

part 'ternak_request.g.dart';

@HiveType(typeId: LocalTypeId.ternakRequest)
class TernakRequest extends HiveObject {
  static const localName = 'ternak_request';

  @HiveField(0)
  String? codeProduct;

  @HiveField(1)
  final String? name;

  @HiveField(2)
  final String? category;

  @HiveField(3)
  final String? rumpun;

  @HiveField(4)
  final String? gender;

  @HiveField(5)
  final DateTime? birthday;

  @HiveField(6)
  final String? program;

  @HiveField(7)
  final String idIshiknas;

  @HiveField(8)
  final bool isSameWithKandang;

  @HiveField(9)
  final TernakBirthdayRequest ternakBirthday;

  @HiveField(10)
  final String? statusKandang;

  @HiveField(11)
  final String? kandang;

  @HiveField(12)
  final String ciriKhas;

  @HiveField(13)
  final String mutuBibit;

  @HiveField(14)
  final DateTime tanggalPerolehan;

  @HiveField(15)
  final String? asalTernak;

  @HiveField(16)
  final int? asalTernakLokasi;

  @HiveField(17)
  final String beratBadan;

  @HiveField(18)
  final String panjangBadan;

  @HiveField(19)
  final String tinggiBadan;

  @HiveField(20)
  final String? idPemilik;

  @HiveField(21)
  final bool isCompany;

  @HiveField(22)
  final bool isVaksinasi;

  @HiveField(23)
  final DateTime? tanggalVaksinasi;

  @HiveField(24)
  final String? vaksinasi;

  @HiveField(25)
  final String? batchNumber;

  @HiveField(26)
  final String? idProduct;

  @HiveField(27)
  final String? pathPhoto;

  @HiveField(28)
  bool isUpdate;

  @HiveField(29)
  String? scanResult;

  String? randomCode;

  @HiveField(30)
  String? reason;

  TernakRequest({
    this.codeProduct,
    this.name,
    this.category,
    this.rumpun,
    this.gender,
    this.birthday,
    this.program,
    required this.idIshiknas,
    this.isSameWithKandang = false,
    required this.ternakBirthday,
    this.statusKandang,
    this.kandang,
    required this.ciriKhas,
    required this.mutuBibit,
    required this.tanggalPerolehan,
    this.asalTernak,
    this.asalTernakLokasi,
    required this.beratBadan,
    required this.panjangBadan,
    required this.tinggiBadan,
    this.idPemilik,
    this.isCompany = false,
    this.isVaksinasi = false,
    this.tanggalVaksinasi,
    this.vaksinasi,
    this.batchNumber,
    this.idProduct,
    this.pathPhoto,
    this.isUpdate = false,
    this.scanResult,
    this.randomCode,
    this.reason,
  });

  Future<FormData> get toPayloadAdd async {
    final payload = FormData.fromMap({
      'code_product': codeProduct,
      'nama_ternak': name,
      'id_category': category,
      'id_rumpun': rumpun,
      'jenis_kelamin': gender,
      'tanggal_lahir_ternak': birthday?.valueApi(),
      'program': program,
      'id_isikhnas': idIshiknas,
      'is_equal': (isSameWithKandang) ? '1' : '0',
      'tempat_lahir_ternak': ternakBirthday.toMap,
      'status_kandang': statusKandang,
      'id_kandang': kandang,
      'id_petugas': null,
      'ciri_khas': ciriKhas,
      'mutu_bibit': mutuBibit,
      'tanggal_perolehan': tanggalPerolehan.valueApi(),
      'asal_ternak': asalTernak,
      'asal_ternak_lokasi': asalTernakLokasi,
      'berat_badan': beratBadan,
      'panjang_badan': panjangBadan,
      'tinggi_badan': tinggiBadan,
      'id_pemilik': idPemilik,
      'is_company': (isCompany) ? '1' : '0',
      'is_vaksinasi': (isVaksinasi) ? '1' : '0',
      'tanggal_vaksinasi': tanggalVaksinasi?.valueApi(),
      'vaksinasi': vaksinasi,
      'batch_number': batchNumber,
      'keterangan': reason,
    });

    if (pathPhoto != null) {
      final multipartFile = await MultipartFile.fromFile(pathPhoto!);
      payload.files.add(MapEntry('path_photo', multipartFile));
    }

    debugPrint(payload.fields.toString());

    return payload;
  }

  Future<FormData> get toPayloadUpdate async {
    final payload = FormData.fromMap({
      'code_product': codeProduct,
      'nama_ternak': name,
      'id_category': category,
      'id_rumpun': rumpun,
      'jenis_kelamin': gender,
      'tanggal_lahir_ternak': birthday,
      'program': program,
      'id_isikhnas': idIshiknas,
      'is_equal': (isSameWithKandang) ? '1' : '0',
      'tempat_lahir_ternak': ternakBirthday.toMap,
      'status_kandang': statusKandang,
      'id_kandang': kandang,
      'id_petugas': null,
      'ciri_khas': ciriKhas,
      'mutu_bibit': mutuBibit,
      'tanggal_perolehan': tanggalPerolehan.valueApi(),
      'asal_ternak': asalTernak,
      'asal_ternak_lokasi': asalTernakLokasi,
      'berat_badan': beratBadan,
      'panjang_badan': panjangBadan,
      'tinggi_badan': tinggiBadan,
      'id_product': idProduct,
      'scan_result': scanResult,
      'keterangan': reason,
    });

    if (pathPhoto != null) {
      final multipartFile = await MultipartFile.fromFile(pathPhoto!);
      payload.files.add(MapEntry('path_photo', multipartFile));
    }

    return payload;
  }
}
