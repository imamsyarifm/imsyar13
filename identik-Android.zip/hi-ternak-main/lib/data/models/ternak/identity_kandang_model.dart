import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'identity_kandang_model.g.dart';

@HiveType(typeId: LocalTypeId.identityKandang)
class IdentityKandangModel extends HiveObject {
  IdentityKandangModel({
    required this.idKandang,
    required this.idProduct,
    required this.namaKandang,
    required this.kapasitas,
    required this.tanggalDibangun,
    required this.jenisKandang,
    this.statusKandang,
    required this.alamat,
    required this.phonePemilikKandang,
    required this.emailPemilikKandang,
  });

  @HiveField(0)
  final String? idKandang;

  @HiveField(1)
  final String idProduct;

  @HiveField(2)
  final String? namaKandang;

  @HiveField(3)
  final String? kapasitas;

  @HiveField(4)
  final DateTime? tanggalDibangun;

  @HiveField(5)
  final String? jenisKandang;

  @HiveField(6)
  final String? statusKandang;

  @HiveField(7)
  final String? alamat;

  @HiveField(8)
  final String? phonePemilikKandang;

  @HiveField(9)
  final String? emailPemilikKandang;

  factory IdentityKandangModel.fromJson(Map<String, dynamic> json) =>
      IdentityKandangModel(
        idKandang: json['id_kandang'],
        idProduct: json['id_product'],
        namaKandang: json['nama_kandang'],
        kapasitas: json['kapasitas'],
        tanggalDibangun: (json['tanggal_dibangun'] != null)
            ? DateTime.parse(json['tanggal_dibangun'])
            : null,
        jenisKandang: json['jenis_kandang'],
        statusKandang: json['status_kandang'],
        alamat: json['alamat'],
        phonePemilikKandang: json['nomor_telepon_pemilik_kandang'],
        emailPemilikKandang: json['email_pemilik_kandang'],
      );

  Map<String, dynamic> toJson() => {
        'id_kandang': idKandang,
        'id_product': idProduct,
        'nama_kandang': namaKandang,
        'kapasitas': kapasitas,
        'tanggal_dibangun': tanggalDibangun?.toIso8601String(),
        'jenis_kandang': jenisKandang,
        'status_kandang': statusKandang,
        'alamat': alamat,
        'nomor_telepon_pemilik_kandang': phonePemilikKandang,
        'email_pemilik_kandang': emailPemilikKandang,
      };
}
