import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'identity_alamat_lahir_ternak.g.dart';

@HiveType(typeId: LocalTypeId.identityAlamatLahirTernak)
class AlamatLahirTernak extends HiveObject {
  AlamatLahirTernak({
    required this.id,
    required this.idProvince,
    required this.province,
    required this.idDistrict,
    required this.district,
    required this.idSubDistrict,
    required this.subDistrict,
    required this.idVillage,
    required this.urbanVillage,
    required this.rt,
    required this.rw,
    required this.longitude,
    required this.latitude,
    required this.address,
    this.zipCode,
  });

  @HiveField(0)
  final String id;

  @HiveField(1)
  final String idProvince;

  @HiveField(2)
  final String province;

  @HiveField(3)
  final String idDistrict;

  @HiveField(4)
  final String district;

  @HiveField(5)
  final String idSubDistrict;

  @HiveField(6)
  final String subDistrict;

  @HiveField(7)
  final String idVillage;

  @HiveField(8)
  final String urbanVillage;

  @HiveField(9)
  final String? rt;

  @HiveField(10)
  final String? rw;

  @HiveField(11)
  final String longitude;

  @HiveField(12)
  final String latitude;

  @HiveField(13)
  final String address;

  @HiveField(14)
  final String? zipCode;

  factory AlamatLahirTernak.fromJson(Map<String, dynamic> json) =>
      AlamatLahirTernak(
        id: json['id'],
        idProvince: json['id_province'],
        province: json['province'],
        idDistrict: json['id_district'],
        district: json['district'],
        idSubDistrict: json['id_sub_district'],
        subDistrict: json['sub_district'],
        idVillage: json['id_village'],
        urbanVillage: json['urban_village'],
        rt: json['rt'],
        rw: json['rw'],
        longitude: json['longitude'],
        latitude: json['latitude'],
        address: json['address'],
        zipCode: json['zip_code'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'id_province': idProvince,
        'province': province,
        'id_district': idDistrict,
        'district': district,
        'id_sub_district': idSubDistrict,
        'sub_district': subDistrict,
        'id_village': idVillage,
        'urban_village': urbanVillage,
        'rt': rt,
        'rw': rw,
        'longitude': longitude,
        'latitude': latitude,
        'address': address,
        'zip_code': zipCode,
      };
}
