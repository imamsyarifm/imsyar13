import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'ternak_birthday_request.g.dart';

@HiveType(typeId: LocalTypeId.ternakBirthdayRequest)
class TernakBirthdayRequest extends HiveObject {
  static const localName = 'ternak_birthday_request';

  @HiveField(0)
  final String? province;

  @HiveField(1)
  final String? district;

  @HiveField(2)
  final String? subDistrict;

  @HiveField(3)
  final String? village;

  @HiveField(4)
  final String address;

  @HiveField(5)
  final String rt;

  @HiveField(6)
  final String rw;

  @HiveField(7)
  final String latitude;

  @HiveField(8)
  final String longitude;

  TernakBirthdayRequest({
    this.province,
    this.district,
    this.subDistrict,
    this.village,
    required this.address,
    required this.rt,
    required this.rw,
    required this.latitude,
    required this.longitude,
  });

  Map<String, dynamic> get toMap {
    return {
      'id_province': province,
      'id_district': district,
      'id_sub_district': subDistrict,
      'id_village': village,
      'address': address,
      'rt': rt,
      'rw': rw,
      'latitude': latitude,
      'longitude': longitude,
    };
  }
}
