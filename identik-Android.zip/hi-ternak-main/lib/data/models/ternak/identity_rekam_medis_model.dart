import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'identity_rekam_medis_model.g.dart';

@HiveType(typeId: LocalTypeId.identityRekamMedis)
class IdentityRekamMedisModel extends HiveObject {
  IdentityRekamMedisModel({
    required this.idProduct,
    required this.kategori,
    required this.mulaiSakit,
    required this.diagnosa,
    required this.penanganan,
    required this.jenis,
    required this.dosis,
    required this.bunting,
    required this.sapih,
    this.batchNumber,
    required this.keterangan,
    this.tanggalInput,
    this.vaksin,
  });

  @HiveField(0)
  final String? idProduct;

  @HiveField(1)
  final String? kategori;

  @HiveField(2)
  final int? mulaiSakit;

  @HiveField(3)
  final String? diagnosa;

  @HiveField(4)
  final String? penanganan;

  @HiveField(5)
  final String? jenis;

  @HiveField(6)
  final String? dosis;

  @HiveField(7)
  final String? bunting;

  @HiveField(8)
  final String? sapih;

  @HiveField(9)
  final String? batchNumber;

  @HiveField(10)
  final String? keterangan;

  @HiveField(11)
  final DateTime? tanggalInput;

  @HiveField(12)
  final String? vaksin;

  factory IdentityRekamMedisModel.fromJson(Map<String, dynamic> json) =>
      IdentityRekamMedisModel(
        idProduct: json['id_product'],
        kategori: json['kategori'],
        mulaiSakit: json['mulai_sakit'],
        diagnosa: json['diagnosa'],
        penanganan: json['penanganan'],
        jenis: json['jenis'],
        dosis: json['dosis'],
        bunting: json['bunting'],
        sapih: json['sapih'],
        batchNumber: json['batch_number'],
        keterangan: json['keterangan'],
        tanggalInput: (json['tanggal_input'] == null)
            ? null
            : DateTime.parse(json['tanggal_input']),
        vaksin: json['vaksin'],
      );

  Map<String, dynamic> toJson() => {
        'id_product': idProduct,
        'kategori': kategori,
        'mulai_sakit': mulaiSakit,
        'diagnosa': diagnosa,
        'penanganan': penanganan,
        'jenis': jenis,
        'dosis': dosis,
        'bunting': bunting,
        'sapih': sapih,
        'batch_number': batchNumber,
        'keterangan': keterangan,
        'tanggal_input':
            (tanggalInput == null) ? null : tanggalInput!.toIso8601String(),
        'vaksin': vaksin,
      };
}
