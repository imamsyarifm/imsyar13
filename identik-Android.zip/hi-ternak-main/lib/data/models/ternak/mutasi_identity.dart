import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'mutasi_identity.g.dart';

@HiveType(typeId: LocalTypeId.identityMutasi)
class MutasiIdentity extends HiveObject {
  MutasiIdentity({
    required this.id,
    required this.idUser,
    required this.idProduct,
    required this.tanggalMutasi,
    required this.statusMutasi,
    required this.opsiPotong,
    required this.rph,
    required this.bobotTerakhir,
    required this.isRegister,
    required this.idPemilikBaru,
    required this.namaPemilikBaru,
    required this.namaKandangBaru,
    required this.namaPemilikLama,
    required this.namaKandangLama,
    required this.pathPhoto,
    required this.name,
    required this.keterangan,
    this.urlImage,
  });

  @HiveField(0)
  final String id;

  @HiveField(1)
  final String idUser;

  @HiveField(2)
  final String idProduct;

  @HiveField(3)
  final DateTime tanggalMutasi;

  @HiveField(4)
  final String statusMutasi;

  @HiveField(5)
  final String? opsiPotong;

  @HiveField(6)
  final String? rph;

  @HiveField(7)
  final String bobotTerakhir;

  @HiveField(8)
  final int? isRegister;

  @HiveField(9)
  final String? idPemilikBaru;

  @HiveField(10)
  final String? namaPemilikBaru;

  @HiveField(11)
  final String? namaKandangBaru;

  @HiveField(12)
  final String? namaPemilikLama;

  @HiveField(13)
  final String? namaKandangLama;

  @HiveField(14)
  final String pathPhoto;

  @HiveField(15)
  final String name;

  @HiveField(16)
  final String keterangan;

  @HiveField(17)
  final String? urlImage;

  factory MutasiIdentity.fromJson(Map<String, dynamic> json) => MutasiIdentity(
        id: json['id'] ?? '',
        idUser: json['id_user'] ?? '',
        idProduct: json['id_product'] ?? '',
        tanggalMutasi: DateTime.parse(json['tanggal_mutasi']),
        statusMutasi: json['status_mutasi'],
        opsiPotong: json['opsi_potong'] ?? '',
        rph: json['rph'] ?? '',
        bobotTerakhir: json['bobot_terakhir'] ?? '0',
        isRegister: json['is_register'] ?? 0,
        idPemilikBaru: json['id_pemilik_baru'] ?? '',
        namaPemilikBaru: json['nama_pemilik_baru'] ?? '',
        namaKandangBaru: json['nama_kandang_baru'] ?? '',
        namaPemilikLama: json['nama_pemilik_lama'] ?? '',
        namaKandangLama: json['nama_kandang_lama'] ?? '',
        pathPhoto: json['path_photo'] ?? '',
        name: json['name'] ?? '',
        keterangan: json['keterangan'] ?? '',
        urlImage: json['url_image'] ?? '',
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'id_user': idUser,
        'id_product': idProduct,
        'tanggal_mutasi': '${tanggalMutasi.year.toString().padLeft(4, '0')}-'
            '${tanggalMutasi.month.toString().padLeft(2, '0')}-'
            '${tanggalMutasi.day.toString().padLeft(2, '0')}',
        'status_mutasi': statusMutasi,
        'opsi_potong': opsiPotong,
        'rph': rph,
        'bobot_terakhir': bobotTerakhir,
        'is_register': isRegister,
        'id_pemilik_baru': idPemilikBaru,
        'nama_pemilik_baru': namaPemilikBaru,
        'nama_kandang_baru': namaKandangBaru,
        'nama_pemilik_lama': namaPemilikLama,
        'nama_kandang_lama': namaKandangLama,
        'path_photo': pathPhoto,
        'name': name,
        'keterangan': keterangan,
        'url_image': urlImage,
      };
}
