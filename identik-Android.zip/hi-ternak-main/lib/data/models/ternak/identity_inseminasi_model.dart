import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'identity_inseminasi_model.g.dart';

@HiveType(typeId: LocalTypeId.identityInseminasi)
class IdentityInseminasiModel extends HiveObject {
  IdentityInseminasiModel({
    required this.idProduct,
    required this.metodePerkawinan,
    required this.tanggalInseminasi,
    required this.inseminasiKe,
    required this.idPenjantan,
    required this.idRumpunPejantan,
    required this.rumpunPenjantan,
    required this.kodeSemen,
    required this.petugas,
    required this.tanggalInseminasiTerakhir,
    required this.keterangan,
    this.kodeProduksi,
    this.produsen,
    this.eartagPejantan,
    this.tglProduksi,
  });

  @HiveField(0)
  final String? idProduct;

  @HiveField(1)
  final String? metodePerkawinan;

  @HiveField(2)
  final DateTime? tanggalInseminasi;

  @HiveField(3)
  final int? inseminasiKe;

  @HiveField(4)
  final String? idPenjantan;

  @HiveField(5)
  final String? idRumpunPejantan;

  @HiveField(6)
  final String? rumpunPenjantan;

  @HiveField(7)
  final String? kodeSemen;

  @HiveField(8)
  final String? petugas;

  @HiveField(9)
  final DateTime? tanggalInseminasiTerakhir;

  @HiveField(10)
  final String? keterangan;

  @HiveField(11)
  final String? kodeProduksi;

  @HiveField(12)
  final String? produsen;

  @HiveField(13)
  final String? eartagPejantan;

  @HiveField(14)
  final String? tglProduksi;

  factory IdentityInseminasiModel.fromJson(Map<String, dynamic> json) =>
      IdentityInseminasiModel(
        idProduct: json['id_product'],
        metodePerkawinan: json['metode_perkawinan'],
        tanggalInseminasi: DateTime.parse(json['tanggal_inseminasi']),
        inseminasiKe: json['inseminasi_ke'],
        idPenjantan: json['id_penjantan'],
        idRumpunPejantan: json['id_rumpun_pejantan'],
        rumpunPenjantan: json['rumpun_penjantan'],
        kodeSemen: json['kode_semen'],
        petugas: json['petugas'],
        tanggalInseminasiTerakhir: (json['tanggal_inseminasi_terakhir'] != null)
            ? DateTime.parse(json['tanggal_inseminasi_terakhir'])
            : null,
        keterangan: json['keterangan'],
        kodeProduksi: json['batch_number'],
        produsen: json['company_name'],
        eartagPejantan: json['id_eartag_pejantan'],
        tglProduksi: json['tanggal'],
      );

  Map<String, dynamic> toJson() {
    return {
      'id_product': idProduct,
      'metode_perkawinan': metodePerkawinan,
      'tanggal_inseminasi':
          '${tanggalInseminasi?.year.toString().padLeft(4, '0')}-'
              '${tanggalInseminasi?.month.toString().padLeft(2, '0')}-'
              '${tanggalInseminasi?.day.toString().padLeft(2, '0')}',
      'inseminasi_ke': inseminasiKe,
      'id_penjantan': idPenjantan,
      'id_rumpun_pejantan': idRumpunPejantan,
      'rumpun_penjantan': rumpunPenjantan,
      'kode_semen': kodeSemen,
      'petugas': petugas,
      'tanggal_inseminasi_terakhir':
          '${tanggalInseminasiTerakhir?.year.toString().padLeft(4, '0')}-'
              '${tanggalInseminasiTerakhir?.month.toString().padLeft(2, '0')}-'
              '${tanggalInseminasiTerakhir?.day.toString().padLeft(2, '0')}',
      'keterangan': keterangan,
    };
  }
}
