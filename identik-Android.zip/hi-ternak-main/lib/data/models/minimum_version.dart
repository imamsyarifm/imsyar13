class MinimumVersion {
    MinimumVersion({
        required this.android,
        required this.ios,
    });

    final int android;
    final int ios;

    factory MinimumVersion.fromJson(Map<String, dynamic> json) 
      => MinimumVersion(
        android: json['android'],
        ios: json['ios'],
    );

    Map<String, dynamic> toJson() => {
        'android': android,
        'ios': ios,
    };
}
