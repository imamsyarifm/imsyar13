import 'address/district_model.dart';
import 'address/province_model.dart';
import 'address/subdistrict_model.dart';
import 'address/village_model.dart';

class RegisterPeternak {
  final String name;
  final String username;
  final String phone;
  final String email;
  final ProvinceModel provinsi;
  final DistrictModel kabupaten;
  final SubdistrictModel kecamatan;
  final VillageModel desa;
  final String alamat;

  RegisterPeternak(
      {required this.name,
      required this.username,
      required this.phone,
      required this.email,
      required this.provinsi,
      required this.kabupaten,
      required this.kecamatan,
      required this.desa,
      required this.alamat});
}

class RegisterKelompok {
  final String name;
  final String namePic;
  final String phone;
  final ProvinceModel provinsi;
  final DistrictModel kabupaten;
  final SubdistrictModel kecamatan;
  final VillageModel desa;
  final String alamat;

  RegisterKelompok(
      {required this.name,
      required this.namePic,
      required this.phone,
      required this.provinsi,
      required this.kabupaten,
      required this.kecamatan,
      required this.desa,
      required this.alamat});
}

class Register {
  final RegisterPeternak peternak;
  final RegisterKelompok? kelompok;
  final String password;

  Register({required this.peternak, this.kelompok, required this.password});
}
