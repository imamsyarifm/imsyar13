import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'induk_jantan.g.dart';

@HiveType(typeId: LocalTypeId.indukJantan)
class IndukJantan extends HiveObject {
  static const localName = 'induk_jantan';

  IndukJantan({
    required this.codeProduct,
    required this.productType,
    required this.umurTernak,
    required this.jenisKelamin,
    required this.rumpun,
    required this.pemilik,
  });

  @HiveField(0)
  final String codeProduct;

  @HiveField(1)
  final String productType;

  @HiveField(2)
  final String umurTernak;

  @HiveField(3)
  final String jenisKelamin;

  @HiveField(4)
  final String rumpun;

  @HiveField(5)
  final String pemilik;

  factory IndukJantan.fromJson(Map<String, dynamic> json) => IndukJantan(
        codeProduct: json['code_product'],
        productType: json['product_type'],
        umurTernak: json['umur_ternak'],
        jenisKelamin: json['jenis_kelamin'],
        rumpun: json['rumpun'],
        pemilik: json['pemilik'],
      );

  Map<String, dynamic> toJson() => {
        'code_product': codeProduct,
        'product_type': productType,
        'umur_ternak': umurTernak,
        'jenis_kelamin': jenisKelamin,
        'rumpun': rumpun,
        'pemilik': pemilik,
      };
}
