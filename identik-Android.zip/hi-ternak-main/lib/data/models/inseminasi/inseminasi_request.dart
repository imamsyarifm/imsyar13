import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'inseminasi_request.g.dart';

@HiveType(typeId: LocalTypeId.inseminasiRequest)
class InseminasiRequest extends HiveObject {
  static const localName = 'inseminasi_request';

  InseminasiRequest({
    required this.idProduct,
    required this.metodePerkawinan,
    required this.tanggalInseminasi,
    this.kodeStraw,
    this.inseminasiKe,
    this.tanggalInseminasiTerakhir,
    this.idPetugas,
    this.idPenjantan,
    required this.keterangan,
    required this.id,
    this.isInput,
    this.passcode,
    this.kodeEmbrio,
  });

  @HiveField(0)
  final String idProduct;

  @HiveField(1)
  final String metodePerkawinan;

  @HiveField(2)
  final DateTime tanggalInseminasi;

  @HiveField(3)
  final String? kodeStraw;

  @HiveField(4)
  final String? inseminasiKe;

  @HiveField(5)
  final DateTime? tanggalInseminasiTerakhir;

  @HiveField(6)
  final String? idPetugas;

  @HiveField(7)
  final String? idPenjantan;

  @HiveField(8)
  final String keterangan;

  @HiveField(9)
  final int id;

  @HiveField(11)
  final int? isInput;

  @HiveField(12)
  final String? passcode;

  @HiveField(13)
  final String? kodeEmbrio;

  factory InseminasiRequest.fromJson(Map<String, dynamic> json) =>
      InseminasiRequest(
        idProduct: json['id_product'],
        metodePerkawinan: json['metode_perkawinan'],
        tanggalInseminasi: DateTime.parse(json['tanggal_inseminasi']),
        kodeStraw: json['kode_straw'],
        inseminasiKe: json['inseminasi_ke'],
        tanggalInseminasiTerakhir: (json['tanggal_inseminasi_terakhir'] != null)
            ? DateTime.parse(json['tanggal_inseminasi_terakhir'])
            : null,
        idPetugas: json['id_petugas'],
        idPenjantan: json['id_penjantan'],
        keterangan: json['keterangan'],
        id: json['id'],
        isInput: json['is_input'],
        passcode: json['passcode'],
        kodeEmbrio: json['id_embrio'],
      );

  Map<String, dynamic> toJson() {
    return {
      'id_product': idProduct,
      'metode_perkawinan': metodePerkawinan,
      'tanggal_inseminasi':
          '${tanggalInseminasi.year.toString().padLeft(4, '0')}-'
              '${tanggalInseminasi.month.toString().padLeft(2, '0')}-'
              '${tanggalInseminasi.day.toString().padLeft(2, '0')}',
      'kode_straw': kodeStraw,
      'inseminasi_ke': inseminasiKe,
      'tanggal_inseminasi_terakhir': (tanggalInseminasiTerakhir != null)
          ? '${tanggalInseminasiTerakhir!.year.toString().padLeft(4, '0')}-'
              '${tanggalInseminasiTerakhir!.month.toString().padLeft(2, '0')}-'
              '${tanggalInseminasiTerakhir!.day.toString().padLeft(2, '0')}'
          : null,
      'id_petugas': idPetugas,
      'id_penjantan': idPenjantan,
      'keterangan': keterangan,
      'id': id,
      'is_input': isInput,
      'passcode': passcode,
      'id_embrio': kodeEmbrio,
    };
  }
}
