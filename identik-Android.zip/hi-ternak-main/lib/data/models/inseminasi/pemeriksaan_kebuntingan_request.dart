class PemeriksaanKebuntinganRequest {
  PemeriksaanKebuntinganRequest({
    required this.idProduct,
    this.tanggal,
    this.isBunting,
    this.usiaBunting,
    this.estimasiKelahiran,
    this.keterangan,
    this.isInput,
    this.passcode,
  });

  final String idProduct;
  final DateTime? tanggal;
  final String? isBunting;
  final String? usiaBunting;
  final String? estimasiKelahiran;
  final String? keterangan;
  final int? isInput;
  final String? passcode;

  factory PemeriksaanKebuntinganRequest.fromJson(Map<String, dynamic> json) =>
      PemeriksaanKebuntinganRequest(
        idProduct: json['id_product'],
        tanggal: DateTime.parse(json['tanggal']),
        isBunting: json['bunting'],
        usiaBunting: json['usia_bunting'],
        estimasiKelahiran: json['estimasi_kelahiran'],
        keterangan: json['keterangan'],
        isInput: json['is_input'],
        passcode: json['passcode'],
      );

  Map<String, dynamic> toJson() => {
        'id_product': idProduct,
        'tanggal': '${tanggal!.year.toString().padLeft(4, '0')}-'
              '${tanggal!.month.toString().padLeft(2, '0')}-'
              '${tanggal!.day.toString().padLeft(2, '0')} '
              '${tanggal!.hour.toString().padLeft(2, '0')}:'
              '${tanggal!.minute.toString().padLeft(2, '0')}:'
              '${tanggal!.second.toString().padLeft(2, '0')}',
        'bunting': isBunting,
        'usia_bunting': usiaBunting,
        'estimasi_kelahiran': estimasiKelahiran,
        'keterangan': keterangan,
        'is_input': isInput,
        'passcode': passcode,
      };
}
