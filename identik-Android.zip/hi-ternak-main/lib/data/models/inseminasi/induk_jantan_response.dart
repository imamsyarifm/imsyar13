import 'induk_jantan.dart';

class IndukJantanResponse {
  IndukJantanResponse({
    required this.success,
    required this.message,
    required this.data,
  });

  final bool success;
  final String message;
  final List<IndukJantan> data;

  factory IndukJantanResponse.fromJson(Map<String, dynamic> json) =>
      IndukJantanResponse(
        success: json['success'],
        message: json['message'],
        data: List<IndukJantan>.from(
            json['data'].map((x) => IndukJantan.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        'success': success,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
      };
}
