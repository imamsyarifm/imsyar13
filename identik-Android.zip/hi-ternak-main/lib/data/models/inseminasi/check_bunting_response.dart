import 'check_bunting.dart';

class CheckBuntingResponse {
  CheckBuntingResponse({
    required this.success,
    required this.message,
    required this.data,
  });

  final int success;
  final String message;
  final CheckBuntingModel data;

  factory CheckBuntingResponse.fromJson(Map<String, dynamic> json) =>
      CheckBuntingResponse(
        success: json['code'],
        message: json['message'],
        data: CheckBuntingModel.fromJson(json['data']),
      );

  Map<String, dynamic> toJson() => {
        'code': success,
        'message': message,
        'data': data,
      };
}
