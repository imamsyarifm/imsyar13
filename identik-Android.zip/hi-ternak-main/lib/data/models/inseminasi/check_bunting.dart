class CheckBuntingModel {
  CheckBuntingModel({
    this.isInseminasi,
    this.umurBunting,
  });

  final String? isInseminasi;
  final int? umurBunting;

  factory CheckBuntingModel.fromJson(Map<String, dynamic> json) =>
      CheckBuntingModel(
        isInseminasi: json['inseminasi'],
        umurBunting: json['umur_bunting'],
      );

  Map<String, dynamic> toJson() => {
        'inseminasi': isInseminasi,
        'umur_bunting': umurBunting,
      };
}
