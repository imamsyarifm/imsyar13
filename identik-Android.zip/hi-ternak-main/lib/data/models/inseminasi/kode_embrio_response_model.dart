import 'kode_embrio_model.dart';

class KodeEmbrioResponseModel {
  KodeEmbrioResponseModel({
    required this.success,
    required this.message,
    required this.data,
  });

  final bool success;
  final String message;
  final List<KodeEmbrioModel> data;

  factory KodeEmbrioResponseModel.fromJson(Map<String, dynamic> json) =>
      KodeEmbrioResponseModel(
        success: json['success'],
        message: json['message'],
        data: List<KodeEmbrioModel>.from(
            json['data'].map((x) => KodeEmbrioModel.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        'success': success,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
      };
}
