class KodeEmbrioModel {
  KodeEmbrioModel({
    required this.id,
    this.idDonor,
    this.eartagBetina,
    this.idPejantan,
    this.eartagPenjantan,
    this.rumpunBetina,
    this.rumpunPenjantan,
  });

  final String id;
  final String? idDonor;
  final String? eartagBetina;
  final String? idPejantan;
  final String? eartagPenjantan;
  final String? rumpunBetina;
  final String? rumpunPenjantan;

  factory KodeEmbrioModel.fromJson(Map<String, dynamic> json) =>
      KodeEmbrioModel(
        id: json['id'],
        idDonor: json['id_donor'] ?? '-',
        eartagBetina: json['eartag_betina'] ?? '-',
        idPejantan: json['id_pejantan'] ?? '-',
        eartagPenjantan: json['eartag_pejantan'] ?? '-',
        rumpunBetina: json['rumpun_betina'] ?? '-',
        rumpunPenjantan: json['rumpun_pejantan'] ?? '-',
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'id_donor': idDonor,
        'eartag_betina': eartagBetina,
        'id_pejantan': idPejantan,
        'eartag_pejantan': eartagPenjantan,
        'rumpun_betina': rumpunBetina,
        'rumpun_pejantan': rumpunPenjantan,
      };
}
