enum FilterInbox { all, news, activities, consultation }
