import 'inbox_model.dart';

class InboxResponseModel {
    InboxResponseModel({
      required this.success,
      required this.message,
      required this.data,
    });

    final bool success;
    final String message;
    final List<InboxModel> data;

    factory InboxResponseModel.fromJson(Map<String, dynamic> json) 
      => InboxResponseModel(
        success: json['success'],
        message: json['message'],
        data: List<InboxModel>.from(json['data'].map((x)
          => InboxModel.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        'success': success,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
    };
}