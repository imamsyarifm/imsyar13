class InboxModel {
  InboxModel({
    required this.id,
    required this.title,
    required this.description,
    required this.pathImage,
    required this.urlImage,
    this.date,
  });

  final String id;
  final String title;
  final String description;
  final String pathImage;
  final String urlImage;
  final String? date;

  factory InboxModel.fromJson(Map<String, dynamic> json) => InboxModel(
      id: json['id'],
      title: json['title'],
      description: json['description'],
      pathImage: json['path_image'],
      urlImage: json['url_image'],
      date: json['date'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'path_image': pathImage,
        'url_image': urlImage,
        'date': date,
      };
}
