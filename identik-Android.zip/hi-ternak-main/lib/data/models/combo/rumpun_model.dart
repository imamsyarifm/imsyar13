import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';
import 'combo_model.dart';

part 'rumpun_model.g.dart';

@HiveType(typeId: LocalTypeId.rumpun)
class RumpunModel extends ComboModel {
  static const rumpun = 'rumpun';

  RumpunModel({
    required this.idJenisTernak,
    required this.jenisTernak,
    required super.label,
    required super.value,
  });

  @HiveField(4)
  final String idJenisTernak;

  @HiveField(5)
  final String jenisTernak;

  factory RumpunModel.fromJson(Map<String, dynamic> json) => RumpunModel(
        value: json['value'],
        label: json['label'],
        idJenisTernak: json['id_jenis_ternak'],
        jenisTernak: json['jenis_ternak'],
      );

  @override
  Map<String, dynamic> toJson() => {
        'value': value,
        'label': label,
        'id_jenis_ternak': idJenisTernak,
        'jenis_ternak': jenisTernak,
      };
}
