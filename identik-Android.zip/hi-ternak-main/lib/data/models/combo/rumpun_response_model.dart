import 'rumpun_model.dart';

class RumpunResponseModel {
  RumpunResponseModel({
    required this.success,
    required this.message,
    required this.data,
  });

  final bool success;
  final String message;
  final List<RumpunModel> data;

  factory RumpunResponseModel.fromJson(Map<String, dynamic> json) =>
      RumpunResponseModel(
        success: json['success'],
        message: json['message'],
        data: List<RumpunModel>.from(
            json['data'].map((x) => RumpunModel.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        'success': success,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
      };
}
