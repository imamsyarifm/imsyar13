import 'kode_straw_model.dart';

class KodeStrawResponseModel {
  KodeStrawResponseModel({
    required this.success,
    required this.message,
    required this.data,
  });

  final bool success;
  final String message;
  final List<KodeStrawModel> data;

  factory KodeStrawResponseModel.fromJson(Map<String, dynamic> json) =>
      KodeStrawResponseModel(
        success: json['success'],
        message: json['message'],
        data: List<KodeStrawModel>.from(
            json['data'].map((x) => KodeStrawModel.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        'success': success,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
      };
}
