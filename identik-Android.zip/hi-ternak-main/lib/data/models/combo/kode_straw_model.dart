class KodeStrawModel {
  KodeStrawModel({
    required this.id,
    this.namaProdusen,
    this.idPejantan,
    this.kodeProduksi,
    this.tanggalProduksi,
    this.nomerEartag,
    this.kodeStraw,
    this.rumpun,
  });

  final String id;
  final String? namaProdusen;
  final String? idPejantan;
  final String? kodeProduksi;
  final String? tanggalProduksi;
  final String? nomerEartag;
  final String? kodeStraw;
  final String? rumpun;

  factory KodeStrawModel.fromJson(Map<String, dynamic> json) => KodeStrawModel(
        id: json['id'],
        namaProdusen: json['company_name'] ?? '-',
        idPejantan: json['id_pejantan'],
        kodeProduksi: json['batch_number'],
        tanggalProduksi: json['tanggal'],
        nomerEartag: json['id_eartag_pejantan'],
        kodeStraw: json['kode_straw'],
        rumpun: json['rumpun'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'company_name': namaProdusen,
        'id_pejantan': idPejantan,
        'batch_number': kodeProduksi,
        'tanggal': tanggalProduksi,
        'id_eartag_pejantan': nomerEartag,
        'kode_straw': kodeStraw,
        'rumpun': rumpun,
      };
}
