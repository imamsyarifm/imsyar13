import 'combo_model.dart';

class ComboResponseModel {
    ComboResponseModel({
      required this.success,
      required this.message,
      required this.data,
    });

    final bool success;
    final String message;
    final List<ComboModel> data;

    factory ComboResponseModel.fromJson(Map<String, dynamic> json) 
      => ComboResponseModel(
        success: json['success'],
        message: json['message'],
        data: List<ComboModel>.from(json['data'].map((x) 
          => ComboModel.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        'success': success,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
    };
}