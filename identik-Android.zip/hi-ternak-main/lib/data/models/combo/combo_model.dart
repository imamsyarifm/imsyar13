import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'combo_model.g.dart';

@HiveType(typeId: LocalTypeId.combo)
class ComboModel extends HiveObject {
  static const categoryTernak = 'categoryTernak';
  static const categoryKeswan = 'categoryKeswan';
  static const gender = 'gender';
  static const genderTernak = 'gender_ternak';
  static const program = 'program';
  static const statusKandang = 'status_kandang';
  static const kandangStatus = 'kandang_status';
  static const kandang = 'kandang';
  static const asalTernak = 'asal_ternak';
  static const merkVaksin = 'merk_vaksin';
  static const jenisVaksin = 'jenis_vaksin';
  static const mutasiOwner = 'mutasi_owner';
  static const mutasiKandang = 'mutasi_kandang';
  static const strawCode = 'straw_code';
  static const inseminasiEmployee = 'inseminasi_employee';
  static const kondisiTernak = 'kondisi_ternak';
  static const jenisKelahiran = 'jenis_kelahiran';

  ComboModel({
    required this.value,
    required this.label,
    this.nik,
    this.alamat,
  });

  @HiveField(0)
  final String value;

  @HiveField(1)
  final String label;

  @HiveField(2)
  final String? nik;

  @HiveField(3)
  final String? alamat;

  factory ComboModel.fromJson(Map<String, dynamic> json) => ComboModel(
        value: json['value'],
        label: json['label'],
        nik: json['nik'],
        alamat: json['alamat_pemilik'],
      );

  Map<String, dynamic> toJson() => {
        'value': value,
        'label': label,
        'nik': nik,
        'alamat_pemilik': alamat,
      };
}
