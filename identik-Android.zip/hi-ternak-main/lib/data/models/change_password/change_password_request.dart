class ChangePasswordRequest {
    ChangePasswordRequest({
        required this.password,
        required this.confirmPassword,
    });

    final String password;
    final String confirmPassword;

    factory ChangePasswordRequest.fromJson(Map<String, dynamic> json) 
      => ChangePasswordRequest(
        password: json['password'],
        confirmPassword: json['confirm_password'],
    );

    Map<String, dynamic> toJson() => {
        'password': password,
        'confirm_password': confirmPassword,
    };
}
class ChangePasscodeRequest {
    ChangePasscodeRequest({
        required this.passcode,
        required this.confirmPasscode,
    });

    final String passcode;
    final String confirmPasscode;

    factory ChangePasscodeRequest.fromJson(Map<String, dynamic> json) 
      => ChangePasscodeRequest(
        passcode: json['passcode'],
        confirmPasscode: json['confirm_passcode'],
    );

    Map<String, dynamic> toJson() => {
        'passcode': passcode,
        'confirm_passcode': confirmPasscode,
    };
}