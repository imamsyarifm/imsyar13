class AreaKerja {
    AreaKerja({
        required this.idProvince,
        required this.idDistrict,
    });

    final String idProvince;
    final String idDistrict;

    factory AreaKerja.fromJson(Map<String, dynamic> json) => AreaKerja(
        idProvince: json['id_province'],
        idDistrict: json['id_district'],
    );

    Map<String, dynamic> toJson() => {
        'id_province': idProvince,
        'id_district': idDistrict,
    };
}