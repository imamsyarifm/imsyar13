import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'unit_usaha_address_request.g.dart';

@HiveType(typeId: LocalTypeId.unitUsahaAddressRequest)
class UnitUsahaAddressRequest extends HiveObject {
  static const localName = 'unit_usaha_address_request';

  UnitUsahaAddressRequest({
    required this.idProvince,
    required this.idDistrict,
    required this.idSubDistrict,
    required this.idVillage,
    required this.address,
    required this.rt,
    required this.rw,
    required this.latitude,
    required this.longitude,
  });

  @HiveField(0)
  final String? idProvince;

  @HiveField(1)
  final String? idDistrict;

  @HiveField(2)
  final String? idSubDistrict;

  @HiveField(3)
  final String? idVillage;

  @HiveField(4)
  final String address;

  @HiveField(5)
  final String rt;

  @HiveField(6)
  final String rw;

  @HiveField(7)
  final String latitude;

  @HiveField(8)
  final String longitude;

  factory UnitUsahaAddressRequest.fromJson(Map<String, dynamic> json) =>
      UnitUsahaAddressRequest(
        idProvince: json['id_province'],
        idDistrict: json['id_district'],
        idSubDistrict: json['id_sub_district'],
        idVillage: json['id_village'],
        address: json['address'],
        rt: json['rt'],
        rw: json['rw'],
        latitude: json['latitude'],
        longitude: json['longitude'],
      );

  Map<String, dynamic> toJson() => {
        'id_province': idProvince,
        'id_district': idDistrict,
        'id_sub_district': idSubDistrict,
        'id_village': idVillage,
        'address': address,
        'rt': rt,
        'rw': rw,
        'latitude': latitude,
        'longitude': longitude,
      };
}
