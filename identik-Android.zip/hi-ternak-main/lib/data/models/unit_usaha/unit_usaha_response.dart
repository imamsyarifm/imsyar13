import 'unit_usaha.dart';

class UnitUsahaResponse {
    UnitUsahaResponse({
        required this.code,
        required this.message,
        required this.data,
    });

    final int code;
    final String message;
    final List<UnitUsaha> data;

    factory UnitUsahaResponse.fromJson(Map<String, dynamic> json) 
      => UnitUsahaResponse(
        code: json['code'],
        message: json['message'],
        data: List<UnitUsaha>.from(json['data'].map((x) 
          => UnitUsaha.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
    };
}