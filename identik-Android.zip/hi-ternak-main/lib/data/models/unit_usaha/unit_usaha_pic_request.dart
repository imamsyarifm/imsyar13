import 'unit_usaha_address_request.dart';

class UnitUsahaPicRequest {
    UnitUsahaPicRequest({
      required this.name,
      required this.gender,
      required this.birthdate,
      required this.nik,
      required this.phone,
      required this.email,
      required this.address,
    });

    final String name;
    final String gender;
    final DateTime? birthdate;
    final String nik;
    final String phone;
    final String email;
    final UnitUsahaAddressRequest address;

    factory UnitUsahaPicRequest.fromJson(Map<String, dynamic> json) 
      => UnitUsahaPicRequest(
        name: json['name'],
        gender: json['gender'],
        birthdate: DateTime.parse(json['birthdate']),
        nik: json['nik'],
        phone: json['phone'],
        email: json['email'],
        address: UnitUsahaAddressRequest.fromJson(json['address']),
    );

    Map<String, dynamic> toJson() => {
        'name': name,
        'gender': gender,
        'birthdate': "${birthdate?.year.toString()
          .padLeft(4, '0')}-${birthdate?.month.toString()
          .padLeft(2, '0')}-${birthdate?.day.toString()
          .padLeft(2, '0')}",
        'nik': nik,
        'phone': phone,
        'email': email,
        'address': address.toJson(),
    };
}
