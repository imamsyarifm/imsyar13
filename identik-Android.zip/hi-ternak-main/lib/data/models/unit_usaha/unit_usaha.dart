import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';
import 'unit_usaha_addres.dart';

part 'unit_usaha.g.dart';

@HiveType(typeId: LocalTypeId.unitUsaha)
class UnitUsaha extends HiveObject {
  static const localName = 'unit_usaha';
  UnitUsaha({
    required this.id,
    this.idIsikhnas,
    required this.idUser,
    required this.idAddress,
    required this.companyName,
    required this.phone,
    required this.email,
    required this.picName,
    required this.picNik,
    required this.picGender,
    required this.picBirthdate,
    required this.picPhone,
    required this.picEmail,
    required this.picAlamat,
    required this.isGovermentOwned,
    required this.address,
    this.registrationNumber,
    this.isSynced = true,
  });

  @HiveField(0)
  final String id;

  @HiveField(1)
  final String? idIsikhnas;

  @HiveField(2)
  final String idUser;

  @HiveField(3)
  final String idAddress;

  @HiveField(4)
  final String companyName;

  @HiveField(5)
  final String phone;

  @HiveField(6)
  final String email;

  @HiveField(7)
  final String picName;

  @HiveField(8)
  final String picNik;

  @HiveField(9)
  final String picGender;

  @HiveField(10)
  final DateTime picBirthdate;

  @HiveField(11)
  final String picPhone;

  @HiveField(12)
  final String picEmail;

  @HiveField(13)
  final String picAlamat;

  @HiveField(14)
  final int? isGovermentOwned;

  @HiveField(15)
  final UnitUsahaAddress address;

  @HiveField(16)
  final String? registrationNumber;

  @HiveField(17)
  final bool isSynced;

  factory UnitUsaha.fromJson(Map<String, dynamic> json) => UnitUsaha(
        id: json['id'],
        idIsikhnas: json['id_isikhnas'],
        idUser: json['id_user'],
        idAddress: json['id_address'],
        companyName: json['company_name'],
        phone: json['phone'],
        email: json['email'],
        picName: json['pic_name'],
        picNik: json['pic_nik'],
        picGender: json['pic_gender'],
        picBirthdate: DateTime.parse(json['pic_birthdate'] ?? '1984-08-29'),
        picPhone: json['pic_phone'],
        picEmail: json['pic_email'],
        picAlamat: json['pic_alamat'],
        isGovermentOwned: json['is_goverment_owned'],
        address: UnitUsahaAddress.fromJson(json['address']),
        registrationNumber: json['registration_number']
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'id_isikhnas': idIsikhnas,
        'id_user': idUser,
        'id_address': idAddress,
        'company_name': companyName,
        'phone': phone,
        'email': email,
        'pic_name': picName,
        'pic_nik': picNik,
        'pic_gender': picGender,
        'pic_birthdate': '${picBirthdate.year.toString().padLeft(4, '0')}-'
            '${picBirthdate.month.toString().padLeft(2, '0')}-'
            '${picBirthdate.day.toString().padLeft(2, '0')}',
        'pic_phone': picPhone,
        'pic_email': picEmail,
        'pic_alamat': picAlamat,
        'is_goverment_owned': isGovermentOwned,
        'address': address.toJson(),
        'registration_number': registrationNumber,
      };
}
