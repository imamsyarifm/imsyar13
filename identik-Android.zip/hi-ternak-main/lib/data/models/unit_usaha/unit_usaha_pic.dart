class UnitUsahaPic {
    UnitUsahaPic({
      required this.id,
      required this.name,
      required this.phone,
      required this.email,
      required this.nik,
      required this.gender,
      required this.birthdate,
      required this.alamat,
    });

    final String id;
    final String name;
    final String phone;
    final String email;
    final String nik;
    final String? gender;
    final DateTime? birthdate;
    final String alamat;

    factory UnitUsahaPic.fromJson(Map<String, dynamic> json) => UnitUsahaPic(
        id: json['id'],
        name: json['name'],
        phone: json['phone'],
        email: json['email'],
        nik: json['nik'],
        gender: json['gender'],
        birthdate: json['birthdate'] == null ? null 
          : DateTime.parse(json['birthdate']),
        alamat: json['alamat'],
    );

    Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'phone': phone,
        'email': email,
        'nik': nik,
        'gender': gender,
        'birthdate': birthdate == null ? null : "${birthdate?.year.toString()
          .padLeft(4, '0')}-${birthdate?.month.toString()
          .padLeft(2, '0')}-${birthdate?.day.toString()
          .padLeft(2, '0')}",
        'alamat': alamat,
    };
}
