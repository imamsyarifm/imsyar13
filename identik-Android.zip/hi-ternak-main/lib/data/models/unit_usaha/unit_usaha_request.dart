import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';
import 'unit_usaha_address_request.dart';

part 'unit_usaha_request.g.dart';

@HiveType(typeId: LocalTypeId.unitUsahaRequest)
class UnitUsahaRequest extends HiveObject {
  static const localName = 'unit_usaha_request';

  UnitUsahaRequest({
    required this.id,
    required this.companyName,
    required this.phone,
    required this.email,
    required this.picNik,
    required this.picName,
    required this.picGender,
    required this.picBirthdate,
    required this.picPhone,
    required this.picEmail,
    required this.picAlamat,
    required this.idIsikhnas,
    required this.isGovermentOwned,
    required this.registrationNumber,
    required this.address,
  });

  @HiveField(0)
  final String? id;

  @HiveField(1)
  final String companyName;

  @HiveField(2)
  final String phone;

  @HiveField(3)
  final String email;

  @HiveField(4)
  final String picNik;

  @HiveField(5)
  final String picName;

  @HiveField(6)
  final String picGender;

  @HiveField(7)
  final DateTime? picBirthdate;

  @HiveField(8)
  final String picPhone;

  @HiveField(9)
  final String picEmail;

  @HiveField(10)
  final String picAlamat;

  @HiveField(11)
  final String? idIsikhnas;

  @HiveField(12)
  final String isGovermentOwned;

  @HiveField(13)
  final String registrationNumber;

  @HiveField(14)
  final UnitUsahaAddressRequest address;

  factory UnitUsahaRequest.fromJson(Map<String, dynamic> json) =>
      UnitUsahaRequest(
        id: json['id'],
        companyName: json['company_name'],
        phone: json['phone'],
        email: json['email'],
        picNik: json['pic_nik'],
        picName: json['pic_name'],
        picGender: json['pic_gender'],
        picBirthdate: (json['pic_birthdate'] != null)
            ? DateTime.parse(json['pic_birthdate'])
            : null,
        picPhone: json['pic_phone'],
        picEmail: json['pic_email'],
        picAlamat: json['pic_alamat'],
        idIsikhnas: json['id_isikhnas'],
        isGovermentOwned: json['is_goverment_owned'],
        registrationNumber: json['registration_number'],
        address: UnitUsahaAddressRequest.fromJson(json['address']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'company_name': companyName,
        'phone': phone,
        'email': email,
        'pic_nik': picNik,
        'pic_name': picName,
        'pic_gender': picGender,
        'pic_birthdate': '${picBirthdate?.year.toString().padLeft(4, '0')}-'
            '${picBirthdate?.month.toString().padLeft(2, '0')}-'
            '${picBirthdate?.day.toString().padLeft(2, '0')}',
        'pic_phone': picPhone,
        'pic_email': picEmail,
        'pic_alamat': picAlamat,
        'id_isikhnas': idIsikhnas,
        'is_goverment_owned': isGovermentOwned,
        'registration_number': registrationNumber,
        'address': address.toJson(),
      };
}
