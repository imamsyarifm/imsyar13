import 'district_model.dart';

class DistrictResponseModel {
    DistrictResponseModel({
      required this.code,
      required this.message,
      required this.data,
    });

    final int code;
    final String message;
    final List<DistrictModel> data;

    factory DistrictResponseModel.fromJson(Map<String, dynamic> json) 
      => DistrictResponseModel(
        code: json['code'],
        message: json['message'],
        data: List<DistrictModel>.from(json['data'].map((x) 
          => DistrictModel.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
    };
}