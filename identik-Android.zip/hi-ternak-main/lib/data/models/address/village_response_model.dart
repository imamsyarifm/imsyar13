import 'village_model.dart';

class VillageResponseModel {
    VillageResponseModel({
      required this.code,
      required this.message,
      required this.data,
    });

    final int code;
    final String message;
    final List<VillageModel> data;

    factory VillageResponseModel.fromJson(Map<String, dynamic> json) 
      => VillageResponseModel(
        code: json['code'],
        message: json['message'],
        data: List<VillageModel>.from(json['data'].map((x) 
          => VillageModel.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
    };
}