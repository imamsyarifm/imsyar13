import 'country_model.dart';

class CountryResponseModel {
    CountryResponseModel({
      required this.code,
      required this.message,
      required this.data,
    });

    final int code;
    final String message;
    final List<CountryModel> data;

    factory CountryResponseModel.fromJson(Map<String, dynamic> json) 
      => CountryResponseModel(
        code: json['code'],
        message: json['message'],
        data: List<CountryModel>.from(json['data'].map((x) 
          => CountryModel.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
    };
}