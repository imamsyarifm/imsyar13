import 'subdistrict_model.dart';

class SubdistrictResponseModel {
    SubdistrictResponseModel({
      required this.code,
      required this.message,
      required this.data,
    });

    final int code;
    final String message;
    final List<SubdistrictModel> data;

    factory SubdistrictResponseModel.fromJson(Map<String, dynamic> json) 
      => SubdistrictResponseModel(
        code: json['code'],
        message: json['message'],
        data: List<SubdistrictModel>.from(json['data'].map((x) 
          => SubdistrictModel.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
    };
}