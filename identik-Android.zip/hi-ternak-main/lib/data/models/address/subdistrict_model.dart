import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'subdistrict_model.g.dart';

@HiveType(typeId: LocalTypeId.subDistrict)
class SubdistrictModel extends HiveObject {
  static const localName = 'subdistrict';

  SubdistrictModel({
    required this.id,
    required this.idDisctrict,
    required this.subDistrict,
    required this.createdAt,
    required this.updatedAt,
  });

  @HiveField(0)
  final String id;

  @HiveField(1)
  final String idDisctrict;

  @HiveField(2)
  final String subDistrict;

  @HiveField(3)
  final DateTime createdAt;

  @HiveField(4)
  final DateTime updatedAt;

  factory SubdistrictModel.fromJson(Map<String, dynamic> json) =>
      SubdistrictModel(
        id: json['id'],
        idDisctrict: json['id_disctrict'],
        subDistrict: json['sub_district'],
        createdAt: DateTime.parse(json['created_at']),
        updatedAt: DateTime.parse(json['updated_at']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'id_disctrict': idDisctrict,
        'sub_district': subDistrict,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
      };
}
