import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'district_model.g.dart';

@HiveType(typeId: LocalTypeId.district)
class DistrictModel extends HiveObject {
  static const localName = 'district';

  DistrictModel({
    required this.id,
    required this.idProvince,
    required this.district,
    required this.latitude,
    required this.longitude,
    required this.createdAt,
    required this.updatedAt,
  });

  @HiveField(0)
  final String id;

  @HiveField(1)
  final String idProvince;

  @HiveField(2)
  final String district;

  @HiveField(3)
  final String latitude;

  @HiveField(4)
  final String longitude;

  @HiveField(5)
  final DateTime createdAt;

  @HiveField(6)
  final DateTime updatedAt;

  factory DistrictModel.fromJson(Map<String, dynamic> json) => DistrictModel(
        id: json['id'],
        idProvince: json['id_province'],
        district: json['district'],
        latitude: json['latitude'],
        longitude: json['longitude'],
        createdAt: DateTime.parse(json['created_at']),
        updatedAt: DateTime.parse(json['updated_at']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'id_province': idProvince,
        'district': district,
        'latitude': latitude,
        'longitude': longitude,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
      };
}
