import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'country_model.g.dart';

@HiveType(typeId: LocalTypeId.country)
class CountryModel extends HiveObject {
  static const localName = 'country';

  CountryModel({
    required this.id,
    required this.code,
    required this.phoneCode,
    required this.country,
    required this.createdAt,
    required this.updatedAt,
  });

  @HiveField(0)
  final int id;

  @HiveField(1)
  final String code;

  @HiveField(2)
  final String phoneCode;

  @HiveField(3)
  final String country;

  @HiveField(4)
  final DateTime createdAt;

  @HiveField(5)
  final DateTime updatedAt;

  factory CountryModel.fromJson(Map<String, dynamic> json) => CountryModel(
        id: json['id'],
        code: json['code'],
        phoneCode: json['phone_code'],
        country: json['country'],
        createdAt: DateTime.parse(json['created_at']),
        updatedAt: DateTime.parse(json['updated_at']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'code': code,
        'phone_code': phoneCode,
        'country': country,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
      };
}
