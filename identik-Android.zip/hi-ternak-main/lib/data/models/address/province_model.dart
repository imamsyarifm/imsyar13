import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'province_model.g.dart';

@HiveType(typeId: LocalTypeId.province)
class ProvinceModel extends HiveObject {
  static const localName = 'province';

  ProvinceModel({
    required this.id,
    required this.idCountry,
    required this.province,
    required this.createdAt,
    required this.updatedAt,
  });

  @HiveField(0)
  final String id;

  @HiveField(1)
  final String idCountry;

  @HiveField(2)
  final String province;

  @HiveField(3)
  final DateTime createdAt;

  @HiveField(4)
  final DateTime updatedAt;

  factory ProvinceModel.fromJson(Map<String, dynamic> json) => ProvinceModel(
        id: json['id'],
        idCountry: json['id_country'],
        province: json['province'],
        createdAt: DateTime.parse(json['created_at']),
        updatedAt: DateTime.parse(json['updated_at']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'id_country': idCountry,
        'province': province,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
      };
}
