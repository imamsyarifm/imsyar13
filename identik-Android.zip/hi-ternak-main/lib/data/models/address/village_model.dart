import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'village_model.g.dart';

@HiveType(typeId: LocalTypeId.village)
class VillageModel extends HiveObject {
  static const localName = 'village';

  VillageModel({
    required this.id,
    required this.idSubDistrict,
    required this.urbanVillage,
    required this.createdAt,
    required this.updatedAt,
  });

  @HiveField(0)
  final String id;

  @HiveField(1)
  final String idSubDistrict;

  @HiveField(2)
  final String urbanVillage;

  @HiveField(3)
  final DateTime createdAt;

  @HiveField(4)
  final DateTime updatedAt;

  factory VillageModel.fromJson(Map<String, dynamic> json) => VillageModel(
        id: json['id'],
        idSubDistrict: json['id_sub_district'],
        urbanVillage: json['urban_village'],
        createdAt: DateTime.parse(json['created_at']),
        updatedAt: DateTime.parse(json['updated_at']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'id_sub_district': idSubDistrict,
        'urban_village': urbanVillage,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
      };
}
