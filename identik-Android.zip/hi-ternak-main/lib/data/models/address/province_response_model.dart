import 'province_model.dart';

class ProvinceResponseModel {
    ProvinceResponseModel({
      required this.code,
      required this.message,
      required this.data,
    });

    final int code;
    final String message;
    final List<ProvinceModel> data;

    factory ProvinceResponseModel.fromJson(Map<String, dynamic> json) 
      => ProvinceResponseModel(
        code: json['code'],
        message: json['message'],
        data: List<ProvinceModel>.from(json['data'].map((x) 
          => ProvinceModel.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
    };
}