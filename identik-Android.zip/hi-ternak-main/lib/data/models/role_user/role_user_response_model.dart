import 'role_user_model.dart';

class RoleUserResponseModel {
    RoleUserResponseModel({
      required this.code,
      required this.message,
      required this.data,
    });

    final int code;
    final String message;
    final List<RoleUserModel> data;

    factory RoleUserResponseModel.fromJson(Map<String, dynamic> json)
      => RoleUserResponseModel(
        code: json['code'],
        message: json['message'],
        data: List<RoleUserModel>.from(json['data'].map((x) 
          => RoleUserModel.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
    };
}