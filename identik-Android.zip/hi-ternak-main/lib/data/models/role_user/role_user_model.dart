class RoleUserModel {
    RoleUserModel({
      required this.id,
      required this.label,
    });

    final String id;
    final String label;

    factory RoleUserModel.fromJson(Map<String, dynamic> json) => RoleUserModel(
        id: json['id'],
        label: json['label'],
    );

    Map<String, dynamic> toJson() => {
        'id': id,
        'label': label,
    };
}
