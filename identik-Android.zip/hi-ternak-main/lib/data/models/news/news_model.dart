class NewsModel {
    NewsModel({
      required this.id,
      required this.title,
      required this.description,
      required this.idType,
      required this.icon,
      required this.pathImage,
      required this.startDate,
      required this.endDate,
      required this.createdAt,
      required this.updatedAt,
      required this.status,
    });

    final String id;
    final String title;
    final String description;
    final String idType;
    final String icon;
    final String pathImage;
    final DateTime startDate;
    final DateTime endDate;
    final DateTime createdAt;
    final DateTime updatedAt;
    final int status;

    factory NewsModel.fromJson(Map<String, dynamic> json) => NewsModel(
        id: json['id'],
        title: json['title'],
        description: json['description'],
        idType: json['id_type'],
        icon: json['icon'],
        pathImage: json['path_image'],
        startDate: DateTime.parse(json['start_date']),
        endDate: DateTime.parse(json['end_date']),
        createdAt: DateTime.parse(json['created_at']),
        updatedAt: DateTime.parse(json['updated_at']),
        status: json['status'],
    );

    Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'id_type': idType,
        'icon': icon,
        'path_image': pathImage,
        'start_date': '${startDate.year.toString().padLeft(4, "0")}-'
          '${startDate.month.toString().padLeft(2, "0")}-'
          '${startDate.day.toString().padLeft(2, "0")}',
        'end_date': '${endDate.year.toString().padLeft(4, "0")}-'
                    '${endDate.month.toString().padLeft(2, "0")}-'
                    '${endDate.day.toString().padLeft(2, "0")}',
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
        'status': status,
    };
}
