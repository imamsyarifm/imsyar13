import 'news_model.dart';

class NewsResponseModel {
    NewsResponseModel({
      required this.success,
      required this.message,
      required this.data,
    });

    final String success;
    final String message;
    final List<NewsModel> data;

    factory NewsResponseModel.fromJson(Map<String, dynamic> json) 
      => NewsResponseModel(
        success: json['success'],
        message: json['message'],
        data: List<NewsModel>.from(json['data'].map((x)
          => NewsModel.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        'success': success,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
    };
}