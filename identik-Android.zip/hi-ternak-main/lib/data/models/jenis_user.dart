class JenisUser {
  final int id;
  final String name;

  const JenisUser({required this.id, required this.name});
}
