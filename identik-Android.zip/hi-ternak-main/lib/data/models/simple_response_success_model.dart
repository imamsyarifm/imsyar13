class SimpleResponseSuccessModel {
    SimpleResponseSuccessModel({
      required this.code,
      required this.message,
    });

    final int code;
    final String message;

    factory SimpleResponseSuccessModel.fromJson(Map<String, dynamic> json) 
      => SimpleResponseSuccessModel(
        code: json['code'],
        message: json['message'],
    );

    Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
    };
}