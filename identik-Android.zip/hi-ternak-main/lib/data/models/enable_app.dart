import 'minimum_version.dart';
import 'store.dart';

class EnableApp {
  EnableApp({
    required this.minimumVersion,
    required this.paymentStatus,
    required this.store,
  });

  final MinimumVersion minimumVersion;
  final bool paymentStatus;
  final Store store;

  factory EnableApp.fromJson(Map<String, dynamic> json) => EnableApp(
        minimumVersion: MinimumVersion.fromJson(json['minimum_version']),
        paymentStatus: json['payment_status'],
        store: Store.fromJson(
          json['store'],
        ),
      );

  Map<String, dynamic> toJson() => {
        'minimum_version': minimumVersion.toJson(),
        'payment_status': paymentStatus,
        'store': store.toJson(),
      };
}
