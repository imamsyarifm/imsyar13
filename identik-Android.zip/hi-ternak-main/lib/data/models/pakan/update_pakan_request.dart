import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'update_pakan_request.g.dart';

@HiveType(typeId: LocalTypeId.pakanRequest)
class UpdatePakanRequest extends HiveObject {
  static const localName = 'pakan_request';

  UpdatePakanRequest({
    required this.idKandang,
    required this.konsentrat,
    required this.rumputLapangan,
    required this.rumputUnggul,
    required this.leguminosa,
    required this.lainLain,
    required this.durasiHari,
    required this.keterangan,
    required this.tanggalInput,
    required this.id,
  });

  @HiveField(0)
  final String idKandang;

  @HiveField(1)
  final String konsentrat;

  @HiveField(2)
  final String rumputLapangan;

  @HiveField(3)
  final String rumputUnggul;

  @HiveField(4)
  final String leguminosa;

  @HiveField(5)
  final String lainLain;

  @HiveField(6)
  final String durasiHari;

  @HiveField(7)
  final String keterangan;

  @HiveField(8)
  final String tanggalInput;

  @HiveField(9)
  final int id;

  factory UpdatePakanRequest.fromJson(Map<String, dynamic> json) =>
      UpdatePakanRequest(
        idKandang: json['id_kandang'],
        konsentrat: json['konsentrat'],
        rumputLapangan: json['rumput_lapangan'],
        rumputUnggul: json['rumput_unggul'],
        leguminosa: json['leguminosa'],
        lainLain: json['lain_lain'],
        durasiHari: json['durasi_hari'],
        keterangan: json['keterangan'],
        tanggalInput: json['tanggal_input'],
        id: json['id'],
      );

  Map<String, dynamic> toJson() => {
        'id_kandang': idKandang,
        'konsentrat': konsentrat,
        'rumput_lapangan': rumputLapangan,
        'rumput_unggul': rumputUnggul,
        'leguminosa': leguminosa,
        'lain_lain': lainLain,
        'durasi_hari': durasiHari,
        'keterangan': keterangan,
        'tanggal_input': tanggalInput,
        'id': id,
      };
}
