class PakanData {
    PakanData({
        required this.id,
        required this.idKandang,
        required this.tanggalInput,
        required this.konsentrat,
        required this.rumputLapangan,
        required this.rumputUnggul,
        required this.leguminosa,
        required this.lainLain,
        required this.durasiHari,
        required this.keterangan,
        required this.createdBy,
        required this.updatedBy,
        required this.createdAt,
        required this.updatedAt,
    });

    final String id;
    final String idKandang;
    final DateTime tanggalInput;
    final String konsentrat;
    final String rumputLapangan;
    final String rumputUnggul;
    final String leguminosa;
    final String lainLain;
    final String durasiHari;
    final String keterangan;
    final String createdBy;
    final dynamic updatedBy;
    final DateTime createdAt;
    final DateTime updatedAt;

    factory PakanData.fromJson(Map<String, dynamic> json) => PakanData(
        id: json['id'],
        idKandang: json['id_kandang'],
        tanggalInput: DateTime.parse(json['tanggal_input']),
        konsentrat: json['konsentrat'],
        rumputLapangan: json['rumput_lapangan'],
        rumputUnggul: json['rumput_unggul'],
        leguminosa: json['leguminosa'],
        lainLain: json['lain_lain'],
        durasiHari: json['durasi_hari'],
        keterangan: json['keterangan'],
        createdBy: json['created_by'],
        updatedBy: json['updated_by'],
        createdAt: DateTime.parse(json['created_at']),
        updatedAt: DateTime.parse(json['updated_at']),
    );

    Map<String, dynamic> toJson() => {
        'id': id,
        'id_kandang': idKandang,
        'tanggal_input': "${tanggalInput.year.toString()
          .padLeft(4, '0')}-${tanggalInput.month.toString()
          .padLeft(2, '0')}-${tanggalInput.day.toString()
          .padLeft(2, '0')}",
        'konsentrat': konsentrat,
        'rumput_lapangan': rumputLapangan,
        'rumput_unggul': rumputUnggul,
        'leguminosa': leguminosa,
        'lain_lain': lainLain,
        'durasi_hari': durasiHari,
        'keterangan': keterangan,
        'created_by': createdBy,
        'updated_by': updatedBy,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
    };
}
