import 'pakan_data.dart';

class Pakan {
    Pakan({
        required this.id,
        required this.namaKandang,
        required this.kapasitas,
        required this.tanggalDibangun,
        required this.namaPemilikKandang,
        required this.nikPemilikKandang,
        required this.pakan,
    });

    final String id;
    final String namaKandang;
    final String kapasitas;
    final DateTime tanggalDibangun;
    final String? namaPemilikKandang;
    final String? nikPemilikKandang;
    final List<PakanData> pakan;

    factory Pakan.fromJson(Map<String, dynamic> json) => Pakan(
        id: json['id'],
        namaKandang: json['nama_kandang'],
        kapasitas: json['kapasitas'],
        tanggalDibangun: 
          DateTime.parse(json['tanggal_dibangun']),
        namaPemilikKandang: json['nama_pemilik_kandang'],
        nikPemilikKandang: json['nik_pemilik_kandang'],
        pakan: List<PakanData>.from(json['pakan'].map((x) 
          => PakanData.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        'id': id,
        'nama_kandang': namaKandang,
        'kapasitas': kapasitas,
        'tanggal_dibangun': tanggalDibangun.toIso8601String(),
        'nama_pemilik_kandang': namaPemilikKandang,
        'nik_pemilik_kandang': nikPemilikKandang,
        'pakan': List<PakanData>.from(pakan.map((x) => x.toJson())),
    };
}
