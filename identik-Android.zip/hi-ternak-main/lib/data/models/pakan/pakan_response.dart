import 'pakan.dart';

class PakanResponse {
    PakanResponse({
        required this.success,
        required this.message,
        required this.data,
    });

    final bool success;
    final String message;
    final List<Pakan> data;

    factory PakanResponse.fromJson(Map<String, dynamic> json) => PakanResponse(
        success: json['success'],
        message: json['message'],
        data: List<Pakan>.from(json['data'].map((x) => Pakan.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        'success': success,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
    };
}