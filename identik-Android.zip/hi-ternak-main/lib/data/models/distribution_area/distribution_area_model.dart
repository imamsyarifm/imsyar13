class DistributionAreaModel {
    DistributionAreaModel({
      required this.id,
      required this.value,
    });

    final int id;
    final String value;

    factory DistributionAreaModel.fromJson(Map<String, dynamic> json) 
      => DistributionAreaModel(
        id: json['id'],
        value: json['value'],
    );

    Map<String, dynamic> toJson() => {
        'id': id,
        'value': value,
    };
}
