import 'distribution_area_model.dart';

class DistributionAreaResponseModel {
    DistributionAreaResponseModel({
      required this.success,
      required this.message,
      required this.data,
    });

    final bool success;
    final String message;
    final List<DistributionAreaModel> data;

    factory DistributionAreaResponseModel.fromJson(Map<String, dynamic> json) 
      => DistributionAreaResponseModel(
        success: json['success'],
        message: json['message'],
        data: List<DistributionAreaModel>.from(json['data'].map((x) 
          => DistributionAreaModel.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        'success': success,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
    };
}
