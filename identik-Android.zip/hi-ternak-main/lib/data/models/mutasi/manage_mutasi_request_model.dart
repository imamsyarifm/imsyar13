import 'package:dio/dio.dart';
import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';
import '../../../utils/datetime_util.dart';

part 'manage_mutasi_request_model.g.dart';

@HiveType(typeId: LocalTypeId.mutasiRequest)
class ManageMutasiRequestModel extends HiveObject {
  static const localName = 'mutasi_request';

  ManageMutasiRequestModel({
    this.idProduct,
    required this.tanggalMutasi,
    this.statusMutasi,
    required this.bobotTerakhir,
    this.opsiPotong,
    this.idRph,
    this.isRegister,
    this.idPemilikBaru,
    this.idKandangBaru,
    required this.keterangan,
    this.pathPhoto,
    required this.id,
    this.isInput,
    this.passcode,
    this.bobotKarkas,
  });

  @HiveField(0)
  final String? idProduct;

  @HiveField(1)
  final DateTime tanggalMutasi;

  @HiveField(2)
  final int? statusMutasi;

  @HiveField(3)
  final String bobotTerakhir;

  @HiveField(4)
  final String? opsiPotong;

  @HiveField(5)
  final String? idRph;

  @HiveField(6)
  final int? isRegister;

  @HiveField(7)
  final String? idPemilikBaru;

  @HiveField(8)
  final String? idKandangBaru;

  @HiveField(9)
  final String keterangan;

  @HiveField(10)
  final String? pathPhoto;

  @HiveField(11)
  final int id;

  @HiveField(12)
  final int? isInput;

  @HiveField(13)
  final String? passcode;

  @HiveField(14)
  final String? bobotKarkas;

  factory ManageMutasiRequestModel.fromJson(Map<String, dynamic> json) =>
      ManageMutasiRequestModel(
        idProduct: json['id_product'],
        tanggalMutasi: DateTime.parse(json['tanggal_mutasi']),
        statusMutasi: json['status_mutasi'],
        bobotTerakhir: json['bobot_terakhir'],
        idPemilikBaru: json['id_pemilik_baru'],
        idKandangBaru: json['id_kandang_baru'],
        idRph: json['id_rph'],
        isRegister: json['is_register'],
        opsiPotong: json['opsi_potong'],
        keterangan: json['keterangan'],
        pathPhoto: json['path_photo'],
        id: json['id'],
        isInput: json['is_input'],
        passcode: json['passcode'],
        bobotKarkas: json['bobot_karkas'],
      );

  Map<String, dynamic> toJson() {
    return {
      'id_product': idProduct,
      'tanggal_mutasi': tanggalMutasi.valueApi(),
      'status_mutasi': statusMutasi,
      'bobot_terakhir': bobotTerakhir,
      'id_pemilik_baru': idPemilikBaru,
      'id_kandang_baru': idKandangBaru,
      'id_rph': idRph,
      'is_register': isRegister,
      'opsi_potong': opsiPotong,
      'keterangan': keterangan,
      'id': id,
      'is_input': isInput,
      'passcode': passcode,
      'bobot_karkas': bobotKarkas,
    };
  }

  Future<FormData> toFormData() async {
    final body = FormData.fromMap(toJson());

    if (pathPhoto != null) {
      final multipartFile = await MultipartFile.fromFile(pathPhoto!);
      body.files.add(MapEntry('path_photo', multipartFile));
    }

    return body;
  }
}
