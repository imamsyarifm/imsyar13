
class MutasiRequestModel {
    MutasiRequestModel({
        required this.codeProduct,
    });

    final String codeProduct;

    factory MutasiRequestModel.fromJson(Map<String, dynamic> json)
      => MutasiRequestModel(
        codeProduct: json['code_product'],
    );

    Map<String, dynamic> toJson() => {
        'code_product': codeProduct,
    };
}