import 'mutasi_data_model.dart';

class MutasiModel {
    MutasiModel({
        required this.id,
        required this.codeProduct,
        required this.idEartag,
        required this.idCategory,
        required this.jenisKelamin,
        required this.pathImage,
        required this.mutasi,
    });

    final String id;
    final String codeProduct;
    final String idEartag;
    final String idCategory;
    final String jenisKelamin;
    final String pathImage;
    final List<MutasiDataModel>? mutasi;

    factory MutasiModel.fromJson(Map<String, dynamic> json) => MutasiModel(
        id: json['id'],
        codeProduct: json['code_product'],
        idEartag: json['id_eartag'],
        idCategory: json['id_category'],
        jenisKelamin: json['jenis_kelamin'],
        pathImage: json['path_image'],
        mutasi: (json['mutasi'] != null)
          ? List<MutasiDataModel>.from(json['mutasi'].map((x) => x)) : null,
    );

    Map<String, dynamic> toJson() => {
        'id': id,
        'code_product': codeProduct,
        'id_eartag': idEartag,
        'id_category': idCategory,
        'jenis_kelamin': jenisKelamin,
        'path_image': pathImage,
        'mutasi': (mutasi != null)
          ?  List<MutasiDataModel>.from(mutasi!.map((x) => x)) : null,
    };
}
