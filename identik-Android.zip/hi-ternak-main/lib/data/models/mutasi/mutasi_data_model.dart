class MutasiDataModel {
  MutasiDataModel({
    required this.id,
    required this.idUser,
    required this.idProduct,
    required this.tanggalMutasi,
    required this.statusMutasi,
    required this.bobotTerakhir,
    required this.idPemilikBaru,
    required this.namaPemilikBaru,
    required this.keterangan,
    required this.urlImage,
  });

  final String id;
  final String idUser;
  final String idProduct;
  final DateTime tanggalMutasi;
  final String statusMutasi;
  final String bobotTerakhir;
  final String idPemilikBaru;
  final String namaPemilikBaru;
  final String keterangan;
  final String urlImage;

  factory MutasiDataModel.fromJson(Map<String, dynamic> json) =>
      MutasiDataModel(
        id: json['id'],
        idUser: json['id_user'],
        idProduct: json['id_product'],
        tanggalMutasi: DateTime.parse(json['tanggal_mutasi']),
        statusMutasi: json['status_mutasi'],
        bobotTerakhir: json['bobot_terakhir'],
        idPemilikBaru: json['id_pemilik_baru'],
        namaPemilikBaru: json['nama_pemilik_baru'],
        keterangan: json['keterangan'],
        urlImage: json['url_image'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'id_user': idUser,
        'id_product': idProduct,
        'tanggal_mutasi': '${tanggalMutasi.year.toString().padLeft(4, '0')}-'
            '${tanggalMutasi.month.toString().padLeft(2, '0')}-'
            '${tanggalMutasi.day.toString().padLeft(2, '0')}',
        'status_mutasi': statusMutasi,
        'bobot_terakhir': bobotTerakhir,
        'id_pemilik_baru': idPemilikBaru,
        'nama_pemilik_baru': namaPemilikBaru,
        'keterangan': keterangan,
        'url_image': urlImage,
      };
}
