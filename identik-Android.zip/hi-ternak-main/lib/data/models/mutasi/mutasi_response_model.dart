import 'mutasi_model.dart';

class MutasiResponseModel {
    MutasiResponseModel({
        required this.code,
        required this.message,
        required this.data,
    });

    final int code;
    final String message;
    final MutasiModel data;

    factory MutasiResponseModel.fromJson(Map<String, dynamic> json) 
      => MutasiResponseModel(
        code: json['code'],
        message: json['message'],
        data: MutasiModel.fromJson(json['data']),
    );

    Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
        'data': data.toJson(),
    };
}