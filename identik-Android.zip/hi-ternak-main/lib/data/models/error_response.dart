class ErrorResponse {
  ErrorResponse({
    this.code,
    required this.message,
  });

  final int? code;
  final String message;

  factory ErrorResponse.fromJson(Map<String, dynamic> json) => ErrorResponse(
        code: json['code'],
        message: json['message'],
      );

  Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
      };
}
