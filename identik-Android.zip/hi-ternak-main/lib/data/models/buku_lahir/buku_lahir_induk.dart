import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'buku_lahir_induk.g.dart';

@HiveType(typeId: LocalTypeId.bukuLahirInduk)
class BukuLahirInduk extends HiveObject {
  static const localName = 'buku_lahir_induk';

  BukuLahirInduk({
    required this.idInseminasi,
    required this.idProduct,
    required this.tanggalInseminasi,
    required this.metodePerkawinan,
    required this.idPenjantan,
  });

  @HiveField(0)
  final String idInseminasi;

  @HiveField(1)
  final String idProduct;

  @HiveField(2)
  final DateTime tanggalInseminasi;

  @HiveField(3)
  final String metodePerkawinan;

  @HiveField(4)
  final String? idPenjantan;

  factory BukuLahirInduk.fromJson(Map<String, dynamic> json) => BukuLahirInduk(
        idInseminasi: json['id_inseminasi'],
        idProduct: json['id_product'],
        tanggalInseminasi: DateTime.parse(json['tanggal_inseminasi']),
        metodePerkawinan: json['metode_perkawinan'],
        idPenjantan: json['id_penjantan'],
      );

  Map<String, dynamic> toJson() => {
        'id_inseminasi': idInseminasi,
        'id_product': idProduct,
        'tanggal_inseminasi':
            '${tanggalInseminasi.year.toString().padLeft(4, '0')}-'
                '${tanggalInseminasi.month.toString().padLeft(2, '0')}-'
                '${tanggalInseminasi.day.toString().padLeft(2, '0')}',
        'metode_perkawinan': metodePerkawinan,
        'id_penjantan': idPenjantan,
      };
}
