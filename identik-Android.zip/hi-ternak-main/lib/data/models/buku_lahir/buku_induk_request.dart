import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';
import '../../../utils/datetime_util.dart';

part 'buku_induk_request.g.dart';

@HiveType(typeId: LocalTypeId.bukuIndukRequest)
class BukuIndukRequest extends HiveObject {
  static const localName = 'buku_induk_request';

  BukuIndukRequest({
    this.idProduct,
    this.idInseminasi,
    this.tanggalLahir,
    this.jenisKelahiran,
    this.idCategory,
    this.jenisKelamin,
    this.kondisiTernak,
    this.beratBadan,
    this.panjangBadan,
    this.tinggiPundak,
    this.lingkarDada,
    this.idRumpun,
    this.program,
    this.umurJanin,
    this.sebabKeguguran,
    this.keterangan,
    required this.id,
    this.isInput,
    this.passcode,
  });

  @HiveField(0)
  final String? idProduct;

  @HiveField(1)
  final String? idInseminasi;

  @HiveField(2)
  final DateTime? tanggalLahir;

  @HiveField(3)
  final String? jenisKelahiran;

  @HiveField(4)
  final String? idCategory;

  @HiveField(5)
  final String? jenisKelamin;

  @HiveField(6)
  final String? kondisiTernak;

  @HiveField(7)
  final String? beratBadan;

  @HiveField(8)
  final String? panjangBadan;

  @HiveField(9)
  final String? tinggiPundak;

  @HiveField(10)
  final String? lingkarDada;

  @HiveField(11)
  final String? idRumpun;

  @HiveField(12)
  final String? program;

  @HiveField(13)
  final String? umurJanin;

  @HiveField(14)
  final String? sebabKeguguran;

  @HiveField(15)
  final String? keterangan;

  @HiveField(16)
  final int id;

  @HiveField(17)
  final int? isInput;

  @HiveField(18)
  final String? passcode;

  factory BukuIndukRequest.fromJson(Map<String, dynamic> json) =>
      BukuIndukRequest(
        idProduct: json['id_product'],
        idInseminasi: json['id_inseminasi'],
        tanggalLahir: DateTime.parse(json['tanggal_lahir']),
        jenisKelahiran: json['jenis_kelahiran'],
        idCategory: json['id_category'],
        jenisKelamin: json['jenis_kelamin'],
        kondisiTernak: json['kondisi_ternak'],
        beratBadan: json['berat_badan'],
        panjangBadan: json['panjang_badan'],
        tinggiPundak: json['tinggi_pundak'],
        lingkarDada: json['lingkar_dada'],
        idRumpun: json['id_rumpun'],
        program: json['program'],
        umurJanin: json['umur_janin'],
        sebabKeguguran: json['sebab_keguguran'],
        keterangan: json['keterangan'],
        id: json['id'],
        isInput: json['is_input'],
        passcode: json['passcode'],
      );

  Map<String, dynamic> toJson() => {
        'id_product': idProduct,
        'id_inseminasi': idInseminasi,
        'tanggal_lahir': tanggalLahir?.valueApi(),
        'jenis_kelahiran': jenisKelahiran,
        'id_category': idCategory,
        'jenis_kelamin': jenisKelamin,
        'kondisi_ternak': kondisiTernak,
        'berat_badan': beratBadan,
        'panjang_badan': panjangBadan,
        'tinggi_pundak': tinggiPundak,
        'lingkar_dada': lingkarDada,
        'id_rumpun': idRumpun,
        'program': program,
        'umur_janin': umurJanin,
        'sebab_keguguran': sebabKeguguran,
        'keterangan': keterangan,
        'id': id,
        'is_input': isInput,
        'passcode': passcode,
      };
}
