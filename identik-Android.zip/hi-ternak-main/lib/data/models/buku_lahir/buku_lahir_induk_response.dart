import 'buku_lahir_induk.dart';

class BukuLahirIndukResponse {
  BukuLahirIndukResponse({
    required this.code,
    required this.message,
    required this.data,
  });

  final int code;
  final String message;
  final List<BukuLahirInduk> data;

  factory BukuLahirIndukResponse.fromJson(Map<String, dynamic> json) =>
      BukuLahirIndukResponse(
        code: json['code'],
        message: json['message'],
        data: List<BukuLahirInduk>.from(
            json['data'].map((x) => BukuLahirInduk.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
        'data': List<dynamic>.from(data.map((x) => x.toJson())),
      };
}
