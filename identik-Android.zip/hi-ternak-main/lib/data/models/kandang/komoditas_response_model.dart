import 'komoditas_model.dart';

class KomoditasResponseModel {
  KomoditasResponseModel({
    required this.success,
    required this.message,
    required this.data,
  });

  final bool success;
  final String message;
  final List<KomoditasModel> data;

  factory KomoditasResponseModel.fromJson(Map<String, dynamic> json) =>
      KomoditasResponseModel(
        success: json['success'],
        message: json['message'],
        data: List<KomoditasModel>.from(
            json['data'].map((x) => KomoditasModel.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        'success': success,
        'message': message,
        'data': List<KomoditasModel>.from(data.map((x) => x.toJson())),
      };
}
