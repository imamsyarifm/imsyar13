import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'add_kandang_address_request_model.g.dart';

@HiveType(typeId: LocalTypeId.addKandangAddress)
class AddKandangAddressRequestModel extends HiveObject {
  static const localName = 'add_kandang_address';

  AddKandangAddressRequestModel({
    this.idProvince,
    this.idDistrict,
    this.idSubDistrict,
    this.idVillage,
    required this.address,
    required this.latitude,
    required this.longitude,
  });

  @HiveField(0)
  final String? idProvince;

  @HiveField(1)
  final String? idDistrict;

  @HiveField(2)
  final String? idSubDistrict;

  @HiveField(3)
  final String? idVillage;

  @HiveField(4)
  final String address;

  @HiveField(5)
  final String latitude;

  @HiveField(6)
  final String longitude;

  factory AddKandangAddressRequestModel.fromJson(Map<String, dynamic> json) =>
      AddKandangAddressRequestModel(
        idProvince: json['id_province'],
        idDistrict: json['id_district'],
        idSubDistrict: json['id_sub_district'],
        idVillage: json['id_village'],
        address: json['address'],
        latitude: json['latitude'],
        longitude: json['longitude'],
      );

  Map<String, dynamic> toJson() => {
        'id_province': idProvince,
        'id_district': idDistrict,
        'id_sub_district': idSubDistrict,
        'id_village': idVillage,
        'address': address,
        'latitude': latitude,
        'longitude': longitude,
      };
}
