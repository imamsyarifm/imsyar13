import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'kandang_owner_model.g.dart';

@HiveType(typeId: LocalTypeId.kandangOwner)
class KandangOwnerModel extends HiveObject {
  static const localName = 'kandang_owner';

  KandangOwnerModel({
    required this.id,
    required this.name,
    required this.phone,
    required this.email,
    required this.nik,
    required this.gender,
    required this.birthdate,
    required this.alamat,
  });

  @HiveField(0)
  final String id;

  @HiveField(1)
  final String name;

  @HiveField(2)
  final String phone;

  @HiveField(3)
  final String email;

  @HiveField(4)
  final String nik;

  @HiveField(5)
  final String? gender;

  @HiveField(6)
  final DateTime? birthdate;

  @HiveField(7)
  final String alamat;

  factory KandangOwnerModel.fromJson(Map<String, dynamic> json) =>
      KandangOwnerModel(
        id: json['id'],
        name: json['name'],
        phone: json['phone'],
        email: json['email'],
        nik: json['nik'],
        gender: json['gender'],
        birthdate: (json['birthdate'] != null)
            ? DateTime.parse(json['birthdate'])
            : null,
        alamat: json['alamat'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'phone': phone,
        'email': email,
        'nik': nik,
        'gender': gender,
        'birthdate': birthdate?.toIso8601String(),
        'alamat': alamat,
      };
}
