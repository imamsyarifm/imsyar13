import 'kandang_model.dart';

class KandangResponseModel {
  KandangResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  final int code;
  final String message;
  final List<KandangModel> data;

  factory KandangResponseModel.fromJson(Map<String, dynamic> json) =>
      KandangResponseModel(
        code: json['code'],
        message: json['message'],
        data: List<KandangModel>.from(
            json['data'].map((x) => KandangModel.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
        'data': List<KandangModel>.from(data.map((x) => x.toJson())),
      };
}
