import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'kandang_address_model.g.dart';

@HiveType(typeId: LocalTypeId.kandangAddress)
class KandangAddressModel extends HiveObject {
  static const localName = 'kandang_address';

  KandangAddressModel({
    required this.id,
    required this.idProvince,
    required this.province,
    required this.idDistrict,
    required this.district,
    required this.idSubDistrict,
    required this.subDistrict,
    required this.idVillage,
    required this.urbanVillage,
    required this.zipCode,
    required this.address,
    required this.rt,
    required this.rw,
    required this.latitude,
    required this.longitude,
  });

  @HiveField(0)
  final String id;

  @HiveField(1)
  final String idProvince;

  @HiveField(2)
  final String province;

  @HiveField(3)
  final String idDistrict;

  @HiveField(4)
  final String district;

  @HiveField(5)
  final String idSubDistrict;

  @HiveField(6)
  final String subDistrict;

  @HiveField(7)
  final String idVillage;

  @HiveField(8)
  final String urbanVillage;

  @HiveField(9)
  final String? zipCode;

  @HiveField(10)
  final String address;

  @HiveField(11)
  final String? rt;

  @HiveField(12)
  final String? rw;

  @HiveField(13)
  final String latitude;

  @HiveField(14)
  final String longitude;

  factory KandangAddressModel.fromJson(Map<String, dynamic> json) =>
      KandangAddressModel(
        id: json['id'],
        idProvince: json['id_province'],
        province: json['province'],
        idDistrict: json['id_district'],
        district: json['district'],
        idSubDistrict: json['id_sub_district'],
        subDistrict: json['sub_district'],
        idVillage: json['id_village'],
        urbanVillage: json['urban_village'],
        zipCode: json['zip_code'],
        address: json['address'],
        rt: json['rt'],
        rw: json['rw'],
        latitude: json['latitude'],
        longitude: json['longitude'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'id_province': idProvince,
        'province': province,
        'id_district': idDistrict,
        'district': district,
        'id_sub_district': idSubDistrict,
        'sub_district': subDistrict,
        'id_village': idVillage,
        'urban_village': urbanVillage,
        'zip_code': zipCode,
        'address': address,
        'rt': rt,
        'rw': rw,
        'latitude': latitude,
        'longitude': longitude,
      };
}
