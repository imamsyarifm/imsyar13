import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';
import 'add_kandang_address_request_model.dart';

part 'add_kandang_request_model.g.dart';

@HiveType(typeId: LocalTypeId.kandangRequest)
class AddKandangRequestModel extends HiveObject {
  static const localName = 'kandang_request';

  AddKandangRequestModel({
    required this.id,
    required this.namaKandang,
    required this.idPemilik,
    required this.tanggalDibangun,
    required this.kapasitas,
    required this.statusKandang,
    required this.isEqual,
    required this.address,
    required this.komoditasId,
  });

  @HiveField(0)
  final String? id;

  @HiveField(1)
  final String namaKandang;

  @HiveField(2)
  final String idPemilik;

  @HiveField(3)
  final DateTime tanggalDibangun;

  @HiveField(4)
  final String kapasitas;

  @HiveField(5)
  final String statusKandang;

  @HiveField(6)
  final String isEqual;

  @HiveField(7)
  final AddKandangAddressRequestModel address;

  @HiveField(8)
  final String komoditasId;

  factory AddKandangRequestModel.fromJson(Map<String, dynamic> json) =>
      AddKandangRequestModel(
        id: json['id'],
        namaKandang: json['nama_kandang'],
        idPemilik: json['id_pemilik'],
        tanggalDibangun: DateTime.parse(json['tanggal_dibangun']),
        kapasitas: json['kapasitas'],
        statusKandang: json['status_kandang'],
        isEqual: json['is_equal'],
        address: AddKandangAddressRequestModel.fromJson(json['address']),
        komoditasId: json['komoditas_id'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'nama_kandang': namaKandang,
        'id_pemilik': idPemilik,
        'tanggal_dibangun':
            '${tanggalDibangun.year.toString().padLeft(4, '0')}-'
                '${tanggalDibangun.month.toString().padLeft(2, '0')}-'
                '${tanggalDibangun.day.toString().padLeft(2, '0')}',
        'kapasitas': kapasitas,
        'status_kandang': statusKandang,
        'is_equal': isEqual,
        'address': address.toJson(),
        'komoditas_id': komoditasId,
      };
}
