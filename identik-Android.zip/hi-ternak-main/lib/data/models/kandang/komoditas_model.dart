import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'komoditas_model.g.dart';

@HiveType(typeId: LocalTypeId.komoditas)
class KomoditasModel extends HiveObject {
  static const localName = 'komoditas';

  KomoditasModel({
    required this.id,
    required this.komoditas,
    required this.keterangan,
  });

  @HiveField(0)
  final String id;

  @HiveField(1)
  final String komoditas;

  @HiveField(2)
  final String? keterangan;


  factory KomoditasModel.fromJson(Map<String, dynamic> json) =>
      KomoditasModel(
        id: json['id'],
        komoditas: json['komoditas'] ?? '',
        keterangan: json['keterangan'] ?? '',
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'id_address': komoditas,
        'id_user': keterangan,
      };
}
