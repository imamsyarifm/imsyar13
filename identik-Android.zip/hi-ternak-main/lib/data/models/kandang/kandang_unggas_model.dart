import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';
import 'kandang_address_model.dart';
import 'kandang_owner_model.dart';

@HiveType(typeId: LocalTypeId.kandangUnggas)
class KandangUnggasModel extends HiveObject {
  static const localName = 'kandang_unggas';

  KandangUnggasModel({
    required this.id,
    required this.idAddress,
    required this.idUser,
    required this.namaKandang,
    required this.kapasitas,
    required this.tanggalDibangun,
    required this.statusKandang,
    required this.createdAt,
    this.isEqual,
    required this.address,
    this.pemilikKandang,
    this.isSynced = true,
  });

  @HiveField(0)
  final String id;

  @HiveField(1)
  final String idAddress;

  @HiveField(2)
  final String? idUser;

  @HiveField(3)
  final String namaKandang;

  @HiveField(4)
  final String kapasitas;

  @HiveField(5)
  final DateTime tanggalDibangun;

  @HiveField(6)
  final String statusKandang;

  @HiveField(7)
  final DateTime createdAt;

  @HiveField(8)
  final String? isEqual;

  @HiveField(9)
  final KandangAddressModel address;

  @HiveField(10)
  final KandangOwnerModel? pemilikKandang;

  @HiveField(11)
  final bool isSynced;

  factory KandangUnggasModel.fromJson(Map<String, dynamic> json) =>
      KandangUnggasModel(
        id: json['id'],
        idAddress: json['id_address'],
        idUser: json['id_user'],
        namaKandang: json['nama_kandang'],
        kapasitas: json['kapasitas'],
        tanggalDibangun: DateTime.parse(json['tanggal_dibangun']),
        statusKandang: json['status_kandang'],
        createdAt: DateTime.parse(json['created_at']),
        isEqual: json['is_equal'],
        address: KandangAddressModel.fromJson(json['address']),
        pemilikKandang: (json['pemilik_kandang'] == null)
            ? null
            : KandangOwnerModel.fromJson(json['pemilik_kandang']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'id_address': idAddress,
        'id_user': idUser,
        'nama_kandang': namaKandang,
        'kapasitas': kapasitas,
        'tanggal_dibangun': tanggalDibangun.toIso8601String(),
        'status_kandang': statusKandang,
        'created_at': createdAt.toIso8601String(),
        'is_equal': isEqual,
        'address': address.toJson(),
        'pemilik_kandang': pemilikKandang?.toJson(),
      };
}
