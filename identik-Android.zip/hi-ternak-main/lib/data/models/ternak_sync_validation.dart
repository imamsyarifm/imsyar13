class TernakSyncValidation {
  TernakSyncValidation({
    required this.randomCode,
    required this.eartag,
  });

  final String randomCode;
  final String eartag;

  factory TernakSyncValidation.fromJson(Map<String, dynamic> json) =>
      TernakSyncValidation(
        randomCode: json['random_code'],
        eartag: json['eartag'],
      );

  Map<String, dynamic> toJson() => {
        'random_code': randomCode,
        'eartag': eartag,
      };
}
