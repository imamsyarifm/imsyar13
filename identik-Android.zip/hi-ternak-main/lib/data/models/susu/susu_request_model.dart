class SusuRequestModel {
    SusuRequestModel({
        required this.codeProduct,
    });

    final String codeProduct;

    factory SusuRequestModel.fromJson(Map<String, dynamic> json) 
      => SusuRequestModel(
        codeProduct: json['code_product'],
    );

    Map<String, dynamic> toJson() => {
        'code_product': codeProduct,
    };
}
