import 'package:hive/hive.dart';

import '../../../app/consts/local_type_id.dart';

part 'produksi_susu_request.g.dart';

@HiveType(typeId: LocalTypeId.produksiSusuRequest)
class ProduksiSusuRequest extends HiveObject {
  static const localName = 'produksi_susu_request';

  ProduksiSusuRequest({
    required this.idProduct,
    required this.laktasiKe,
    required this.tanggalSampling,
    required this.productTotalLiter,
    required this.keterangan,
    required this.id,
    this.isInput,
    this.passcode,
  });

  @HiveField(0)
  final String idProduct;

  @HiveField(1)
  final String laktasiKe;

  @HiveField(2)
  final DateTime tanggalSampling;

  @HiveField(3)
  final String productTotalLiter;

  @HiveField(4)
  final String keterangan;

  @HiveField(5)
  final int id;

  @HiveField(6)
  final int? isInput;

  @HiveField(7)
  final String? passcode;

  factory ProduksiSusuRequest.fromJson(Map<String, dynamic> json) =>
      ProduksiSusuRequest(
        idProduct: json['id_product'],
        laktasiKe: json['laktasi_ke'],
        tanggalSampling: DateTime.parse(json['tanggal_sampling']),
        productTotalLiter: json['product_total_liter'],
        keterangan: json['keterangan'],
        id: json['id'],
        isInput: json['is_input'],
        passcode: json['passcode'],
      );

  Map<String, dynamic> toJson() => {
        'id_product': idProduct,
        'laktasi_ke': laktasiKe,
        'tanggal_sampling':
            '${tanggalSampling.year.toString().padLeft(4, '0')}-'
                '${tanggalSampling.month.toString().padLeft(2, '0')}-'
                '${tanggalSampling.day.toString().padLeft(2, '0')}',
        'product_total_liter': productTotalLiter,
        'keterangan': keterangan,
        'id': id,
        'is_input': isInput,
        'passcode': passcode,
      };
}
