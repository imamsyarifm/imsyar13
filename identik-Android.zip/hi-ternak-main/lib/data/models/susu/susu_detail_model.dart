class SusuDetailModel {
    SusuDetailModel({
        required this.idProduct,
        required this.tanggalSampling,
        required this.laktasiKe,
        required this.productPagiLiter,
        required this.productPagiKg,
        required this.productSoreLiter,
        required this.productSoreKg,
        required this.productTotalLiter,
        required this.productTotalKg,
        required this.warna,
        required this.bau,
        required this.lemak,
        required this.protein,
        required this.ts,
        required this.snf,
        required this.laktosa,
        required this.density,
        required this.fpd,
        required this.acidity,
        required this.tpc,
        required this.ph,
    });

    final String idProduct;
    final DateTime tanggalSampling;
    final int laktasiKe;
    final String productPagiLiter;
    final String productPagiKg;
    final String productSoreLiter;
    final String productSoreKg;
    final String productTotalLiter;
    final String productTotalKg;
    final String warna;
    final String bau;
    final String lemak;
    final String protein;
    final String ts;
    final String snf;
    final String laktosa;
    final String density;
    final String fpd;
    final String acidity;
    final String tpc;
    final String ph;

    factory SusuDetailModel.fromJson(Map<String, dynamic> json) 
      => SusuDetailModel(
        idProduct: json['id_product'],
        tanggalSampling: DateTime.parse(json['tanggal_sampling']),
        laktasiKe: json['laktasi_ke'],
        productPagiLiter: json['product_pagi_liter'],
        productPagiKg: json['product_pagi_kg'],
        productSoreLiter: json['product_sore_liter'],
        productSoreKg: json['product_sore_kg'],
        productTotalLiter: json['product_total_liter'],
        productTotalKg: json['product_total_kg'],
        warna: json['warna'],
        bau: json['bau'],
        lemak: json['lemak'],
        protein: json['protein'],
        ts: json['ts'],
        snf: json['snf'],
        laktosa: json['laktosa'],
        density: json['density'],
        fpd: json['fpd'],
        acidity: json['acidity'],
        tpc: json['tpc'],
        ph: json['ph'],
    );

    Map<String, dynamic> toJson() => {
        'id_product': idProduct,
        'tanggal_sampling': "${tanggalSampling.year.toString().padLeft(4, 
          '0')}-${tanggalSampling.month.toString().padLeft(2, 
          '0')}-${tanggalSampling.day.toString().padLeft(2, '0')}",
        'laktasi_ke': laktasiKe,
        'product_pagi_liter': productPagiLiter,
        'product_pagi_kg': productPagiKg,
        'product_sore_liter': productSoreLiter,
        'product_sore_kg': productSoreKg,
        'product_total_liter': productTotalLiter,
        'product_total_kg': productTotalKg,
        'warna': warna,
        'bau': bau,
        'lemak': lemak,
        'protein': protein,
        'ts': ts,
        'snf': snf,
        'laktosa': laktosa,
        'density': density,
        'fpd': fpd,
        'acidity': acidity,
        'tpc': tpc,
        'ph': ph,
    };
}
