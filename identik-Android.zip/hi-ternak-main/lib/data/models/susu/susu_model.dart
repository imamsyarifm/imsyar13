import 'susu_detail_model.dart';

class SusuModel {
    SusuModel({
        required this.id,
        required this.codeProduct,
        required this.idEartag,
        required this.idCategory,
        required this.jenisKelamin,
        required this.pathImage,
        required this.susu,
    });

    final String id;
    final String codeProduct;
    final String idEartag;
    final String idCategory;
    final String jenisKelamin;
    final String pathImage;
    final List<SusuDetailModel> susu;

    factory SusuModel.fromJson(Map<String, dynamic> json) => SusuModel(
        id: json['id'],
        codeProduct: json['code_product'],
        idEartag: json['id_eartag'],
        idCategory: json['id_category'],
        jenisKelamin: json['jenis_kelamin'],
        pathImage: json['path_image'],
        susu: List<SusuDetailModel>.from(json['susu'].map((x) 
          => SusuDetailModel.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        'id': id,
        'code_product': codeProduct,
        'id_eartag': idEartag,
        'id_category': idCategory,
        'jenis_kelamin': jenisKelamin,
        'path_image': pathImage,
        'susu': List<dynamic>.from(susu.map((x) => x.toJson())),
    };
}