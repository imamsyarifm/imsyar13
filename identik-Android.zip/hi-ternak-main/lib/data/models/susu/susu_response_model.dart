import 'susu_model.dart';

class SusuResponseModel {
    SusuResponseModel({
        required this.code,
        required this.message,
        required this.data,
    });

    final int code;
    final String message;
    final SusuModel? data;

    factory SusuResponseModel.fromJson(Map<String, dynamic> json) 
      => SusuResponseModel(
        code: json['code'],
        message: json['message'],
        data: (json['data'] != null)
          ? SusuModel.fromJson(json['data']) : null,
    );

    Map<String, dynamic> toJson() => {
        'code': code,
        'message': message,
        'data': data?.toJson(),
    };
}