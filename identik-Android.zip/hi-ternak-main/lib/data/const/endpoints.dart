class Endpoints {
  // Address
  static const country = '/api/address/country';
  static const province = '/api/address/province';
  static const district = '/api/address/district';
  static const subdistrict = '/api/address/sub-district';
  static const village = '/api/address/village';
  static const onlyDistrict = '/api/address/only-district';

  // Pakan
  static const managePakan = '/api/product/manage-pakan';
  static const allPakan = '/api/product/list-pakan';

  // User Credentials
  static const role = '/api/role-user';
  static const register = '/api/register';
  static const login = '/api/login';
  // TODO: forgot password
  static const logout = '/api/logout';
  static const profile = '/api/profile';
  static const editProfile = '/api/edit-profile';
  static const changePassword = '/api/change-password';
  static const changePasscode = '/api/change-passcode';
  static const checkPasscode = '/api/check-passcode';
  static const ternakSyncValidation = '/api/send-message-validation';
  static const checkUpdate = '/api/version';

  // Inbox & Berita Informasi
  static const news = '/api/berita';
  static const inbox = '/api/inbox';
  static const inboxSent = '/api/list-send-message';
  static const activities = '/api/kegiatan';
  static const sendMessage = '/api/send';

  // Combo
  static const gender = '/api/combo/gender';
  static const comodity = '/api/combo/comodity';
  static const businessType = '/api/combo/business-type';
  static const salesProduct = '/api/combo/sales-product';
  static const religion = '/api/combo/religion';
  static const statusKandang = '/api/product/status-kandang';
  static const kelompok = '/api/kelompok';

  // Kandang
  static const kandang = '/api/kandang';
  static const kandangOwners = '/api/kandang/pemilik';
  static const kandangStatus = '/api/kandang/status';
  static const komoditas = '/api/kandang/komoditas';

  // Unit Usaha
  static const unitUsaha = '/api/kelompok/get';
  static const addUnitUsaha = '/api/kelompok';

  // Owner
  static const owners = '/api/pemilik';

  // Scan QR
  static const scan = '/api/product/scan';
  static const addTernak = '/api/product/create';
  static const productKandang = '/api/product/kandang';
  static const petugasVaksinasi = '/api/product/petugas-vaksinasi';
  static const mutasiReplaceEartag = '/api/product/replace-eartag';

  // Identitas Hewan
  static const kategoriTernak = '/api/product/kategori-ternak';
  static const asalTernak = '/api/product/asal-ternak';
  static const program = '/api/product/program';
  static const genderTernak = '/api/product/jenis-kelamin-ternak';
  static const setBirthday = '/api/product/penentuan-tanggal-lahir';
  static const perkawinanMethods = '/api/product/metode-perkawinan';
  static const bornTypes = '/api/product/tipe-kelahiran';
  static const allRumpun = '/api/product/rumpun';
  static const allTernak = '/api/product/identitas';
  static const biodataTernak = '/api/product/biodata';
  static const historyTernak = '/api/product/history';
  static const ownerTernak = '/api/product/kepemilikan';
  static const taniGroup = '/api/product/kelompok-tani';
  static const rumpun = '/api/product/rumpun';
  static const insentif = '/api/send/insentif';

  // Identitas Hewan Sample Version
  static const ternakType = '/api/product/jenis-ternak';
  static const distributionArea = '/api/product/daerah-distribusi';

  // Kesehatan Hewan
  static const keswanCategories = '/api/product/keswan-kategori';
  static const keswan = '/api/product/keswan';
  static const keswanBobot = '/api/product/keswan-bobot';
  static const keswanKesehatan = '/api/product/keswan-kesehatan';
  static const option = '/api/product/option';
  static const obat = '/api/product/vaksin-obat';
  static const jenisVaksin = '/api/product/jenis-vaksin';

  // Susu Hewan
  static const susu = '/api/product/susu';
  static const manageSusu = '/api/product/manage-susu';

  // Mutasi Hewan
  static const daftarPemilik = '/api/product/daftar-pemilik';
  static const statusMutasi = '/api/product/status-mutasi';
  static const mutasi = '/api/product/mutasi';
  static const manageMutasi = '/api/product/manage-mutasi';
  static const rph = '/api/product/rph';
  static const mutasiOwner = '/api/product/mutasi-pemilik';
  static const mutasiKandang = '/api/product/mutasi-kandang';
  static const mutasiAktivasi = '/api/product/activation';
  static const mutasiSubtitusi = '/api/product/exchange';

  static const lahirInduk = '/api/product/combo-lahir-induk';
  static const jenisKelahiran = '/api/product/jenis-kelahiran';
  static const kondisiTernak = '/api/product/kondisi-ternak';
  static const bukuLahir = '/api/product/buku-lahir';

  static const strawCode = '/api/product/kode-straw';
  static const embrioCode = '/api/product/embrio';
  static const inseminasiEmployee = '/api/product/petugas-inseminasi';
  static const indukJantan = '/api/product/induk-jantan';
  static const updateInseminasi = '/api/product/manage-inseminasi';
  static const updatePemeriksaanKebutingan = '/api/pkb';
  static const checkBunting = '/api/pkb/validation';
}
