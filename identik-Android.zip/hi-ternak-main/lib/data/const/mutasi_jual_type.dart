enum MutasiJualType {
  registered(1),
  outside(0);

  final int id;
  const MutasiJualType(this.id);
}
