enum MutasiPotongType {
  tradisional('tradisional'),
  rph('rph');

  final String id;
  const MutasiPotongType(this.id);
}
