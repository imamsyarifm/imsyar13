enum OwnerType {
  pemilik(1, 'Pemilik'),
  pemelihara(2, 'Pemelihara');

  final int value;
  final String label;

  const OwnerType(this.value, this.label);
}
