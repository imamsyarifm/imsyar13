enum MutationType {
  potong(2),
  mati(1),
  hilang(3),
  jual(4),
  pindah(5);

  final int id;
  const MutationType(this.id);
}
