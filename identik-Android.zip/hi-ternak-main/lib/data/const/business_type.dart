enum BusinessType {
  pemerintah(1, 'Pemerintah'),
  swasta(2, 'Swasta');

  final int value;
  final String label;

  const BusinessType(this.value, this.label);
}
