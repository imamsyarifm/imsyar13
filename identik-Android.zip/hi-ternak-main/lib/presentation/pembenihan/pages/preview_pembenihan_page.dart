import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../widgets/default_scaffold.dart';
import '../pembenihan_featured.dart';

class PreviewPembenihanPage extends StatelessWidget {
  const PreviewPembenihanPage({Key? key}) : super(key: key);

  static const routeName = '/preview-pembenihan-page';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Preview Data Pembenihan',
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Stack(
            children: [
              Container(
                margin: const EdgeInsets.only(bottom: 50),
                child: buildForm(context),
              ),
            ],
          ),
        ),
        bottomNavigation: buildAction(context),
      );

  Widget buildForm(BuildContext context) {
    return Form(
      child: ListView(
        children: [
          const SizedBox(height: 16),
          Text(
            'Mohon Periksa Kembali Data Yang Telah '
            'Diinputkan Pada Panen',
            style:
                GoogleFonts.roboto(fontSize: 18, fontWeight: FontWeight.w500),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 32),
          const Row(
            children: [
               Text('Scan Code'),
               SizedBox(width: 10),
               Text(':'),
               SizedBox(width: 5),
            ],
          ),
          const SizedBox(height: 16),
          const Row(
            children: [
               Text('Tanggal Implementasi'),
               SizedBox(width: 10),
               Text(':'),
               SizedBox(width: 5),
            ],
          ),
          const SizedBox(height: 16),
          const Row(
            children: [
               Text('Komoditas'),
               SizedBox(width: 10),
               Text(':'),
               SizedBox(width: 5),
            ],
          ),
          const SizedBox(height: 16),
          const Row(
            children: [
               Text('Jumlah'),
               SizedBox(width: 10),
               Text(':'),
               SizedBox(width: 5),
            ],
          ),
          const SizedBox(height: 16),
          const Row(
            children: [
               Text('Usia Ternak'),
               SizedBox(width: 10),
               Text(':'),
               SizedBox(width: 5),
            ],
          ),
          const SizedBox(height: 16),
          const Row(
            children: [
               Text('Bobot Ternak(kg)'),
               SizedBox(width: 10),
               Text(':'),
               SizedBox(width: 5),
            ],
          ),
          const SizedBox(height: 16),
          const Row(
            children: [
               Text('Keterangan'),
               SizedBox(width: 10),
               Text(':'),
               SizedBox(width: 5),
            ],
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget buildAction(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Row(children: [
        Expanded(
          child: Padding(
            padding:
                const EdgeInsets.only(left: 12, top: 12, bottom: 12, right: 6),
            child: SizedBox(
              height: 40,
              child: ElevatedButton(
                  onPressed: () => Get.back(),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(36))),
                  child: Text(
                    'BATAL',
                    style: GoogleFonts.roboto(
                        color: black,
                        fontSize: 14,
                        fontWeight: FontWeight.bold),
                  )),
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding:
                const EdgeInsets.only(right: 12, top: 12, bottom: 12, left: 6),
            child: SizedBox(
                height: 40,
                child: ElevatedButton(
                  onPressed: () => Get.to(const PasscodePembenihanPage()),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: yellowDark,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(36))),
                  child: Text(
                    'SIMPAN',
                    style: GoogleFonts.roboto(
                        color: black,
                        fontSize: 14,
                        fontWeight: FontWeight.bold),
                  ),
                )),
          ),
        ),
      ]),
    );
  }
}
