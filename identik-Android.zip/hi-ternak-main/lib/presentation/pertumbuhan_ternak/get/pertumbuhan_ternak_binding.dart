import 'package:get/get.dart';
import 'pertumbuhan_ternak_controller.dart';

class PertumbuhanTernakBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(PertumbuhanTernakController());
  }
}