import 'package:get/get.dart';
import '../params/pertumbuhan_ternak_params.dart';

class PertumbuhanTernakController extends GetxController {
  late PertumbuhanTernakParams params;

  @override
  void onInit() {
    super.onInit();
    retrieveArgs;
  }

  void get retrieveArgs {
    final args = Get.arguments;
    if (args is PertumbuhanTernakParams) {
      params = args;
    }
  }
}
