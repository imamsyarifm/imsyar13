import '../../../data/models/ternak/identity_ternak_model.dart';

class PertumbuhanTernakParams {
  final IdentityTernakModel ternak;
  final bool isFromScan;

  PertumbuhanTernakParams({
    required this.ternak,
    this.isFromScan = false,
  });
}
