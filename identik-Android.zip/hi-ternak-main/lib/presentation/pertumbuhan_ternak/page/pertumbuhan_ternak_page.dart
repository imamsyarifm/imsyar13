import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/ternak/identity_pertumbuhan_model.dart';
import '../../../utils/datetime_util.dart';
import '../../keswan/pages/keswan_edit_page.dart';
import '../../widgets/default_scaffold.dart';
import '../get/pertumbuhan_ternak_controller.dart';
import 'pertumbuhan_detail_page.dart';

class PertumbuhanTernakPage extends GetView<PertumbuhanTernakController> {
  static const routeName = '/pertumbuhan-ternak';
  const PertumbuhanTernakPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultScaffold(
      appBarTitle: 'Pertumbuhan ',
      body: ListView.separated(
        itemBuilder: (context, index) {
          final pertumbuhan = controller.params.ternak.pertumbuhan?[index];
          return pertumbuhanItem(
            codeProduct: controller.params.ternak.codeProduct ?? '-',
            context: context,
            pertumbuhan: pertumbuhan,
          );
        },
        separatorBuilder: (context, index) => const Divider(
          color: greyE5,
          height: 0,
        ),
        itemCount: controller.params.ternak.pertumbuhan?.length ?? 0,
      ),
      floatingAction: Visibility(
        visible: controller.params.isFromScan,
        child: FloatingActionButton(
          backgroundColor: green,
          onPressed: () => onUpdatePertumbuhan(context),
          child: const Icon(Icons.add),
        ),
      ),
    );
  }

  Widget pertumbuhanItem({
    required BuildContext context,
    required String codeProduct,
    IdentityPertumbuhanModel? pertumbuhan,
  }) {
    final tanggalInput = pertumbuhan?.tanggalInput?.readable() ?? '-';
    final usia = pertumbuhan?.usia ?? '';
    final title = '$tanggalInput ($usia bulan)';

    return Padding(
      padding: const EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: 8,
      ),
      child: GestureDetector(
        onTap: () => Get.to(PertumbuhanDetailPage(
          codeProduct: codeProduct,
          ternak: pertumbuhan,
        )),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: GoogleFonts.roboto(
                color: black,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
            Row(
              children: [
                Expanded(
                    child: Text(
                  'Berat Badan: ${pertumbuhan?.beratBadan}kg',
                  style: GoogleFonts.roboto(
                    fontSize: 12,
                    color: grey8,
                  ),
                )),
                const Icon(Icons.chevron_right)
              ],
            ),
          ],
        ),
      ),
    );
  }

  void onUpdatePertumbuhan(BuildContext context) {
    Get.toNamed(
      KeswanEditPage.routeName,
      arguments: controller.params,
    );
  }
}
