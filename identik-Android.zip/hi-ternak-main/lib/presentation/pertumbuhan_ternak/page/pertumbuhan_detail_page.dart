import 'package:flutter/material.dart';

import '../../../data/models/ternak/identity_pertumbuhan_model.dart';
import '../../../utils/datetime_util.dart';
import '../../widgets/component_tile.dart';
import '../../widgets/default_scaffold.dart';

class PertumbuhanDetailPage extends StatelessWidget {
  static const routeName = '/pertumbuhan-detail';
  const PertumbuhanDetailPage({
    required this.codeProduct,
    Key? key,
    this.ternak,
  }) : super(key: key);

  final String codeProduct;
  final IdentityPertumbuhanModel? ternak;

  @override
  Widget build(BuildContext context) {
    return DefaultScaffold(
      appBarTitle: codeProduct,
      body: ListView(children: [
        ComponentTile(
            title: 'Tanggal', value: ternak?.tanggalInput?.readable() ?? ''),
        ComponentTile(
            title: 'Berat Badan (kg)', value: ternak?.beratBadan ?? '-'),
        ComponentTile(
            title: 'Panjang Badan (cm)', value: ternak?.panjangBadan ?? '-'),
        ComponentTile(
            title: 'Tinggi Badan (cm)', value: ternak?.tinggiBadan ?? '-'),
        ComponentTile(
            title: 'Tinggi Pinggul (cm)', value: ternak?.tinggiPinggul ?? '-'),
        ComponentTile(
            title: 'Lebar Pinggul (cm)', value: ternak?.lebarPinggul ?? '-'),
        ComponentTile(
            title: 'Lingkar Data (cm)', value: ternak?.lingkarDada ?? '-'),
        ComponentTile(
            title: 'Lingkar Skrotum (cm)',
            value: ternak?.lingkarSkrotum ?? '-'),
        ComponentTile(
            title: 'Suhu Tubuh (celcius)', value: ternak?.suhuTubuh ?? '-'),
        const SizedBox(height: 100)
      ]),
    );
  }
}
