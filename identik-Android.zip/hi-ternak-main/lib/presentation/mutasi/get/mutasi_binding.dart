import 'package:get/get.dart';
import 'mutasi_controller.dart';

class MutasiBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(MutasiController());
  }
}
