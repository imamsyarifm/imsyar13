import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/address_repository.dart';
import '../../../data/repositories/combo_repository.dart';
import '../../../data/repositories/keswan_repository.dart';
import '../../../data/repositories/owner_repository.dart';
import '../../../data/repositories/setting_repository.dart';
import '../../../data/repositories/ternak_repository.dart';
import 'mutasi_subtitusi_eartag_edit_cotroller.dart';

class MutasiSubtitusiEartagEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(AddressRepository(
      client: Get.find<Dio>(),
    ));
    Get.put<TernakRepository>(TernakRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(ComboRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(SettingRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(OwnerRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(KeswanRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(MutasiSubtitusiEartagEditController(
      addressRepository: Get.find<AddressRepository>(),
      comboRepository: Get.find<ComboRepository>(),
      ternakRepository: Get.find<TernakRepository>(),
      settingRepository: Get.find<SettingRepository>(),
      ownerRepository: Get.find<OwnerRepository>(),
      keswanRepository: Get.find<KeswanRepository>(),
    ));
  }
}
