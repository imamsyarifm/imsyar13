import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/mutasi_repository.dart';
import 'mutasi_aktivasi_edit_controller.dart';

class MutasiAktivasiEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(MutasiRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(MutasiAktivasiEditController(
      repository: Get.find<MutasiRepository>(),
    ));
  }
}
