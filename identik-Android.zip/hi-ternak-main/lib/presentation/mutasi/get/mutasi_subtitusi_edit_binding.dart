import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/mutasi_repository.dart';
import 'mutasi_subtitusi_edit_controller.dart';

class MutasiSubtitusiEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(MutasiRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(MutasiSubtitusiEditController(
      repository: Get.find<MutasiRepository>(),
    ));
  }
}
