import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/mutasi_repository.dart';
import 'mutasi_edit_controller.dart';

class MutasiEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(MutasiRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(MutasiEditController(
      repository: Get.find<MutasiRepository>(),
    ));
  }
}
