import 'package:get/get.dart';
import 'package:intl/intl.dart';

class MutasiController extends GetxController {
  String date() {
    final dateFormat = DateFormat('dd MMMM yyyy');
    return dateFormat.format(DateTime.now());
  }
}
