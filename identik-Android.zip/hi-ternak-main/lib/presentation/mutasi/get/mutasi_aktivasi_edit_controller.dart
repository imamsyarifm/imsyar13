import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' hide FormData, MultipartFile;
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../data/const/mutasi_jual_type.dart';
import '../../../data/const/mutasi_potong_type.dart';
import '../../../data/const/mutation_type.dart';
import '../../../data/models/combo/combo_model.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../../../data/repositories/mutasi_repository.dart';
import '../../../utils/datetime_util.dart';
import '../../identitas/pages/identitas_detail_page.dart';
import '../../main/main_page.dart';
import '../params/mutasi_edit_params.dart';
import '../widgets/search_mutasi_kandang_delegate.dart';

class MutasiAktivasiEditController extends GetxController {
  final MutasiRepository _repository;

  MutasiAktivasiEditController({
    required MutasiRepository repository,
  }) : _repository = repository;

  final formKey = GlobalKey<FormState>();
  final etMutasiDate = TextEditingController();
  final etUmur = TextEditingController();
  final etPerkiraanBobot = TextEditingController();
  final etKeterangan = TextEditingController();
  final etMutasiPotongType = TextEditingController();
  final etMutasiJualType = TextEditingController();
  final etOwner = TextEditingController();
  final etKandang = TextEditingController();
  final etRph = TextEditingController();
  final etPhoto = TextEditingController();
  final imagePicker = ImagePicker();
  final pinController = TextEditingController();
  final focusNode = FocusNode();

  final _selectedStatus = ''.obs;
  final _selectedMutasiDate = DateTime.now().obs;
  final _ternak = Rx<IdentityTernakModel?>(null);
  final _type = Rx<MutationType?>(null);
  final _mutasiPotongType = Rx<MutasiPotongType?>(null);
  final _mutasiJualType = Rx<MutasiJualType?>(null);
  final _selectedPhoto = Rx<XFile?>(null);
  final _selectedOwner = Rx<ComboModel?>(null);
  final _kandangSelected = Rx<ComboModel?>(null);
  final _selectedRph = Rx<String?>(null);
  final _isUpdatingMutasi = false.obs;
  final _isFromProfile = false.obs;
  final _selectedMutasiFirstDate = DateTime.now().obs;
  final _firstDate = Rx<String?>(null);
  final _firstMonth = Rx<String?>(null);
  final _firstYear = Rx<String?>(null);

  String? get firstDate => _firstDate.value;
  String? get firstMonth => _firstMonth.value;
  String? get firstYear => _firstYear.value;
  DateTime get selectedMutasiFirstDate => _selectedMutasiFirstDate.value;

  String get selectedStatus => _selectedStatus.value;
  DateTime get selectedMutasiDate => _selectedMutasiDate.value;
  IdentityTernakModel? get ternak => _ternak.value;
  MutationType? get type => _type.value;
  MutasiPotongType? get mutasiPotongType => _mutasiPotongType.value;
  MutasiJualType? get mutasiJualType => _mutasiJualType.value;
  ComboModel? get selectedOwner => _selectedOwner.value;
  ComboModel? get selectedKandang => _kandangSelected.value;
  String? get selectedRph => _selectedRph.value;
  bool get isUpdatingMutasi => _isUpdatingMutasi.value;
  XFile? get selectedPhoto => _selectedPhoto.value;

  @override
  void onInit() {
    retrieveArgs();
    super.onInit();
    initialValue();
    setFirstDateMutasi();
  }

  void initialValue() {
    etMutasiDate.text = DateTime.now().readable();
  }

   void setFirstDateMutasi() {
    _selectedMutasiFirstDate.value = ternak!.mutasi.isEmpty
        ? ternak?.createdAt as DateTime
        : ternak?.mutasi.first.tanggalMutasi as DateTime;

    final dateFormatDay = DateFormat('dd');
    final dateFormatMonth = DateFormat('MM');
    final dateFormatYear = DateFormat('yyyy');

    _firstDate.value = dateFormatDay.format(_selectedMutasiFirstDate.value);
    _firstMonth.value = dateFormatMonth.format(_selectedMutasiFirstDate.value);
    _firstYear.value = dateFormatYear.format(_selectedMutasiFirstDate.value);
  }

  void retrieveArgs() {
    final args = Get.arguments;
    if (args is MutasiEditParams) {
      _ternak.value = args.ternak;
      _type.value = args.mutationType;
      _isFromProfile.value = args.isFromProfile;
    }
  }

  void setMutasiDate(DateTime dateTime) {
    _selectedMutasiDate.value = dateTime;
    final dateFormat = DateFormat('dd MMMM yyyy');
    etMutasiDate.text = dateFormat.format(dateTime);
  }

  void setMutasiPotongType(MutasiPotongType type) {
    _mutasiPotongType.value = type;
    etMutasiPotongType.text = (type == MutasiPotongType.tradisional)
        ? 'Tradisional'
        : 'Rumah Potong Hewan';
    Get.back();
  }

  void setMutasiJualType(MutasiJualType type) {
    _mutasiJualType.value = type;
    etMutasiJualType.text = (type == MutasiJualType.registered)
        ? 'Peternak Terdaftar'
        : 'Pihak Luar';
    Get.back();
  }

  void setPhoto(XFile? file) {
    _selectedPhoto.value = file;
    etPhoto.text = file?.name ?? file?.path ?? '';
    Get.back();
  }

  void setPemilik(ComboModel value) {
    _selectedOwner.value = value;
    etOwner.text = value.label;
  }

  Future<void> chooseKandang(BuildContext context) async {
    if (_selectedOwner.value == null) {
      Get.showSnackbar(const GetSnackBar(
        message: 'Silahkan pilih pemilik terlebih dahulu',
        duration: Duration(seconds: 3),
      ));
      return;
    }

    final kandangSelected = await showSearch(
      context: context,
      delegate: SearchMutasiKandangDelegate(
        idOwner: _selectedOwner.value!.value,
      ),
    );

    if (kandangSelected is ComboModel) {
      _kandangSelected.value = kandangSelected;
      etKandang.text = kandangSelected.label;
    }
  }

  void setSelectedRph(ComboModel value) {
    _selectedRph.value = value.value;
    etRph.text = value.label;
  }

  Future<void> save() async {
    if (formKey.currentState?.validate() == false) {
      return;
    }

    _isUpdatingMutasi.value = true;

    final prefs = await SharedPreferences.getInstance();
    final bool? isInput = prefs.getBool('isInput');

    try {
      if (isInput!) {
        if (pinController.text.length != 6) {
          Get.showSnackbar(const GetSnackBar(
            message: 'Passcode harus 6 digit',
            duration: Duration(seconds: 3),
          ));
          return;
        }
      }

      final payload = FormData.fromMap({
        'code_product': _ternak.value?.codeProduct,
        'is_input': 0,
      });

      final payloadInput = FormData.fromMap({
        'code_product': _ternak.value?.codeProduct,
        'is_input': 1,
        'passcode': pinController.text,
      });

      final update = await _repository
          .updateMutasiAktif(isInput ? payloadInput : payload);

      _isUpdatingMutasi.value = false;

      if (update) {
        if (_isFromProfile.value) {
          Get.until(
              (route) => route.settings.name == IdentitasDetailPage.routeName);
        } else {
          Get.until((route) => route.settings.name == MainPage.routeName);
        }
        Get.showSnackbar(const GetSnackBar(
          message: 'Penambahan Data Mutasi Berhasil',
          duration: Duration(seconds: 3),
        ));
      } else {
        Get.showSnackbar(const GetSnackBar(
          message: 'Penambahan Data Mutasi Gagal',
          duration: Duration(seconds: 3),
        ));
      }
    } catch (error) {
      _isUpdatingMutasi.value = false;
      Get.showSnackbar(GetSnackBar(
        title: 'Penambahan Data Mutasi Gagal',
        message: error.toString(),
        duration: const Duration(seconds: 3),
      ));
    }
  }
}
