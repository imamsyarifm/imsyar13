import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart' hide FormData, MultipartFile;
import 'package:intl/intl.dart';
import 'package:scanner/peruri_scanner.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../data/const/mutasi_jual_type.dart';
import '../../../data/const/mutasi_potong_type.dart';
import '../../../data/const/mutation_type.dart';
import '../../../data/models/combo/combo_model.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../../../data/repositories/mutasi_repository.dart';
import '../../../utils/datetime_util.dart';
import '../../identitas/pages/identitas_detail_page.dart';
import '../../main/main_page.dart';
import '../pages/preview_mutasi_subtitusi_page.dart';
import '../params/mutasi_edit_params.dart';

class MutasiSubtitusiEditController extends SuperController {
  final MutasiRepository _repository;

  MutasiSubtitusiEditController({
    required MutasiRepository repository,
  }) : _repository = repository;

  final formKey = GlobalKey<FormState>();
  final etMutasiDate = TextEditingController();
  final etOldEartag = TextEditingController();
  final etCode = TextEditingController();
  final etLocation = TextEditingController();
  final etNumber = TextEditingController();
  final etResult = TextEditingController();
  final pinController = TextEditingController();
  final focusNode = FocusNode();
  String? scanResult;

  final _selectedStatus = ''.obs;
  final _selectedMutasiDate = DateTime.now().obs;
  final _ternak = Rx<IdentityTernakModel?>(null);
  final _type = Rx<MutationType?>(null);
  final _mutasiPotongType = Rx<MutasiPotongType?>(null);
  final _mutasiJualType = Rx<MutasiJualType?>(null);
  final _selectedOwner = Rx<ComboModel?>(null);
  final _kandangSelected = Rx<ComboModel?>(null);
  final _selectedRph = Rx<String?>(null);
  final _isUpdatingMutasi = false.obs;
  final _isFromProfile = false.obs;
  final _selectedMutasiFirstDate = DateTime.now().obs;
  final _firstDate = Rx<String?>(null);
  final _firstMonth = Rx<String?>(null);
  final _firstYear = Rx<String?>(null);

  String? get firstDate => _firstDate.value;
  String? get firstMonth => _firstMonth.value;
  String? get firstYear => _firstYear.value;
  DateTime get selectedMutasiFirstDate => _selectedMutasiFirstDate.value;

  String get selectedStatus => _selectedStatus.value;
  DateTime get selectedMutasiDate => _selectedMutasiDate.value;
  IdentityTernakModel? get ternak => _ternak.value;
  MutationType? get type => _type.value;
  MutasiPotongType? get mutasiPotongType => _mutasiPotongType.value;
  MutasiJualType? get mutasiJualType => _mutasiJualType.value;
  ComboModel? get selectedOwner => _selectedOwner.value;
  ComboModel? get selectedKandang => _kandangSelected.value;
  String? get selectedRph => _selectedRph.value;
  bool get isUpdatingMutasi => _isUpdatingMutasi.value;

  @override
  void onInit() {
    retrieveArgs();
    super.onInit();
    initialValue();
    setFirstDateMutasi();
  }

  void initialValue() {
    etMutasiDate.text = DateTime.now().readable();
    etOldEartag.text = _ternak.value!.codeProduct.toString();
  }

  void retrieveArgs() {
    final args = Get.arguments;
    if (args is MutasiEditParams) {
      _ternak.value = args.ternak;
      _type.value = args.mutationType;
      _isFromProfile.value = args.isFromProfile;
    }
  }

  void setFirstDateMutasi() {
    _selectedMutasiFirstDate.value = ternak!.mutasi.isEmpty
        ? ternak?.createdAt as DateTime
        : ternak?.mutasi.first.tanggalMutasi as DateTime;

    final dateFormatDay = DateFormat('dd');
    final dateFormatMonth = DateFormat('MM');
    final dateFormatYear = DateFormat('yyyy');

    _firstDate.value = dateFormatDay.format(_selectedMutasiFirstDate.value);
    _firstMonth.value = dateFormatMonth.format(_selectedMutasiFirstDate.value);
    _firstYear.value = dateFormatYear.format(_selectedMutasiFirstDate.value);
  }

  String? validator(int length, String? value) {
    if (value == null) {
      return 'Tidak boleh kosong, harap isi minimal $length karakter';
    } else if (value.length < length) {
      return 'Harap isi minimal $length karakter';
    } else {
      return null;
    }
  }

  void setMutasiDate(DateTime dateTime) {
    _selectedMutasiDate.value = dateTime;
    final dateFormat = DateFormat('dd MMMM yyyy');
    etMutasiDate.text = dateFormat.format(dateTime);
  }

  void setCode(String value) {
    etCode.text = value;
  }

  void setLocation(String value) {
    etLocation.text = value;
  }

  void setNumber(String value) {
    etNumber.text = value;
  }

  String get result {
    return '${etCode.text} ${etLocation.text} ${etNumber.text}';
  }

  void setNewEartag() {
    etResult.text = result;
  }

  void next() {
    if (formKey.currentState?.validate() == false) {
      return;
    }

    if (etResult.text == '') {
      Get.showSnackbar(const GetSnackBar(
        message: 'Eartag Baru Harus Diisi',
        duration: Duration(seconds: 3),
      ));
    } else {
      Get.toNamed(PreviewMutasiSubtitusiPage.routeName);
    }
  }

  void peruriScan() async {
    Clipboard.setData(const ClipboardData(text: ''));
    await PeruriScanner.scan();
    resultScan();
  }

  void resultScan() async {
    while (scanResult == null) {
      final result = await PeruriScanner.resultScan;
      if (result != null) {
        scanResult = result;
      }
    }

    final decodedValue = await PeruriScanner.decodeQR(scanResult!);
    final newEartag = decodedValue?.dcdPublicData;

    etResult.text = newEartag ?? scanResult ?? '-';
  }

  Future<void> save() async {
    if (formKey.currentState?.validate() == false) {
      return;
    }

    _isUpdatingMutasi.value = true;

    final prefs = await SharedPreferences.getInstance();
    final bool? isInput = prefs.getBool('isInput');

    try {
      if (isInput!) {
        if (pinController.text.length != 6) {
          Get.showSnackbar(const GetSnackBar(
            message: 'Passcode harus 6 digit',
            duration: Duration(seconds: 3),
          ));
          return;
        }
      }

      final payload = FormData.fromMap({
        'code_product': _ternak.value?.codeProduct,
        'new_code_product': etResult.text,
        'is_input': 0,
      });

      final payloadInput = FormData.fromMap({
        'code_product': _ternak.value?.codeProduct,
        'new_code_product': etResult.text,
        'is_input': 1,
        'passcode': pinController.text,
      });

      final update = await _repository
          .updateMutasiSubtitusi(isInput ? payloadInput : payload);

      _isUpdatingMutasi.value = false;

      if (update) {
        if (_isFromProfile.value) {
          Get.until(
              (route) => route.settings.name == IdentitasDetailPage.routeName);
        } else {
          Get.until((route) => route.settings.name == MainPage.routeName);
        }
        Get.showSnackbar(const GetSnackBar(
          message: 'Penambahan Data Mutasi Berhasil',
          duration: Duration(seconds: 3),
        ));
      } else {
        Get.showSnackbar(const GetSnackBar(
          message: 'Penambahan Data Mutasi Gagal',
          duration: Duration(seconds: 3),
        ));
      }
    } catch (error) {
      _isUpdatingMutasi.value = false;
      Get.showSnackbar(GetSnackBar(
        title: 'Penambahan Data Mutasi Gagal',
        message: error.toString(),
        duration: const Duration(seconds: 3),
      ));
    }
  }

  @override
  void onDetached() {}

  @override
  void onInactive() {}

  @override
  void onPaused() {}

  @override
  void onResumed() {
    Timer(const Duration(seconds: 10), () {
      if (scanResult == null || scanResult == 'null') {
        Get.back();
        Get.showSnackbar(const GetSnackBar(
          message: 'Gagal mendapatkan data',
          duration: Duration(seconds: 3),
        ));
      }
    });
    resultScan();
  }
}
