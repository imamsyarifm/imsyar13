import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../data/const/mutasi_potong_type.dart';
import '../../widgets/preview_image_widget.dart';
import '../get/mutasi_edit_controller.dart';

class PreviewMutasiPotongWidget extends GetWidget<MutasiEditController> {
  const PreviewMutasiPotongWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Form(
      key: controller.formKey,
      child: ListView(children: [
        const SizedBox(height: 16),
        Text(
          'Mohon Periksa Kembali Data Yang Telah Diinputkan Pada Mutasi Potong',
          style: GoogleFonts.roboto(fontSize: 18, fontWeight: FontWeight.w500),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 26),
        Row(
          children: [
            const Text('QR Code'),
            const SizedBox(width: 48),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.ternak!.codeProduct.toString())
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('Tanggal Potong'),
            const SizedBox(width: 5),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etMutasiDate.text)
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('Lokasi Potong'),
            const SizedBox(width: 13),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etMutasiPotongType.text)
          ],
        ),
        const SizedBox(height: 16),
        if (controller.mutasiPotongType == MutasiPotongType.rph)
          ...buildMutasiTypePotong(),
        Row(
          children: [
            const Text('Perkiraan Bobot'),
            const SizedBox(width: 5),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etPerkiraanBobot.text != ''
                ? '${controller.etPerkiraanBobot.text} (kg)'
                : '- (kg)')
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('Bobot Karkas'),
            const SizedBox(width: 20),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etBobotKarkas.text != ''
                ? '${controller.etBobotKarkas.text} (kg)'
                : '- (kg)')
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('Keterangan'),
            const SizedBox(width: 34),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etKeterangan.text != ''
                ? controller.etKeterangan.text
                : '-')
          ],
        ),
        const SizedBox(height: 16),
        Obx(() => Row(
              children: [
                const Text('Photo'),
                const SizedBox(width: 5),
                (controller.selectedPhoto != null)
                    ? GestureDetector(
                        onTap: () => Get.bottomSheet(PreviewImageWidget(
                          imageFile: controller.selectedPhoto!,
                        )),
                        child: const Padding(
                          padding: EdgeInsets.only(left: 8),
                          child: Icon(Icons.image, color: green),
                        ),
                      )
                    : const Text('-')
              ],
            )),
        const SizedBox(height: 16),
      ]),
    );
  }

  List<Widget> buildMutasiTypePotong() => [
        Row(
          children: [
            const Text('Rumah Potong \nHewan'),
            const SizedBox(width: 8),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etRph.text != '' ? controller.etRph.text : '-')
          ],
        ),
        const SizedBox(height: 16),
      ];
}
