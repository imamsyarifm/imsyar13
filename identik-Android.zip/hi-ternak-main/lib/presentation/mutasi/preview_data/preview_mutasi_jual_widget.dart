import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../data/const/mutasi_jual_type.dart';
import '../../widgets/preview_image_widget.dart';
import '../get/mutasi_edit_controller.dart';

class PreviewMutasiJualWidget extends GetWidget<MutasiEditController> {
  const PreviewMutasiJualWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Form(
      key: controller.formKey,
      child: ListView(children: [
        const SizedBox(height: 16),
        Text(
          'Mohon Periksa Kembali Data Yang Telah Diinputkan Pada Mutasi Jual',
          style: GoogleFonts.roboto(fontSize: 18, fontWeight: FontWeight.w500),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 26),
        Row(
          children: [
            const Text('QR Code'),
            const SizedBox(width: 52),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.ternak!.codeProduct.toString())
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('Tanggal Jual'),
            const SizedBox(width: 25),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etMutasiDate.text)
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('Jenis Penjualan'),
            const SizedBox(width: 5),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etMutasiJualType.text)
          ],
        ),
        const SizedBox(height: 16),
        if (controller.mutasiJualType == MutasiJualType.registered)
          ...buildMutasiTypeJual(),
        Row(
          children: [
            const Text('Perkiraan Bobot'),
            const SizedBox(width: 5),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etPerkiraanBobot.text != ''
                ? '${controller.etPerkiraanBobot.text} (kg)'
                : '- (kg)')
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('Keterangan'),
            const SizedBox(width: 34),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etKeterangan.text != ''
                ? controller.etKeterangan.text
                : '-')
          ],
        ),
        const SizedBox(height: 16),
        Obx(() => Row(
              children: [
                const Text('Photo'),
                const SizedBox(width: 5),
                (controller.selectedPhoto != null)
                    ? GestureDetector(
                        onTap: () => Get.bottomSheet(PreviewImageWidget(
                          imageFile: controller.selectedPhoto!,
                        )),
                        child: const Padding(
                          padding: EdgeInsets.only(left: 8),
                          child: Icon(Icons.image, color: green),
                        ),
                      )
                    : const Text('-')
              ],
            )),
        const SizedBox(height: 16),
      ]),
    );
  }

  List<Widget> buildMutasiTypeJual() => [
        Row(
          children: [
            const Text('Pemilik / \nUnit Usaha'),
            const SizedBox(width: 38),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etOwner.text != ''
                ? controller.etOwner.text
                : '-')
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('Kandang'),
            const SizedBox(width: 48),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etKandang.text != ''
                ? controller.etKandang.text
                : '-')
          ],
        ),
        const SizedBox(height: 16),
      ];
}
