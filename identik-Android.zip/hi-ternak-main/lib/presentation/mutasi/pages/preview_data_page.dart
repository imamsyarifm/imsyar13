import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../app/consts/colors.dart';
import '../../../data/const/mutation_type.dart';
import '../../widgets/default_scaffold.dart';
import '../get/mutasi_edit_controller.dart';
import '../preview_data/preview_mutasi_hilang_widget.dart';
import '../preview_data/preview_mutasi_jual_widget.dart';
import '../preview_data/preview_mutasi_mati_widget.dart';
import '../preview_data/preview_mutasi_pindah_widget.dart';
import '../preview_data/preview_mutasi_potong_widget.dart';
import 'passcode/passcode_mutasi_page.dart';

class PreviewMutasiEditPage extends GetView<MutasiEditController> {
  const PreviewMutasiEditPage({Key? key}) : super(key: key);

  static const routeName = '/preview-data-mutasi';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Mutasi Check Data',
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Obx(() => Stack(
                children: [
                  Container(
                    margin: const EdgeInsets.only(bottom: 36),
                    child: buildForm(context),
                  ),
                ],
              )),
        ),
        bottomNavigation: buildAction(context),
      );

  Widget buildForm(BuildContext context) {
    switch (controller.type) {
      case MutationType.hilang:
        return const PreviewMutasiHilangWidget();
      case MutationType.jual:
        return const PreviewMutasiJualWidget();
      case MutationType.mati:
        return const PreviewMutasiMatiWidget();
      case MutationType.pindah:
        return const PreviewMutasiPindahWidget();
      case MutationType.potong:
        return const PreviewMutasiPotongWidget();
      default:
        return const CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(green),
        );
    }
  }

  Widget buildAction(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Row(children: [
        Expanded(
          child: Padding(
            padding:
                const EdgeInsets.only(left: 12, top: 12, bottom: 12, right: 6),
            child: SizedBox(
              height: 40,
              child: ElevatedButton(
                  onPressed: () => Get.back(),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(36))),
                  child: Text(
                    'BATAL',
                    style: GoogleFonts.roboto(
                        color: black,
                        fontSize: 14,
                        fontWeight: FontWeight.bold),
                  )),
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding:
                const EdgeInsets.only(right: 12, top: 12, bottom: 12, left: 6),
            child: SizedBox(
              height: 40,
              child: Obx(() {
                if (controller.isUpdatingMutasi) {
                  return const Center(
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(green),
                    ),
                  );
                }

                return ElevatedButton(
                  onPressed: () async {
                    final prefs = await SharedPreferences.getInstance();
                    final bool? isInput = prefs.getBool('isInput');
                    if (isInput == true) {
                      Get.toNamed(PasscodeMutasiPage.routeName);
                    } else {
                      controller.save();
                    }
                  },
                  style: ElevatedButton.styleFrom(
                      backgroundColor: yellowDark,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(36))),
                  child: Text(
                    'SIMPAN',
                    style: GoogleFonts.roboto(
                        color: black,
                        fontSize: 14,
                        fontWeight: FontWeight.bold),
                  ),
                );
              }),
            ),
          ),
        ),
      ]),
    );
  }
}
