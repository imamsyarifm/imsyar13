import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../utils/validation_util.dart';
import '../../widgets/default_scaffold.dart';
import '../../widgets/edit_text.dart';
import '../../widgets/ternak_information_dragable.dart';
import '../get/mutasi_subtitusi_edit_controller.dart';

class MutasiSubtitusiShowPage extends GetView<MutasiSubtitusiEditController> {
  const MutasiSubtitusiShowPage({Key? key}) : super(key: key);

  static const routeName = '/mutasi-subtitusi-show';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Mutasi Subtitusi',
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Obx(
            () => Stack(
              children: [
                Container(
                  margin: const EdgeInsets.only(bottom: 50),
                  child: buildForm(context),
                ),
                Visibility(
                  visible: controller.ternak != null,
                  child: DraggableScrollableSheet(
                    initialChildSize: 0.25,
                    minChildSize: 0.10,
                    maxChildSize: 1,
                    builder: (context, scrollController) {
                      return SingleChildScrollView(
                        controller: scrollController,
                        child: TernakInformationDragable(
                          ternak: controller.ternak!,
                        ),
                      );
                    },
                  ),
                )
              ],
            ),
          ),
        ),
        bottomNavigation: buildAction(context),
      );

  Widget buildForm(BuildContext context) {
    return Form(
      child: ListView(
        children: [
          EditText(
            label: 'Tanggal Subtitusi',
            validator: (value) =>
                ValidationUtil.emptyValidate('Tanggal Subtitusi', value),
            keyboardType: TextInputType.datetime,
            controller: controller.etMutasiDate,
            isReadOnly: true,
            onTap: () async {
              final dateTime = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime(
                      int.parse(controller.firstYear.toString()),
                      int.parse(controller.firstMonth.toString()),
                      int.parse(controller.firstDate.toString())),
                  lastDate: DateTime.now());
              if (dateTime != null) controller.setMutasiDate(dateTime);
            },
          ),
          const SizedBox(height: 16),
          EditText(
            label: 'Eartag Lama*',
            validator: (value) =>
                ValidationUtil.emptyValidate('Eartag Lama', value),
            keyboardType: TextInputType.datetime,
            controller: controller.etOldEartag,
            isReadOnly: true,
          ),
          const SizedBox(height: 16),
          EditText(
            label: 'Eartag Baru*',
            validator: (value) =>
                ValidationUtil.emptyValidate('Eartag Baru', value),
            keyboardType: TextInputType.datetime,
            controller: controller.etResult,
            isReadOnly: true,
          ),
          const SizedBox(height: 40),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: ElevatedButton(
                onPressed: () => controller.peruriScan(),
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(36))),
                child: Text(
                  'SCAN EARTAG BARU',
                  style: GoogleFonts.roboto(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.bold),
                )),
          ),
        ],
      ),
    );
  }

  Widget buildAction(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Row(children: [
        Expanded(
          child: Padding(
            padding:
                const EdgeInsets.only(left: 12, top: 12, bottom: 12, right: 6),
            child: SizedBox(
              height: 40,
              child: ElevatedButton(
                  onPressed: () => Get.back(),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(36))),
                  child: Text(
                    'BATAL',
                    style: GoogleFonts.roboto(
                        color: black,
                        fontSize: 14,
                        fontWeight: FontWeight.bold),
                  )),
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding:
                const EdgeInsets.only(right: 12, top: 12, bottom: 12, left: 6),
            child: SizedBox(
              height: 40,
              child: Obx(() {
                if (controller.isUpdatingMutasi) {
                  return const Center(
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(green),
                    ),
                  );
                }

                return ElevatedButton(
                  onPressed: () {
                    if (controller.formKey.currentState?.validate() == false) {
                      return;
                    }

                    controller.next();
                  },
                  style: ElevatedButton.styleFrom(
                      backgroundColor: yellowDark,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(36))),
                  child: Text(
                    'SIMPAN',
                    style: GoogleFonts.roboto(
                        color: black,
                        fontSize: 14,
                        fontWeight: FontWeight.bold),
                  ),
                );
              }),
            ),
          ),
        ),
      ]),
    );
  }
}
