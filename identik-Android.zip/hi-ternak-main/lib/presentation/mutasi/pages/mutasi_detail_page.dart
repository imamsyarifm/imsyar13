import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../app/consts/icons.dart';
import '../../widgets/component_tile.dart';
import '../../widgets/default_scaffold.dart';
import '../get/mutasi_controller.dart';
import 'mutasi_edit_page.dart';

class MutasiDetailPage extends GetView<MutasiController> {
  static const routeName = '/mutasi-detail';

  const MutasiDetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Mutasi 1',
        body: ListView(children: [
          ComponentTile(title: 'Tanggal Mutasi', value: controller.date()),
          const ComponentTile(title: 'Umur (bulan)', value: '1'),
          const ComponentTile(title: 'Status', value: 'Jual'),
          const ComponentTile(title: 'Bobot Terakhir', value: '102'),
          const ComponentTile(title: 'Pembeli', value: 'Dadang Jaelani'),
          const ComponentTile(title: 'Keterangan', value: '-'),
          const SizedBox(height: 50),
          Center(
              child: ElevatedButton(
            onPressed: () => {},
            style: ElevatedButton.styleFrom(
                textStyle: GoogleFonts.roboto(
                    fontSize: 16, fontWeight: FontWeight.bold, color: gold),
                backgroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(36),
                    side: const BorderSide(color: gold, width: 1))),
            child: Text('Klaim Asuransi',
                style: GoogleFonts.roboto(
                    fontSize: 16, fontWeight: FontWeight.bold, color: gold)),
          ))
        ]),
        floatingAction: FloatingActionButton(
          backgroundColor: yellowDark,
          onPressed: () => Get.toNamed(MutasiEditPage.routeName),
          child: Image.asset(pencil, width: 16, height: 16),
        ),
      );
}
