import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';

import '../../../app/consts/colors.dart';
import '../../../app/consts/images.dart';
import '../../../data/models/address/country_model.dart';
import '../../../data/models/address/subdistrict_model.dart';
import '../../../data/models/address/village_model.dart';
import '../../../data/models/combo/combo_model.dart';
import '../../../data/models/combo/rumpun_model.dart';
import '../../../utils/datetime_util.dart';
import '../../../utils/validation_util.dart';
import '../../identitas/widgets/search_kandang_delegate.dart';
import '../../identitas/widgets/search_owner_delegate.dart';
import '../../main/main_page.dart';
import '../../register/widgets/chooseable_widget.dart';
import '../../widgets/confirm_update_widget.dart';
import '../../widgets/default_scaffold.dart';
import '../../widgets/edit_text.dart';
import '../get/mutasi_subtitusi_eartag_edit_cotroller.dart';

class MutasiSubtitusiEartagEditPage
    extends GetView<MutasiSubtitusiEartagEditController> {
  const MutasiSubtitusiEartagEditPage({Key? key}) : super(key: key);

  static const routeName = '/mutasi-subtitusi-eartag-edit';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
      appBarTitle: 'Mutasi Eartag Hilang/Rusak',
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: controller.formKey,
          autovalidateMode: AutovalidateMode.always,
          child: ListView(
            children: [
              const SizedBox(height: 6),
              EditText(
                label: 'QR Code*',
                validator: (value) =>
                    ValidationUtil.emptyValidate('QR Code', value),
                keyboardType: TextInputType.number,
                controller: controller.etQrCode,
                isReadOnly: true,
              ),
              const SizedBox(height: 16),
              EditText(
                label: 'ID Isikhnas',
                keyboardType: TextInputType.text,
                textInputAction: TextInputAction.done,
                controller: controller.etIdIsikhnas,
                autoValidateMode: AutovalidateMode.onUserInteraction,
                enableInteractiveSelection: false,
                maxLength: 20,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9.,\s]')),
                ],
              ),
              const SizedBox(height: 16),
              EditText(
                label: 'Nama Ternak',
                keyboardType: TextInputType.text,
                textInputAction: TextInputAction.done,
                controller: controller.etNamaTernak,
                enableInteractiveSelection: false,
                maxLength: 20,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9.,\s]')),
                ],
              ),
              const SizedBox(height: 16),
              Obx(() {
                if (controller.isLoadingCategories) {
                  return loadingDropdown;
                } else {
                  return EditText(
                    label: 'Kategori Ternak*',
                    validator: (value) =>
                        ValidationUtil.emptyValidate('Kategori Ternak', value),
                    autoValidateMode: AutovalidateMode.onUserInteraction,
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.done,
                    suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                    isReadOnly: true,
                    onTap: () => showModalBottomSheet(
                      context: context,
                      builder: (context) => ChooseableWidget<ComboModel>(
                        values: controller.categories,
                        title: (value) => value.label,
                        onSelected: (value) => controller.setCategory(
                            value: value, isInitial: false),
                      ),
                    ),
                    controller: controller.etCategory,
                  );
                }
              }),
              const SizedBox(height: 16),
              Obx(() {
                if (controller.isLoadingRumpun) {
                  return loadingDropdown;
                } else {
                  return EditText(
                    label: 'Rumpun*',
                    validator: (value) =>
                        ValidationUtil.emptyValidate('Rumpun', value),
                    autoValidateMode: AutovalidateMode.onUserInteraction,
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.done,
                    suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                    isReadOnly: true,
                    onTap: () => showModalBottomSheet(
                      context: context,
                      builder: (context) => ChooseableWidget<RumpunModel>(
                        values: controller.rumpun,
                        title: (value) => value.label,
                        onSelected: (value) => controller.setRumpun(
                            value: value, isInitial: false),
                      ),
                    ),
                    controller: controller.etRumpun,
                  );
                }
              }),
              const SizedBox(height: 16),
              Obx(() {
                if (controller.isLoadingGenders) {
                  return loadingDropdown;
                } else {
                  return EditText(
                    label: 'Jenis Kelamin*',
                    validator: (value) =>
                        ValidationUtil.emptyValidate('Jenis Kelamin', value),
                    autoValidateMode: AutovalidateMode.onUserInteraction,
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.done,
                    suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                    isReadOnly: true,
                    onTap: () => showModalBottomSheet(
                      context: context,
                      builder: (context) => ChooseableWidget<ComboModel>(
                        values: controller.genders,
                        title: (value) => value.label,
                        onSelected: (value) => controller.setGender(
                            value: value, isInitial: false),
                      ),
                    ),
                    controller: controller.etGender,
                  );
                }
              }),
              const SizedBox(height: 16),
              EditText(
                label: 'Tanggal Lahir*',
                validator: (value) =>
                    ValidationUtil.emptyValidate('Tanggal Lahir', value),
                autoValidateMode: AutovalidateMode.onUserInteraction,
                keyboardType: TextInputType.datetime,
                controller: controller.etBirthday,
                isReadOnly: true,
                onTap: () async {
                  final dateTime = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now().add(Duration(
                        days: DateTime.now().differencToOldYear(25).inDays,
                      )),
                      firstDate: DateTime.now().add(Duration(
                        days: DateTime.now().differencToOldYear(25).inDays,
                      )),
                      lastDate: DateTime.now());
                  if (dateTime != null) controller.setBirthDay(dateTime);
                },
              ),
              const SizedBox(height: 14),
              Obx(() {
                if (controller.isLoadingPrograms) {
                  return loadingDropdown;
                } else {
                  return EditText(
                    label: 'Program*',
                    validator: (value) =>
                        ValidationUtil.emptyValidate('Program', value),
                    autoValidateMode: AutovalidateMode.onUserInteraction,
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.done,
                    suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                    isReadOnly: true,
                    onTap: () => showModalBottomSheet(
                      context: context,
                      builder: (context) => ChooseableWidget<ComboModel>(
                        values: controller.programs,
                        title: (value) => value.label,
                        onSelected: (value) => controller.setProgram(
                            value: value, isInitial: false),
                      ),
                    ),
                    controller: controller.etProgram,
                  );
                }
              }),
              const SizedBox(height: 16),
              EditText(
                label: 'Pemilik*',
                validator: (value) =>
                    ValidationUtil.emptyValidate('Pemilik', value),
                autoValidateMode: AutovalidateMode.onUserInteraction,
                keyboardType: TextInputType.text,
                textInputAction: TextInputAction.done,
                controller: controller.etOwner,
                isReadOnly: true,
                onTap: () async {
                  if (controller.ternak != null) return;

                  final context = Get.context;
                  if (context != null) {
                    final owner = await showSearch(
                      context: context,
                      delegate: SearchOwnerDelegate(),
                    );
                    controller.setOwner(owner);
                  }
                },
              ),
              const SizedBox(height: 16),
              Obx(() {
                if (controller.isLoadingStatusKandang) {
                  return loadingDropdown;
                } else {
                  return EditText(
                    label: 'Status Kandang',
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.done,
                    suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                    isReadOnly: true,
                    onTap: () => showModalBottomSheet(
                      context: context,
                      builder: (context) => ChooseableWidget<ComboModel>(
                        values: controller.allStatusKandang,
                        title: (value) => value.label,
                        onSelected: (value) => controller.setStatusKandang(
                            value: value, isInitial: false),
                      ),
                    ),
                    controller: controller.etStatusKandang,
                  );
                }
              }),
              const SizedBox(height: 16),
              Obx(() {
                if (controller.isLoadingKandang) {
                  return loadingDropdown;
                } else {
                  return EditText(
                    label: 'Kandang*',
                    validator: (value) =>
                        ValidationUtil.emptyValidate('Kandang', value),
                    autoValidateMode: AutovalidateMode.onUserInteraction,
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.done,
                    suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                    isReadOnly: true,
                    onTap: () async {
                      if (controller.ternak != null) return;

                      final context = Get.context;
                      if (context != null) {
                        final kandang = await showSearch(
                          context: context,
                          delegate: SearchKandangDelegate(
                              allKandang: controller.allKandang),
                        );

                        if (kandang != null) {
                          controller.setKandang(value: kandang);
                        }
                      }
                    },
                    controller: controller.etKandang,
                  );
                }
              }),
              const SizedBox(height: 6),
              Row(
                children: [
                  Obx(
                    () => Checkbox(
                      value: controller.isSameWithKandang,
                      onChanged: controller.setSameWithKandang,
                      activeColor: green,
                    ),
                  ),
                  const Text('Sama dengan alamat kandang')
                ],
              ),
              const SizedBox(height: 8),
              Obx(
                () => Visibility(
                  visible: !controller.isSameWithKandang,
                  child: Column(children: buildAddressTernak(context)),
                ),
              ),
              EditText(
                label: 'Ciri Khas',
                keyboardType: TextInputType.text,
                textInputAction: TextInputAction.done,
                controller: controller.etCiriKhas,
                maxLength: 50,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9.,\s]')),
                ],
              ),
              const SizedBox(height: 16),
              EditText(
                label: 'Mutu Bibit',
                keyboardType: TextInputType.text,
                textInputAction: TextInputAction.done,
                controller: controller.etMutuBibit,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9.,\s]')),
                ],
                maxLength: 50,
              ),
              const SizedBox(height: 16),
              EditText(
                label: 'Tanggal Perolehan*',
                validator: (value) =>
                    ValidationUtil.emptyValidate('Tanggal Perolehan', value),
                autoValidateMode: AutovalidateMode.onUserInteraction,
                keyboardType: TextInputType.datetime,
                controller: controller.etTanggalPerolehan,
                isReadOnly: true,
                onTap: () async {
                  final dateTime = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: controller.selectedBirthday ??
                          DateTime.now().add(
                            Duration(
                              days:
                                  DateTime.now().differencToOldYear(100).inDays,
                            ),
                          ),
                      lastDate: DateTime.now());
                  if (dateTime != null) {
                    controller.setTanggalPerolehan(dateTime);
                  }
                },
              ),
              const SizedBox(height: 16),
              Obx(() {
                if (controller.isLoadingAsalTernak) {
                  return loadingDropdown;
                } else {
                  return EditText(
                    label: 'Asal Ternak*',
                    validator: (value) =>
                        ValidationUtil.emptyValidate('Asal Ternak', value),
                    autoValidateMode: AutovalidateMode.onUserInteraction,
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.done,
                    suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                    isReadOnly: true,
                    onTap: () => showModalBottomSheet(
                      context: context,
                      builder: (context) => ChooseableWidget<ComboModel>(
                        values: controller.allAsalTernak,
                        title: (value) => value.label,
                        onSelected: (value) => controller.setAsalTernak(
                            value: value, isInitial: false),
                      ),
                    ),
                    controller: controller.etAsalTernak,
                  );
                }
              }),
              const SizedBox(height: 16),
              Obx(() {
                if (controller.isLoadingCountry) {
                  return loadingDropdown;
                } else {
                  if (!controller.isTernakImport) {
                    return const SizedBox.shrink();
                  }

                  return EditText(
                    label: 'Asal Ternak Lokasi*',
                    validator: (value) => ValidationUtil.emptyValidate(
                        'Asal Ternak Lokasi', value),
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.done,
                    suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                    isReadOnly: true,
                    onTap: () => showModalBottomSheet(
                      context: context,
                      builder: (context) => ChooseableWidget<CountryModel>(
                        values: controller.allCountry,
                        title: (value) => value.country,
                        onSelected: (value) => controller.setAsalTernakLokasi(
                            value: value, isInitial: false),
                      ),
                    ),
                    controller: controller.etAsalTernakLokasi,
                  );
                }
              }),
              Obx(() => Visibility(
                    visible: controller.isTernakImport,
                    child: const SizedBox(height: 16),
                  )),
              Obx(() {
                if (controller.ternak != null) return const SizedBox.shrink();

                return RadioListTile<bool>(
                  value: true,
                  groupValue: controller.selectedIsVacination,
                  onChanged: (value) => controller.setIsVaciation(value),
                  title: const Text('Sudah Vaksinasi'),
                  activeColor: green,
                );
              }),
              Obx(() {
                if (controller.ternak != null) return const SizedBox.shrink();

                return RadioListTile<bool>(
                  value: false,
                  groupValue: controller.selectedIsVacination,
                  onChanged: (value) => controller.setIsVaciation(value),
                  title: const Text('Tidak Vaksinasi'),
                  activeColor: green,
                );
              }),
              Obx(() => Visibility(
                    visible: controller.selectedIsVacination &&
                        controller.ternak == null,
                    child: const SizedBox(height: 16),
                  )),
              Obx(() => Visibility(
                    visible: controller.selectedIsVacination &&
                        controller.ternak == null,
                    child: const SizedBox(height: 16),
                  )),
              Obx(() => Visibility(
                    visible: controller.selectedIsVacination &&
                        controller.ternak == null,
                    child: EditText(
                      label: 'Tanggal Vaksin*',
                      validator: (value) =>
                          ValidationUtil.emptyValidate('Tanggal Vaksin', value),
                      autoValidateMode: AutovalidateMode.onUserInteraction,
                      keyboardType: TextInputType.datetime,
                      controller: controller.etVaccineDate,
                      isReadOnly: true,
                      onTap: () async {
                        final dateTime = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: controller.selectedBirthday ??
                                DateTime.now().add(
                                  Duration(
                                    days: DateTime.now()
                                        .differencToOldYear(100)
                                        .inDays,
                                  ),
                                ),
                            lastDate: DateTime.now());
                        if (dateTime != null) {
                          controller.setTanggalVaksin(dateTime);
                        }
                      },
                    ),
                  )),
              Obx(() => Visibility(
                    visible: controller.selectedIsVacination &&
                        controller.ternak == null,
                    child: const SizedBox(height: 16),
                  )),
              Obx(() => Visibility(
                    visible: controller.selectedIsVacination &&
                        controller.ternak == null,
                    child: EditText(
                      label: 'Merk Vaksin*',
                      validator: (value) =>
                          ValidationUtil.emptyValidate('Merk Vaksin', value),
                      autoValidateMode: AutovalidateMode.onUserInteraction,
                      keyboardType: TextInputType.text,
                      textInputAction: TextInputAction.done,
                      controller: controller.etVaccineMerk,
                      isReadOnly: true,
                      onTap: () async {
                        showModalBottomSheet(
                          context: context,
                          builder: (context) => ChooseableWidget<ComboModel>(
                            values: controller.allObat,
                            title: (ComboModel category) => category.label,
                            onSelected: (category) =>
                                controller.setObat(category),
                          ),
                        );
                      },
                    ),
                  )),
              Obx(() => Visibility(
                    visible: controller.selectedIsVacination &&
                        controller.ternak == null,
                    child: const SizedBox(height: 16),
                  )),
              Obx(() => Visibility(
                    visible: controller.selectedIsVacination &&
                        controller.ternak == null,
                    child: EditText(
                      label: 'Batch',
                      keyboardType: TextInputType.text,
                      textInputAction: TextInputAction.done,
                      controller: controller.etBatch,
                      maxLength: 50,
                      inputFormatters: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(
                            RegExp(r'[A-Za-z0-9.,\s]')),
                      ],
                    ),
                  )),
              Obx(() => Visibility(
                    visible: controller.selectedIsVacination &&
                        controller.ternak == null,
                    child: const SizedBox(height: 16),
                  )),
              EditText(
                label: 'Berat Badan (Kg)',
                keyboardType: TextInputType.number,
                controller: controller.etBeratBadan,
                maxLength: 5,
                autoValidateMode: AutovalidateMode.onUserInteraction,
                validator: (value) {
                  if ((int.tryParse(value ?? '0') ?? 0) > 15000) {
                    return 'Maksimal berat badan adalah 15000kg';
                  }

                  return null;
                },
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                ],
              ),
              const SizedBox(height: 16),
              EditText(
                label: 'Panjang Badan (cm)',
                keyboardType: TextInputType.number,
                controller: controller.etPanjangBadan,
                maxLength: 3,
                autoValidateMode: AutovalidateMode.onUserInteraction,
                validator: (value) {
                  if ((int.tryParse(value ?? '0') ?? 0) > 300) {
                    return 'Maksimal berat badan adalah 300cm';
                  }

                  return null;
                },
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                ],
              ),
              const SizedBox(height: 16),
              EditText(
                label: 'Tinggi Badan (cm)',
                keyboardType: TextInputType.number,
                controller: controller.etTinggiBadan,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                ],
                maxLength: 3,
                validator: (value) {
                  if ((int.tryParse(value ?? '0') ?? 0) > 300) {
                    return 'Maksimal tinggi badan adalah 300cm';
                  }

                  return null;
                },
              ),
              const SizedBox(height: 16),
              // EditText(
              //   label: 'Alasan',
              //   keyboardType: TextInputType.text,
              //   controller: controller.etTinggiBadan,
              // ),
              EditText(
                label: 'Alasan*',
                validator: (value) =>
                    ValidationUtil.emptyValidate('Alasan', value),
                keyboardType: TextInputType.number,
                textInputAction: TextInputAction.done,
                suffixIcon: const Icon(Icons.arrow_drop_down),
                isReadOnly: true,
                onTap: () => showModalBottomSheet(
                  context: context,
                  builder: (context) => ChooseableWidget<ComboModel>(
                      values: [
                        ComboModel(
                          value: 'rusak',
                          label: 'Rusak',
                        ),
                        ComboModel(
                          value: 'hilang',
                          label: 'Hilang',
                        ),
                      ],
                      title: (value) => value.label,
                      onSelected: (value) => controller.setAlasan(value)),
                ),
                controller: controller.etReason,
              ),
              const SizedBox(height: 16),
              Obx(() {
                if (controller.selectedPhoto != null) {
                  final file = File(controller.selectedPhoto!.path);
                  return Image.file(file);
                }

                if (controller.ternak != null &&
                    controller.ternak?.urlImage != null &&
                    controller.ternak?.urlImage!.isNotEmpty == true) {
                  return FadeInImage.assetNetwork(
                    placeholder: logo,
                    image: controller.ternak!.urlImage!,
                  );
                }

                return const SizedBox.shrink();
              }),
              const SizedBox(height: 100),
            ],
          ),
        ),
      ),
      floatingAction: FloatingActionButton(
        backgroundColor: yellowDark,
        onPressed: () => Get.bottomSheet(
          Container(
            color: Colors.white,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  title: const Text('Galeri'),
                  subtitle: const Text('Pilih gambar dari galeri'),
                  onTap: () async {
                    final file = await controller.imagePicker.pickImage(
                        source: ImageSource.gallery, imageQuality: 25);
                    controller.setPhoto(file);
                  },
                ),
                ListTile(
                  title: const Text('Kamera'),
                  subtitle: const Text('Pilih gambar dari kamera'),
                  onTap: () async {
                    final file = await controller.imagePicker.pickImage(
                        source: ImageSource.camera, imageQuality: 25);
                    controller.setPhoto(file);
                  },
                ),
              ],
            ),
          ),
        ),
        child: const Icon(Icons.upload_file),
      ),
      bottomNavigation: Obx(() {
        if (controller.updatingTernak) {
          const LinearProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(green),
          );
        }

        return Container(
          color: Colors.white,
          child: Visibility(
            visible: controller.updatingTernak,
            replacement: Row(children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 12, top: 12, bottom: 12, right: 6),
                  child: SizedBox(
                    height: 40,
                    child: ElevatedButton(
                        onPressed: () => Get.dialog(ConfirmUpdateWidget(
                              content: 'Apakah anda yakin ingin membatalkan '
                                  'perubahan ini?',
                              onCancelPressed: () => Get.back(),
                              onConfirmedPressed: () {
                                Get.until(
                                  (route) =>
                                      route.settings.name == MainPage.routeName,
                                );
                              },
                            )),
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(36))),
                        child: Text(
                          'BATAL',
                          style: GoogleFonts.roboto(
                              color: black,
                              fontSize: 14,
                              fontWeight: FontWeight.bold),
                        )),
                  ),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(
                      right: 12, top: 12, bottom: 12, left: 6),
                  child: SizedBox(
                    height: 40,
                    child: ElevatedButton(
                        onPressed: () {
                          if (controller.latitude.value == 0 ||
                              controller.longitude.value == 0) {
                            Get.showSnackbar(const GetSnackBar(
                              message:
                                  'Mohon pastikan titik koordinat sudah sesuai',
                              duration: Duration(seconds: 3),
                            ));
                            return;
                          }

                          final validate =
                              controller.formKey.currentState?.validate();
                          if (validate == false) {
                            return;
                          } else {
                            controller.saveTernak();
                          }
                        },
                        style: ElevatedButton.styleFrom(
                            backgroundColor: yellowDark,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(36))),
                        child: Text(
                          'SIMPAN',
                          style: GoogleFonts.roboto(
                              color: black,
                              fontSize: 14,
                              fontWeight: FontWeight.bold),
                        )),
                  ),
                ),
              ),
            ]),
            child: const LinearProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(green),
            ),
          ),
        );
      }));

  Widget get loadingDropdown => const Center(
        child: CircularProgressIndicator(
          color: green,
        ),
      );

  List<Widget> buildAddressTernak(BuildContext context) {
    return [
      Obx(() {
        if (controller.isLoadingProvinces) {
          return const Center(
            child: CircularProgressIndicator(
              color: green,
            ),
          );
        } else {
          return EditText(
            controller: controller.etProvinsi,
            validator: (value) =>
                ValidationUtil.emptyValidate('Provinsi', value),
            // onTap: () => showModalBottomSheet(
            //   context: context,
            //   builder: (context) => ChooseableWidget<ProvinceModel>(
            //     values: controller.provinces,
            //     title: (ProvinceModel provinsi) => provinsi.province,
            //     onSelected: (provinsi) {
            //       controller.setProvinsi(provinsi);
            //       Get.back();
            //     },
            //   ),
            // ),
            isReadOnly: true,
            label: 'Propinsi*',
            suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
          );
        }
      }),
      const SizedBox(height: 14),
      Obx(() {
        if (controller.isLoadingDistricts) {
          return const Center(
            child: CircularProgressIndicator(
              color: green,
            ),
          );
        } else {
          return EditText(
            controller: controller.etKabupaten,
            validator: (value) =>
                ValidationUtil.emptyValidate('Kabupaten', value),
            // onTap: () => showModalBottomSheet(
            //     context: context,
            //     builder: (context) => ChooseableWidget<DistrictModel>(
            //           values: controller.districts,
            //           title: (DistrictModel kabupaten) => kabupaten.district,
            //           onSelected: (kabupaten) {
            //             controller.setKabupaten(
            //               kabupaten,
            //             );
            //             Get.back();
            //           },
            //         )),
            label: 'Kabupaten / Kota*',
            isReadOnly: true,
            suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
          );
        }
      }),
      const SizedBox(height: 14),
      Obx(() {
        if (controller.isLoadingSubDistricts) {
          return const Center(
            child: CircularProgressIndicator(
              color: green,
            ),
          );
        } else {
          return EditText(
            controller: controller.etKecamatan,
            validator: (value) =>
                ValidationUtil.emptyValidate('Kecamatan', value),
            autoValidateMode: AutovalidateMode.onUserInteraction,
            onTap: () => showModalBottomSheet(
                context: context,
                builder: (context) => ChooseableWidget<SubdistrictModel>(
                      values: controller.subDistricts,
                      title: (SubdistrictModel kecamatan) =>
                          kecamatan.subDistrict,
                      onSelected: (kecamatan) {
                        controller.setKecamatan(kecamatan);
                        Get.back();
                      },
                    )),
            label: 'Kecamatan*',
            isReadOnly: true,
            suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
          );
        }
      }),
      const SizedBox(height: 14),
      Obx(() {
        if (controller.isLoadingVillages) {
          return const Center(
            child: CircularProgressIndicator(
              color: green,
            ),
          );
        } else {
          return EditText(
            controller: controller.etDesa,
            validator: (value) => ValidationUtil.emptyValidate('Desa', value),
            autoValidateMode: AutovalidateMode.onUserInteraction,
            onTap: () => showModalBottomSheet(
                context: context,
                builder: (context) => ChooseableWidget<VillageModel>(
                      values: controller.villages,
                      title: (VillageModel desa) => desa.urbanVillage,
                      onSelected: (desa) {
                        controller.setDesa(desa);
                        Get.back();
                      },
                    )),
            label: 'Desa*',
            isReadOnly: true,
            suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
          );
        }
      }),
      const SizedBox(height: 14),
      EditText(
        controller: controller.etAlamat,
        keyboardType: TextInputType.streetAddress,
        label: 'Alamat Lengkap',
        minLines: 5,
        maxLines: null,
        maxLength: 100,
        inputFormatters: <TextInputFormatter>[
          FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9.,\s]')),
        ],
      ),
      const SizedBox(height: 16),
      EditText(
        label: 'RT',
        keyboardType: TextInputType.number,
        controller: controller.etRt,
        maxLength: 3,
        inputFormatters: <TextInputFormatter>[
          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
        ],
      ),
      const SizedBox(height: 16),
      EditText(
        label: 'RW',
        keyboardType: TextInputType.number,
        controller: controller.etRw,
        maxLength: 3,
        inputFormatters: <TextInputFormatter>[
          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
        ],
      ),
      Obx(
        () => ListTile(
          title: Text('Latitude: ${controller.latitude}',
              style: GoogleFonts.roboto(
                fontSize: 14,
                color: black,
              )),
          subtitle: Text('Longitude: ${controller.longitude}',
              style: GoogleFonts.roboto(
                fontSize: 14,
                color: black,
              )),
          trailing: IconButton(
            icon: const Icon(Icons.location_on, color: green),
            onPressed: () => controller.getCurrentLocation(),
          ),
        ),
      ),
      const SizedBox(height: 6),
    ];
  }
}
