import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../app/consts/colors.dart';
import '../../widgets/default_scaffold.dart';
import '../get/mutasi_subtitusi_edit_controller.dart';
import 'passcode/passcode_mutasi_subtitusi_page.dart';

class PreviewMutasiSubtitusiPage
    extends GetView<MutasiSubtitusiEditController> {
  const PreviewMutasiSubtitusiPage({Key? key}) : super(key: key);

  static const routeName = '/mutasi-subtitusi-preview';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Check Mutasi Subtitusi',
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Obx(
            () => Stack(
              children: [
                Container(
                  margin: const EdgeInsets.only(bottom: 50),
                  child: buildForm(context),
                ),
              ],
            ),
          ),
        ),
        bottomNavigation: buildAction(context),
      );

  Widget buildForm(BuildContext context) {
    return Form(
      child: ListView(
        children: [
          const SizedBox(height: 16),
          Text(
            'Mohon Periksa Kembali Data Yang Telah '
            'Diinputkan Pada Mutasi Subtitusi',
            style:
                GoogleFonts.roboto(fontSize: 18, fontWeight: FontWeight.w500),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 26),
          Row(
            children: [
              const Text('QR Code'),
              const SizedBox(width: 58),
              const Text(':'),
              const SizedBox(width: 5),
              Text(controller.ternak!.codeProduct.toString())
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text('Tanggal Subtitusi'),
              const SizedBox(width: 5),
              const Text(':'),
              const SizedBox(width: 5),
              Text(controller.etMutasiDate.text)
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text('QR Code Baru'),
              const SizedBox(width: 25),
              const Text(':'),
              const SizedBox(width: 5),
              Text(controller.etResult.text)
            ],
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget buildAction(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Row(children: [
        Expanded(
          child: Padding(
            padding:
                const EdgeInsets.only(left: 12, top: 12, bottom: 12, right: 6),
            child: SizedBox(
              height: 40,
              child: ElevatedButton(
                  onPressed: () => Get.back(),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(36))),
                  child: Text(
                    'BATAL',
                    style: GoogleFonts.roboto(
                        color: black,
                        fontSize: 14,
                        fontWeight: FontWeight.bold),
                  )),
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding:
                const EdgeInsets.only(right: 12, top: 12, bottom: 12, left: 6),
            child: SizedBox(
              height: 40,
              child: Obx(() {
                if (controller.isUpdatingMutasi) {
                  return const Center(
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(green),
                    ),
                  );
                }

                return ElevatedButton(
                  onPressed: () async {
                    final prefs = await SharedPreferences.getInstance();
                    final bool? isInput = prefs.getBool('isInput');
                    if (isInput == true) {
                      Get.toNamed(PasscodeMutasiSubtitusiPage.routeName);
                    } else {
                      controller.save();
                    }
                  },
                  style: ElevatedButton.styleFrom(
                      backgroundColor: yellowDark,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(36))),
                  child: Text(
                    'SIMPAN',
                    style: GoogleFonts.roboto(
                        color: black,
                        fontSize: 14,
                        fontWeight: FontWeight.bold),
                  ),
                );
              }),
            ),
          ),
        ),
      ]),
    );
  }
}
