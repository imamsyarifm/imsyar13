import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../data/const/mutation_type.dart';
import '../../widgets/default_scaffold.dart';
import '../../widgets/ternak_information_dragable.dart';
import '../get/mutasi_edit_controller.dart';
import '../widgets/mutasi_hilang_widget.dart';
import '../widgets/mutasi_jual_widget.dart';
import '../widgets/mutasi_mati_widget.dart';
import '../widgets/mutasi_pindah_widget.dart';
import '../widgets/mutasi_potong_widget.dart';
import 'preview_data_page.dart';

class MutasiEditPage extends GetView<MutasiEditController> {
  const MutasiEditPage({Key? key}) : super(key: key);

  static const routeName = '/mutasi-edit';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Mutasi',
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Obx(() => Stack(
                children: [
                  Container(
                    margin: const EdgeInsets.only(bottom: 36),
                    child: buildForm(context),
                  ),
                  Visibility(
                    visible: controller.ternak != null,
                    child: DraggableScrollableSheet(
                      initialChildSize: 0.25,
                      minChildSize: 0.10,
                      maxChildSize: 1,
                      builder: (context, scrollController) {
                        return SingleChildScrollView(
                          controller: scrollController,
                          child: TernakInformationDragable(
                            ternak: controller.ternak!,
                          ),
                        );
                      },
                    ),
                  )
                ],
              )),
        ),
        bottomNavigation: buildAction(context),
      );

  Widget buildForm(BuildContext context) {
    switch (controller.type) {
      case MutationType.hilang:
        return const MutasiHilangWidget();
      case MutationType.jual:
        return const MutasiJualWidget();
      case MutationType.mati:
        return const MutasiMatiWidget();
      case MutationType.pindah:
        return const MutasiPindahWidget();
      case MutationType.potong:
        return const MutasiPotongWidget();
      default:
        return const CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(green),
        );
    }
  }

  Widget buildAction(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Row(children: [
        Expanded(
          child: Padding(
            padding:
                const EdgeInsets.only(left: 12, top: 12, bottom: 12, right: 6),
            child: SizedBox(
              height: 40,
              child: ElevatedButton(
                  onPressed: () => Get.back(),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(36))),
                  child: Text(
                    'BATAL',
                    style: GoogleFonts.roboto(
                        color: black,
                        fontSize: 14,
                        fontWeight: FontWeight.bold),
                  )),
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding:
                const EdgeInsets.only(right: 12, top: 12, bottom: 12, left: 6),
            child: SizedBox(
              height: 40,
              child: Obx(() {
                if (controller.isUpdatingMutasi) {
                  return const Center(
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(green),
                    ),
                  );
                }

                return ElevatedButton(
                  onPressed: () {
                    if (controller.formKey.currentState?.validate() == false) {
                      return;
                    }

                    Get.toNamed(PreviewMutasiEditPage.routeName);
                  },
                  style: ElevatedButton.styleFrom(
                      backgroundColor: yellowDark,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(36))),
                  child: Text(
                    'SIMPAN',
                    style: GoogleFonts.roboto(
                        color: black,
                        fontSize: 14,
                        fontWeight: FontWeight.bold),
                  ),
                );
              }),
            ),
          ),
        ),
      ]),
    );
  }
}
