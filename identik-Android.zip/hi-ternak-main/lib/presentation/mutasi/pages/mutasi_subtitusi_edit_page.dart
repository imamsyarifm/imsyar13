import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../utils/validation_util.dart';
import '../../widgets/default_scaffold.dart';
import '../../widgets/edit_text.dart';
import '../../widgets/ternak_information_dragable.dart';
import '../get/mutasi_subtitusi_edit_controller.dart';

class MutasiSubtitusiEditPage extends GetView<MutasiSubtitusiEditController> {
  const MutasiSubtitusiEditPage({Key? key}) : super(key: key);

  static const routeName = '/mutasi-subtitusi-edit';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Mutasi Subtitusi',
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Obx(
            () => Stack(
              children: [
                Container(
                  margin: const EdgeInsets.only(bottom: 50),
                  child: buildForm(context),
                ),
                Visibility(
                  visible: controller.ternak != null,
                  child: DraggableScrollableSheet(
                    initialChildSize: 0.25,
                    minChildSize: 0.10,
                    maxChildSize: 1,
                    builder: (context, scrollController) {
                      return SingleChildScrollView(
                        controller: scrollController,
                        child: TernakInformationDragable(
                          ternak: controller.ternak!,
                        ),
                      );
                    },
                  ),
                )
              ],
            ),
          ),
        ),
        bottomNavigation: buildAction(context),
      );

  Widget buildForm(BuildContext context) {
    return Form(
      child: ListView(
        children: [
          EditText(
            label: 'Tanggal Subtitusi',
            validator: (value) =>
                ValidationUtil.emptyValidate('Tanggal Subtitusi', value),
            keyboardType: TextInputType.datetime,
            controller: controller.etMutasiDate,
            isReadOnly: true,
            onTap: () {},
          ),
          const Text('Masukkan Kode Eartag Baru'),
          const SizedBox(height: 16),
          EditText(
            label: 'Kode',
            validator: (value) => controller.validator(3, value),
            controller: controller.etCode,
            // isReadOnly: true,
            maxLength: 3,
            enableInteractiveSelection: false,
          ),
          // const SizedBox(height: 16),
          // TextFormField(
          //   textCapitalization: TextCapitalization.sentences,
          //   enableInteractiveSelection: false,
          //   controller: controller.etCode,
          //   maxLength: 3,
          //   validator: (value) => controller.validator(3, value),
          // ),
          const SizedBox(
            height: 16,
          ),
          EditText(
            label: 'Lokasi',
            validator: (value) => controller.validator(2, value),
            controller: controller.etLocation,
            // isReadOnly: true,
            maxLength: 2,
            enableInteractiveSelection: false,
          ),
          // TextFormField(
          //   controller: controller.etLocation,
          //   maxLength: 2,
          //   validator: (value) => controller.validator(2, value),
          // ),
          const SizedBox(
            height: 16,
          ),
          EditText(
            label: 'Number',
            validator: (value) => controller.validator(10, value),
            controller: controller.etNumber,
            // isReadOnly: true,
            maxLength: 10,
            enableInteractiveSelection: false,
          ),
          // TextFormField(
          //   keyboardType: TextInputType.visiblePassword,
          //   enableInteractiveSelection: false,
          //   controller: controller.etNumber,
          //   maxLength: 10,
          //   validator: (value) => controller.validator(10, value),
          // ),
        ],
      ),
    );
  }

  Widget buildAction(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Row(children: [
        Expanded(
          child: Padding(
            padding:
                const EdgeInsets.only(left: 12, top: 12, bottom: 12, right: 6),
            child: SizedBox(
              height: 40,
              child: ElevatedButton(
                  onPressed: () => Get.back(),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(36))),
                  child: Text(
                    'BATAL',
                    style: GoogleFonts.roboto(
                        color: black,
                        fontSize: 14,
                        fontWeight: FontWeight.bold),
                  )),
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding:
                const EdgeInsets.only(right: 12, top: 12, bottom: 12, left: 6),
            child: SizedBox(
              height: 40,
              child: Obx(() {
                if (controller.isUpdatingMutasi) {
                  return const Center(
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(green),
                    ),
                  );
                }

                return ElevatedButton(
                  onPressed: () {
                    controller.next();
                  },
                  style: ElevatedButton.styleFrom(
                      backgroundColor: yellowDark,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(36))),
                  child: Text(
                    'SIMPAN',
                    style: GoogleFonts.roboto(
                        color: black,
                        fontSize: 14,
                        fontWeight: FontWeight.bold),
                  ),
                );
              }),
            ),
          ),
        ),
      ]),
    );
  }
}
