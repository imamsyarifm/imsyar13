import '../../../data/const/mutation_type.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';

class MutasiEditParams {
  final MutationType mutationType;
  final IdentityTernakModel ternak;
  final bool isFromProfile;
  final bool isInput;

  MutasiEditParams({
    required this.mutationType,
    required this.ternak,
    this.isFromProfile = false,
    this.isInput = false,
  });
}
