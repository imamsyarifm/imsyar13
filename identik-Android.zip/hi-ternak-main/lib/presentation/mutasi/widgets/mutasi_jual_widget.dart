import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../../../app/consts/colors.dart';
import '../../../data/const/mutasi_jual_type.dart';
import '../../../utils/validation_util.dart';
import '../../register/widgets/chooseable_widget.dart';
import '../../widgets/edit_text.dart';
import '../../widgets/preview_image_widget.dart';
import '../get/mutasi_edit_controller.dart';
import 'search_mutasi_owner_delegate.dart';

class MutasiJualWidget extends GetWidget<MutasiEditController> {
  const MutasiJualWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Obx(() => Form(
          key: controller.formKey,
          child: ListView(children: [
            EditText(
              label: 'Tanggal Jual*',
              validator: (value) =>
                  ValidationUtil.emptyValidate('Tanggal Jual', value),
              keyboardType: TextInputType.datetime,
              suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
              isReadOnly: true,
              onTap: () async {
                final dateTime = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime(
                        int.parse(controller.firstYear.toString()),
                        int.parse(controller.firstMonth.toString()),
                        int.parse(controller.firstDate.toString())),
                    lastDate: DateTime.now());
                if (dateTime != null) controller.setMutasiDate(dateTime);
              },
              controller: controller.etMutasiDate,
            ),
            const SizedBox(height: 16),
            EditText(
                label: 'Jenis Penjualan*',
                validator: (value) =>
                    ValidationUtil.emptyValidate('Jenis Penjualan', value),
                keyboardType: TextInputType.text,
                textInputAction: TextInputAction.done,
                suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                isReadOnly: true,
                onTap: () => showModalBottomSheet(
                      context: context,
                      builder: (context) => ChooseableWidget<MutasiJualType>(
                        values: const [
                          MutasiJualType.registered,
                          MutasiJualType.outside,
                        ],
                        title: (value) => (value == MutasiJualType.registered)
                            ? 'Peternak Terdaftar'
                            : 'Pihak Luar',
                        onSelected: controller.setMutasiJualType,
                      ),
                    ),
                controller: controller.etMutasiJualType),
            const SizedBox(height: 16),
            if (controller.mutasiJualType == MutasiJualType.registered)
              ...buildMutasiJualRegistered(context),
            EditText(
                label: 'Perkiraan Bobot (kg)*',
                validator: (value) =>
                    ValidationUtil.emptyValidate('Perkiraan Bobot', value),
                keyboardType: TextInputType.number,
                controller: controller.etPerkiraanBobot),
            const SizedBox(height: 16),
            EditText(
                label: 'Isi Keterangan*',
                validator: (value) =>
                    ValidationUtil.emptyValidate('Isi Keterangan', value),
                keyboardType: TextInputType.text,
                textInputAction: TextInputAction.done,
                controller: controller.etKeterangan),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: EditText(
                    label: 'Photo',
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.done,
                    controller: controller.etPhoto,
                    isReadOnly: true,
                    onTap: () => Get.bottomSheet(
                      Container(
                        color: Colors.white,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            ListTile(
                              title: const Text('Galeri'),
                              subtitle: const Text('Pilih gambar dari galeri'),
                              onTap: () async {
                                final file = await controller.imagePicker
                                    .pickImage(
                                        source: ImageSource.gallery,
                                        imageQuality: 25);
                                controller.setPhoto(file);
                              },
                            ),
                            ListTile(
                              title: const Text('Kamera'),
                              subtitle: const Text('Pilih gambar dari kamera'),
                              onTap: () async {
                                final file = await controller.imagePicker
                                    .pickImage(
                                        source: ImageSource.camera,
                                        imageQuality: 25);
                                controller.setPhoto(file);
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                (controller.selectedPhoto != null)
                    ? GestureDetector(
                        onTap: () => Get.bottomSheet(PreviewImageWidget(
                          imageFile: controller.selectedPhoto!,
                        )),
                        child: const Padding(
                          padding: EdgeInsets.only(left: 8),
                          child: Icon(Icons.image, color: green),
                        ),
                      )
                    : const SizedBox.shrink()
              ],
            ),
            const SizedBox(height: 16),
          ]),
        ));
  }

  List<Widget> buildMutasiJualRegistered(BuildContext context) => [
        EditText(
          label: 'Pemilik / Unit Usaha*',
          validator: (value) =>
              ValidationUtil.emptyValidate('Pemilik / Unit Usaha', value),
          autoValidateMode: AutovalidateMode.onUserInteraction,
          keyboardType: TextInputType.text,
          textInputAction: TextInputAction.done,
          controller: controller.etOwner,
          isReadOnly: true,
          onTap: () async {
            final context = Get.context;
            if (context != null) {
              final owner = await showSearch(
                context: context,
                delegate: SearchMutasiOwnerDelegate(),
              );
              controller.setPemilik(owner);
            }
          },
        ),
        const SizedBox(height: 16),
        EditText(
          label: 'Kandang*',
          validator: (value) => ValidationUtil.emptyValidate('Kandang', value),
          keyboardType: TextInputType.number,
          controller: controller.etKandang,
          isReadOnly: true,
          onTap: () => controller.chooseKandang(context),
        ),
        const SizedBox(height: 16),
      ];
}
