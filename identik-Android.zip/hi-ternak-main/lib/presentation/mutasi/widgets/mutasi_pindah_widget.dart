import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../../../app/consts/colors.dart';
import '../../../utils/validation_util.dart';
import '../../widgets/edit_text.dart';
import '../../widgets/preview_image_widget.dart';
import '../get/mutasi_edit_controller.dart';
import 'search_mutasi_owner_delegate.dart';

class MutasiPindahWidget extends GetWidget<MutasiEditController> {
  const MutasiPindahWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Form(
      key: controller.formKey,
      child: ListView(children: [
        EditText(
          label: 'Tanggal Pindah',
          validator: (value) =>
              ValidationUtil.emptyValidate('Tanggal Pindah', value),
          keyboardType: TextInputType.datetime,
          suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
          isReadOnly: true,
          onTap: () async {
            final dateTime = await showDatePicker(
                context: context,
                initialDate: DateTime.now(),
                 firstDate: DateTime(
                    int.parse(controller.firstYear.toString()),
                    int.parse(controller.firstMonth.toString()),
                    int.parse(controller.firstDate.toString())),
                lastDate: DateTime.now());
            if (dateTime != null) controller.setMutasiDate(dateTime);
          },
          controller: controller.etMutasiDate,
        ),
        const SizedBox(height: 16),
        EditText(
          label: 'Pemilik / Unit Usaha Baru*',
          validator: (value) =>
              ValidationUtil.emptyValidate('Pemilik / Unit Usaha', value),
          autoValidateMode: AutovalidateMode.onUserInteraction,
          keyboardType: TextInputType.text,
          textInputAction: TextInputAction.done,
          controller: controller.etOwner,
          isReadOnly: true,
          onTap: () async {
            final context = Get.context;
            if (context != null) {
              final owner = await showSearch(
                context: context,
                delegate: SearchMutasiOwnerDelegate(),
              );
              controller.setPemilik(owner);
            }
          },
        ),
        const SizedBox(height: 16),
        EditText(
          label: 'Kandang Baru*',
          validator: (value) => ValidationUtil.emptyValidate('Kandang', value),
          keyboardType: TextInputType.number,
          controller: controller.etKandang,
          isReadOnly: true,
          onTap: () => controller.chooseKandang(context),
        ),
        const SizedBox(height: 16),
        EditText(
            label: 'Perkiraan Bobot (kg)',
            // validator: (value) =>
            //     ValidationUtil.emptyValidate('Perkiraan Bobot', value),
            keyboardType: TextInputType.number,
            controller: controller.etPerkiraanBobot),
        const SizedBox(height: 16),
        EditText(
            label: 'Isi Keterangan',
            // validator: (value) =>
            //     ValidationUtil.emptyValidate('Isi Keterangan', value),
            keyboardType: TextInputType.text,
            textInputAction: TextInputAction.done,
            controller: controller.etKeterangan),
        const SizedBox(height: 16),
        Obx(() => Row(
              children: [
                Expanded(
                  child: EditText(
                    label: 'Photo',
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.done,
                    controller: controller.etPhoto,
                    isReadOnly: true,
                    onTap: () => Get.bottomSheet(
                      Container(
                        color: Colors.white,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            ListTile(
                              title: const Text('Galeri'),
                              subtitle: const Text('Pilih gambar dari galeri'),
                              onTap: () async {
                                final file = await controller.imagePicker
                                    .pickImage(
                                        source: ImageSource.gallery,
                                        imageQuality: 25);
                                controller.setPhoto(file);
                              },
                            ),
                            ListTile(
                              title: const Text('Kamera'),
                              subtitle: const Text('Pilih gambar dari kamera'),
                              onTap: () async {
                                final file = await controller.imagePicker
                                    .pickImage(
                                        source: ImageSource.camera,
                                        imageQuality: 25);
                                controller.setPhoto(file);
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                (controller.selectedPhoto != null)
                    ? GestureDetector(
                        onTap: () => Get.bottomSheet(PreviewImageWidget(
                          imageFile: controller.selectedPhoto!,
                        )),
                        child: const Padding(
                          padding: EdgeInsets.only(left: 8),
                          child: Icon(Icons.image, color: green),
                        ),
                      )
                    : const SizedBox.shrink()
              ],
            )),
        const SizedBox(height: 16),
      ]),
    );
  }
}
