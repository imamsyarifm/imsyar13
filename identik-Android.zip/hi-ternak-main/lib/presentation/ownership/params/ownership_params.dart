import '../../../data/models/ternak/identity_ternak_model.dart';

class OwnershipParams {
  final IdentityTernakModel ternak;
  final bool isFromScan;

  OwnershipParams({
    required this.ternak,
    this.isFromScan = false,
  });
}
