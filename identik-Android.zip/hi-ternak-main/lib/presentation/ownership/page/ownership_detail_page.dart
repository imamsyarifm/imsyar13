import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../data/const/mutation_type.dart';
import '../../../utils/datetime_util.dart';
import '../../mutasi/pages/mutasi_edit_page.dart';
import '../../mutasi/params/mutasi_edit_params.dart';
import '../../widgets/default_scaffold.dart';
import '../get/ownership_detail_controller.dart';

class OwnershipDetailPage extends GetView<OwnershipDetailController> {
  static const routeName = '/ownership-detail';

  const OwnershipDetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Detail Kepemilikan',
        body: ListView(children: [
          componentTile(context, 'Nama',
              controller.params.ternak.kepemilikan?.nama ?? '-'),
          componentTile(context, 'Alamat',
              controller.params.ternak.kepemilikan?.alamat ?? '-'),
          componentTile(
              context,
              'Tanggal Memiliki',
              controller.params.ternak.kepemilikan?.tanggalMemilki.readable() ??
                  DateTime.now().readable()),
          componentTile(context, 'Keterangan',
              controller.params.ternak.kepemilikan?.keterangan ?? '-'),
        ]),
        floatingAction: Visibility(
          visible: controller.params.ternak.jenisKelamin == 'betina' &&
              controller.params.isFromScan,
          child: FloatingActionButton(
            backgroundColor: green,
            onPressed: () => onUpdateOwnership(context),
            child: const Icon(Icons.add),
          ),
        ),
      );

  Widget componentTile(BuildContext context, String title, String value) =>
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            ListTile(
              contentPadding: const EdgeInsets.all(0),
              title: Text(title,
                  style: GoogleFonts.roboto(
                    color: black,
                    fontSize: 12,
                  )),
              subtitle: Text(value,
                  textAlign: TextAlign.justify,
                  style: GoogleFonts.roboto(
                      color: black, fontWeight: FontWeight.bold, fontSize: 16)),
            ),
            const Divider(color: greyE5, height: 0)
          ],
        ),
      );

  void onUpdateOwnership(BuildContext context) {
    Get.bottomSheet(Container(
      color: Colors.white,
      child: ListView(
        children: [
          ListTile(
            title: const Text('Potong'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => mutasiType(MutationType.potong),
          ),
          const Divider(),
          ListTile(
            title: const Text('Mati'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => mutasiType(MutationType.mati),
          ),
          const Divider(),
          ListTile(
            title: const Text('Hilang'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => mutasiType(MutationType.hilang),
          ),
          const Divider(),
          ListTile(
            title: const Text('Jual'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => mutasiType(MutationType.jual),
          ),
          const Divider(),
          ListTile(
            title: const Text('Pindah'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => mutasiType(MutationType.pindah),
          ),
        ],
      ),
    ));
  }

  void mutasiType(MutationType type) async {
    Get.toNamed(
      MutasiEditPage.routeName,
      arguments: MutasiEditParams(
        mutationType: type,
        ternak: controller.params.ternak,
        isFromProfile: true,
      ),
    );
  }
}
