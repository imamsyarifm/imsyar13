import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../utils/datetime_util.dart';
import '../../widgets/default_scaffold.dart';
import '../get/ownership_controller.dart';
import 'ownership_detail_page.dart';

class OwnershipPage extends GetView<OwnershipController> {
  static const routeName = '/ownership';

  const OwnershipPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Kepemilikan',
        body: ListView.builder(
          itemCount: controller.allMutasi.length,
          itemBuilder: (context, index) {
            final mutasi = controller.allMutasi[index];
            return Padding(
              padding: const EdgeInsets.only(left: 16, right: 16, top: 8),
              child: GestureDetector(
                onTap: () => Get.toNamed(OwnershipDetailPage.routeName,
                  arguments: mutasi,
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                              Text(mutasi.tanggalMemilki.readable()),
                              Text('Nama Pemilik: ${mutasi.nama}',
                                  style: GoogleFonts.roboto(color: grey8))
                            ])),
                        const Icon(Icons.arrow_right)
                      ],
                    ),
                    const Divider(color: greyE5)
                  ],
                ),
              ),
            );
          },
        ),
      );
}
