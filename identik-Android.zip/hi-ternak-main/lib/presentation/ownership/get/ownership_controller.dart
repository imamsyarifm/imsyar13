import 'package:get/get.dart';
import '../../../data/models/ternak/identity_kepemilikan_model.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';

class OwnershipController extends GetxController {
  final allMutasi = <IdentityKepemilikanModel>[];
  late IdentityTernakModel ternak;

  @override
  void onInit() {
    super.onInit();
    retrieveArgs();
  }

  void retrieveArgs() {
    final args = Get.arguments;
    if (args is IdentityTernakModel) {
      ternak = args;

      allMutasi.clear();
      if (args.kepemilikan != null) args.kepemilikan;
    }
  }
}
