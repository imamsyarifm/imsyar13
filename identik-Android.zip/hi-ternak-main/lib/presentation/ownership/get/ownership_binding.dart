import 'package:get/get.dart';
import 'ownership_controller.dart';

class OwnershipBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(OwnershipController());
  }
}
