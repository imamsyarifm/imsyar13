import 'package:get/get.dart';
import 'ownership_detail_controller.dart';

class OwnershipDetailBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(OwnershipDetailController());
  }
}
