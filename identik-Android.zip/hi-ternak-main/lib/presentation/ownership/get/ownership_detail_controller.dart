import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../params/ownership_params.dart';

class OwnershipDetailController extends GetxController {
  late OwnershipParams params;

  @override
  void onInit() {
    super.onInit();
    retrieveArgs();
  }

  void retrieveArgs() {
    final args = Get.arguments;
    if (args is OwnershipParams) {
      params = args;
    }
  }

  String date() {
    final dateFormat = DateFormat('dd MMMM yyyy');
    return dateFormat.format(DateTime.now());
  }
}
