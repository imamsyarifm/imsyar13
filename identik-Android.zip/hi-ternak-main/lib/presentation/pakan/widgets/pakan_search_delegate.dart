import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/pakan/pakan.dart';
import '../../../data/repositories/pakan_repository.dart';
import 'pakan_tile.dart';

class PakanSearchDelegate extends SearchDelegate {
  final repository = PakanRepository(
    client: Get.find<Dio>(),
  );

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          query = '';
        },
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () {
        Get.back();
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return FutureBuilder<List<Pakan>>(
      future: repository.list(keyword: query),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          return ListView.builder(
            itemCount: snapshot.data?.length ?? 0,
            itemBuilder: (context, index) {
              final pakan = snapshot.data![index];
              return Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 8),
                child: GestureDetector(
                  onTap: () async {
                    if (pakan.pakan.isNotEmpty) {
                      await Get.bottomSheet(
                        PakanTile(
                          allPakan: pakan.pakan,
                        ),
                        backgroundColor: Colors.white,
                        ignoreSafeArea: false,
                        isScrollControlled: true,
                      );
                    }
                  },
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                              child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(pakan.namaKandang),
                              Text('${pakan.kapasitas} ekor',
                                  style: GoogleFonts.roboto(color: grey8))
                            ],
                          )),
                          const Icon(Icons.arrow_right)
                        ],
                      ),
                      const Divider(color: greyE5)
                    ],
                  ),
                ),
              );
            },
          );
        } else {
          return const Center(
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(green),
            ),
          );
        }
      },
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return const Center(
      child: Text('Harap masukan kata kunci'),
    );
  }
}
