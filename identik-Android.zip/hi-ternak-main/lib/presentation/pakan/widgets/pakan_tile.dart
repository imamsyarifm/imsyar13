import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/pakan/pakan_data.dart';
import '../../../utils/datetime_util.dart';
import '../pages/pakan_detail_page.dart';

class PakanTile extends StatelessWidget {
  const PakanTile({
    required this.allPakan,
    Key? key,
  }) : super(key: key);

  final List<PakanData> allPakan;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: green,
        leading: IconButton(
          onPressed: () => Get.back(), 
          icon: const Icon(Icons.close),
        ),
        title: const Text('Pakan'),
      ),
      body: ListView.builder(
        itemBuilder: (context, index) => ListTile(
          title: Text(allPakan[index].tanggalInput.readable()),
          subtitle: Text('Durasi per hari '
            '${allPakan[index].durasiHari} kali'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Get.toNamed(PakanDetailPage.routeName, 
            arguments: allPakan[index]),
        ),
        itemCount: allPakan.length,
      ),
    );
  }
}
