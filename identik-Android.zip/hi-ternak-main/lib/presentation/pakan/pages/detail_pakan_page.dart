import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../app/consts/icons.dart';
import 'pakan_edit_page.dart';

class DetailPakanPage extends StatelessWidget {
  const DetailPakanPage({Key? key}) : super(key: key);

  static const routeName = '/pakan-detail';

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: green,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: green,
          title: const Text('Pakan'),
        ),
        body: Container(
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(16), topRight: Radius.circular(16)),
            color: Colors.white,
          ),
          child: ListView(
            children: [
              componentTile(context, 'Konsentrat (kg)', '14'),
              componentTile(context, 'Rumput Lapangan (kg)', '100'),
              componentTile(context, 'Leguminosa (kg)', '102'),
              componentTile(context, 'Lain - lain (kg)', '350'),
              componentTile(context, 'Keterangan',
                            // ignore: lines_longer_than_80_chars
                  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
              const SizedBox(height: 100)
            ],
          ),
        ),
        floatingActionButton: FloatingActionButton(
          backgroundColor: yellowDark,
          onPressed: () => Get.toNamed(PakanEditPage.routeName),
          child: Image.asset(pencil, width: 16, height: 16),
        ),
      );

  Widget componentTile(BuildContext context, String title, String value) =>
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            ListTile(
              contentPadding: const EdgeInsets.all(0),
              title: Text(title,
                  style: GoogleFonts.roboto(
                    color: black,
                    fontSize: 12,
                  )),
              subtitle: Text(value,
                  textAlign: TextAlign.justify,
                  style: GoogleFonts.roboto(
                      color: black, fontWeight: FontWeight.bold, fontSize: 16)),
            ),
            const Divider(color: greyE5, height: 0)
          ],
        ),
      );
}
