import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/pakan/pakan.dart';
import '../get/pakan_controller.dart';
import '../widgets/pakan_search_delegate.dart';
import '../widgets/pakan_tile.dart';
import 'pakan_edit_page.dart';

class PakanPage extends GetView<PakanController> {
  const PakanPage({Key? key}) : super(key: key);

  static const routeName = '/pakan';

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: green,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: green,
          title: const Text('Pakan'),
          actions: [
            IconButton(
              onPressed: () => showSearch(
                context: context,
                delegate: PakanSearchDelegate(),
              ),
              icon: const Icon(Icons.search),
            ),
          ],
        ),
        body: Container(
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(16), topRight: Radius.circular(16)),
            color: Colors.white,
          ),
          child: PagedListView<int, Pakan>(
            pagingController: controller.pagingController,
            builderDelegate: PagedChildBuilderDelegate<Pakan>(
              itemBuilder: (context, item, index) {
                return Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16, top: 8),
                  child: GestureDetector(
                    onTap: () async {
                      if (item.pakan.isNotEmpty) {
                        await Get.bottomSheet(
                          PakanTile(
                            allPakan: item.pakan,
                          ),
                          backgroundColor: Colors.white,
                          ignoreSafeArea: false,
                          isScrollControlled: true,
                        );
                        controller.pagingController.refresh();
                      }
                    },
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                                child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(item.namaKandang),
                                Text('${item.kapasitas} ekor',
                                    style: GoogleFonts.roboto(color: grey8))
                              ],
                            )),
                            const Icon(Icons.arrow_right)
                          ],
                        ),
                        const Divider(color: greyE5)
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
        floatingActionButton: FloatingActionButton(
          backgroundColor: green,
          onPressed: () async {
            await Get.toNamed(PakanEditPage.routeName);
            controller.pagingController.refresh();
          },
          child: const Icon(Icons.add),
        ),
      );
}
