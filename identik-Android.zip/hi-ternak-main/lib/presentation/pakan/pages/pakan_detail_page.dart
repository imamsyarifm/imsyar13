import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../app/consts/colors.dart';
import '../../widgets/component_tile.dart';
import '../../widgets/default_scaffold.dart';
import '../get/pakan_detail_controller.dart';

class PakanDetailPage extends GetView<PakanDetailController> {
  static const routeName = '/pakan-detail';

  const PakanDetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      if (controller.pakan == null) {
        return DefaultScaffold(
          appBarTitle: 'Detail Pakan',
          body: Container(
            color: Colors.white,
            child: const Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(green),
              ),
            ),
          ),
        );
      }

      return DefaultScaffold(
        appBarTitle: 'Detail Pakan',
        body: ListView(children: [
          ComponentTile(
            title: 'Konsentrat',
            value: controller.pakan?.konsentrat ?? '-',
          ),
          ComponentTile(
            title: 'Rumput Lapangan',
            value: controller.pakan?.rumputLapangan ?? '-',
          ),
          ComponentTile(
            title: 'Rumput Unggul',
            value: controller.pakan?.rumputUnggul ?? '-',
          ),
          ComponentTile(
            title: 'Leguminosa',
            value: controller.pakan?.leguminosa ?? '-',
          ),
          ComponentTile(
            title: 'Durasi per hari',
            value: controller.pakan?.durasiHari ?? '-',
          ),
          ComponentTile(
            title: 'Lain-lain',
            value: controller.pakan?.lainLain ?? '-',
          ),
          ComponentTile(
            title: 'Keterangan',
            value: controller.pakan?.keterangan ?? '-',
          ),
        ]),
      );
    });
  }
}
