import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../utils/datetime_util.dart';
import '../../../utils/validation_util.dart';
import '../../widgets/confirm_update_widget.dart';
import '../../widgets/default_scaffold.dart';
import '../../widgets/edit_text.dart';
import '../get/pakan_edit_controller.dart';

class PakanEditPage extends GetView<PakanEditController> {
  const PakanEditPage({Key? key}) : super(key: key);

  static const routeName = '/pakan-edit';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Pakan',
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: controller.formKey,
            child: ListView(
              children: [
                EditText(
                  label: 'Tanggal',
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Tanggal', value),
                  autoValidateMode: AutovalidateMode.onUserInteraction,
                  keyboardType: TextInputType.datetime,
                  controller: controller.etDate,
                  isReadOnly: true,
                  onTap: () async {
                    final dateTime = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime.now().add(
                          Duration(
                            days: DateTime.now().differencToOldYear(100).inDays,
                          ),
                        ),
                        lastDate: DateTime.now());
                    if (dateTime != null) controller.setDate(dateTime);
                  },
                ),
                const SizedBox(height: 16),
                EditText(
                  label: 'Kandang*',
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Kandang', value),
                  keyboardType: TextInputType.number,
                  controller: controller.etKandang,
                  isReadOnly: true,
                  onTap: () => controller.chooseKandang(context),
                ),
                const SizedBox(height: 16),
                EditText(
                  label: 'Konsentrat (kg)*',
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Konsentrat', value),
                  keyboardType: TextInputType.number,
                  controller: controller.etKonsentrat,
                ),
                const SizedBox(height: 16),
                EditText(
                    label: 'Rumput Lapangan (kg)*',
                    validator: (value) =>
                        ValidationUtil.emptyValidate('Rumput Lapangan', value),
                    keyboardType: TextInputType.number,
                    controller: controller.etRumputLapangan),
                const SizedBox(height: 16),
                EditText(
                    label: 'Rumput Unggul (kg)*',
                    validator: (value) =>
                        ValidationUtil.emptyValidate('Rumput Unggul', value),
                    keyboardType: TextInputType.number,
                    controller: controller.etRumputUnggul),
                const SizedBox(height: 16),
                EditText(
                    label: 'Leguminosa (kg)*',
                    validator: (value) =>
                        ValidationUtil.emptyValidate('Leguminosa', value),
                    keyboardType: TextInputType.number,
                    controller: controller.etLeguminosa),
                const SizedBox(height: 16),
                EditText(
                    label: 'Lain - lain (kg)',
                    keyboardType: TextInputType.number,
                    controller: controller.etLainnya),
                const SizedBox(height: 16),
                EditText(
                  label: 'Durasi (kali/hari)*',
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Durasi', value),
                  keyboardType: TextInputType.number,
                  controller: controller.etDurasi,
                ),
                const SizedBox(height: 16),
                EditText(
                  label: 'Keterangan',
                  minLines: 5,
                  maxLines: null,
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.done,
                  controller: controller.etKeterangan,
                ),
              ],
            ),
          ),
        ),
        bottomNavigation: Container(
          color: Colors.white,
          child: Row(children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 12, top: 12, bottom: 12, right: 6),
                child: SizedBox(
                  height: 40,
                  child: ElevatedButton(
                      onPressed: () => Get.back(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(36))),
                      child: Text(
                        'BATAL',
                        style: GoogleFonts.roboto(
                            color: black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      )),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                    right: 12, top: 12, bottom: 12, left: 6),
                child: SizedBox(
                  height: 40,
                  child: Obx(() {
                    if (controller.isUpdatingPakan) {
                      return const Center(
                        child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(green),
                        ),
                      );
                    }

                    return ElevatedButton(
                      onPressed: () {
                        Get.dialog(ConfirmUpdateWidget(
                          onCancelPressed: () => Get.back(),
                          onConfirmedPressed: () => controller.updatePakan(),
                        ));
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: yellowDark,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(36))),
                      child: Text(
                        'SIMPAN',
                        style: GoogleFonts.roboto(
                            color: black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      ),
                    );
                  }),
                ),
              ),
            ),
          ]),
        ),
      );
}
