import 'package:get/get.dart';

import 'pakan_detail_controller.dart';

class PakanDetailBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(PakanDetailController());
  }
}
