import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../data/models/kandang/kandang_model.dart';
import '../../../data/models/pakan/update_pakan_request.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../../../data/repositories/pakan_repository.dart';
import '../../../utils/datetime_util.dart';
import '../../kandang/widgets/kandang_search_delegate.dart';

class PakanEditController extends GetxController {
  PakanEditController({
    required PakanRepository repository,
  }) : _repository = repository;

  final PakanRepository _repository;

  final formKey = GlobalKey<FormState>();
  final etKonsentrat = TextEditingController();
  final etRumputLapangan = TextEditingController();
  final etRumputUnggul = TextEditingController();
  final etLeguminosa = TextEditingController();
  final etLainnya = TextEditingController();
  final etKeterangan = TextEditingController();
  final etDurasi = TextEditingController();
  final etKandang = TextEditingController();
  final etDate = TextEditingController();

  final _kandangSelected = Rx<KandangModel?>(null);
  final _durationSelected = Rx<int>(1);
  final _ternak = Rx<IdentityTernakModel?>(null);
  final _isUpdatingPakan = false.obs;
  final _selectedDate = Rx<DateTime>(DateTime.now());

  KandangModel? get kandangSelected => _kandangSelected.value;
  int get durationSelected => _durationSelected.value;
  IdentityTernakModel? get ternak => _ternak.value;
  bool get isUpdatingPakan => _isUpdatingPakan.value;

  @override
  void onReady() {
    super.onReady();
    final args = Get.arguments;
    if (args is IdentityTernakModel) {
      _ternak.value = args;
    }

    initialValue();
  }

  void initialValue() {
    etKonsentrat.text = '0';
    etRumputLapangan.text = '0';
    etRumputUnggul.text = '0';
    etLeguminosa.text = '0';
    etLainnya.text = '0';

    setDate(DateTime.now());
  }

  Future<void> chooseKandang(BuildContext context) async {
    final kandangSelected = await showSearch(
      context: context,
      delegate: KandangSearchDelegate(isForm: true),
    );

    if (kandangSelected is KandangModel) {
      _kandangSelected.value = kandangSelected;
      etKandang.text = kandangSelected.namaKandang;
    }
  }

  void setDuration(int duration) {
    _durationSelected.value = duration;
  }

  void updatePakan() async {
    _isUpdatingPakan.value = true;

    if (formKey.currentState?.validate() == false) {
      _isUpdatingPakan.value = false;
      return;
    }

    final request = UpdatePakanRequest(
      idKandang: _kandangSelected.value?.id ?? '-',
      konsentrat: etKonsentrat.text,
      rumputLapangan: etRumputLapangan.text,
      rumputUnggul: etRumputUnggul.text,
      leguminosa: etLeguminosa.text,
      lainLain: etLainnya.text,
      durasiHari: etDurasi.text,
      keterangan: etKeterangan.text,
      tanggalInput: _selectedDate.value.valueApi(),
      id: DateTime.now().millisecondsSinceEpoch,
    );

    final update = await _repository.updatePakan(
      request: request,
    );
    if (update) {
      Get.back();
      Get.showSnackbar(const GetSnackBar(
        message: 'Perubahan Data Pakan Berhasil',
        duration: Duration(seconds: 3),
      ));
    } else {
      Get.showSnackbar(const GetSnackBar(
        message: 'Perubahan Data Pakan Gagal',
        duration: Duration(seconds: 3),
      ));
    }

    _isUpdatingPakan.value = false;
  }

  void setDate(DateTime dateTime) {
    _selectedDate.value = dateTime;
    etDate.text = dateTime.readable();
  }
}
