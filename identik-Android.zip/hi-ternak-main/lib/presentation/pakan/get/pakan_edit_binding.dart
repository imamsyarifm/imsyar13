import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/pakan_repository.dart';
import 'pakan_edit_controller.dart';

class PakanEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(PakanRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(PakanEditController(
      repository: Get.find<PakanRepository>(),
    ));
  }
}
