import 'package:get/get.dart';

import '../../../data/models/pakan/pakan_data.dart';

class PakanDetailController extends GetxController {
  final _pakan = Rx<PakanData?>(null);

  PakanData? get pakan => _pakan.value;

  @override
  void onReady() {
    super.onReady();
    retrieveArgs;
  }

  void get retrieveArgs {
    final args = Get.arguments;
    if (args is PakanData) {
      _pakan.value = args;
    }
  }
}