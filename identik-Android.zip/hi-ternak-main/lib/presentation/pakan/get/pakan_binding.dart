import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/pakan_repository.dart';
import 'pakan_controller.dart';

class PakanBinding extends Bindings {
  @override
  void dependencies() {
    Get.put<PakanRepository>(PakanRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(PakanController(
      repository: Get.find<PakanRepository>(),
    ));
  }
}
