import 'package:dio/dio.dart';
import 'package:get/get.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

import '../../../data/models/pakan/pakan.dart';
import '../../../data/models/pakan/pakan_data.dart';
import '../../../data/repositories/pakan_repository.dart';
import '../../../utils/validation_util.dart';

class PakanController extends GetxController {
  final PakanRepository _repository;

  PakanController({
    required PakanRepository repository,
  }) : _repository = repository;

  static const _pageSize = 20;
  final pagingController = PagingController<int, Pakan>(
    firstPageKey: 0,
  );

  @override
  void onInit() {
    pagingController.addPageRequestListener((pageKey) {
      retrievePakan(pageKey);
    });
    super.onInit();
  }

  void retrievePakan(int page) async {
    try {
      final newItems = await _repository.list(
        offset: page,
      );
      final isLastPage = newItems.length < _pageSize;
      if (isLastPage) {
        pagingController.appendLastPage(newItems);
      } else {
        final nextPageKey = page + 1;
        pagingController.appendPage(newItems, nextPageKey);
      }
    } catch (error) {
      pagingController.error = error;
      Get.showSnackbar(GetSnackBar(
        message: ValidationUtil.errorMessage(error as DioError),
        duration: const Duration(seconds: 3),
      ));
    }
  }

  PakanData dataPakan(Pakan pakan) => pakan.pakan.first;

  @override
  void dispose() {
    pagingController.dispose();
    super.dispose();
  }
}
