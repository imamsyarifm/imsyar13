import 'package:get/get.dart';

import '../../../data/models/owner/owner_model.dart';

class OwnerDetailController extends GetxController {
  final _owner = Rx<OwnerModel?>(null);

  OwnerModel? get owner => _owner.value;

  @override
  void onReady() {
    super.onReady();
    retrieveArgs;
  }

  void get retrieveArgs async {
    final args = Get.arguments;
    if (args is OwnerModel) {
      _owner.value = args;
    }
  }

  String get address {
    final fullAddress = owner!.address;
    return '${fullAddress.address} RT ${fullAddress.rt} RW ${fullAddress.rw}'
        ' ${fullAddress.district}';
  }
}
