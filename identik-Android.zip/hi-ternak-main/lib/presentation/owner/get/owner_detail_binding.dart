import 'package:get/get.dart';

import 'owner_detail_controller.dart';

class OwnerDetailBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(OwnerDetailController());
  }
}
