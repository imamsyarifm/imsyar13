// import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../data/const/owner_type.dart';
import '../../../data/models/address/district_model.dart';
import '../../../data/models/address/province_model.dart';
import '../../../data/models/address/subdistrict_model.dart';
import '../../../data/models/address/village_model.dart';
import '../../../data/models/owner/add_owner_address_request_model.dart';
import '../../../data/models/owner/add_owner_request_model.dart';
import '../../../data/models/owner/owner_model.dart';
import '../../../data/repositories/address_repository.dart';
import '../../../data/repositories/owner_repository.dart';
import '../../../data/repositories/setting_repository.dart';
import '../../../utils/datetime_util.dart';
import '../../../utils/location_util.dart';
// import '../../../utils/validation_util.dart';
import '../pages/owner_page.dart';

class AddOwnerController extends GetxController {
  final AddressRepository _addressRepository;
  final OwnerRepository _ownerRepository;
  final SettingRepository _settingRepository;

  AddOwnerController({
    required AddressRepository addressRepository,
    required OwnerRepository ownerRepository,
    required SettingRepository settingRepository,
  })  : _addressRepository = addressRepository,
        _ownerRepository = ownerRepository,
        _settingRepository = settingRepository;

  final formKey = GlobalKey<FormState>();
  final etNik = TextEditingController();
  final etNamaLengkap = TextEditingController();
  final etEmail = TextEditingController();
  final etPhone = TextEditingController();
  final etProvince = TextEditingController();
  final etDistrict = TextEditingController();
  final etSubdistrict = TextEditingController();
  final etVillage = TextEditingController();
  final etAddress = TextEditingController();
  final etGender = TextEditingController();
  final etBirthday = TextEditingController();
  final etRt = TextEditingController();
  final etRw = TextEditingController();
  final etIdIsikhnas = TextEditingController();

  final latitude = 0.0.obs;
  final longitude = 0.0.obs;

  final _provinces = Rx<List<ProvinceModel>>([]);
  final _districts = Rx<List<DistrictModel>>([]);
  final _subDistricts = Rx<List<SubdistrictModel>>([]);
  final _villages = Rx<List<VillageModel>>([]);
  final _selectedProvince = Rx<ProvinceModel?>(null);
  final _selectedDistrict = Rx<DistrictModel?>(null);
  final _selectedSubdistrict = Rx<SubdistrictModel?>(null);
  final _selectedVillage = Rx<VillageModel?>(null);
  final _selectedGender = true.obs;
  final _selectedBirthday = Rx<DateTime>(DateTime.now());
  final _isLoadingProvinces = false.obs;
  final _isLoadingDistricts = false.obs;
  final _isLoadingSubDistricts = false.obs;
  final _isLoadingVillages = false.obs;
  final _isUpdatingOwner = false.obs;
  final _ownerType = Rx<OwnerType>(OwnerType.pemilik);
  final _owner = Rx<OwnerModel?>(null);

  ProvinceModel? get selectedProvince => _selectedProvince.value;
  DistrictModel? get selectedDistrict => _selectedDistrict.value;
  SubdistrictModel? get selectedSubdistrict => _selectedSubdistrict.value;
  VillageModel? get selectedVillage => _selectedVillage.value;
  bool get selectedGender => _selectedGender.value;
  DateTime get selectedBirthday => _selectedBirthday.value;
  List<ProvinceModel> get provinces => _provinces.value;
  List<DistrictModel> get districts => _districts.value;
  List<SubdistrictModel> get subDistricts => _subDistricts.value;
  List<VillageModel> get villages => _villages.value;
  bool get isLoadingProvinces => _isLoadingProvinces.value;
  bool get isLoadingDistricts => _isLoadingDistricts.value;
  bool get isLoadingSubDistricts => _isLoadingSubDistricts.value;
  bool get isLoadingVillages => _isLoadingVillages.value;
  OwnerModel? get owner => _owner.value;
  OwnerType get ownerType => _ownerType.value;
  bool get isUpdatingOwner => _isUpdatingOwner.value;

  @override
  void onReady() async {
    super.onReady();
    getCurrentLocation();
    await retrieveProvinces(1);
    await retrieveArgs;
  }

  Future<void> get retrieveArgs async {
    final args = Get.arguments;
    if (args is OwnerModel) {
      _owner.value = args;
      await initialData();
    } else {
      await initialCreateData();
    }
  }

  Future<void> initialCreateData() async {
    setGender(
      isMale: true,
      isInitial: true,
    );
    etBirthday.text = DateTime.now()
        .add(Duration(days: DateTime.now().differencToOldYear(15).inDays))
        .readable();
    _selectedBirthday.value = DateTime.now();

    final defaultProvince = await _settingRepository.defaultProvince;
    final searchProvince =
        _provinces.value.where((element) => element.id == defaultProvince);
    if (searchProvince.isNotEmpty) {
      await setProvinsi(
        value: searchProvince.first,
        isInitial: true,
      );
    }

    final defaultDistrict = await _settingRepository.defaultDistrict;
    final searchDistrict =
        _districts.value.where((element) => element.id == defaultDistrict);
    if (searchDistrict.isNotEmpty) {
      await setKabupaten(
        value: searchDistrict.first,
        isInitial: true,
      );
    }
  }

  Future<void> initialData() async {
    etNik.text = owner!.nik;
    etNamaLengkap.text = owner!.name;
    etEmail.text = owner!.email;
    etPhone.text = owner!.phone;
    etBirthday.text = owner!.birthdate.readable();
    _selectedBirthday.value = owner!.birthdate;

    _selectedGender.value = (owner?.gender == 'laki-laki');
    etGender.text = (_selectedGender.value) ? 'Laki - Laki' : 'Perempuan';

    final searchProvince = _provinces.value
        .where((element) => element.id == owner!.address.idProvince);
    if (searchProvince.isNotEmpty) {
      await setProvinsi(
        value: searchProvince.first,
        isInitial: true,
      );
    }

    final searchDistrict = _districts.value
        .where((element) => element.id == owner!.address.idDistrict);
    if (searchDistrict.isNotEmpty) {
      await setKabupaten(
        value: searchDistrict.first,
        isInitial: true,
      );
    }

    final searchSubDistrict = _subDistricts.value
        .where((element) => element.id == owner!.address.idSubDistrict);
    if (searchSubDistrict.isNotEmpty) {
      await setKecamatan(
        value: searchSubDistrict.first,
        isInitial: true,
      );
    }

    final searchVillage = _villages.value
        .where((element) => element.id == owner!.address.idVillage);
    if (searchVillage.isNotEmpty) {
      await setDesa(
        value: searchVillage.first,
        isInitial: true,
      );
    }

    etAddress.text = owner!.address.address;
    etRt.text = owner!.address.rt;
    etRw.text = owner!.address.rw;
    etIdIsikhnas.text = owner!.idIsikhnas ?? '';

    setOwnerType(
      (owner?.isPemilik == 1) ? OwnerType.pemilik : OwnerType.pemelihara,
    );
  }

  void getCurrentLocation() async {
    final currentLocation = await LocationUtil.currentLocation;
    if (currentLocation != null) {
      latitude.value = currentLocation.latitude;
      longitude.value = currentLocation.longitude;
    }
  }

  Future<void> setProvinsi({
    required ProvinceModel value,
    bool isInitial = false,
  }) async {
    _selectedProvince.value = value;
    etProvince.text = value.province;
    await retrieveDistricts(value.id);
    if (!isInitial) Get.back();
  }

  Future<void> setKabupaten({
    required DistrictModel value,
    bool isInitial = false,
  }) async {
    _selectedDistrict.value = value;
    etDistrict.text = value.district;
    await retrieveSubDistricts(value.id);
    if (!isInitial) Get.back();
  }

  Future<void> setKecamatan({
    required SubdistrictModel value,
    bool isInitial = false,
  }) async {
    _selectedSubdistrict.value = value;
    etSubdistrict.text = value.subDistrict;

    await retrieveVillages(value.id);
    _selectedVillage.value = null;
    etVillage.clear();

    if (!isInitial) Get.back();
  }

  Future<void> setDesa({
    required VillageModel value,
    bool isInitial = false,
  }) async {
    _selectedVillage.value = value;
    etVillage.text = value.urbanVillage;
    if (!isInitial) Get.back();
  }

  Future<void> retrieveProvinces(int idCountry) async {
    _isLoadingProvinces.value = true;
    final provinces = await _addressRepository.provinces(idCountry);
    _provinces.value = provinces;
    _isLoadingProvinces.value = false;
  }

  Future<void> retrieveDistricts(String idProvince) async {
    _isLoadingDistricts.value = true;
    final districts = await _addressRepository.districts(idProvince);
    _districts.value = districts;
    _isLoadingDistricts.value = false;
  }

  Future<void> retrieveSubDistricts(String idDistrict) async {
    _isLoadingSubDistricts.value = true;
    final subDistricts = await _addressRepository.subDistricts(idDistrict);
    _subDistricts.value = subDistricts;
    _isLoadingSubDistricts.value = false;
  }

  Future<void> retrieveVillages(String idSubDistrict) async {
    _isLoadingVillages.value = true;
    final villages = await _addressRepository.villages(idSubDistrict);
    _villages.value = villages;
    _isLoadingVillages.value = false;
  }

  void setGender({
    required bool isMale,
    bool isInitial = false,
  }) {
    _selectedGender.value = isMale;
    etGender.text = (isMale) ? 'Laki - Laki' : 'Perempuan';
    if (!isInitial) Get.back();
  }

  String dateString(DateTime dateTime) {
    final dateFormat = DateFormat('dd MMMM yyyy');
    return dateFormat.format(dateTime);
  }

  void setBirthDay(DateTime dateTime) {
    _selectedBirthday.value = dateTime;
    etBirthday.text = dateString(dateTime);
  }

  bool get isAnyMissingForm {
    if (etNik.text.isEmpty) return true;
    if (etNamaLengkap.text.isEmpty) return true;
    if (_selectedSubdistrict.value == null) return true;
    if (_selectedVillage.value == null) return true;

    return false;
  }

  void manageOwner() async {
    if (isAnyMissingForm) {
      return;
    }

    final addressRequst = AddOwnerAddressRequestModel(
      idProvince: _selectedProvince.value?.id,
      idDistrict: _selectedDistrict.value?.id,
      idSubDistrict: _selectedSubdistrict.value?.id,
      idVillage: _selectedVillage.value?.id,
      rt: etRt.text,
      rw: etRw.text,
      address: etAddress.text,
      latitude: latitude.value.toString(),
      longitude: longitude.value.toString(),
    );

    final request = AddOwnerRequestModel(
      id: _owner.value?.id,
      nik: etNik.text,
      name: etNamaLengkap.text,
      gender: (_selectedGender.value) ? 'laki-laki' : 'perempuan',
      birthdate: _selectedBirthday.value.valueApi(),
      email: etEmail.text,
      phone: etPhone.text,
      idIsikhnas: etIdIsikhnas.text,
      isPemilik: (_ownerType.value == OwnerType.pemilik) ? '1' : '0',
      address: addressRequst,
    );

    try {
      final update = await _ownerRepository.insert(request);
      if (update) {
        Get.until((route) => route.settings.name == OwnerPage.routeName);
        Get.showSnackbar(const GetSnackBar(
          message: 'Perubahan data pemilik berhasil',
          duration: Duration(seconds: 3),
        ));
      } else {
        Get.showSnackbar(const GetSnackBar(
          message: 'Perubahan data pemilik gagal',
          duration: Duration(seconds: 3),
        ));
      }
    } catch (error) {
      // Get.showSnackbar(GetSnackBar(
      //   message: ValidationUtil.errorMessage(error as DioError),
      //   duration: const Duration(seconds: 3),
      // ));
      Get.showSnackbar(const GetSnackBar(
        message: 'Perubahan data pemilik gagal',
        duration: Duration(seconds: 3),
      ));
    }
  }

  void setOwnerType(OwnerType? type) {
    if (type != null) _ownerType.value = type;
  }
}
