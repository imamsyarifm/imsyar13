import 'package:dio/dio.dart';
import 'package:get/get.dart';

import '../../../data/repositories/owner_repository.dart';
import 'owner_controller.dart';

class OwnerBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(OwnerRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(OwnerController(
      repository: Get.find<OwnerRepository>(),
    ));
  }
}
