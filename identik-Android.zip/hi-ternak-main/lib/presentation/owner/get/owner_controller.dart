import 'package:dio/dio.dart';
import 'package:get/get.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

import '../../../data/models/owner/owner_model.dart';
import '../../../data/repositories/owner_repository.dart';
import '../../../utils/networking_util.dart';
import '../../../utils/validation_util.dart';

class OwnerController extends GetxController {
  final OwnerRepository _repository;

  OwnerController({
    required OwnerRepository repository,
  }) : _repository = repository;

  static const _pageSize = 20;
  final pagingController = PagingController<int, OwnerModel>(
    firstPageKey: 0,
  );

  final _isConnectedToNetwork = false.obs;

  bool get isConnectedToNetwork => _isConnectedToNetwork.value;

  @override
  void onInit() {
    super.onInit();
    pagingController.addPageRequestListener((pageKey) {
      retrieveOwners(pageKey);
    });
  }

  @override
  void onReady() async {
    _isConnectedToNetwork.value = await NetworkingUtil.isConnected;
    super.onReady();
    retrieveOwners;
  }

  void retrieveOwners(int page) async {
    try {
      final newItems = await _repository.owners(
        offset: page,
        isIncludeCompany: false,
      );
      final isLastPage = newItems.length < _pageSize;
      if (isLastPage) {
        pagingController.appendLastPage(newItems);
      } else {
        final nextPageKey = page + 1;
        pagingController.appendPage(newItems, nextPageKey);
      }
    } catch (error) {
      pagingController.error = error;
      Get.showSnackbar(GetSnackBar(
        message: ValidationUtil.errorMessage(error as DioError),
        duration: const Duration(seconds: 3),
      ));
    }
  }

  @override
  void dispose() {
    pagingController.dispose();
    super.dispose();
  }
}
