import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/owner/owner_model.dart';
import '../../identitas/widgets/search_owner_delegate.dart';
import '../../widgets/default_scaffold.dart';
import '../get/owner_controller.dart';
import 'add_owner_page.dart';
import 'owner_detail_page.dart';

class OwnerPage extends GetView<OwnerController> {
  const OwnerPage({Key? key}) : super(key: key);

  static const routeName = '/owner';

  @override
  Widget build(BuildContext context) {
    return DefaultScaffold(
      appBarTitle: 'Pemilik',
      actions: [
        IconButton(
          onPressed: () => showSearch(
            context: context,
            delegate: SearchOwnerDelegate(
              isForm: false,
              isIncludeCompany: false,
            ),
          ),
          icon: const Icon(Icons.search),
        ),
      ],
      body: PagedListView<int, OwnerModel>(
        pagingController: controller.pagingController,
        builderDelegate: PagedChildBuilderDelegate<OwnerModel>(
          itemBuilder: (context, item, index) {
            return Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: ListTile(
                title: Text(item.name,
                    style: GoogleFonts.roboto(fontWeight: FontWeight.bold)),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item.nik),
                    Text(
                        '${item.address.province}, ${item.address.district},'
                        '${item.address.subDistrict},'
                        '${item.address.urbanVillage}',
                        style: GoogleFonts.roboto(color: grey8)),
                  ],
                ),
                trailing: const Icon(Icons.arrow_right),
                onTap: () async {
                  await Get.toNamed(OwnerDetailPage.routeName, arguments: item);
                  controller.retrieveOwners;
                },
              ),
            );
          },
        ),
      ),
      floatingAction: Obx(
        () => Visibility(
          visible: controller.isConnectedToNetwork,
          replacement: const SizedBox.shrink(),
          child: FloatingActionButton(
            onPressed: () async {
              await Get.toNamed(AddOwnerPage.routeName);
              controller.pagingController.refresh();
            },
            backgroundColor: green,
            child: const Icon(Icons.person_add),
          ),
        ),
      ),
    );
  }
}
