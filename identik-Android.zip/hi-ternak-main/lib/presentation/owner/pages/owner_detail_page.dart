import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../app/consts/colors.dart';
import '../../widgets/component_tile.dart';
import '../../widgets/default_scaffold.dart';
import '../get/owner_detail_controller.dart';
import 'add_owner_page.dart';

class OwnerDetailPage extends GetView<OwnerDetailController> {
  const OwnerDetailPage({Key? key}) : super(key: key);

  static const routeName = '/owner-detail';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Detail Pemilik',
        body: Obx(() {
          if (controller.owner == null) {
            return Container(
              color: Colors.white,
              child: const Center(
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(green),
                ),
              ),
            );
          }

          return ListView(children: [
            ComponentTile(title: 'NIK', value: controller.owner!.nik),
            ComponentTile(
                title: 'ID Isikhnas',
                value: controller.owner!.idIsikhnas ?? '-'),
            ComponentTile(title: 'Nama', value: controller.owner!.name),
            ComponentTile(
                title: 'Jenis Kelamin', value: controller.owner!.gender),
            ComponentTile(title: 'Umur', value: controller.owner!.umur),
            ComponentTile(title: 'No. Telepon', value: controller.owner!.phone),
            ComponentTile(title: 'Email', value: controller.owner!.email),
            ComponentTile(
              title: 'Status',
              value:
                  (controller.owner!.isPemilik == 1) ? 'Pemilik' : 'Pemelihara',
            ),
            ComponentTile(
              title: 'Alamat',
              value: controller.address,
            ),
          ]);
        }),
        floatingAction: FloatingActionButton(
          onPressed: () =>
              Get.toNamed(AddOwnerPage.routeName, arguments: controller.owner),
          backgroundColor: green,
          child: const Icon(Icons.edit, color: Colors.white),
        ),
      );
}
