import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../data/const/owner_type.dart';
import '../../../data/models/address/subdistrict_model.dart';
import '../../../data/models/address/village_model.dart';
import '../../../utils/datetime_util.dart';
import '../../../utils/validation_util.dart';
import '../../register/widgets/chooseable_widget.dart';
import '../../widgets/confirm_update_widget.dart';
import '../../widgets/default_scaffold.dart';
import '../../widgets/edit_text.dart';
import '../get/add_owner_controller.dart';
import 'owner_page.dart';

class AddOwnerPage extends GetView<AddOwnerController> {
  const AddOwnerPage({Key? key}) : super(key: key);

  static const routeName = '/add-owner';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
      appBarTitle: 'Tambah Pemilik',
      body: Container(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: controller.formKey,
          child: ListView(
            children: [
              Obx(
                () => EditText(
                  label: 'NIK*',
                  validator: (value) => ValidationUtil.emptyMinLengthValidate(
                    formName: 'NIK',
                    value: value,
                    minLength: 16,
                  ),
                  autoValidateMode: AutovalidateMode.onUserInteraction,
                  keyboardType: TextInputType.number,
                  controller: controller.etNik,
                  isReadOnly: controller.owner != null,
                  maxLength: 16,
                  enableInteractiveSelection: false,
                  inputFormatters: <TextInputFormatter>[
                    FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              EditText(
                label: 'Nama Lengkap*',
                validator: (value) => ValidationUtil.emptyMinLengthValidate(
                  formName: 'Nama Lengkap',
                  value: value,
                  minLength: 3,
                ),
                autoValidateMode: AutovalidateMode.onUserInteraction,
                keyboardType: TextInputType.text,
                textInputAction: TextInputAction.done,
                controller: controller.etNamaLengkap,
                maxLength: 30,
                enableInteractiveSelection: false,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(
                      RegExp(r'[A-Za-z0-9.,-\s]')),
                ],
              ),
              const SizedBox(height: 16),
              EditText(
                  label: 'Jenis Kelamin*',
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Jenis Kelamin', value),
                  autoValidateMode: AutovalidateMode.onUserInteraction,
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.done,
                  suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                  isReadOnly: true,
                  onTap: () => showModalBottomSheet(
                      context: context,
                      builder: (context) => ChooseableWidget<bool>(
                          values: List.generate(2, (index) => index % 2 == 0),
                          title: (value) =>
                              (value) ? 'Laki - Laki' : 'Perempuan',
                          onSelected: (value) => controller.setGender(
                                isMale: value,
                                isInitial: false,
                              ))),
                  controller: controller.etGender),
              const SizedBox(height: 16),
              EditText(
                  label: 'Tanggal Lahir*',
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Tanggal Lahir', value),
                  autoValidateMode: AutovalidateMode.onUserInteraction,
                  keyboardType: TextInputType.datetime,
                  suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                  isReadOnly: true,
                  onTap: () async {
                    final dateTime = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now().add(Duration(
                          days: DateTime.now().differencToOldYear(15).inDays)),
                      firstDate: DateTime.now().add(Duration(
                          days: DateTime.now().differencToOldYear(100).inDays)),
                      lastDate: DateTime.now().add(Duration(
                          days: DateTime.now().differencToOldYear(15).inDays)),
                    );
                    if (dateTime != null) controller.setBirthDay(dateTime);
                  },
                  controller: controller.etBirthday),
              const SizedBox(height: 16),
              EditText(
                label: 'Email',
                keyboardType: TextInputType.emailAddress,
                controller: controller.etEmail,
                maxLength: 100,
              ),
              const SizedBox(height: 16),
              EditText(
                label: 'No. Telepon*',
                keyboardType: TextInputType.phone,
                controller: controller.etPhone,
                validator: (value) => ValidationUtil.emptyMinLengthValidate(
                  formName: 'No. Telepon',
                  value: value,
                  minLength: 8,
                ),
                autoValidateMode: AutovalidateMode.onUserInteraction,
                maxLength: 13,
                enableInteractiveSelection: false,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                ],
              ),
              const SizedBox(height: 16),
              EditText(
                label: 'ID Isikhnas*',
                keyboardType: TextInputType.text,
                textInputAction: TextInputAction.done,
                controller: controller.etIdIsikhnas,
                validator: (value) =>
                    ValidationUtil.emptyValidate('ID Isikhnas', value),
                autoValidateMode: AutovalidateMode.onUserInteraction,
                enableInteractiveSelection: false,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(
                      RegExp(r'[A-Za-z0-9.,-\s]')),
                ],
                maxLength: 50,
              ),
              const SizedBox(height: 6),
              Obx(() {
                return RadioListTile<OwnerType>(
                  value: OwnerType.pemilik,
                  groupValue: controller.ownerType,
                  onChanged: (value) => controller.setOwnerType(value),
                  title: Text(OwnerType.pemilik.label),
                  activeColor: green,
                );
              }),
              Obx(() {
                return RadioListTile<OwnerType>(
                  value: OwnerType.pemelihara,
                  groupValue: controller.ownerType,
                  onChanged: (value) => controller.setOwnerType(value),
                  title: Text(OwnerType.pemelihara.label),
                  activeColor: green,
                );
              }),
              const SizedBox(height: 6),
              Obx(() {
                if (controller.isLoadingProvinces) {
                  return const Center(
                    child: CircularProgressIndicator(
                      color: green,
                    ),
                  );
                } else {
                  return EditText(
                    controller: controller.etProvince,
                    validator: (value) =>
                        ValidationUtil.emptyValidate('Provinsi', value),
                    // onTap: () => showModalBottomSheet(
                    //   context: context,
                    //   builder: (context) => ChooseableWidget<ProvinceModel>(
                    //     values: controller.provinces,
                    //     title: (ProvinceModel provinsi) => provinsi.province,
                    //     onSelected: (provinsi) => controller.setProvinsi(
                    //       value: provinsi,
                    //     ),
                    //   ),
                    // ),
                    isReadOnly: true,
                    label: 'Propinsi*',
                    suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                  );
                }
              }),
              const SizedBox(height: 14),
              Obx(() {
                if (controller.isLoadingDistricts) {
                  return const Center(
                    child: CircularProgressIndicator(
                      color: green,
                    ),
                  );
                } else {
                  return EditText(
                    controller: controller.etDistrict,
                    validator: (value) =>
                        ValidationUtil.emptyValidate('Kabupaten', value),
                    // onTap: () => showModalBottomSheet(
                    //     context: context,
                    //     builder: (context) =>
                    //  ChooseableWidget<DistrictModel>(
                    //           values: controller.districts,
                    //           title: (DistrictModel kabupaten) =>
                    //               kabupaten.district,
                    //           onSelected: (kabupaten) =>
                    //               controller.setKabupaten(value: kabupaten),
                    //         )),
                    label: 'Kabupaten / Kota*',
                    isReadOnly: true,
                    suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                  );
                }
              }),
              const SizedBox(height: 14),
              Obx(() {
                if (controller.isLoadingSubDistricts) {
                  return const Center(
                    child: CircularProgressIndicator(
                      color: green,
                    ),
                  );
                } else {
                  return EditText(
                    controller: controller.etSubdistrict,
                    validator: (value) =>
                        ValidationUtil.emptyValidate('Kecamatan', value),
                    autoValidateMode: AutovalidateMode.onUserInteraction,
                    onTap: () => showModalBottomSheet(
                        context: context,
                        builder: (context) =>
                            ChooseableWidget<SubdistrictModel>(
                              values: controller.subDistricts,
                              title: (SubdistrictModel kecamatan) =>
                                  kecamatan.subDistrict,
                              onSelected: (kecamatan) =>
                                  controller.setKecamatan(value: kecamatan),
                            )),
                    label: 'Kecamatan*',
                    isReadOnly: true,
                    suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                  );
                }
              }),
              const SizedBox(height: 14),
              Obx(() {
                if (controller.isLoadingVillages) {
                  return const Center(
                    child: CircularProgressIndicator(
                      color: green,
                    ),
                  );
                } else {
                  return EditText(
                    controller: controller.etVillage,
                    validator: (value) =>
                        ValidationUtil.emptyValidate('Desa', value),
                    autoValidateMode: AutovalidateMode.onUserInteraction,
                    onTap: () => showModalBottomSheet(
                        context: context,
                        builder: (context) => ChooseableWidget<VillageModel>(
                              values: controller.villages,
                              title: (VillageModel desa) => desa.urbanVillage,
                              onSelected: (desa) =>
                                  controller.setDesa(value: desa),
                            )),
                    label: 'Desa*',
                    isReadOnly: true,
                    suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                  );
                }
              }),
              const SizedBox(height: 14),
              EditText(
                controller: controller.etAddress,
                keyboardType: TextInputType.streetAddress,
                label: 'Alamat Lengkap*',
                minLines: 5,
                maxLines: null,
                validator: (value) => ValidationUtil.emptyMinLengthValidate(
                  formName: 'Alamat Lengkap',
                  value: value,
                  minLength: 10,
                ),
                autoValidateMode: AutovalidateMode.onUserInteraction,
                maxLength: 100,
                enableInteractiveSelection: false,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(
                      RegExp(r'[A-Za-z0-9.,-\s]')),
                ],
              ),
              const SizedBox(height: 14),
              EditText(
                controller: controller.etRt,
                keyboardType: TextInputType.number,
                label: 'RT*',
                validator: (value) => ValidationUtil.emptyValidate('RT', value),
                autoValidateMode: AutovalidateMode.onUserInteraction,
                maxLength: 3,
                enableInteractiveSelection: false,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                ],
              ),
              const SizedBox(height: 14),
              EditText(
                controller: controller.etRw,
                keyboardType: TextInputType.number,
                label: 'RW*',
                validator: (value) => ValidationUtil.emptyValidate('RW', value),
                autoValidateMode: AutovalidateMode.onUserInteraction,
                maxLength: 3,
                enableInteractiveSelection: false,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                ],
              ),
              const SizedBox(height: 14),
              Obx(
                () => ListTile(
                  title: Text('Latitude: ${controller.latitude}',
                      style: GoogleFonts.roboto(
                        fontSize: 14,
                        color: black,
                      )),
                  subtitle: Text('Longitude: ${controller.longitude}',
                      style: GoogleFonts.roboto(
                        fontSize: 14,
                        color: black,
                      )),
                  trailing: IconButton(
                    icon: const Icon(Icons.location_on, color: green),
                    onPressed: () => controller.getCurrentLocation(),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigation: Obx(() {
        if (controller.isUpdatingOwner) {
          return const LinearProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(green),
          );
        }

        return Container(
          color: Colors.white,
          child: Row(children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 12, top: 12, bottom: 12, right: 6),
                child: SizedBox(
                  height: 40,
                  child: ElevatedButton(
                      onPressed: () => Get.dialog(ConfirmUpdateWidget(
                            content: 'Apakah anda yakin ingin membatalkan '
                                'perubahan ini?',
                            onCancelPressed: () => Get.back(),
                            onConfirmedPressed: () {
                              Get.until((route) =>
                                  route.settings.name == OwnerPage.routeName);
                            },
                          )),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(36))),
                      child: Text(
                        'BATAL',
                        style: GoogleFonts.roboto(
                            color: black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      )),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                    right: 12, top: 12, bottom: 12, left: 6),
                child: SizedBox(
                  height: 40,
                  child: ElevatedButton(
                      onPressed: () {
                        if (controller.formKey.currentState?.validate() ==
                            false) {
                          return;
                        }

                        if (controller.latitude.value == 0 ||
                            controller.longitude.value == 0) {
                          Get.showSnackbar(const GetSnackBar(
                            message:
                                'Mohon pastikan titik koordinat sudah sesuai',
                            duration: Duration(seconds: 3),
                          ));
                          return;
                        }

                        Get.dialog(ConfirmUpdateWidget(
                          onCancelPressed: () => Get.back(),
                          onConfirmedPressed: () => controller.manageOwner(),
                        ));
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: yellowDark,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(36))),
                      child: Text(
                        'SIMPAN',
                        style: GoogleFonts.roboto(
                            color: black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      )),
                ),
              ),
            ),
          ]),
        );
      }));
}
