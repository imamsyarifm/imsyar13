import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../data/models/address/district_model.dart';
import '../../../data/models/address/province_model.dart';
import '../../../data/models/address/subdistrict_model.dart';
import '../../../data/models/address/village_model.dart';
import '../../../data/models/combo/combo_model.dart';
import '../../../data/models/register.dart';
import '../../../data/models/register/register_address_request_model.dart';
import '../../../data/models/register/register_request_model.dart';
import '../../../data/repositories/address_repository.dart';
import '../../../data/repositories/authentication_repository.dart';
import '../../../data/repositories/combo_repository.dart';
import '../../../utils/location_util.dart';
import '../../../utils/validation_util.dart';
import '../../login/pages/login_page.dart';
import '../pages/register_password_page.dart';

class RegisterController extends GetxController {
  final AddressRepository _addressRepository;
  final AuthenticationRepository _authenticationRepository;
  final ComboRepository _comboRepository;

  RegisterController({
    required AddressRepository addressRepository,
    required AuthenticationRepository authenticationRepository,
    required ComboRepository comboRepository,
  })  : _addressRepository = addressRepository,
        _authenticationRepository = authenticationRepository,
        _comboRepository = comboRepository;

  final registerPeternakFormKey = GlobalKey<FormState>();
  final registerKelompokFormKey = GlobalKey<FormState>();
  final registerPasswordFormKey = GlobalKey<FormState>();

  final etNamaPeternak = TextEditingController();
  final etUsername = TextEditingController();
  final etPhone = TextEditingController();
  final etEmail = TextEditingController();
  final etKelompok = TextEditingController();

  final etProvinsi = TextEditingController();
  final etKabupaten = TextEditingController();
  final etWorkArea = TextEditingController();
  final etKecamatan = TextEditingController();
  final etDesa = TextEditingController();
  final etAlamat = TextEditingController();

  final etNamaKelompok = TextEditingController();
  final etNamaPic = TextEditingController();
  final etPhoneKelompok = TextEditingController();

  final etProvinsiKelompok = TextEditingController();
  final etKabupatenKelompok = TextEditingController();
  final etKecamatanKelompok = TextEditingController();
  final etDesaKelompok = TextEditingController();
  final etAlamatKelompok = TextEditingController();

  final etPassword = TextEditingController();
  final etPasswordConfirm = TextEditingController();

  final _selectedProvinsi = Rx<ProvinceModel?>(null);
  final _selectedKabupaten = Rx<DistrictModel?>(null);
  final _selectedOnlyDistrict = Rx<DistrictModel?>(null);
  final _selectedKecamatan = Rx<SubdistrictModel?>(null);
  final _selectedDesa = Rx<VillageModel?>(null);
  final _selectedKelompok = Rx<ComboModel?>(null);
  final _officerType = true.obs;

  final _selectedProvinsiKelompok = Rx<ProvinceModel?>(null);
  final _selectedKabupatenKelompok = Rx<DistrictModel?>(null);
  final _selectedKecamatanKelompok = Rx<SubdistrictModel?>(null);
  final _selectedDesaKelompok = Rx<VillageModel?>(null);

  final _provinces = Rx<List<ProvinceModel>>([]);
  final _districts = Rx<List<DistrictModel>>([]);
  final _onlyDistricts = Rx<List<DistrictModel>>([]);
  final _subDistricts = Rx<List<SubdistrictModel>>([]);
  final _villages = Rx<List<VillageModel>>([]);
  final _allKelompok = Rx<List<ComboModel>>([]);
  final _isLoadingProvinces = false.obs;
  final _isLoadingDistricts = false.obs;
  final _isLoadingOnlyDistricts = false.obs;
  final _isLoadingSubDistricts = false.obs;
  final _isLoadingVillages = false.obs;
  final _isLoadingKelompok = false.obs;
  final latitude = 0.0.obs;
  final longitude = 0.0.obs;

  late RegisterPeternak registerPeternak;
  late RegisterKelompok registerKelompok;

  ProvinceModel? get selectedProvinsi => _selectedProvinsi.value;
  DistrictModel? get selectedKabupaten => _selectedKabupaten.value;
  DistrictModel? get selectedOnlyDistrict => _selectedOnlyDistrict.value;
  SubdistrictModel? get selectedKecamatan => _selectedKecamatan.value;
  VillageModel? get selectedDesa => _selectedDesa.value;
  ProvinceModel? get selectedProvinsiKelompok => _selectedProvinsi.value;
  DistrictModel? get selectedKabupatenKelompok => _selectedKabupaten.value;
  SubdistrictModel? get selectedKecamatanKelompok => _selectedKecamatan.value;
  VillageModel? get selectedDesaKelompok => _selectedDesa.value;
  ComboModel? get selectedKelompok => _selectedKelompok.value;
  List<ProvinceModel> get provinces => _provinces.value;
  List<DistrictModel> get districts => _districts.value;
  List<DistrictModel> get onlyDistricts => _onlyDistricts.value;
  List<SubdistrictModel> get subDistricts => _subDistricts.value;
  List<VillageModel> get villages => _villages.value;
  List<ComboModel> get allKelompok => _allKelompok.value;
  bool get isLoadingProvinces => _isLoadingProvinces.value;
  bool get isLoadingDistricts => _isLoadingDistricts.value;
  bool get isLoadingOnlyDistricts => _isLoadingOnlyDistricts.value;
  bool get isLoadingSubDistricts => _isLoadingSubDistricts.value;
  bool get isLoadingVillages => _isLoadingVillages.value;
  bool get isLoadingKelompok => _isLoadingKelompok.value;
  bool get officerType => _officerType.value;

  @override
  void onReady() async {
    super.onReady();

    /// Indonesian id is 1
    retrieveProvinces(1);
    retrieveOnlyDistricts;
    retrieveKelompok;
  }

  void setProvinsi(ProvinceModel value) {
    _selectedProvinsi.value = value;
    etProvinsi.text = value.province;
    retrieveDistricts(value.id);
    Get.back();
  }

  void setKabupaten(DistrictModel value) {
    _selectedKabupaten.value = value;
    etKabupaten.text = value.district;
    retrieveSubDistricts(value.id);
    Get.back();
  }

  void setWorkArea(DistrictModel value) {
    _selectedOnlyDistrict.value = value;
    etWorkArea.text = value.district;
    Get.back();
  }

  void setKecamatan(SubdistrictModel value) {
    _selectedKecamatan.value = value;
    etKecamatan.text = value.subDistrict;
    retrieveVillages(value.id);
    Get.back();
  }

  void setDesa(VillageModel value) {
    _selectedDesa.value = value;
    etDesa.text = value.urbanVillage;
    Get.back();
  }

  void setProvinsiKelompok(ProvinceModel value) {
    _selectedProvinsiKelompok.value = value;
    etProvinsiKelompok.text = value.province;
    Get.back();
  }

  void setKabupatenKelompok(DistrictModel value) {
    _selectedKabupatenKelompok.value = value;
    etKabupatenKelompok.text = value.district;
    Get.back();
  }

  void setKecamatanKelompok(SubdistrictModel value) {
    _selectedKecamatanKelompok.value = value;
    etKecamatanKelompok.text = value.subDistrict;
    Get.back();
  }

  void setDesaKelompok(VillageModel value) {
    _selectedDesaKelompok.value = value;
    etDesaKelompok.text = value.urbanVillage;
    Get.back();
  }

  void setKelompok(ComboModel value) {
    _selectedKelompok.value = value;
    etKelompok.text = value.label;
    Get.back();
  }

  void setRegisterKelompok() {
    if (registerKelompokFormKey.currentState!.validate()) {
      registerKelompok = RegisterKelompok(
          name: etNamaKelompok.text,
          namePic: etNamaPic.text,
          phone: etPhoneKelompok.text,
          provinsi: selectedProvinsiKelompok!,
          kabupaten: selectedKabupatenKelompok!,
          kecamatan: selectedKecamatanKelompok!,
          desa: selectedDesaKelompok!,
          alamat: etAlamatKelompok.text);

      Get.toNamed(RegisterPasswordPage.routeName);
    }
  }

  bool get isPayloadRegisterMissing {
    if (etNamaPeternak.text.isEmpty) return true;
    if (etUsername.text.isEmpty) return true;
    if (etPhone.text.isEmpty) return true;
    if (etEmail.text.isEmpty) return true;
    if (_selectedOnlyDistrict.value == null) return true;
    if (etAlamat.text.isEmpty) return true;
    // if (_selectedKabupaten.value == null) return true;
    // if (_selectedKecamatan.value == null) return true;
    // if (_selectedProvinsi.value == null) return true;
    // if (_selectedDesa.value == null) return true;
    if (etPassword.text.isEmpty) return true;

    return false;
  }

  bool get canNextForm {
    if (etNamaPeternak.text.isEmpty) return false;
    if (etUsername.text.isEmpty) return false;
    if (etPhone.text.isEmpty) return false;
    if (etEmail.text.isEmpty) return false;
    if (_selectedOnlyDistrict.value == null) return false;
    if (etAlamat.text.isEmpty) return false;
    // if (_selectedKabupaten.value == null) return false;
    // if (_selectedKecamatan.value == null) return false;
    // if (_selectedProvinsi.value == null) return false;
    // if (_selectedDesa.value == null) return false;

    return true;
  }

  void register() async {
    if (isPayloadRegisterMissing) {
      Get.showSnackbar(const GetSnackBar(
        title: 'Registrasi Gagal',
        message: 'Harap lengkapi formulir!',
        duration: Duration(seconds: 3),
      ));
      return;
    }

    if (registerPasswordFormKey.currentState!.validate()) {
      if (etPassword.text == etPasswordConfirm.text) {
        final payload = RegisterRequestModel(
          name: etNamaPeternak.text,
          username: etUsername.text,
          phone: etPhone.text,
          email: etEmail.text,
          workArea: _selectedOnlyDistrict.value!.id.toString(),
          isOfficer: (_officerType.value) ? '1' : '2',
          idKelompok:
              (!_officerType.value) ? _selectedKelompok.value?.value : null,
          address: RegisterAddressRequestModel(
            address: etAlamat.text,
            idDistrict: _selectedKabupaten.value?.id.toString(),
            idSubDistrict: _selectedKecamatan.value?.id.toString(),
            idProvince: _selectedProvinsi.value?.id.toString(),
            idVillage: _selectedDesa.value?.id.toString(),
            latitude: latitude.value.toString(),
            longitude: longitude.value.toString(),
          ),
          password: etPassword.text,
        );

        try {
          final register = await _authenticationRepository.register(payload);

          if (register) {
            Get.showSnackbar(const GetSnackBar(
              title: 'Registrasi Berhasil',
              message: 'Harap login untuk menggunakan aplikasi',
              duration: Duration(seconds: 3),
            ));
            Get.offAllNamed(LoginPage.routeName);
          } else {
            Get.showSnackbar(const GetSnackBar(
              title: 'Registrasi Gagal',
              message: 'Kata sandi dan konfirmasi kata sandi berbeda!',
              duration: Duration(seconds: 3),
            ));
          }
        } catch (error) {
          debugPrint(error.toString());
          Get.showSnackbar(GetSnackBar(
            message: ValidationUtil.errorMessage(error as DioError),
            duration: const Duration(seconds: 3),
          ));
        }
      } else {
        Get.showSnackbar(const GetSnackBar(
          title: 'Registrasi Gagal',
          message: 'Kata sandi dan konfirmasi kata sandi berbeda!',
          duration: Duration(seconds: 3),
        ));
      }
    }
  }

  void retrieveProvinces(int idCountry) async {
    _isLoadingProvinces.value = true;
    final provinces = await _addressRepository.provinces(idCountry);
    _provinces.value = provinces;
    _isLoadingProvinces.value = false;
  }

  void retrieveDistricts(String idProvince) async {
    _isLoadingDistricts.value = true;
    final districts = await _addressRepository.districts(idProvince);
    _districts.value = districts;
    _isLoadingDistricts.value = false;
  }

  void get retrieveOnlyDistricts async {
    _isLoadingOnlyDistricts.value = true;
    final districts = await _addressRepository.onlyDistricts;
    _onlyDistricts.value = districts;
    _isLoadingOnlyDistricts.value = false;
  }

  void retrieveSubDistricts(String idDistrict) async {
    _isLoadingSubDistricts.value = true;
    final subDistricts = await _addressRepository.subDistricts(idDistrict);
    _subDistricts.value = subDistricts;
    _isLoadingSubDistricts.value = false;
  }

  void retrieveVillages(String idSubDistrict) async {
    _isLoadingVillages.value = true;
    final villages = await _addressRepository.villages(idSubDistrict);
    _villages.value = villages;
    _isLoadingVillages.value = false;
  }

  void get retrieveKelompok async {
    _isLoadingKelompok.value = true;
    final kelompok = await _comboRepository.allKelompok;
    _allKelompok.value = kelompok;
    _isLoadingKelompok.value = false;
  }

  void getCurrentLocation() async {
    final currentLocation = await LocationUtil.currentLocation;
    if (currentLocation != null) {
      latitude.value = currentLocation.latitude;
      longitude.value = currentLocation.longitude;
    }
  }
}
