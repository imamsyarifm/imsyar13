import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/address_repository.dart';

import '../../../data/repositories/authentication_repository.dart';
import '../../../data/repositories/combo_repository.dart';
import 'register_controller.dart';

class RegisterBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(AddressRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(AuthenticationRepository(
      dio: Get.find<Dio>(),
    ));
    Get.put(ComboRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(RegisterController(
      addressRepository: Get.find<AddressRepository>(),
      authenticationRepository: Get.find<AuthenticationRepository>(),
      comboRepository: Get.find<ComboRepository>(),
    ));
  }
}
