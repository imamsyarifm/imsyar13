import 'package:flutter/material.dart';

class ChooseableWidget<T> extends StatelessWidget {
  const ChooseableWidget(
      {Key? key,
      required this.values,
      required this.title,
      required this.onSelected})
      : super(key: key);

  final List<T> values;
  final String Function(T) title;
  final Function(T) onSelected;

  @override
  Widget build(BuildContext context) => ListView.separated(
      itemBuilder: (context, index) => ListTile(
          title: Text(title(values[index])),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => onSelected(values[index])),
      separatorBuilder: (context, index) => const Divider(height: 0),
      itemCount: values.length);
}
