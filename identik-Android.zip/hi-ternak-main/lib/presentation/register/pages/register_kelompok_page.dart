import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/address/district_model.dart';
import '../../../data/models/address/province_model.dart';
import '../../../data/models/address/subdistrict_model.dart';
import '../../../data/models/address/village_model.dart';
import '../../../utils/validation_util.dart';
import '../../widgets/edit_text.dart';
import '../../widgets/top_authentication_widget.dart';
import '../get/register_controller.dart';
import '../widgets/chooseable_widget.dart';

class RegisterKelompokPage extends GetView<RegisterController> {
  const RegisterKelompokPage({Key? key}) : super(key: key);

  static const routeName = '/register-kelompok';

  @override
  Widget build(BuildContext context) => Scaffold(
          body: Padding(
        padding: const EdgeInsets.only(left: 16, right: 16),
        child: Form(
          key: controller.registerKelompokFormKey,
          child: ListView(
            children: [
              const TopAuthenticationWidget(
                title: 'REGISTRASI',
              ),
              Center(
                child: Text(
                  'Data Diri',
                  style: GoogleFonts.roboto(
                      color: black, fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 14),
              EditText(
                  controller: controller.etNamaKelompok,
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Nama', value),
                  keyboardType: TextInputType.name,
                  label: 'Nama*'),
              const SizedBox(height: 16),
              EditText(
                  controller: controller.etNamaPic,
                  keyboardType: TextInputType.name,
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Nama PIC', value),
                  label: 'Nama PIC*'),
              const SizedBox(height: 16),
              EditText(
                  controller: controller.etPhoneKelompok,
                  keyboardType: TextInputType.phone,
                  validator: (value) =>
                      ValidationUtil.emptyValidate('No Telepon', value),
                  label: 'No. Telepon*'),
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 18, horizontal: 16),
                child: Divider(color: greyC, height: 0),
              ),
              Center(
                child: Text(
                  'Alamat',
                  style: GoogleFonts.roboto(
                      color: black, fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 14),
              EditText(
                  controller: controller.etProvinsiKelompok,
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Provinsi', value),
                  onTap: () => showModalBottomSheet(
                      context: context,
                      builder: (context) => ChooseableWidget<ProvinceModel>(
                          values: controller.provinces,
                          title: (ProvinceModel provinsi) => provinsi.province,
                          onSelected: (provinsi) =>
                              controller.setProvinsiKelompok(provinsi))),
                  isReadOnly: true,
                  label: 'Propinsi*',
                  suffixIcon: const Icon(Icons.arrow_drop_down, color: black)),
              const SizedBox(height: 14),
              EditText(
                  controller: controller.etKabupatenKelompok,
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Kabupaten', value),
                  onTap: () => showModalBottomSheet(
                      context: context,
                      builder: (context) => ChooseableWidget<DistrictModel>(
                            values: controller.districts,
                            title: (DistrictModel kabupaten) =>
                                kabupaten.district,
                            onSelected: (kabupaten) =>
                                controller.setKabupatenKelompok(kabupaten),
                          )),
                  label: 'Kabupaten / Kota*',
                  isReadOnly: true,
                  suffixIcon: const Icon(Icons.arrow_drop_down, color: black)),
              const SizedBox(height: 14),
              EditText(
                  controller: controller.etKecamatanKelompok,
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Kecamatan', value),
                  onTap: () => showModalBottomSheet(
                      context: context,
                      builder: (context) => ChooseableWidget<SubdistrictModel>(
                            values: controller.subDistricts,
                            title: (SubdistrictModel kecamatan) =>
                                kecamatan.subDistrict,
                            onSelected: (kecamatan) =>
                                controller.setKecamatanKelompok(kecamatan),
                          )),
                  label: 'Kecamatan*',
                  isReadOnly: true,
                  suffixIcon: const Icon(Icons.arrow_drop_down, color: black)),
              const SizedBox(height: 14),
              EditText(
                  controller: controller.etDesaKelompok,
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Desa', value),
                  onTap: () => showModalBottomSheet(
                      context: context,
                      builder: (context) => ChooseableWidget<VillageModel>(
                            values: controller.villages,
                            title: (VillageModel desa) => desa.urbanVillage,
                            onSelected: (desa) =>
                                controller.setDesaKelompok(desa),
                          )),
                  label: 'Desa*',
                  isReadOnly: true,
                  suffixIcon: const Icon(Icons.arrow_drop_down, color: black)),
              const SizedBox(height: 14),
              EditText(
                controller: controller.etAlamatKelompok,
                keyboardType: TextInputType.streetAddress,
                validator: (value) =>
                    ValidationUtil.emptyValidate('Alamat Lengkap', value),
                label: 'Alamat Lengkap*',
                minLines: 5,
                maxLines: null,
              ),
              Container(
                height: 45,
                margin: const EdgeInsets.only(
                    left: 16, right: 16, top: 45, bottom: 24),
                child: ElevatedButton(
                    onPressed: () => controller.setRegisterKelompok(),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: yellowDark,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(36))),
                    child: Text(
                      'SELANJUTNYA',
                      style: GoogleFonts.roboto(
                          color: black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                    )),
              ),
              const SizedBox(height: 48),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Sudah punya akun?',
                      style: GoogleFonts.roboto(
                          color: black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(width: 6),
                  GestureDetector(
                    onTap: () => Get.back(),
                    child: Text('Login disini',
                        style: GoogleFonts.roboto(
                            color: gold,
                            fontSize: 14,
                            fontWeight: FontWeight.bold)),
                  )
                ],
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ));
}
