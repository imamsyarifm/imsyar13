import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../utils/validation_util.dart';
import '../../login/pages/login_page.dart';
import '../../widgets/edit_text.dart';
import '../../widgets/top_authentication_widget.dart';
import '../get/register_controller.dart';

class RegisterPasswordPage extends GetView<RegisterController> {
  const RegisterPasswordPage({Key? key}) : super(key: key);

  static const routeName = '/register-password';

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Form(
            key: controller.registerPasswordFormKey,
            child: ListView(
              children: [
                const TopAuthenticationWidget(
                  title: 'REGISTRASI',
                ),
                Center(
                  child: Text(
                    'Kata Sandi',
                    style: GoogleFonts.roboto(
                        color: black,
                        fontSize: 16,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16, top: 20),
                  child: EditText(
                    controller: controller.etPassword,
                    validator: (value) =>
                        ValidationUtil.emptyValidate('Kata Sandi', value),
                    label: 'Kata Sandi*',
                    isSecret: true,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16, top: 20),
                  child: EditText(
                    controller: controller.etPasswordConfirm,
                    validator: (value) => ValidationUtil.emptyValidate(
                        'Konfirmasi Kata Sandi', value),
                    label: 'Kata Sandi (Sekali Lagi)*',
                    isSecret: true,
                  ),
                ),
                Container(
                  height: 45,
                  margin: const EdgeInsets.only(left: 16, right: 16, top: 20),
                  child: ElevatedButton(
                      onPressed: () => controller.register(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: yellowDark,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(36))),
                      child: Text(
                        'REGISTER',
                        style: GoogleFonts.roboto(
                            color: black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      )),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 55),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Sudah punya akun?',
                          style: GoogleFonts.roboto(
                              color: black,
                              fontSize: 14,
                              fontWeight: FontWeight.bold)),
                      const SizedBox(width: 6),
                      GestureDetector(
                        onTap: () => Get.offAllNamed(LoginPage.routeName),
                        child: Text('Login disini',
                            style: GoogleFonts.roboto(
                                color: gold,
                                fontSize: 14,
                                fontWeight: FontWeight.bold)),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      );
}
