import 'package:extended_image/extended_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../app/consts/icons.dart';
import '../../widgets/default_scaffold.dart';
import '../get/inbox_detail_controller.dart';

class InboxDetailPage extends GetView<InboxDetailController> {
  static const routeName = '/inbox-detail';

  const InboxDetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Inbox Detail',
        body: ListView(children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              Image.asset(newspaper, width: 50, height: 50),
              const SizedBox(
                width: 16,
              ),
              Text(controller.inbox.title),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 16, right: 16),
            child: Html(data: controller.inbox.date),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 16, right: 16),
            child: Html(data: controller.inbox.description),
          ),
          ExtendedImage.network(controller.inbox.urlImage),
        ]),
        bottomNavigation: Container(
          color: Colors.white,
          padding: const EdgeInsets.all(16),
          height: 80,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: yellowDark,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(36))),
            onPressed: () => Get.back(),
            child: Text('KEMBALI KE INBOX',
                style: GoogleFonts.roboto(
                    color: black, fontSize: 16, fontWeight: FontWeight.bold)),
          ),
        ),
      );
}
