import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../app/consts/colors.dart';
import '../get/inbox_received_controller.dart';
import '../widgets/item_inbox.dart';

class InboxReceivedPage extends GetView<InboxReceivedController> {
  const InboxReceivedPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      if (controller.isLoadingInbox) {
        return const Center(
          child: CircularProgressIndicator(
            color: green,
          ),
        );
      } else {
        return ListView.builder(
          itemCount: controller.allInbox.length,
          itemBuilder: (context, index) {
            final inbox = controller.allInbox[index];
            return Padding(
              padding: const EdgeInsets.only(left: 8, right: 8),
              child: ItemInbox(
                inbox: inbox,
              ),
            );
          },
        );
      }
    });
  }
}
