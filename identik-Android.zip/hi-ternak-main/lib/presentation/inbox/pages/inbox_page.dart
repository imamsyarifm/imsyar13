import 'package:flutter/material.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../widgets/default_scaffold.dart';
import '../get/inbox_controller.dart';
import 'inbox_received_page.dart';
import 'inbox_sent_page.dart';

class InboxPage extends GetView<InboxController> {
  const InboxPage({Key? key}) : super(key: key);

  static const routeName = '/inbox';

  @override
  Widget build(BuildContext context) {
    return DefaultScaffold(
        appBarTitle: 'Inbox',
        body: Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(16), topRight: Radius.circular(16)),
          ),
          child: Column(
            children: [
              TabBar(
                controller: controller.tabController,
                labelColor: black,
                unselectedLabelColor: grey9B,
                indicatorColor: green,
                labelStyle: GoogleFonts.roboto(
                  color: black,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
                tabs: const [
                  Tab(
                    text: 'Diterima',
                  ),
                  Tab(
                    text: 'Dikirim',
                  )
                ],
              ),
              Expanded(
                child: TabBarView(
                  controller: controller.tabController,
                  children: const [
                    InboxReceivedPage(),
                    InboxSentPage(),
                  ],
                ),
              ),
            ],
          ),
        ));
  }
}
