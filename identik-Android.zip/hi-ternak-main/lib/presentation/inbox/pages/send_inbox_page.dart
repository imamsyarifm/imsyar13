import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';

import '../../../app/consts/colors.dart';
import '../../../utils/validation_util.dart';
import '../../widgets/default_scaffold.dart';
import '../../widgets/edit_text.dart';
import '../get/send_inbox_controller.dart';

class SendInboxPage extends GetView<SendInboxController> {
  static const routeName = '/inbox/send';

  const SendInboxPage({super.key});

  @override
  Widget build(BuildContext context) => DefaultScaffold(
      appBarTitle: 'Tambah Pemilik',
      body: Container(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: controller.formKey,
          child: ListView(
            children: [
              EditText(
                label: 'Judul*',
                validator: (value) =>
                    ValidationUtil.emptyValidate('Judul', value),
                autoValidateMode: AutovalidateMode.onUserInteraction,
                keyboardType: TextInputType.text,
                textInputAction: TextInputAction.done,
                controller: controller.etTitle,
              ),
              const SizedBox(height: 16),
              EditText(
                label: 'Photo',
                keyboardType: TextInputType.text,
                textInputAction: TextInputAction.done,
                controller: controller.etPhoto,
                isReadOnly: true,
                onTap: () => Get.bottomSheet(
                  Container(
                    color: Colors.white,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        ListTile(
                          title: const Text('Galeri'),
                          subtitle: const Text('Pilih gambar dari galeri'),
                          onTap: () async {
                            final file = await controller.imagePicker.pickImage(
                                source: ImageSource.gallery, imageQuality: 25);
                            controller.setPhoto(file);
                          },
                        ),
                        ListTile(
                          title: const Text('Kamera'),
                          subtitle: const Text('Pilih gambar dari kamera'),
                          onTap: () async {
                            final file = await controller.imagePicker.pickImage(
                                source: ImageSource.camera, imageQuality: 25);
                            controller.setPhoto(file);
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              EditText(
                  label: 'Deskripsi*',
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Deskripsi', value),
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.done,
                  minLines: 5,
                  maxLines: null,
                  controller: controller.etDescription),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
      bottomNavigation: Obx(() {
        if (controller.isSendingMessage) {
          return const LinearProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(green),
          );
        }

        return Container(
          color: Colors.white,
          child: Row(children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 12, top: 12, bottom: 12, right: 6),
                child: SizedBox(
                  height: 40,
                  child: ElevatedButton(
                      onPressed: () => Get.back(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(36))),
                      child: Text(
                        'BATAL',
                        style: GoogleFonts.roboto(
                            color: black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      )),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                    right: 12, top: 12, bottom: 12, left: 6),
                child: SizedBox(
                  height: 40,
                  child: ElevatedButton(
                      onPressed: () {
                        if (controller.formKey.currentState?.validate() ==
                            false) {
                          return;
                        }

                        controller.send();
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: yellowDark,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(36))),
                      child: Text(
                        'SIMPAN',
                        style: GoogleFonts.roboto(
                            color: black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      )),
                ),
              ),
            ),
          ]),
        );
      }));
}
