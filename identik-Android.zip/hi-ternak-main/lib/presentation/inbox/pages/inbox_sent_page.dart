import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../app/consts/colors.dart';
import '../get/inbox_sent_controller.dart';
import '../widgets/item_inbox.dart';
import 'send_inbox_page.dart';

class InboxSentPage extends GetView<InboxSentController> {
  const InboxSentPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(() {
        if (controller.isLoadingInbox) {
          return const Center(
            child: CircularProgressIndicator(
              color: green,
            ),
          );
        } else {
          return ListView.builder(
            itemCount: controller.allInbox.length,
            itemBuilder: (context, index) {
              final inbox = controller.allInbox[index];
              return Padding(
                padding: const EdgeInsets.only(left: 8, right: 8),
                child: ItemInbox(
                  inbox: inbox,
                ),
              );
            },
          );
        }
      }),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.send),
        onPressed: () async {
          await Get.toNamed(SendInboxPage.routeName);
          controller.retrieveInbox;
        },
      ),
    );
  }
}
