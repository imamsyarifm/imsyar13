import 'package:get/get.dart';

import '../../../data/models/inbox/inbox_model.dart';
import '../../../data/repositories/inbox_news_repository.dart';

class InboxSentController extends GetxController {
  final InboxNewsRepository _repository;

  InboxSentController({
    required InboxNewsRepository repository,
  }) : _repository = repository;

  final _isLoadingInbox = false.obs;
  final _allInbox = Rx<List<InboxModel>>([]);

  bool get isLoadingInbox => _isLoadingInbox.value;
  List<InboxModel> get allInbox => _allInbox.value;

  @override
  void onReady() {
    super.onReady();
    retrieveInbox;
  }

  void get retrieveInbox async {
    _isLoadingInbox.value = true;
    final allInbox = await _repository.allInbox(false);
    _allInbox.value = allInbox;
    _isLoadingInbox.value = false;
  }
}
