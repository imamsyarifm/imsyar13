import 'package:get/get.dart';

import '../../../data/models/inbox/inbox_model.dart';

class InboxDetailController extends GetxController {
  late InboxModel inbox;

  @override
  void onInit() {
    retrieveArgs();
    super.onInit();
  }

  void retrieveArgs() {
    final args = Get.arguments;
    if (args is InboxModel) {
      inbox = args;
    }
  }
}
