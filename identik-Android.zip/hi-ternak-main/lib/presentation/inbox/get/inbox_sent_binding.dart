import 'package:dio/dio.dart';
import 'package:get/get.dart';

import '../../../data/repositories/inbox_news_repository.dart';
import 'inbox_sent_controller.dart';

class InboxSentBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(InboxNewsRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(InboxSentController(
      repository: Get.find<InboxNewsRepository>(),
    ));
  }
}
