import 'package:get/get.dart';

import 'inbox_detail_controller.dart';

class InboxDetailBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(InboxDetailController());
  }
}
