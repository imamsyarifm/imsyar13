import 'package:get/get.dart';

import '../../../data/models/inbox/inbox_model.dart';
import '../../../data/repositories/inbox_news_repository.dart';

class InboxReceivedController extends GetxController {
  final InboxNewsRepository _repository;

  InboxReceivedController({
    required InboxNewsRepository repository,
  }) : _repository = repository;

  final _isLoadingInbox = false.obs;
  final _allInbox = Rx<List<InboxModel>>([]);

  bool get isLoadingInbox => _isLoadingInbox.value;
  List<InboxModel> get allInbox => _allInbox.value;

  @override
  void onReady() {
    super.onReady();
    retrieveInbox;
  }

  void get retrieveInbox async {
    _isLoadingInbox.value = true;
    final allInbox = await _repository.allInbox(true);
    _allInbox.value = allInbox;
    _isLoadingInbox.value = false;
  }
}
