import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' hide FormData, MultipartFile;
import 'package:image_picker/image_picker.dart';

import '../../../data/repositories/inbox_news_repository.dart';

class SendInboxController extends GetxController {
  final InboxNewsRepository _repository;

  SendInboxController({
    required InboxNewsRepository repository,
  }) : _repository = repository;

  final etTitle = TextEditingController();
  final etDescription = TextEditingController();
  final etPhoto = TextEditingController();

  final imagePicker = ImagePicker();

  final formKey = GlobalKey<FormState>();

  final _selectedPhoto = Rx<XFile?>(null);
  final _isSendingMessage = false.obs;

  XFile? get selectedPhoto => _selectedPhoto.value;
  bool get isSendingMessage => _isSendingMessage.value;

  void setPhoto(XFile? file) {
    _selectedPhoto.value = file;
    etPhoto.text = file?.name ?? file?.path ?? '';
    Get.back();
  }

  Future<void> send() async {
    if (formKey.currentState?.validate() == false) {
      return;
    }

    _isSendingMessage.value = true;

    try {
      final payload = FormData.fromMap({
        'title': etTitle.text,
        'description': etDescription.text,
      });

      if (_selectedPhoto.value != null) {
        final multipartFile =
            await MultipartFile.fromFile(_selectedPhoto.value!.path);
        payload.files.add(MapEntry('path_file', multipartFile));
      }

      final sent = await _repository.sendMessage(payload);

      _isSendingMessage.value = false;

      if (sent) {
        Get.back();
        Get.showSnackbar(const GetSnackBar(
          message: 'Pesan Berhasil Dikirim',
          duration: Duration(seconds: 3),
        ));
      } else {
        Get.showSnackbar(const GetSnackBar(
          message: 'Pesan Gagal Dikirim',
          duration: Duration(seconds: 3),
        ));
      }
    } catch (error) {
      _isSendingMessage.value = false;
      Get.showSnackbar(const GetSnackBar(
        message: 'Pesan Gagal Dikirim',
        duration: Duration(seconds: 3),
      ));
    }
  }
}
