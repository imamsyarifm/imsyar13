import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../data/repositories/authentication_repository.dart';
import 'passcode_edit_controller.dart';

class PasscodeEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(AuthenticationRepository(
      dio: Get.find<Dio>(),
    ));

    Get.put(PasscodeEditController(
      repository: Get.find<AuthenticationRepository>(),
    ));
  }
}
