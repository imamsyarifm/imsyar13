// import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../data/models/change_password/change_password_request.dart';
import '../../data/repositories/authentication_repository.dart';
// import '../../utils/validation_util.dart';
import '../main/main_page.dart';
import 'passcode_confirm_edit_page.dart';

class PasscodeConfirmEditController extends GetxController {
  PasscodeConfirmEditController({
    required AuthenticationRepository repository,
  }) : _repository = repository;

  final AuthenticationRepository _repository;

  late PasscodeParams params;

  final pinController = TextEditingController();
  final focusNode = FocusNode();
  final formKey = GlobalKey<FormState>();

  @override
  void onInit() {
    super.onInit();
    retrieveArgs();
  }

  @override
  void dispose() {
    pinController.dispose();
    focusNode.dispose();
    super.dispose();
  }

  void retrieveArgs() {
    final args = Get.arguments;
    if (args is PasscodeParams) {
      params = args;
    }
  }

  void changePassword() async {
    if (formKey.currentState?.validate() == false) {
      return;
    }

    final newPass = params.passcode;
    final confirmPass = pinController.text;

    if (newPass != confirmPass) {
      Get.showSnackbar(const GetSnackBar(
        message: 'Terdapat perbedaan antara passcode baru dengan '
            'konfirmasi passcode, harap cek kembali',
        duration: Duration(seconds: 3),
      ));
      return;
    }

    final payload = ChangePasscodeRequest(
      passcode: params.passcode,
      confirmPasscode: pinController.text,
    );

    try {
      final response = await _repository.changePasscode(payload);
      if (response) {
        Get.offAllNamed(MainPage.routeName);
        Get.showSnackbar(const GetSnackBar(
          message: 'Perubahan Passcode Berhasil',
          duration: Duration(seconds: 3),
        ));
      } else {
        Get.showSnackbar(const GetSnackBar(
          message: 'Perubahan Passcode Gagal',
          duration: Duration(seconds: 3),
        ));
      }
    } catch (error) {
      // Get.showSnackbar(GetSnackBar(
      //   message: ValidationUtil.errorMessage(error as DioError),
      //   duration: const Duration(seconds: 3),
      // ));
      Get.showSnackbar(const GetSnackBar(
        message: 'Perubahan Passcode Gagal',
        duration: Duration(seconds: 3),
      ));
    }
  }
}
