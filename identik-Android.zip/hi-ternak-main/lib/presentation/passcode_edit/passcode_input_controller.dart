import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../utils/validation_util.dart';
import 'passcode_input_page.dart';

class PasscodeInputController extends GetxController {
  late PasscodeInputParams params;

  final pinController = TextEditingController();
  final focusNode = FocusNode();
  final formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    pinController.dispose();
    focusNode.dispose();
    super.dispose();
  }

  void retrieveArgs() {
    final args = Get.arguments;
    if (pinController.text.length == 6) {
      if (args is PasscodeInputParams) {
        params = args;
      }
    }
  }

  Future<void> changePassword() async {
    if (formKey.currentState?.validate() == false) {
      return;
    }

    if (pinController.text.length != 6) {
      Get.showSnackbar(const GetSnackBar(
        message: 'Passcode Harus 6 Digit',
        duration: Duration(seconds: 3),
      ));
    } else {
      await params.save;
    }

    try {
      await params.save;
    } catch (error) {
      Get.showSnackbar(GetSnackBar(
        message: ValidationUtil.errorMessage(error as DioError),
        duration: const Duration(seconds: 3),
      ));
    }

    // await params.save;
  }
}
