// import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../data/models/change_password/change_password_request.dart';
import '../../data/repositories/authentication_repository.dart';
// import '../../utils/validation_util.dart';
import '../main/main_page.dart';

class PasscodeEditController extends GetxController {
  PasscodeEditController({
    required AuthenticationRepository repository,
  }) : _repository = repository;

  final AuthenticationRepository _repository;

  final pinController = TextEditingController();
  final pinController2 = TextEditingController();
  final focusNode = FocusNode();
  GlobalKey<FormState> formKey = GlobalKey<FormState>();
  GlobalKey<FormState> formKey2 = GlobalKey<FormState>();

  @override
  void dispose() {
    pinController.dispose();
    focusNode.dispose();
    super.dispose();
  }

  void changePassword() async {
    if (formKey.currentState?.validate() == false) {
      return;
    }

    final newPass = pinController.text;
    final confirmPass = pinController2.text;

    if (newPass != confirmPass) {
      Get.showSnackbar(const GetSnackBar(
        message: 'Terdapat perbedaan antara passcode baru dengan '
            'konfirmasi passcode, harap cek kembali',
        duration: Duration(seconds: 3),
      ));
      return;
    }

    final payload = ChangePasscodeRequest(
      passcode: pinController.text,
      confirmPasscode: pinController2.text,
    );

    try {
      final response = await _repository.changePasscode(payload);
      if (response) {
        Get.offAllNamed(MainPage.routeName);
        Get.showSnackbar(const GetSnackBar(
          message: 'Perubahan Passcode Berhasil',
          duration: Duration(seconds: 3),
        ));
      } else {
        Get.showSnackbar(const GetSnackBar(
          message: 'Perubahan Passcode Gagal',
          duration: Duration(seconds: 3),
        ));
      }
    } catch (error) {
      // Get.showSnackbar(GetSnackBar(
      //   message: ValidationUtil.errorMessage(error as DioError),
      //   duration: const Duration(seconds: 3),
      // ));
      Get.showSnackbar(const GetSnackBar(
        message: 'Perubahan Passcode Gagal',
        duration: Duration(seconds: 3),
      ));
    }
  }
}
