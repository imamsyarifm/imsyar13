import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../data/repositories/authentication_repository.dart';
import 'passcode_confirm_edit_controller.dart';

class PasscodeConfirmEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(AuthenticationRepository(
      dio: Get.find<Dio>(),
    ));

    Get.put(PasscodeConfirmEditController(
      repository: Get.find<AuthenticationRepository>(),
    ));
  }
}
