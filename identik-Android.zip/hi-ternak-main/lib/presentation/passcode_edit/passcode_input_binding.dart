import 'package:get/get.dart';
import 'passcode_input_controller.dart';

class PasscodeInputBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(PasscodeInputController());
  }
}
