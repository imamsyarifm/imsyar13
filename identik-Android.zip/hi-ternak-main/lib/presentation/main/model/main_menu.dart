import 'package:convex_bottom_bar/convex_bottom_bar.dart';

class MainMenu {
  TabItem item;
  String route;

  MainMenu({required this.item, required this.route});
}