import 'package:convex_bottom_bar/convex_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../app/consts/icons.dart';
import '../../app/consts/local_keys.dart';
import '../../utils/local_helper.dart';
import '../akun/get/akun_binding.dart';
import '../akun/pages/akun_page.dart';
import '../berita/news_binding.dart';
import '../home/get/home_binding.dart';
import '../home/pages/home_page.dart';
import '../identitas/get/identitas_binding.dart';
import '../identitas/pages/identitas_page.dart';
import '../inbox/get/inbox_binding.dart';
import '../inbox/get/inbox_received_binding.dart';
import '../inbox/get/inbox_sent_binding.dart';
import '../inbox/pages/inbox_page.dart';
import '../kegiatan/kegiatan_binding.dart';
import '../scan/scan_page.dart';
import '../under_development/under_development_page.dart';
import 'model/main_menu.dart';

class MainController extends GetxController {
  final _menuIndex = 0.obs;

  int get menuIndex => _menuIndex.value;

  final Map<String, String> menus = {
    'home-selected': homeSelected,
    'home-unselected': homeUnselected,
    'home-2-selected': home2Selected,
    'home-2-unselected': home2Unselected,
    'inbox-selected': inboxSelected,
    'inbox-unselected': inboxUnselected,
    'marketplace-selected': marketplaceSelected,
    'marketplace-unselected': marketplaceUnselected,
    'chat-selected': chatSelected,
    'chat-unselected': chatUnselected,
    'akun-selected': accountSelected,
    'akun-unselected': accountUnselected,
    'akun-2-selected': account2Selected,
    'akun-2-unselected': account2Unselected
  };

  void changeMenu(int index) {
    _menuIndex.value = index;
    if (index == 2) {
      Get.toNamed(_pages[index],
          arguments: ScanPageParams(
            isTransaction: false,
          ));
    } else {
      Get.offNamed(_pages[index], id: 1);
    }
  }

  Future<String> homeMenu() async {
    final isIndividuAccount = await LocalHelper.getKey(LocalKeys.isIndividu);
    if (isIndividuAccount) {
      if (_menuIndex.value == 0) {
        return menus['home-selected']!;
      } else {
        return menus['home-unselected']!;
      }
    } else {
      if (_menuIndex.value == 0) {
        return menus['home-2-selected']!;
      } else {
        return menus['home-2-unselected']!;
      }
    }
  }

  Future<String> accountMenu() async {
    final isIndividuAccount = await LocalHelper.getKey(LocalKeys.isIndividu);
    if (isIndividuAccount) {
      if (_menuIndex.value == 4) {
        return menus['akun-selected']!;
      } else {
        return menus['akun-unselected']!;
      }
    } else {
      if (_menuIndex.value == 4) {
        return menus['akun-2-selected']!;
      } else {
        return menus['akun-2-unselected']!;
      }
    }
  }

  Route? onGenerateRoute(RouteSettings setting) {
    switch (setting.name) {
      case HomePage.routeName:
        return GetPageRoute(
            settings: setting,
            routeName: HomePage.routeName,
            page: () => const HomePage(),
            bindings: [
              KegiatanBinding(),
              NewsBinding(),
              HomeBinding(),
            ],
            transition: Transition.noTransition,
            transitionDuration: const Duration(seconds: 0));
      case InboxPage.routeName:
        return GetPageRoute(
            settings: setting,
            routeName: InboxPage.routeName,
            page: () => const InboxPage(),
            bindings: [
              InboxReceivedBinding(),
              InboxSentBinding(),
              InboxBinding(),
            ],
            transition: Transition.noTransition,
            transitionDuration: const Duration(seconds: 0));
      case UnderDevelopmentPage.routeName:
        return GetPageRoute(
            settings: setting,
            routeName: UnderDevelopmentPage.routeName,
            page: () => const UnderDevelopmentPage(),
            transition: Transition.noTransition,
            transitionDuration: const Duration(seconds: 0));
      case IdentitasPage.routeName:
        return GetPageRoute(
            settings: setting,
            routeName: IdentitasPage.routeName,
            page: () => const IdentitasPage(),
            binding: IdentitasBinding(),
            transition: Transition.noTransition,
            transitionDuration: const Duration(seconds: 0));
      case AkunPage.routeName:
        return GetPageRoute(
            settings: setting,
            routeName: AkunPage.routeName,
            page: () => const AkunPage(),
            binding: AkunBinding(),
            transition: Transition.noTransition,
            transitionDuration: const Duration(seconds: 0));
      default:
        return null;
    }
  }

  final _pages = [
    HomePage.routeName,
    IdentitasPage.routeName,
    ScanPage.routeName,
    InboxPage.routeName,
    AkunPage.routeName
  ];

  final appPages = <MainMenu>[
    MainMenu(
      item: const TabItem(
        title: 'Home',
        icon: Icon(Icons.home),
      ),
      route: HomePage.routeName,
    ),
    MainMenu(
      item: const TabItem(
        title: 'Ternak',
        icon: Icon(Icons.list_alt),
      ),
      route: InboxPage.routeName,
    ),
    MainMenu(
      item: TabItem(title: 'Scan', icon: Image.asset(qrScan)),
      route: ScanPage.routeName,
    ),
    MainMenu(
      item: const TabItem(
        title: 'Inbox',
        icon: Icon(Icons.inbox),
      ),
      route: InboxPage.routeName,
    ),
    MainMenu(
      item: const TabItem(
        title: 'Account',
        icon: Icon(Icons.person),
      ),
      route: AkunPage.routeName,
    ),
  ];
}
