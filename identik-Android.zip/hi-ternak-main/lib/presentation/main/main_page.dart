import 'package:convex_bottom_bar/convex_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../app/consts/colors.dart';
import '../home/pages/home_page.dart';
import 'main_controller.dart';

class MainPage extends GetView<MainController> {
  const MainPage({Key? key}) : super(key: key);

  static const routeName = '/main';

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Navigator(
          key: Get.nestedKey(1),
          initialRoute: HomePage.routeName,
          onGenerateRoute: controller.onGenerateRoute,
        ),
        // floatingActionButton: FloatingActionButton(
        //   onPressed: () {
        //     Get.offNamedUntil(
        //       IdentitasBiodataEditPage.routeName,
        //       (route) => (route.settings.name == MainPage.routeName),
        //       arguments: '23432478239',
        //     );
        //   },
        // ),
        bottomNavigationBar: ConvexAppBar(
          style: TabStyle.fixedCircle,
          backgroundColor: Colors.white,
          activeColor: black,
          color: black,
          onTap: (index) => controller.changeMenu(index),
          items: controller.appPages.map((menu) => menu.item).toList(),
        ),
      );
}
