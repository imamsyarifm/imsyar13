import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../data/repositories/authentication_repository.dart';
import '../../passcode_edit/passcode_edit_page.dart';
import '../../scan/scan_page.dart';
import '../pages/input_eartag_page.dart';

class InputEartagController extends GetxController {
  InputEartagController({
    required AuthenticationRepository repository,
  }) : _repository = repository;

  final AuthenticationRepository _repository;

  final form = GlobalKey<FormState>();
  final etCode = TextEditingController();
  final etLocation = TextEditingController();
  final etNumber = TextEditingController();
  late InputEartagParams params;

  @override
  void onInit() {
    retrieveParams();
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
    defaultValue();
    retriveStatusPasscode();
  }

  void defaultValue() {
    etCode.text = 'AAA';
    etLocation.text = '00';
    etNumber.text = '0000000000';
  }

  void retrieveParams() {
    final args = Get.arguments;
    if (args is InputEartagParams) {
      params = args;
    }
  }

  retriveStatusPasscode() async {
    if (params.isPublic) {
      return;
    }
    try {
      final status = await _repository.checkPasscode();
      debugPrint('p: $status');
    } catch (e) {
      Get.defaultDialog(
          barrierDismissible: false,
          title: 'WARNING',
          content: const Text(
            'Passcode belum tersedia, '
            'silahkan membuatnya dihalaman profile',
            textAlign: TextAlign.center,
          ),
          confirm: OutlinedButton(
            onPressed: () => Get.toNamed(PasscodeEditPage.routeName),
            child: const Text('Ok'),
          ),
          cancel: ElevatedButton(
            onPressed: () {
              Get.back();
              Get.back();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: const Text('Kembali'),
          ));
    }
  }

  void setCode(String value) {
    etCode.text = value;
  }

  void setLocation(String value) {
    etLocation.text = value;
  }

  void setNumber(String value) {
    etNumber.text = value;
  }

  String get result {
    return '${etCode.text} ${etLocation.text} ${etNumber.text}';
  }

  String? validator(int length, String? value) {
    if (value == null) {
      return 'Tidak boleh kosong, harap isi minimal $length karakter';
    } else if (value.length < length) {
      return 'Harap isi minimal $length karakter';
    } else {
      return null;
    }
  }

  Future<void> save({
    bool isTransaction = true,
    bool isProduksiSusu = false,
    bool isPublic = false,
  }) async {
    if (params.isPublic == false) {
      Get.toNamed(
        ScanPage.routeName,
        arguments: ScanPageParams(
          onScanned: params.onScanned,
          isProduksiSusu: params.isProduksiSusu,
          isPublic: isPublic,
          isTransaction: isTransaction,
          isInput: true, 
          inputNumber: result,
          isMutasiAktivasi: params.isMutasiAktivasi,
        ),
      );
    } else {
      Get.toNamed(
        ScanPage.routeName,
        arguments: ScanPageParams(
          isPublic: true,
          isInput: true,
          inputNumber: result,
        ),
      );
    }
  }
}
