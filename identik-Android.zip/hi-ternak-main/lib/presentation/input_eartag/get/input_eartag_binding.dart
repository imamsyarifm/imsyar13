import 'package:dio/dio.dart';
import 'package:get/get.dart';

import '../../../data/repositories/authentication_repository.dart';
import 'input_eartag_cotroller.dart';

class InputEartagBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(AuthenticationRepository(
      dio: Get.find<Dio>(),
    ));

    Get.put(InputEartagController(
      repository: Get.find<AuthenticationRepository>(),
    ));
    // Get.put(InputEartagController());
  }
}