import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../get/input_eartag_cotroller.dart';

class InputEartagPage extends GetView<InputEartagController> {
  static const routeName = '/input-eartag';

  const InputEartagPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: green,
        title: const Text('Eartag Ternak'),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Form(
          key: controller.form,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          child: ListView(
            children: [
              const SizedBox(
                height: 50,
              ),
              TextFormField(
                textCapitalization: TextCapitalization.sentences,
                enableInteractiveSelection: false,
                controller: controller.etCode,
                maxLength: 3,
                validator: (value) => controller.validator(3, value),
                style: const TextStyle(
                  fontSize: 30,
                  letterSpacing: 10.0,
                ),
              ),
              const SizedBox(
                height: 16,
              ),
              TextFormField(
                controller: controller.etLocation,
                maxLength: 2,
                validator: (value) => controller.validator(2, value),
                style: const TextStyle(
                  fontSize: 30,
                  letterSpacing: 10.0,
                ),
              ),
              const SizedBox(
                height: 16,
              ),
              TextFormField(
                keyboardType: TextInputType.visiblePassword,
                enableInteractiveSelection: false,
                controller: controller.etNumber,
                maxLength: 10,
                validator: (value) => controller.validator(10, value),
                style: const TextStyle(
                  fontSize: 30,
                  letterSpacing: 10.0,
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: buildBottom(context),
    );
  }

  Widget buildBottom(BuildContext context) {
    final paddingBottom = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: paddingBottom,
      ),
      child: ElevatedButton(
        onPressed: () => controller.save(),
        style: ElevatedButton.styleFrom(
          backgroundColor: green,
        ),
        child: const Text('Simpan'),
      ),
    );
  }
}
class InputEartagParams {
  final bool isTransaction;
  final bool isProduksiSusu;
  final bool isPublic;
  final bool isMutasiAktivasi;
  final bool isInseminasi;
  final Function(IdentityTernakModel)? onScanned;

  InputEartagParams({
    this.isTransaction = true,
    this.isProduksiSusu = false,
    this.isPublic = false,
    this.isMutasiAktivasi = false,
    this.onScanned,
    this.isInseminasi = false,
  });
}