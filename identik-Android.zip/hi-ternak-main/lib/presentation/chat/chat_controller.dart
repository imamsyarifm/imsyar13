import 'package:get/get.dart';
import 'chat_page.dart';

class ChatController extends GetxController {
  @override
  void onInit() {
    super.onInit();
    final arguments = Get.arguments;
    if (arguments is ChatParams) {}
  }
}
