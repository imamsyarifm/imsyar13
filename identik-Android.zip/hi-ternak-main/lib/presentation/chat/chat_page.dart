import 'package:flutter/material.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../../app/consts/colors.dart';
import '../../app/consts/icons.dart';
import '../widgets/default_scaffold.dart';
import '../widgets/edit_text.dart';
import 'chat_controller.dart';

class ChatPage extends GetView<ChatController> {
  const ChatPage({Key? key}) : super(key: key);

  static const routeName = '/chat';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
      appBarTitle: 'Chat',
      actions: [
        GestureDetector(
          onTap: () => launchUrlString('tel:+681546415204'),
          child: Container(
            margin: const EdgeInsets.all(12),
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
                color: yellow, borderRadius: BorderRadius.circular(36)),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.call, color: black),
                Text('Telpon Admin',
                    style: GoogleFonts.roboto(
                        color: black,
                        fontSize: 16,
                        fontWeight: FontWeight.bold))
              ],
            ),
          ),
        )
      ],
      body: ListView.builder(
          itemBuilder: (context, index) =>
              (index % 2 == 0) ? _senderChat(context) : _receiverChat(context)),
      bottomNavigation: Container(
        color: Colors.white,
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Expanded(
                child: EditText(
                    hint: 'Tulis pesan anda disini...',
                    radius: BorderRadius.circular(100))),
            const SizedBox(width: 16),
            GestureDetector(
                onTap: () => {},
                child: Image.asset(send, width: 17, height: 17))
          ],
        ),
      ));

  Widget _senderChat(BuildContext context) => Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          const SizedBox.shrink(),
          Container(
              padding: const EdgeInsets.all(8),
              margin: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  border: Border.all(color: green),
                  borderRadius: BorderRadius.circular(16)),
              child: const Text('Saya mau menanyakan tentang pakan sapi saya'))
        ],
      );

  Widget _receiverChat(BuildContext context) =>
      Row(mainAxisAlignment: MainAxisAlignment.start, children: [
        Container(
            padding: const EdgeInsets.all(8),
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                border: Border.all(color: grey9B),
                borderRadius: BorderRadius.circular(16)),
            child: const Text('Ada yang bisa saya bantu?')),
        const SizedBox.shrink()
      ]);
}

class ChatParams {
  final String subject;
  final String message;

  ChatParams({required this.subject, required this.message});
}
