import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_connect/http/src/status/http_status.dart';
import 'package:scanner/peruri_scanner.dart';

import '../../../app/consts/pending_transaction_type.dart';
import '../../../data/models/buku_lahir/buku_induk_request.dart';
import '../../../data/models/inseminasi/inseminasi_request.dart';
import '../../../data/models/kandang/kandang_model.dart';
import '../../../data/models/keswan/keswan_bobot_request_model.dart';
import '../../../data/models/keswan/keswan_kesehatan_request_model.dart';
import '../../../data/models/mutasi/manage_mutasi_request_model.dart';
import '../../../data/models/owner/owner_model.dart';
import '../../../data/models/pakan/update_pakan_request.dart';
import '../../../data/models/susu/produksi_susu_request.dart';
import '../../../data/models/ternak/ternak_request.dart';
import '../../../data/models/unit_usaha/unit_usaha.dart';
import '../../../data/repositories/buku_lahir_repository.dart';
import '../../../data/repositories/inseminasi_repository.dart';
import '../../../data/repositories/kandang_repository.dart';
import '../../../data/repositories/keswan_repository.dart';
import '../../../data/repositories/mutasi_repository.dart';
import '../../../data/repositories/owner_repository.dart';
import '../../../data/repositories/pakan_repository.dart';
import '../../../data/repositories/pending_transaction_repository.dart';
import '../../../data/repositories/susu_repository.dart';
import '../../../data/repositories/ternak_repository.dart';
import '../../../data/repositories/unit_usaha_repository.dart';
import '../../../utils/local_helper.dart';
import '../../../utils/validation_util.dart';

class PendingTransactionController extends GetxController
    with GetSingleTickerProviderStateMixin {
  late TabController tabController;
  final PendingTransactionRepository _repository;
  final UnitUsahaRepository _unitUsahaRepository;
  final OwnerRepository _ownerRepository;
  final KandangRepository _kandangRepository;
  final TernakRepository _ternakRepository;
  final KeswanRepository _keswanRepository;
  final MutasiRepository _mutasiRepository;
  final SusuRepository _susuRepository;
  final InseminasiRepository _inseminasiRepository;
  final PakanRepository _pakanRepository;
  final BukuLahirRepository _bukuLahirRepository;

  PendingTransactionController({
    required PendingTransactionRepository repository,
    required UnitUsahaRepository unitUsahaRepository,
    required OwnerRepository ownerRepository,
    required KandangRepository kandangRepository,
    required TernakRepository ternakRepository,
    required KeswanRepository keswanRepository,
    required MutasiRepository mutasiRepository,
    required SusuRepository susuRepository,
    required InseminasiRepository inseminasiRepository,
    required PakanRepository pakanRepository,
    required BukuLahirRepository bukuLahirRepository,
  })  : _repository = repository,
        _unitUsahaRepository = unitUsahaRepository,
        _ownerRepository = ownerRepository,
        _kandangRepository = kandangRepository,
        _ternakRepository = ternakRepository,
        _keswanRepository = keswanRepository,
        _mutasiRepository = mutasiRepository,
        _susuRepository = susuRepository,
        _inseminasiRepository = inseminasiRepository,
        _pakanRepository = pakanRepository,
        _bukuLahirRepository = bukuLahirRepository;

  final _currentTab = Rx<PendingTransaction?>(null);
  final _values = Rx<List>([]);

  PendingTransaction? get currentTab => _currentTab.value;
  List get values => _values.value;

  @override
  void onInit() {
    tabController = TabController(length: 11, vsync: this);
    super.onInit();
  }

  void updateActivePendingTransaction(PendingTransaction newActive) {
    _currentTab.value = newActive;
  }

  static const tabs = [
    PendingTransaction.unitUsaha,
    PendingTransaction.owner,
    PendingTransaction.kandang,
    PendingTransaction.ternak,
    PendingTransaction.pertumbuhan,
    PendingTransaction.vaksinasi,
    PendingTransaction.mutasi,
    PendingTransaction.susu,
    PendingTransaction.inseminasi,
    PendingTransaction.bukuLahir,
    PendingTransaction.pakan,
  ];

  void sync(PendingTransaction? type) async {
    if (type == null) {
      syncAll();
    } else {
      switch (type) {
        case PendingTransaction.unitUsaha:
          unawaited(syncUnitUsaha());
          break;
        case PendingTransaction.owner:
          unawaited(syncOwner());
          break;
        case PendingTransaction.kandang:
          unawaited(syncKandang());
          break;
        case PendingTransaction.ternak:
          unawaited(syncTernak());
          break;
        case PendingTransaction.pertumbuhan:
          unawaited(syncPertumbuhan());
          break;
        case PendingTransaction.vaksinasi:
          unawaited(syncVaksinasi());
          break;
        case PendingTransaction.mutasi:
          unawaited(syncMutasi());
          break;
        case PendingTransaction.susu:
          unawaited(syncSusu());
          break;
        case PendingTransaction.inseminasi:
          unawaited(syncInseminasi());
          break;
        case PendingTransaction.bukuLahir:
          unawaited(syncBukuLahir());
          break;
        case PendingTransaction.pakan:
          unawaited(syncPakan());
          break;
      }
    }
  }

  Future<void> syncUnitUsaha() async {
    final values = await _repository.allUnitusaha;
    for (UnitUsaha value in values) {
      final sync = await _unitUsahaRepository.syncUpload(value);
      if (sync) {
        LocalHelper.delete<UnitUsaha>(PendingTransaction.unitUsaha.localName,
            (table) => table.id == value.id);
      }
    }
    tabController.animateTo(2);
  }

  Future<void> syncOwner() async {
    final values = await _repository.allOwner;
    for (OwnerModel value in values) {
      final sync = await _ownerRepository.syncUpload(value);
      if (sync) {
        LocalHelper.delete<OwnerModel>(PendingTransaction.owner.localName,
            (table) => table.id == value.id);
      }
    }
    tabController.animateTo(3);
  }

  Future<void> syncKandang() async {
    final values = await _repository.allKandang;
    for (KandangModel value in values) {
      final sync = await _kandangRepository.syncUpload(value);
      if (sync) {
        LocalHelper.delete<OwnerModel>(PendingTransaction.owner.localName,
            (table) => table.id == value.id);
      }
    }
    tabController.animateTo(4);
  }

  Future<void> syncTernak() async {
    final values = await _repository.allTernak;
    for (TernakRequest value in values) {
      final isStartWithAlphabet =
          ValidationUtil.startWithAlphabet(value.codeProduct!);
      if (!isStartWithAlphabet) {
        value.randomCode = value.codeProduct;
        final decodedValue = await PeruriScanner.decodeQR(value.scanResult!);
        value.codeProduct = decodedValue?.dcdPublicData ?? value.codeProduct;
      }
      final sync = await _ternakRepository.addTernak(
        request: value,
        localStrategy: false,
      );

      // Success or exists
      if (sync.code == HttpStatus.ok || sync.code == 403) {
        LocalHelper.delete<TernakRequest>(PendingTransaction.ternak.localName,
            (table) => table.codeProduct == value.codeProduct);
      }
    }

    tabController.animateTo(5);
  }

  Future<void> syncPertumbuhan() async {
    final values = await _repository.allKeswanGrowth;
    for (KeswanBobotRequestModel value in values) {
      final sync = await _keswanRepository.keswanBobot(
        request: value,
        localStrategy: false,
      );
      if (sync.code == HttpStatus.ok) {
        LocalHelper.delete<KeswanBobotRequestModel>(
            PendingTransaction.pertumbuhan.localName,
            (table) => table.id == value.id);
      }
    }
    tabController.animateTo(6);
  }

  Future<void> syncVaksinasi() async {
    final values = await _repository.allKeswanHealth;
    for (KeswanKesehatanRequestModel value in values) {
      final sync = await _keswanRepository.keswanKesehatan(
        request: value,
        localStrategy: false,
      );
      if (sync.code == HttpStatus.ok) {
        LocalHelper.delete<KeswanKesehatanRequestModel>(
            PendingTransaction.vaksinasi.localName,
            (table) => table.id == value.id);
      }
    }
    tabController.animateTo(7);
  }

  Future<void> syncMutasi() async {
    final values = await _repository.allMutasi;
    for (ManageMutasiRequestModel value in values) {
      final sync = await _mutasiRepository.manageMutasi(
        request: value,
        localStrategy: false,
      );
      if (sync) {
        LocalHelper.delete<ManageMutasiRequestModel>(
            PendingTransaction.mutasi.localName,
            (table) => table.id == value.id);
      }
    }
    tabController.animateTo(8);
  }

  Future<void> syncSusu() async {
    final values = await _repository.allProduksiSusu;
    for (ProduksiSusuRequest value in values) {
      final sync = await _susuRepository.manageSusu(
        request: value,
        localStrategy: false,
      );
      if (sync) {
        LocalHelper.delete<ProduksiSusuRequest>(
            PendingTransaction.susu.localName, (table) => table.id == value.id);
      }
    }
    tabController.animateTo(9);
  }

  Future<void> syncInseminasi() async {
    final values = await _repository.allInseminasi;
    for (InseminasiRequest value in values) {
      final sync = await _inseminasiRepository.update(
        request: value,
        localStrategy: false,
      );
      if (sync) {
        LocalHelper.delete<InseminasiRequest>(
            PendingTransaction.inseminasi.localName,
            (table) => table.id == value.id);
      }
    }
    tabController.animateTo(10);
  }

  Future<void> syncBukuLahir() async {
    final values = await _repository.allBukuLahir;
    for (BukuIndukRequest value in values) {
      final sync = await _bukuLahirRepository.save(
        payload: value,
        localStrategy: false,
      );
      if (sync) {
        LocalHelper.delete<BukuIndukRequest>(
            PendingTransaction.bukuLahir.localName,
            (table) => table.id == value.id);
      }
    }
    tabController.animateTo(11);
  }

  Future<void> syncPakan() async {
    final values = await _repository.allPakan;
    for (UpdatePakanRequest value in values) {
      final sync = await _pakanRepository.updatePakan(
        request: value,
        localStrategy: false,
      );
      if (sync) {
        LocalHelper.delete<UpdatePakanRequest>(
            PendingTransaction.pakan.localName,
            (table) => table.id == value.id);
      }
    }
    tabController.animateTo(0);
  }

  void syncAll() async {
    await syncUnitUsaha();
    await syncOwner();
    await syncKandang();
    await syncTernak();
    await syncPertumbuhan();
    await syncVaksinasi();
    await syncMutasi();
    await syncSusu();
    await syncInseminasi();
    await syncBukuLahir();
    await syncPakan();
  }
}
