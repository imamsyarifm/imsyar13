import 'package:dio/dio.dart';
import 'package:get/get.dart';

import '../../../data/repositories/buku_lahir_repository.dart';
import '../../../data/repositories/inseminasi_repository.dart';
import '../../../data/repositories/kandang_repository.dart';
import '../../../data/repositories/keswan_repository.dart';
import '../../../data/repositories/mutasi_repository.dart';
import '../../../data/repositories/owner_repository.dart';
import '../../../data/repositories/pakan_repository.dart';
import '../../../data/repositories/pending_transaction_repository.dart';
import '../../../data/repositories/susu_repository.dart';
import '../../../data/repositories/ternak_repository.dart';
import '../../../data/repositories/unit_usaha_repository.dart';
import 'pending_transaction_controller.dart';

class PendingTransactionBinding extends Bindings {
  @override
  void dependencies() {
    Get.put<PendingTransactionRepository>(PendingTransactionRepository());

    Get.put(KandangRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(OwnerRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(UnitUsahaRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(BukuLahirRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(InseminasiRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(KeswanRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(MutasiRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(PakanRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(SusuRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(TernakRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(PendingTransactionController(
      repository: Get.find<PendingTransactionRepository>(),
      kandangRepository: Get.find<KandangRepository>(),
      ownerRepository: Get.find<OwnerRepository>(),
      unitUsahaRepository: Get.find<UnitUsahaRepository>(),
      bukuLahirRepository: Get.find<BukuLahirRepository>(),
      inseminasiRepository: Get.find<InseminasiRepository>(),
      keswanRepository: Get.find<KeswanRepository>(),
      mutasiRepository: Get.find<MutasiRepository>(),
      pakanRepository: Get.find<PakanRepository>(),
      susuRepository: Get.find<SusuRepository>(),
      ternakRepository: Get.find<TernakRepository>(),
    ));
  }
}
