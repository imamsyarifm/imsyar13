import 'package:flutter/material.dart';

import '../../../app/consts/pending_transaction_type.dart';
import '../../../data/models/kandang/kandang_model.dart';
import '../../../data/models/owner/owner_model.dart';
import '../../../data/models/unit_usaha/unit_usaha.dart';
import '../../../utils/local_helper.dart';

class PendingTransactionListWidget<D> extends StatefulWidget {
  const PendingTransactionListWidget({
    super.key,
    required this.transaction,
    this.subtitle,
    required this.title,
  });

  final PendingTransaction transaction;
  final String? Function(D)? subtitle;
  final String Function(D) title;

  @override
  State<PendingTransactionListWidget<D>> createState() =>
      _PendingTransactionListWidgetState<D>();
}

class _PendingTransactionListWidgetState<D>
    extends State<PendingTransactionListWidget<D>> {
  final values = [];

  @override
  void didChangeDependencies() async {
    super.didChangeDependencies();
    final table = await LocalHelper.getTable<D>(widget.transaction.localName);
    setState(() {
      switch (D) {
        case UnitUsaha:
          final data = table.values.toList() as List<UnitUsaha>;
          final filteredData =
              data.where((element) => element.isSynced == false);
          values.addAll(filteredData);
          break;
        case OwnerModel:
          final data = table.values.toList() as List<OwnerModel>;
          final filteredData =
              data.where((element) => element.isSynced == false);
          values.addAll(filteredData);
          break;
        case KandangModel:
          final data = table.values.toList() as List<KandangModel>;
          final filteredData =
              data.where((element) => element.isSynced == false);
          values.addAll(filteredData);
          break;
        default:
          values.addAll(table.values.toList());
          break;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      itemBuilder: (context, index) {
        final value = values[index];
        return ListTile(
          title: Text(widget.title.call(value)),
          subtitle: (widget.subtitle != null)
              ? Text(widget.subtitle!.call(value)!)
              : null,
        );
      },
      separatorBuilder: (context, index) => const Divider(),
      itemCount: values.length,
    );
  }
}
