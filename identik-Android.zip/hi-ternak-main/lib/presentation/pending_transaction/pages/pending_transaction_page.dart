import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../app/consts/pending_transaction_type.dart';
import '../../../data/models/buku_lahir/buku_induk_request.dart';
import '../../../data/models/inseminasi/inseminasi_request.dart';
import '../../../data/models/kandang/kandang_model.dart';
import '../../../data/models/keswan/keswan_bobot_request_model.dart';
import '../../../data/models/keswan/keswan_kesehatan_request_model.dart';
import '../../../data/models/mutasi/manage_mutasi_request_model.dart';
import '../../../data/models/owner/owner_model.dart';
import '../../../data/models/pakan/update_pakan_request.dart';
import '../../../data/models/susu/produksi_susu_request.dart';
import '../../../data/models/ternak/ternak_request.dart';
import '../../../data/models/unit_usaha/unit_usaha.dart';
import '../../widgets/default_scaffold.dart';
import '../get/pending_transaction_controller.dart';
import '../widgets/pending_transaction_list_widget.dart';

class PendingTransactionPage extends GetView<PendingTransactionController> {
  static const routeName = '/pending-transaction';

  const PendingTransactionPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultScaffold(
      appBarTitle: 'Pending Transaction',
      actions: [
        IconButton(
          onPressed: () => controller.syncAll(),
          icon: const Icon(Icons.upload_rounded),
        ),
      ],
      body: Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(16),
            topRight: Radius.circular(16),
          ),
        ),
        child: Column(
          children: [
            TabBar(
              controller: controller.tabController,
              labelColor: black,
              unselectedLabelColor: grey9B,
              indicatorColor: green,
              labelStyle: GoogleFonts.roboto(
                color: black,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
              isScrollable: true,
              tabs: [
                Tab(
                  text: PendingTransactionController.tabs[0].name,
                ),
                Tab(
                  text: PendingTransactionController.tabs[1].name,
                ),
                Tab(
                  text: PendingTransactionController.tabs[2].name,
                ),
                Tab(
                  text: PendingTransactionController.tabs[3].name,
                ),
                Tab(
                  text: PendingTransactionController.tabs[4].name,
                ),
                Tab(
                  text: PendingTransactionController.tabs[5].name,
                ),
                Tab(
                  text: PendingTransactionController.tabs[6].name,
                ),
                Tab(
                  text: PendingTransactionController.tabs[7].name,
                ),
                Tab(
                  text: PendingTransactionController.tabs[8].name,
                ),
                Tab(
                  text: PendingTransactionController.tabs[9].name,
                ),
                Tab(
                  text: PendingTransactionController.tabs[10].name,
                ),
              ],
              onTap: (value) {
                final pending = PendingTransactionController.tabs[value];
                controller.updateActivePendingTransaction(pending);
              },
            ),
            Expanded(
              child: Obx(
                () => TabBarView(
                  controller: controller.tabController,
                  children: [
                    PendingTransactionListWidget<UnitUsaha>(
                      subtitle: null,
                      title: (usaha) => usaha.companyName,
                      transaction:
                          controller.currentTab ?? PendingTransaction.unitUsaha,
                    ),
                    PendingTransactionListWidget<OwnerModel>(
                      subtitle: null,
                      title: (owner) => owner.name,
                      transaction:
                          controller.currentTab ?? PendingTransaction.owner,
                    ),
                    PendingTransactionListWidget<KandangModel>(
                      subtitle: null,
                      title: (kandang) => kandang.namaKandang,
                      transaction:
                          controller.currentTab ?? PendingTransaction.kandang,
                    ),
                    PendingTransactionListWidget<TernakRequest>(
                      subtitle: null,
                      title: (ternak) => ternak.codeProduct ?? '-',
                      transaction:
                          controller.currentTab ?? PendingTransaction.ternak,
                    ),
                    PendingTransactionListWidget<KeswanBobotRequestModel>(
                      subtitle: (keswan) => keswan.keterangan,
                      title: (keswan) => keswan.idProduct,
                      transaction: controller.currentTab ??
                          PendingTransaction.pertumbuhan,
                    ),
                    PendingTransactionListWidget<KeswanKesehatanRequestModel>(
                      subtitle: (keswan) => keswan.keterangan,
                      title: (keswan) => keswan.idProduct,
                      transaction:
                          controller.currentTab ?? PendingTransaction.vaksinasi,
                    ),
                    PendingTransactionListWidget<ManageMutasiRequestModel>(
                      subtitle: (mutasi) => mutasi.keterangan,
                      title: (mutasi) => mutasi.idProduct ?? '-',
                      transaction:
                          controller.currentTab ?? PendingTransaction.mutasi,
                    ),
                    PendingTransactionListWidget<ProduksiSusuRequest>(
                      subtitle: (susu) => susu.keterangan,
                      title: (susu) => susu.idProduct,
                      transaction:
                          controller.currentTab ?? PendingTransaction.susu,
                    ),
                    PendingTransactionListWidget<InseminasiRequest>(
                      subtitle: (inseminasi) => inseminasi.keterangan,
                      title: (inseminasi) => inseminasi.idProduct,
                      transaction: controller.currentTab ??
                          PendingTransaction.inseminasi,
                    ),
                    PendingTransactionListWidget<BukuIndukRequest>(
                      subtitle: (bukuInduk) => bukuInduk.keterangan,
                      title: (bukuInduk) => bukuInduk.idProduct ?? '-',
                      transaction:
                          controller.currentTab ?? PendingTransaction.bukuLahir,
                    ),
                    PendingTransactionListWidget<UpdatePakanRequest>(
                      subtitle: (pakan) => pakan.keterangan,
                      title: (pakan) => pakan.idKandang,
                      transaction:
                          controller.currentTab ?? PendingTransaction.pakan,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      floatingAction: FloatingActionButton(
        onPressed: () => controller.sync(controller.currentTab),
        backgroundColor: green,
        child: const Icon(Icons.refresh),
      ),
    );
  }
}
