import 'package:flutter/material.dart';
import 'package:get/get.dart';

class KualitasSusuEditController extends GetxController {
  final etWarna = TextEditingController();
  final etBau = TextEditingController();
  final etLemak = TextEditingController();
  final etProtein = TextEditingController();
  final etTs = TextEditingController();
  final etNsf = TextEditingController();
  final etLaktosa = TextEditingController();
  final etDensity = TextEditingController();
  final etFpd = TextEditingController();
  final etAcidity = TextEditingController();
  final etTpc = TextEditingController();
  final etPh = TextEditingController();
}
