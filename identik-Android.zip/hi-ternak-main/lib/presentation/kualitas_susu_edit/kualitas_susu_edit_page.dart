import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../app/consts/colors.dart';
import '../../utils/validation_util.dart';
import '../widgets/default_scaffold.dart';
import '../widgets/edit_text.dart';
import 'kualitas_susu_edit_controller.dart';

class KualitasSusuEditPage extends GetView<KualitasSusuEditController> {
  static const routeName = '/edit-kualitas-susu';
  const KualitasSusuEditPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => DefaultScaffold(
      appBarTitle: 'Produksi Susu',
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          child: ListView(children: [
            EditText(
              label: 'Warna*',
              validator: (value) =>
                  ValidationUtil.emptyValidate('Warna', value),
              keyboardType: TextInputType.text,
              textInputAction: TextInputAction.done,
              controller: controller.etWarna,
            ),
            const SizedBox(height: 16),
            EditText(
              label: 'Bau*',
              validator: (value) => ValidationUtil.emptyValidate('Bau', value),
              keyboardType: TextInputType.text,
              textInputAction: TextInputAction.done,
              controller: controller.etBau,
            ),
            const SizedBox(height: 16),
            EditText(
              label: 'Lemak*',
              validator: (value) =>
                  ValidationUtil.emptyValidate('Lemak', value),
              keyboardType: TextInputType.number,
              controller: controller.etBau,
            ),
            const SizedBox(height: 16),
            EditText(
              label: 'Protein*',
              validator: (value) =>
                  ValidationUtil.emptyValidate('Protein', value),
              keyboardType: TextInputType.number,
              controller: controller.etProtein,
            ),
            const SizedBox(height: 16),
            EditText(
              label: 'TS*',
              validator: (value) => ValidationUtil.emptyValidate('TS', value),
              keyboardType: TextInputType.number,
              controller: controller.etTs,
            ),
            const SizedBox(height: 16),
            EditText(
              label: 'NSF*',
              validator: (value) => ValidationUtil.emptyValidate('NSF', value),
              keyboardType: TextInputType.number,
              controller: controller.etNsf,
            ),
            const SizedBox(height: 16),
            EditText(
              label: 'Laktosa*',
              validator: (value) =>
                  ValidationUtil.emptyValidate('Laktosa', value),
              keyboardType: TextInputType.number,
              controller: controller.etLaktosa,
            ),
            const SizedBox(height: 16),
            EditText(
              label: 'Density*',
              validator: (value) =>
                  ValidationUtil.emptyValidate('Density', value),
              keyboardType: TextInputType.number,
              controller: controller.etDensity,
            ),
            const SizedBox(height: 16),
            EditText(
              label: 'FPD*',
              validator: (value) => ValidationUtil.emptyValidate('FPD', value),
              keyboardType: TextInputType.number,
              controller: controller.etFpd,
            ),
            const SizedBox(height: 16),
            EditText(
              label: 'Acidity*',
              validator: (value) =>
                  ValidationUtil.emptyValidate('Acidity', value),
              keyboardType: TextInputType.number,
              controller: controller.etAcidity,
            ),
            const SizedBox(height: 16),
            EditText(
              label: 'TPC*',
              validator: (value) => ValidationUtil.emptyValidate('TPC', value),
              keyboardType: TextInputType.number,
              controller: controller.etTpc,
            ),
            const SizedBox(height: 16),
            EditText(
              label: 'PH*',
              validator: (value) => ValidationUtil.emptyValidate('PH', value),
              keyboardType: TextInputType.number,
              controller: controller.etPh,
            ),
            const SizedBox(height: 16),
          ]),
        ),
      ),
      bottomNavigation: Container(
        color: Colors.white,
        child: Row(children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 12, top: 12, bottom: 12, right: 6),
              child: SizedBox(
                height: 40,
                child: ElevatedButton(
                    onPressed: () => Get.back(),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(36))),
                    child: Text(
                      'BATAL',
                      style: GoogleFonts.roboto(
                          color: black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                    )),
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(
                  right: 12, top: 12, bottom: 12, left: 6),
              child: SizedBox(
                height: 40,
                child: ElevatedButton(
                    onPressed: () => {},
                    style: ElevatedButton.styleFrom(
                        backgroundColor: yellowDark,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(36))),
                    child: Text(
                      'SIMPAN',
                      style: GoogleFonts.roboto(
                          color: black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                    )),
              ),
            ),
          ),
        ]),
      ));
}
