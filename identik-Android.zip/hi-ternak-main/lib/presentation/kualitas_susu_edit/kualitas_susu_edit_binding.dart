import 'package:get/get.dart';
import 'kualitas_susu_edit_controller.dart';

class KualitasSusuEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(KualitasSusuEditController());
  }
}
