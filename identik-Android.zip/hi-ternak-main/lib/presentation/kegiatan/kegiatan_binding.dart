import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../data/repositories/inbox_news_repository.dart';
import 'kegiatan_controller.dart';

class KegiatanBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(InboxNewsRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(KegiatanController(
      repository: Get.find<InboxNewsRepository>(),
    ));
  }
}
