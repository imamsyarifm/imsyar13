import 'package:carousel_slider/carousel_controller.dart';
import 'package:get/get.dart';

import '../../data/models/inbox/inbox_model.dart';
import '../../data/repositories/inbox_news_repository.dart';

class KegiatanController extends GetxController {
  final carouselController = CarouselController();

  final InboxNewsRepository _repository;

  KegiatanController({required InboxNewsRepository repository})
      : _repository = repository;

  final _activities = Rx<List<InboxModel>>([]);
  final _carouselIndex = 0.obs;

  List<InboxModel> get activities => _activities.value;
  int get carouselIndex => _carouselIndex.value;

  @override
  void onInit() {
    retrieveActivities();
    super.onInit();
  }

  void retrieveActivities() async {
    final activities = await _repository.allActivity;
    _activities.value = activities;
  }

  void changeCarouselIndex(int index) => _carouselIndex.value = index;
}
