import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../app/consts/colors.dart';
import 'kegiatan_controller.dart';
import 'widgets/activity_widget.dart';

class KegiatanPage extends GetView<KegiatanController> {
  const KegiatanPage({Key? key}) : super(key: key);

  static const routeName = '/kegiatan';

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      if (controller.activities.isEmpty) {
        return const Center(
          child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(green),
          ),
        );
      }

      return Expanded(
          child: CarouselSlider.builder(
        carouselController: controller.carouselController,
        itemCount: controller.activities.length,
        itemBuilder: (context, itemIndex, pageViewIndex) => ActivityWidget(
          activity: controller.activities[itemIndex],
        ),
        options: CarouselOptions(
          height: Get.height,
          onPageChanged: (index, reason) =>
              controller.changeCarouselIndex(index),
          autoPlay: true,
          disableCenter: true,
          enlargeCenterPage: true,
        ),
      ));
    });
  }
}
