import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import '../widgets/default_scaffold.dart';

class PrivacyPolicyPage extends StatelessWidget {
  static const routeName = '/privacy-policy';

  const PrivacyPolicyPage({super.key, required this.url});

  final String url;

  @override
  Widget build(BuildContext context) {
    return DefaultScaffold(
      appBarTitle: 'Kebijakan Privasi',
      body: InAppWebView(
        initialUrlRequest: URLRequest(url: Uri.parse(url)),
        androidOnPermissionRequest: (controller, origin, resources) async {
          return PermissionRequestResponse(
              resources: resources,
              action: PermissionRequestResponseAction.GRANT);
        },
      ),
    );
  }
}
