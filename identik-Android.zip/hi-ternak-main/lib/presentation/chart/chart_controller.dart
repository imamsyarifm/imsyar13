import 'package:flutter/services.dart';
import 'package:get/get.dart';

class ChartController extends GetxController {
  @override
  void onInit() {
    super.onInit();

    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
    ]);
  }

  @override
  void onClose() {
    super.onClose();

    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);
  }
}
