import 'package:get/get.dart';
import 'keswan_controller.dart';

class KeswanBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(KeswanController());
  }
}
