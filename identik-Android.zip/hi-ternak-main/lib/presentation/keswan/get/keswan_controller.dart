import 'package:flutter/material.dart';
import 'package:get/get.dart';

class KeswanController extends GetxController
    with GetSingleTickerProviderStateMixin {
  late TabController tabController;

  final _carouselImageIndex = 0.obs;

  int get carouselImageIndex => _carouselImageIndex.value;

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(length: 2, vsync: this);
  }

  void changeCarouselImageIndex(int index) => _carouselImageIndex.value = index;
}
