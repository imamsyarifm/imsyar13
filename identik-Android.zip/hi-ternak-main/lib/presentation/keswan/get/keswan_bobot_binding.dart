import 'package:get/get.dart';
import 'keswan_bobot_controller.dart';

class KeswanBobotBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(KeswanBobotController());
  }
}
