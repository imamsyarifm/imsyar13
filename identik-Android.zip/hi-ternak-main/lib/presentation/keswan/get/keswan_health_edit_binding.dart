import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/combo_repository.dart';
import '../../../data/repositories/keswan_repository.dart';
import '../../../data/repositories/ternak_repository.dart';
import 'keswan_health_edit_controller.dart';

class KeswanHealthEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(ComboRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(KeswanRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(TernakRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(KeswanHealthEditController(
      comboRepository: Get.find<ComboRepository>(),
      keswanRepository: Get.find<KeswanRepository>(),
      ternakRepository: Get.find<TernakRepository>(),
    ));
  }
}
