import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_connect/http/src/status/http_status.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../data/models/combo/combo_model.dart';
import '../../../data/models/keswan/keswan_kesehatan_request_model.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../../../data/repositories/combo_repository.dart';
import '../../../data/repositories/keswan_repository.dart';
import '../../../data/repositories/ternak_repository.dart';
import '../../../utils/datetime_util.dart';
import '../../../utils/validation_util.dart';
import '../../identitas/pages/identitas_detail_page.dart';
import '../../identitas/params/identitas_detail_params.dart';
import '../../main/main_page.dart';
import '../../rekam_medis/params/rekam_medis_params.dart';

class KeswanHealthEditController extends GetxController {
  final ComboRepository _comboRepository;
  final KeswanRepository _keswanRepository;
  final TernakRepository _ternakRepository;

  KeswanHealthEditController({
    required ComboRepository comboRepository,
    required KeswanRepository keswanRepository,
    required TernakRepository ternakRepository,
  })  : _comboRepository = comboRepository,
        _keswanRepository = keswanRepository,
        _ternakRepository = ternakRepository;

  late IdentityTernakModel ternak;

  final formKey = GlobalKey<FormState>();
  final etDate = TextEditingController();
  final etCategory = TextEditingController();
  final etVaksin = TextEditingController();
  final etJenis = TextEditingController();
  final etObat = TextEditingController();
  final etDosis = TextEditingController();
  final etKeterangan = TextEditingController();
  final etBatchNumber = TextEditingController();
  final pinController = TextEditingController();
  final focusNode = FocusNode();

  final _jenisSelected = Rx<ComboModel?>(null);
  final _dosisSelected = 1.obs;
  final _selectedObat = Rx<ComboModel?>(null);
  final _isLoadingCategory = false.obs;
  final _categories = Rx<List<ComboModel>>([]);
  final _selectedCategory = Rx<ComboModel?>(null);
  final _isLoadingOption = false.obs;
  final _isLoadingObat = false.obs;
  final _isLoadingJenis = false.obs;
  final _allObat = Rx<List<ComboModel>>([]);
  final _selectedOption = Rx<ComboModel?>(null);
  final _processingData = false.obs;
  final _isVaccine = false.obs;
  final _date = Rx<DateTime>(DateTime.now());
  final _isFromProfile = false.obs;
  final _allJenis = Rx<List<ComboModel>>([]);

  ComboModel? get jenisSelected => _jenisSelected.value;
  int get dosisSelected => _dosisSelected.value;
  ComboModel? get selectedObat => _selectedObat.value;
  bool get isLoadingCategory => _isLoadingCategory.value;
  List<ComboModel> get categories => _categories.value;
  ComboModel? get selectedCategory => _selectedCategory.value;
  bool get isLoadingOption => _isLoadingOption.value;
  bool get isLoadingObat => _isLoadingObat.value;
  bool get isLoadingJenis => _isLoadingJenis.value;
  List<ComboModel> get allObat => _allObat.value;
  List<ComboModel> get allJenis => _allJenis.value;
  ComboModel? get selectedOption => _selectedOption.value;
  bool get processingData => _processingData.value;
  bool get isVaccine => _isVaccine.value;
  DateTime get date => _date.value;

  @override
  void onInit() async {
    super.onInit();
    setDate(DateTime.now());
    await retrieveCategories();
    await retrieveArgs();
    await retriveJenis;
  }

  Future<void> retrieveArgs() async {
    final args = Get.arguments;
    if (args is IdentityTernakModel) {
      ternak = args;
      await initialData();
    } else if (args is RekamMedisParams) {
      ternak = args.ternak;
      _isFromProfile.value = true;
    }
  }

  Future<void> initialData() async {
    await setCategory(
      category: _categories.value.first,
      isInitial: true,
    );

    // _selectedObat.value = _allObat.value.first;
    // etObat.text = _selectedObat.value?.label ?? '';
  }

  Future<void> retrieveCategories() async {
    _isLoadingCategory.value = true;
    _categories.value = await _comboRepository.keswanCategories;
    _isLoadingCategory.value = false;

    final vaksin =
        _categories.value.firstWhere((element) => element.value == 'vaksin');
    setCategory(
      category: vaksin,
      isInitial: true,
    );
  }

  void setJenisSelected(ComboModel value) async {
    _jenisSelected.value = value;
    etJenis.text = value.label;
    await retrieveObat;
    Get.back();
  }

  void setDosisSelected(int value) {
    _dosisSelected.value = value;
    etDosis.text = value.toString();
    Get.back();
  }

  Future<void> setCategory({
    required ComboModel category,
    bool isInitial = false,
  }) async {
    _selectedCategory.value = category;
    etCategory.text = category.label;
    // await retrieveObat;

    if (_selectedCategory.value?.value == 'vaksin') {
      _isVaccine.value = true;
    } else {
      _isVaccine.value = false;
    }

    if (!isInitial) Get.back();
  }

  void setObat(ComboModel value) {
    _selectedObat.value = value;
    etObat.text = value.label;
    Get.back();
  }

  void save() async {
    _processingData.value = true;

    final prefs = await SharedPreferences.getInstance();
    final bool? isInputPasscode = prefs.getBool('isInput');

    final request = KeswanKesehatanRequestModel(
      idProduct: ternak.codeProduct ?? '-',
      kategori: _selectedCategory.value?.value ?? '-',
      tanggalVaksinasi: _date.value,
      batchNumber: etBatchNumber.text,
      vaksinObat: _selectedObat.value?.value,
      jenis: '',
      dosis: etDosis.text,
      keterangan: etKeterangan.text,
      id: DateTime.now().millisecondsSinceEpoch,
      isInput: isInputPasscode! ? 1 : 0,
      passcode: isInputPasscode ? pinController.text : '',
    );

    try {
      if (isInputPasscode) {
        if (pinController.text.length != 6) {
          Get.showSnackbar(const GetSnackBar(
            message: 'Passcode harus 6 digit',
            duration: Duration(seconds: 3),
          ));
          return;
        }
      }
      
      final update = await _keswanRepository.keswanKesehatan(
        request: request,
      );
      if (update.code == HttpStatus.ok) {
        final foundTernak = await _ternakRepository.allTernak(query: ternak.id);
        _processingData.value = false;
        if (_selectedCategory.value?.value == 'vaksin') {
          if (_isFromProfile.value) {
            Get.until((route) =>
                route.settings.name == IdentitasDetailPage.routeName);
          } else {
            Get.until((route) => route.settings.name == MainPage.routeName);
          }
          Get.showSnackbar(const GetSnackBar(
            message: 'Update vaksinasi berhasil',
            duration: Duration(seconds: 3),
          ));
        } else {
          if (foundTernak.isNotEmpty) {
            Get.offNamedUntil(
              IdentitasDetailPage.routeName,
              (route) => route.settings.name == MainPage.routeName,
              arguments: IdentitasDetailParams(ternak: foundTernak.first),
            );
          }
          Get.showSnackbar(const GetSnackBar(
            message: 'Update rekam medis berhasil',
            duration: Duration(seconds: 3),
          ));
        }
      } else {
        Get.showSnackbar(const GetSnackBar(
          message: 'Update rekam medis gagal',
          duration: Duration(seconds: 3),
        ));
        _processingData.value = false;
      }
    } catch (error) {
      debugPrint(error.toString());
      Get.showSnackbar(GetSnackBar(
        message: ValidationUtil.errorMessage(error as DioError),
        duration: const Duration(seconds: 3),
      ));
      _processingData.value = false;
    }
  }

  Future<void> get retriveJenis async {
    _isLoadingJenis.value = true;
    final allJenis = await _comboRepository.catVaksins;
    _allJenis.value = allJenis;
    _isLoadingJenis.value = false;
  }

  Future<void> get retrieveObat async {
    _isLoadingObat.value = true;
    final jenis = _jenisSelected.value!.value;
    final allObat = await _comboRepository.obat('vaksin', jenis);
    _allObat.value = allObat;
    _isLoadingObat.value = false;
  }

  void setDate(DateTime date) {
    _date.value = date;
    etDate.text = date.readable();
  }
}
