// import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_connect/http/src/status/http_status.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../data/models/keswan/keswan_bobot_request_model.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../../../data/repositories/keswan_repository.dart';
import '../../../utils/datetime_util.dart';
// import '../../../utils/validation_util.dart';
import '../../identitas/pages/identitas_detail_page.dart';
import '../../main/main_page.dart';
import '../../pertumbuhan_ternak/params/pertumbuhan_ternak_params.dart';

class KeswanEditController extends GetxController {
  late IdentityTernakModel ternak;
  final KeswanRepository _keswanRepository;
  final _processingData = false.obs;
  final _isFromProfile = false.obs;

  bool get processingData => _processingData.value;

  KeswanEditController({
    required KeswanRepository keswanRepository,
  }) : _keswanRepository = keswanRepository;

  @override
  void onInit() {
    super.onInit();
    setDate(DateTime.now());
    retrieveArgs();
  }

  void retrieveArgs() {
    final args = Get.arguments;
    if (args is IdentityTernakModel) {
      ternak = args;
    } else if (args is PertumbuhanTernakParams) {
      ternak = args.ternak;
      _isFromProfile.value = true;
    }
  }

  final formKey = GlobalKey<FormState>();
  final etDate = TextEditingController();
  final etUmur = TextEditingController();
  final etLingkarDada = TextEditingController();
  final etPanjangBadan = TextEditingController();
  final etTinggiPundak = TextEditingController();
  final etTinggiPinggul = TextEditingController();
  final etLebarPinggul = TextEditingController();
  final etTinggiSkrotum = TextEditingController();
  final etBobot = TextEditingController();
  final etSuhuTubuh = TextEditingController();
  final etKeterangan = TextEditingController();
  final pinController = TextEditingController();
  final focusNode = FocusNode();

  final _date = Rx<DateTime>(DateTime.now());

  DateTime get date => _date.value;

  void setDate(DateTime date) {
    _date.value = date;
    etDate.text = date.readable();
  }

  void save() async {
    _processingData.value = true;

    final prefs = await SharedPreferences.getInstance();
    final bool? isInputPasscode = prefs.getBool('isInput');

    final request = KeswanBobotRequestModel(
      idProduct: ternak.codeProduct ?? '-',
      usia: etUmur.text,
      beratBadan: etBobot.text,
      panjangBadan: etPanjangBadan.text,
      tinggiBadan: etTinggiPundak.text,
      tinggiPinggul: etTinggiPinggul.text,
      lebarPinggul: etLebarPinggul.text,
      lingkarDada: etLingkarDada.text,
      lingkarSkrotum: etTinggiSkrotum.text,
      suhuTubuh: etSuhuTubuh.text,
      keterangan: etKeterangan.text,
      id: DateTime.now().millisecondsSinceEpoch,
      isInput: isInputPasscode! ? 1 : 0,
      passcode: isInputPasscode ? pinController.text : '',
    );

    try {
      if (isInputPasscode) {
        if (pinController.text.length != 6) {
          Get.showSnackbar(const GetSnackBar(
            message: 'Passcode harus 6 digit',
            duration: Duration(seconds: 3),
          ));
          return;
        }
      }

      final model = await _keswanRepository.keswanBobot(
        request: request,
      );
      if (model.code == HttpStatus.ok) {
        if (_isFromProfile.value) {
          Get.until(
              (route) => route.settings.name == IdentitasDetailPage.routeName);
        } else {
          Get.until((route) => route.settings.name == MainPage.routeName);
          Get.showSnackbar(const GetSnackBar(
            message: 'Perubahan Data Pertumbuhan Berhasil',
            duration: Duration(seconds: 3),
          ));
        }
      } else {
        Get.showSnackbar(const GetSnackBar(
          message: 'Perubahan Data Pertumbuhan Gagal',
          duration: Duration(seconds: 3),
        ));
      }
    } catch (e) {
      // Get.showSnackbar(GetSnackBar(
      //   message: ValidationUtil.errorMessage(e as DioError),
      //   duration: const Duration(seconds: 3),
      // ));
      Get.showSnackbar(const GetSnackBar(
        message: 'Perubahan Data Pertumbuhan Gagal',
        duration: Duration(seconds: 3),
      ));
      _processingData.value = false;
    }
  }
}
