import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../app/consts/icons.dart';
import '../get/keswan_controller.dart';
import '../pages/keswan_health_edit_page.dart';

class KeswanHealthWidget extends GetWidget<KeswanController> {
  const KeswanHealthWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => Scaffold(
        body: ListView(
          children: [
            contentTile(context, 'Bunting', 'Negatif'),
            contentTile(context, 'Sapih', 'Ya'),
            contentTile(context, 'Diagnosa', '-'),
            contentTile(context, 'Penangangan', '-'),
            contentTile(context, 'Vaksin / Pengobatan', '-'),
            contentTile(context, 'Jenis', '-'),
            contentTile(context, 'Dosis', '-'),
            contentTile(context, 'Keterangan', '-'),
            const SizedBox(height: 100)
          ],
        ),
        floatingActionButton: FloatingActionButton(
          backgroundColor: yellowDark,
          onPressed: () => Get.toNamed(KeswanHealthEditPage.routeName),
          child: Image.asset(pencil, width: 16, height: 16),
        ),
      );

  Widget contentTile(BuildContext context, String title, String value,
          {Widget? trailing}) =>
      Column(
        children: [
          ListTile(
            title: Text(title,
                style: GoogleFonts.roboto(color: black, fontSize: 12)),
            subtitle: Text(value,
                style: GoogleFonts.roboto(
                    color: black, fontSize: 16, fontWeight: FontWeight.bold),
                textAlign: TextAlign.justify),
            trailing: trailing,
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Divider(color: greyC, thickness: 1, height: 0),
          )
        ],
      );
}
