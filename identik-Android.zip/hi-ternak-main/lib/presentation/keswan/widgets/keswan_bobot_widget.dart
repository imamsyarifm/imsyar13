import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../app/consts/icons.dart';
import '../get/keswan_controller.dart';
import '../pages/keswan_bobot_page.dart';
import '../pages/keswan_edit_page.dart';

class KeswanBobotWidget extends GetWidget<KeswanController> {
  const KeswanBobotWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => Scaffold(
        body: ListView(
          children: [
            contentTile(context, 'Umur (bulan)', '14'),
            contentTile(context, 'Lingkar Dada (cm)', '100'),
            contentTile(context, 'Panjang Badan (cm)', '220'),
            contentTile(context, 'Tinggi Pundak (cm)', '102'),
            contentTile(context, 'Bobot (kg)', '350',
                trailing: GestureDetector(
                    onTap: () => Get.toNamed(KeswanBobotPage.routeName),
                    child: const Icon(Icons.arrow_right, color: black))),
            contentTile(context, 'Suhu Tubuh', '36'),
            contentTile(
                context,
                'Keterangan',
                // ignore: lines_longer_than_80_chars
                'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).'),
            const SizedBox(height: 100)
          ],
        ),
        floatingActionButton: FloatingActionButton(
          backgroundColor: yellowDark,
          onPressed: () => Get.toNamed(KeswanEditPage.routeName),
          child: Image.asset(pencil, width: 16, height: 16),
        ),
      );

  Widget contentTile(BuildContext context, String title, String value,
          {Widget? trailing}) =>
      Column(
        children: [
          ListTile(
            title: Text(title,
                style: GoogleFonts.roboto(color: black, fontSize: 12)),
            subtitle: Text(value,
                style: GoogleFonts.roboto(
                    color: black, fontSize: 16, fontWeight: FontWeight.bold),
                textAlign: TextAlign.justify),
            trailing: trailing,
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Divider(color: greyC, thickness: 1, height: 0),
          )
        ],
      );
}
