import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../app/consts/colors.dart';
import '../get/keswan_health_edit_controller.dart';
import 'passcode_keswan_health_page.dart';

class PreviewKeswanHealthPage extends GetView<KeswanHealthEditController> {
  const PreviewKeswanHealthPage({Key? key}) : super(key: key);

  static const routeName = '/preview-keswan-health';

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: green,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: green,
          title: const Text('Check Data Vaksinasi'),
        ),
        body: Container(
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(16), topRight: Radius.circular(16)),
            color: Colors.white,
          ),
          child: Form(
            key: controller.formKey,
            child: ListView(children: [
              Padding(
                padding: const EdgeInsets.only(
                    left: 16, right: 16, top: 16, bottom: 26),
                child: Text(
                  'Mohon Periksa Kembali Data Yang Telah '
                  'Diinputkan Pada Vaksinasi',
                  style: GoogleFonts.roboto(
                      fontSize: 18, fontWeight: FontWeight.w500),
                  textAlign: TextAlign.center,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('QR Code'),
                    const SizedBox(width: 40),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.ternak.codeProduct.toString())
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Tanggal'),
                    const SizedBox(width: 46),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etDate.text)
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Jenis'),
                    const SizedBox(width: 63),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etJenis.text != ''
                        ? controller.etJenis.text
                        : '-')
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Obat'),
                    const SizedBox(width: 65),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etObat.text != ''
                        ? controller.etObat.text
                        : '-')
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Dosis'),
                    const SizedBox(width: 60),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etDosis.text != ''
                        ? controller.etDosis.text
                        : '-')
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('No Batch'),
                    const SizedBox(width: 38),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etBatchNumber.text != ''
                        ? controller.etBatchNumber.text
                        : '-')
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Keterangan'),
                    const SizedBox(width: 25),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etKeterangan.text != ''
                        ? controller.etKeterangan.text
                        : '-')
                  ],
                ),
              ),
            ]),
          ),
        ),
        bottomNavigationBar: Obx(() {
          return (controller.processingData)
              ? const LinearProgressIndicator(
                  color: green,
                )
              : Container(
                  color: Colors.white,
                  child: Row(
                    children: [
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(
                              left: 12, top: 12, bottom: 12, right: 6),
                          child: SizedBox(
                            height: 40,
                            child: ElevatedButton(
                                onPressed: () => Get.back(),
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.white,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(36))),
                                child: Text(
                                  'BATAL',
                                  style: GoogleFonts.roboto(
                                      color: black,
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold),
                                )),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(
                              right: 12, top: 12, bottom: 12, left: 6),
                          child: SizedBox(
                            height: 40,
                            child: ElevatedButton(
                                onPressed: () async {
                                  final prefs =
                                      await SharedPreferences.getInstance();
                                  final bool? isInput =
                                      prefs.getBool('isInput');
                                  if (isInput == true) {
                                    Get.toNamed(
                                        PasscodeKeswanHealthPage.routeName);
                                  } else {
                                    controller.save();
                                  }
                                },
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: yellowDark,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(36))),
                                child: Text(
                                  'SIMPAN',
                                  style: GoogleFonts.roboto(
                                      color: black,
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold),
                                )),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
        }),
      );
}
