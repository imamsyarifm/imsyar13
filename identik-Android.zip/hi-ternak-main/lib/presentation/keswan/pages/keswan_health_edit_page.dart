import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/combo/combo_model.dart';
import '../../../utils/datetime_util.dart';
import '../../../utils/validation_util.dart';
import '../../register/widgets/chooseable_widget.dart';
import '../../widgets/edit_text.dart';
import '../get/keswan_health_edit_controller.dart';
import 'preview_keswan_health_page.dart';

class KeswanHealthEditPage extends GetView<KeswanHealthEditController> {
  const KeswanHealthEditPage({Key? key}) : super(key: key);

  static const routeName = '/keswan-health-edit';

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: green,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: green,
          title: const Text('Update Vaksinasi'),
        ),
        body: Container(
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(16), topRight: Radius.circular(16)),
            color: Colors.white,
          ),
          child: Form(
            key: controller.formKey,
            child: ListView(children: [
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: EditText(
                  label: 'Tanggal*',
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Tanggal', value),
                  autoValidateMode: AutovalidateMode.onUserInteraction,
                  keyboardType: TextInputType.datetime,
                  controller: controller.etDate,
                  isReadOnly: true,
                  onTap: () async {
                    final dateTime = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime.now().add(
                          Duration(
                            days: DateTime.now().differencToOldYear(100).inDays,
                          ),
                        ),
                        lastDate: DateTime.now());
                    if (dateTime != null) {
                      controller.setDate(dateTime);
                    }
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Obx(
                  () {
                    if (controller.isLoadingCategory) {
                      return const Center(
                        child: CircularProgressIndicator(
                          color: green,
                        ),
                      );
                    } else {
                      return EditText(
                        controller: controller.etJenis,
                        validator: (value) =>
                            ValidationUtil.emptyValidate('Jenis', value),
                        onTap: () => showModalBottomSheet(
                          context: context,
                          builder: (context) => ChooseableWidget<ComboModel>(
                            values: controller.allJenis,
                            title: (ComboModel category) => category.label,
                            onSelected: (category) =>
                                controller.setJenisSelected(category),
                          ),
                        ),
                        isReadOnly: true,
                        label: 'Jenis*',
                        suffixIcon:
                            const Icon(Icons.arrow_drop_down, color: black),
                      );
                    }
                  },
                ),
              ),
              // Padding(
              //   padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
              //   child: EditText(
              //     controller: controller.etJenis,
              //     validator: (value) =>
              //         ValidationUtil.emptyValidate('Jenis', value),
              //     autoValidateMode: AutovalidateMode.onUserInteraction,
              //     label: 'Jenis*',
              //     keyboardType: TextInputType.text,
              //     textInputAction: TextInputAction.done,
              //   ),
              // ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Obx(() {
                  if (controller.isLoadingObat) {
                    return const Center(
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(green),
                      ),
                    );
                  }

                  return EditText(
                    controller: controller.etObat,
                    validator: (value) =>
                        ValidationUtil.emptyValidate('Obat', value),
                    autoValidateMode: AutovalidateMode.onUserInteraction,
                    isReadOnly: true,
                    label: 'Obat*',
                    onTap: () => showModalBottomSheet(
                      context: context,
                      builder: (context) => ChooseableWidget<ComboModel>(
                        values: controller.allObat,
                        title: (ComboModel category) => category.label,
                        onSelected: (category) => controller.setObat(category),
                      ),
                    ),
                    suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                  );
                }),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: EditText(
                  controller: controller.etDosis,
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Dosis', value),
                  autoValidateMode: AutovalidateMode.onUserInteraction,
                  label: 'Dosis*',
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.done,
                  suffixIcon: const Icon(
                    Icons.arrow_drop_down,
                    color: Colors.black54,
                  ),
                  isReadOnly: true,
                  onTap: () => showModalBottomSheet(
                      context: context,
                      builder: (context) => ChooseableWidget<int>(
                          values: List.generate(3, (index) => index),
                          title: (value) => '${value + 1}',
                          onSelected: (value) =>
                              controller.setDosisSelected(value + 1))),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: EditText(
                  controller: controller.etBatchNumber,
                  label: 'No Batch',
                  keyboardType: TextInputType.number,
                  textInputAction: TextInputAction.done,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: EditText(
                  controller: controller.etKeterangan,
                  label: 'Keterangan',
                  minLines: 5,
                  maxLines: null,
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.done,
                ),
              ),
              const SizedBox(height: 20)
            ]),
          ),
        ),
        bottomNavigationBar: Obx(() {
          if (controller.processingData) {
            return const LinearProgressIndicator(
              color: green,
            );
          }

          return Container(
            color: Colors.white,
            child: Row(children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 12, top: 12, bottom: 12, right: 6),
                  child: SizedBox(
                    height: 40,
                    child: ElevatedButton(
                        onPressed: () => Get.back(),
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(36))),
                        child: Text(
                          'BATAL',
                          style: GoogleFonts.roboto(
                              color: black,
                              fontSize: 14,
                              fontWeight: FontWeight.bold),
                        )),
                  ),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(
                      right: 12, top: 12, bottom: 12, left: 6),
                  child: SizedBox(
                    height: 40,
                    child: ElevatedButton(
                        onPressed: () async {
                          if (controller.formKey.currentState?.validate() ==
                              false) {
                            return;
                          }

                          Get.toNamed(PreviewKeswanHealthPage.routeName);
                        },
                        style: ElevatedButton.styleFrom(
                            backgroundColor: yellowDark,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(36))),
                        child: Text(
                          'SIMPAN',
                          style: GoogleFonts.roboto(
                              color: black,
                              fontSize: 14,
                              fontWeight: FontWeight.bold),
                        )),
                  ),
                ),
              ),
            ]),
          );
        }),
      );
}
