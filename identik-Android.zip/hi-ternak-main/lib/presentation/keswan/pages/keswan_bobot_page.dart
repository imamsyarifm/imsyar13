import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import '../../../app/consts/colors.dart';
import '../get/keswan_bobot_controller.dart';

class KeswanBobotPage extends GetView<KeswanBobotController> {
  const KeswanBobotPage({Key? key}) : super(key: key);

  static const routeName = '/keswan-bobot';

  final cutOffYValue = 5.0;
  final dateTextStyle = const TextStyle(
      fontSize: 10, color: Colors.purple, fontWeight: FontWeight.bold);

  @override
  Widget build(BuildContext context) {
    MediaQuery.of(context).orientation == Orientation.landscape;
    return Scaffold(
      backgroundColor: green,
      appBar: AppBar(
        backgroundColor: green,
        title: const Text('Keswan - Bobot Sapi 1 (kg)'),
        elevation: 0,
      ),
      body: Container(
        padding: const EdgeInsets.all(16),
        decoration: const BoxDecoration(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16)),
          color: Colors.white,
        ),
        child: ListView(
          children: [
            const SizedBox(height: 16),
            Center(
              child: Container(
                decoration: BoxDecoration(
                    color: greyF4, borderRadius: BorderRadius.circular(36)),
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Text('Bobot Sapi tahun ${DateTime.now().year}'),
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: 300,
              height: 140,
              child: LineChart(
                LineChartData(
                  lineTouchData: const LineTouchData(enabled: false),
                  lineBarsData: [
                    LineChartBarData(
                      spots: [
                        const FlSpot(0, 4),
                        const FlSpot(1, 3.5),
                        const FlSpot(2, 4.5),
                        const FlSpot(3, 1),
                        const FlSpot(4, 4),
                        const FlSpot(5, 6),
                        const FlSpot(6, 6.5),
                        const FlSpot(7, 6),
                        const FlSpot(8, 4),
                        const FlSpot(9, 6),
                        const FlSpot(10, 6),
                        const FlSpot(11, 7),
                      ],
                      isCurved: true,
                      barWidth: 8,
                      color: Colors.purpleAccent,
                      belowBarData: BarAreaData(
                        show: true,
                        color: Colors.deepPurple.withOpacity(0.4),
                        cutOffY: cutOffYValue,
                        applyCutOffY: true,
                      ),
                      aboveBarData: BarAreaData(
                        show: true,
                        color: Colors.orange.withOpacity(0.6),
                        cutOffY: cutOffYValue,
                        applyCutOffY: true,
                      ),
                      dotData: const FlDotData(
                        show: false,
                      ),
                    ),
                  ],
                  minY: 0,
                  titlesData: FlTitlesData(
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 14,
                        getTitlesWidget: (double value, TitleMeta meta) {
                          switch (value.toInt()) {
                            case 0:
                              return SideTitleWidget(
                                axisSide: meta.axisSide,
                                child: Text('Jan', style: dateTextStyle),
                              );
                            case 1:
                              return SideTitleWidget(
                                axisSide: meta.axisSide,
                                child: Text('Feb', style: dateTextStyle),
                              );
                            case 2:
                              return SideTitleWidget(
                                axisSide: meta.axisSide,
                                child: Text('Mar', style: dateTextStyle),
                              );
                            case 3:
                              return SideTitleWidget(
                                axisSide: meta.axisSide,
                                child: const Text('Apr'),
                              );
                            case 4:
                              return SideTitleWidget(
                                axisSide: meta.axisSide,
                                child: Text('May', style: dateTextStyle),
                              );
                            case 5:
                              return SideTitleWidget(
                                axisSide: meta.axisSide,
                                child: Text('Jun', style: dateTextStyle),
                              );
                            case 6:
                              return SideTitleWidget(
                                axisSide: meta.axisSide,
                                child: Text('Jul', style: dateTextStyle),
                              );
                            case 7:
                              return SideTitleWidget(
                                axisSide: meta.axisSide,
                                child: Text('Aug', style: dateTextStyle),
                              );
                            case 8:
                              return SideTitleWidget(
                                axisSide: meta.axisSide,
                                child: Text('Sep', style: dateTextStyle),
                              );
                            case 9:
                              return SideTitleWidget(
                                axisSide: meta.axisSide,
                                child: Text('Oct', style: dateTextStyle),
                              );
                            case 10:
                              return SideTitleWidget(
                                axisSide: meta.axisSide,
                                child: Text('Nov', style: dateTextStyle),
                              );
                            case 11:
                              return SideTitleWidget(
                                axisSide: meta.axisSide,
                                child: Text('Dec', style: dateTextStyle),
                              );
                            default:
                              return SideTitleWidget(
                                axisSide: meta.axisSide,
                                child: Text('', style: dateTextStyle),
                              );
                          }
                        },
                      ),
                    ),
                    leftTitles: AxisTitles(
                        sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (double value, TitleMeta meta) {
                        return SideTitleWidget(
                          axisSide: meta.axisSide,
                          child: Text('\$ ${value + 0.5}'),
                        );
                      },
                    )),
                  ),
                  gridData: FlGridData(
                    show: true,
                    checkToShowHorizontalLine: (double value) {
                      return value == 1 ||
                          value == 6 ||
                          value == 4 ||
                          value == 5;
                    },
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
