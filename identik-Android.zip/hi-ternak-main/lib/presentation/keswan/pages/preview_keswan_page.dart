import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../app/consts/colors.dart';
import '../get/keswan_edit_controller.dart';
import 'passcode_keswan_page.dart';

class PreviewKeswanPage extends GetView<KeswanEditController> {
  const PreviewKeswanPage({Key? key}) : super(key: key);

  static const routeName = '/preview-keswan';

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: green,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: green,
          title: const Text('Check Data Pertumbuhan'),
        ),
        body: Container(
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(16), topRight: Radius.circular(16)),
            color: Colors.white,
          ),
          child: Form(
            key: controller.formKey,
            child: ListView(children: [
              Padding(
                padding: const EdgeInsets.only(
                    left: 16, right: 16, top: 16, bottom: 26),
                child: Text(
                  'Mohon Periksa Kembali Data Yang Telah '
                  'Diinputkan Pada Pertumbuhan',
                  style: GoogleFonts.roboto(
                      fontSize: 18, fontWeight: FontWeight.w500),
                  textAlign: TextAlign.center,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('QR Code'),
                    const SizedBox(width: 40),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.ternak.codeProduct.toString())
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Tanggal'),
                    const SizedBox(width: 46),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etDate.text)
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Umur'),
                    const SizedBox(width: 63),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etUmur.text != ''
                        ? '${controller.etUmur.text} bulan'
                        : '-')
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Bobot'),
                    const SizedBox(width: 60),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etBobot.text != ''
                        ? '${controller.etBobot.text} kg'
                        : '-')
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Panjang Badan'),
                    const SizedBox(width: 5),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etPanjangBadan.text != ''
                        ? '${controller.etPanjangBadan.text} cm'
                        : '-')
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Lingkar Dada'),
                    const SizedBox(width: 17),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etLingkarDada.text != ''
                        ? '${controller.etLingkarDada.text} cm'
                        : '-')
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Tinggi Badan'),
                    const SizedBox(width: 17),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etTinggiPundak.text != ''
                        ? '${controller.etTinggiPundak.text} cm'
                        : '-')
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Tinggi Pinggul'),
                    const SizedBox(width: 11),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etTinggiPinggul.text != ''
                        ? '${controller.etTinggiPinggul.text} cm'
                        : '-')
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Lebar Pinggul'),
                    const SizedBox(width: 14),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etLebarPinggul.text != ''
                        ? '${controller.etLebarPinggul.text} cm'
                        : '-')
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Suhu Tubuh'),
                    const SizedBox(width: 25),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etSuhuTubuh.text != ''
                        ? controller.etSuhuTubuh.text
                        : '-')
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Tinggi Skrotum'),
                    const SizedBox(width: 6),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etTinggiSkrotum.text != ''
                        ? '${controller.etTinggiSkrotum.text} cm'
                        : '-')
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Keterangan'),
                    const SizedBox(width: 28),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etKeterangan.text != ''
                        ? controller.etKeterangan.text
                        : '-')
                  ],
                ),
              ),
            ]),
          ),
        ),
        bottomNavigationBar: Obx(() {
          return (controller.processingData)
              ? const LinearProgressIndicator(
                  color: green,
                )
              : Container(
                  color: Colors.white,
                  child: Row(
                    children: [
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(
                              left: 12, top: 12, bottom: 12, right: 6),
                          child: SizedBox(
                            height: 40,
                            child: ElevatedButton(
                                onPressed: () => Get.back(),
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.white,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(36))),
                                child: Text(
                                  'BATAL',
                                  style: GoogleFonts.roboto(
                                      color: black,
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold),
                                )),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(
                              right: 12, top: 12, bottom: 12, left: 6),
                          child: SizedBox(
                            height: 40,
                            child: ElevatedButton(
                                onPressed: () async {
                                  final prefs =
                                      await SharedPreferences.getInstance();
                                  final bool? isInput =
                                      prefs.getBool('isInput');
                                  if (isInput == true) {
                                    Get.toNamed(PasscodeKeswanPage.routeName);
                                  } else {
                                    controller.save();
                                  }
                                },
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: yellowDark,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(36))),
                                child: Text(
                                  'SIMPAN',
                                  style: GoogleFonts.roboto(
                                      color: black,
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold),
                                )),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
        }),
      );
}
