import 'package:carousel_slider/carousel_slider.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../app/consts/colors.dart';
import '../../../app/consts/images.dart';
import '../get/keswan_controller.dart';
import '../widgets/keswan_bobot_widget.dart';
import '../widgets/keswan_health_widget.dart';

class KeswanPage extends GetView<KeswanController> {
  const KeswanPage({Key? key}) : super(key: key);

  static const routeName = '/keswan';

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: green,
        appBar: AppBar(
          backgroundColor: green,
          elevation: 0,
          title: const Text('Keswan Sapi 1'),
        ),
        body: Container(
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(16), topRight: Radius.circular(16)),
            color: Colors.white,
          ),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: CarouselSlider.builder(
                    itemCount: 5,
                    itemBuilder: (context, itemIndex, pageViewIndex) =>
                        ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: FadeInImage.assetNetwork(
                              width: double.infinity,
                              fit: BoxFit.cover,
                              placeholder: logo,
                              image:
                                  'https://sinauternak.com/wp-content/uploads/2020/04/Mengenal-Sapi-Limousin-min.jpg'),
                        ),
                    options: CarouselOptions(
                        onPageChanged: (index, reason) =>
                            controller.changeCarouselImageIndex(index),
                        autoPlay: true,
                        height: 150,
                        enlargeCenterPage: true)),
              ),
              Obx(
                () => DotsIndicator(
                    dotsCount: 5,
                    position: controller.carouselImageIndex,
                    decorator:
                        const DotsDecorator(activeColor: gold, color: greyB)),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: TabBar(
                    indicatorColor: gold,
                    labelColor: black,
                    unselectedLabelColor: grey9B,
                    labelStyle: GoogleFonts.roboto(
                        color: black,
                        fontSize: 14,
                        fontWeight: FontWeight.bold),
                    controller: controller.tabController,
                    tabs: const [
                      Tab(
                        text: 'Bobot',
                      ),
                      Tab(
                        text: 'Kesehatan',
                      )
                    ]),
              ),
              Expanded(
                  child: TabBarView(
                      controller: controller.tabController,
                      children: const [
                    KeswanBobotWidget(),
                    KeswanHealthWidget()
                  ]))
            ],
          ),
        ),
      );
}
