import '../../../data/models/ternak/identity_ternak_model.dart';

class IdentitasDetailParams {
  final IdentityTernakModel ternak;
  final bool isFromForm;
  final bool isFromScan;

  IdentitasDetailParams({
    required this.ternak,
    this.isFromForm = false,
    this.isFromScan = false,
  });
}
