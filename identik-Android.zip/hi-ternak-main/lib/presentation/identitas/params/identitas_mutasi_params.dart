import '../../../data/models/ternak/identity_ternak_model.dart';

class IdentitasMutasiParams {
  final IdentityTernakModel ternak;
  final bool isFromScan;

  IdentitasMutasiParams({
    required this.ternak,
    this.isFromScan = false,
  });
}
