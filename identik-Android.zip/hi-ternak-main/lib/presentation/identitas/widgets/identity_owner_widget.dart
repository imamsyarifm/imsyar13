import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher_string.dart';
import '../../../data/models/ternak/identity_kandang_model.dart';
import '../../../data/models/ternak/identity_kepemilikan_model.dart';
import '../../../utils/datetime_util.dart';

import '../../widgets/component_tile.dart';

class IdentityOwnerWidget extends StatelessWidget {
  const IdentityOwnerWidget({
    Key? key,
    this.isPersonal = false,
    this.owner,
    this.kandang,
  }) : super(key: key);

  final bool isPersonal;
  final IdentityKepemilikanModel? owner;
  final IdentityKandangModel? kandang;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          Visibility(
            visible: isPersonal == false,
            child: ComponentTile(
              title: 'NIB',
              value: owner?.nib ?? '-',
            ),
          ),
          ComponentTile(
            title: 'NIK',
            value: owner?.nikPemilik ?? '-',
          ),
          ComponentTile(
            title: 'Nama',
            value: owner?.nama ?? '-',
          ),
          ComponentTile(
            title: 'Jenis Kelamin',
            value: owner?.gender ?? '-',
          ),
          ComponentTile(
            title: 'Umur',
            value: owner?.umur ?? '-',
          ),
          ComponentTile(
            title: 'Tanggal Lahir',
            value: owner?.birthdate?.readable() ?? DateTime.now().readable(),
          ),
          // TODO: Missing data
          ComponentTile(
            title: 'Tanggal Terdaftar',
            value: DateTime.now().readable(),
          ),
          ComponentTile(title: 'Alamat', value: owner?.alamat ?? '-'),
          ComponentTile(
            title: 'Koordinat',
            value: owner?.koordinat ?? '-',
            trailing: IconButton(
              icon: const Icon(Icons.map),
              onPressed: () => redirectToMap(owner?.koordinat),
            ),
          ),
          ComponentTile(
            title: 'No. Telepon',
            value: owner?.phone ?? '-',
          ),
          ComponentTile(
            title: 'Email',
            value: owner?.email ?? '-',
          ),
          ComponentTile(
            title: 'Tanggal Perolehan',
            value: owner?.tanggalMemilki.readable() ?? '-',
          ),
          Visibility(
            visible: !isPersonal,
            child: ComponentTile(
                title: 'Alamat Unit Usaha',
                value: owner?.alamat ?? '-'),
          ),
          Visibility(
            visible: isPersonal,
            child: ComponentTile(
                title: 'Alamat Kandang',
                value: kandang?.alamat ?? '-'),
          ),
          ComponentTile(
            title: 'Koordinat',
            // TODO: Need fixing
            value: owner?.koordinat ?? '-',
            trailing: IconButton(
              icon: const Icon(Icons.map),
              onPressed: () => redirectToMap(owner?.koordinat),
            ),
          ),
          Visibility(
            visible: isPersonal,
            child: ComponentTile(
              title: 'No. Telepon Pemilik Kandang',
              value: kandang?.phonePemilikKandang ?? '-',
            ),
          ),
          Visibility(
            visible: !isPersonal,
            child: ComponentTile(
              title: 'No. Telepon Unit Usaha',
              value: owner?.phoneUnitUsaha ?? '-',
            ),
          ),
          Visibility(
            visible: isPersonal,
            child: ComponentTile(
              title: 'Email Pemilik Kandang',
              value: kandang?.emailPemilikKandang ?? '-',
            ),
          ),
          Visibility(
            visible: !isPersonal,
            child: ComponentTile(
              title: 'Email Unit Usaha',
              value: owner?.emailUnitUsaha ?? '-',
            ),
          ),
        ],
      ),
    );
  }

  void redirectToMap(String? koordinat) {
    final splitKoordinat = koordinat?.split(',');
    final latitude = splitKoordinat?[0];
    final longitude = splitKoordinat?[1];
    launchUrlString(
        'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude');
  }
}
