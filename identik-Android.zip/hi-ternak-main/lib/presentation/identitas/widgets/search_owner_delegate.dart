import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/owner/owner_model.dart';
import '../../../data/repositories/owner_repository.dart';
import '../../owner/pages/owner_detail_page.dart';

class SearchOwnerDelegate extends SearchDelegate {
  SearchOwnerDelegate({
    this.isForm = true,
    this.isIncludeCompany = true,
  });

  final bool isForm;
  final bool isIncludeCompany;

  final repository = OwnerRepository(
    client: Get.find<Dio>(),
  );

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          query = '';
        },
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () {
        Get.back();
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return FutureBuilder<List<OwnerModel>>(
      future:
          repository.owners(query: query, isIncludeCompany: isIncludeCompany),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          return ListView.builder(
            itemCount: snapshot.data?.length ?? 0,
            itemBuilder: (context, index) {
              final owner = snapshot.data?[index];
              return Container(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: ListTile(
                  title: Text(owner?.name ?? '-',
                      style: GoogleFonts.roboto(fontWeight: FontWeight.bold)),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(owner?.nik ?? '-'),
                      Text(
                          '${owner?.address.province}, '
                          '${owner?.address.district},'
                          '${owner?.address.subDistrict},'
                          '${owner?.address.urbanVillage}',
                          style: GoogleFonts.roboto(color: grey8)),
                    ],
                  ),
                  onTap: () => (isForm)
                      ? Get.back(
                          result: owner,
                        )
                      : Get.toNamed(
                          OwnerDetailPage.routeName,
                          arguments: owner,
                        ),
                ),
              );
            },
          );
        } else {
          return const Center(
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(green),
            ),
          );
        }
      },
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return const Center(
      child: Text('Harap masukan kata kunci'),
    );
  }
}
