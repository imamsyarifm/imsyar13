import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/address/district_model.dart';
import '../../../data/models/address/province_model.dart';
import '../../../data/models/address/subdistrict_model.dart';
import '../../../data/models/address/village_model.dart';
import '../../../data/models/combo/combo_model.dart';
import '../../../utils/validation_util.dart';
import '../../register/widgets/chooseable_widget.dart';
import '../../widgets/edit_text.dart';
import '../get/identitas_controller.dart';
import 'search_owner_delegate.dart';

class FilterTernakWidget extends GetWidget<IdentitasController> {
  static const routeName = '/filter-ternak';
  const FilterTernakWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Filter Ternak'),
        backgroundColor: green,
      ),
      body: Container(
        color: Colors.white,
        padding: const EdgeInsets.all(8),
        child: ListView(
          children: [
            EditText(
              label: 'Pemilik*',
              validator: (value) =>
                  ValidationUtil.emptyValidate('Pemilik', value),
              autoValidateMode: AutovalidateMode.onUserInteraction,
              keyboardType: TextInputType.text,
              textInputAction: TextInputAction.done,
              controller: controller.etOwner,
              isReadOnly: true,
              onTap: () async {
                final context = Get.context;
                if (context != null) {
                  final owner = await showSearch(
                    context: context,
                    delegate: SearchOwnerDelegate(),
                  );
                  controller.setOwner(owner);
                }
              },
            ),
            const SizedBox(height: 16),
            Obx(() {
              if (controller.isLoadingStatusKandang) {
                return const Center(
                  child: CircularProgressIndicator(
                    color: green,
                  ),
                );
              }

              return EditText(
                label: 'Status Kandang',
                keyboardType: TextInputType.text,
                textInputAction: TextInputAction.done,
                suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                isReadOnly: true,
                onTap: () => showModalBottomSheet(
                  context: context,
                  builder: (context) => ChooseableWidget<ComboModel>(
                    values: controller.allStatusKandang,
                    title: (value) => value.label,
                    onSelected: (value) => controller.setStatusKandang(
                        value: value, isInitial: false),
                  ),
                ),
                controller: controller.etStatusKandang,
              );
            }),
            const SizedBox(height: 16),
            EditText(
              label: 'Kandang*',
              validator: (value) =>
                  ValidationUtil.emptyValidate('Kandang', value),
              autoValidateMode: AutovalidateMode.onUserInteraction,
              keyboardType: TextInputType.text,
              textInputAction: TextInputAction.done,
              suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
              isReadOnly: true,
              onTap: () {
                showModalBottomSheet(
                  context: context,
                  builder: (context) => ChooseableWidget<ComboModel>(
                    values: controller.allKandang,
                    title: (value) => value.label,
                    onSelected: (value) =>
                        controller.setKandang(value: value, isInitial: false),
                  ),
                );
              },
              controller: controller.etKandang,
            ),
            const SizedBox(height: 16),
            ...buildAddressTernak(context),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        margin: const EdgeInsets.all(8),
        color: Colors.white,
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: green,
          ),
          onPressed: () => Get.back(),
          child: const Text('Filter'),
        ),
      ),
    );
  }

  List<Widget> buildAddressTernak(BuildContext context) {
    return [
      Obx(() {
        if (controller.isLoadingProvinces) {
          return const Center(
            child: CircularProgressIndicator(
              color: green,
            ),
          );
        } else {
          return EditText(
            controller: controller.etProvinsi,
            validator: (value) =>
                ValidationUtil.emptyValidate('Provinsi', value),
            onTap: () => showModalBottomSheet(
              context: context,
              builder: (context) => ChooseableWidget<ProvinceModel>(
                values: controller.provinces,
                title: (ProvinceModel provinsi) => provinsi.province,
                onSelected: (provinsi) => controller.setProvinsi(
                  value: provinsi,
                ),
              ),
            ),
            isReadOnly: true,
            label: 'Propinsi*',
            suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
          );
        }
      }),
      const SizedBox(height: 14),
      Obx(() {
        if (controller.isLoadingDistricts) {
          return const Center(
            child: CircularProgressIndicator(
              color: green,
            ),
          );
        } else {
          return EditText(
            controller: controller.etKabupaten,
            validator: (value) =>
                ValidationUtil.emptyValidate('Kabupaten', value),
            onTap: () => showModalBottomSheet(
                context: context,
                builder: (context) => ChooseableWidget<DistrictModel>(
                      values: controller.districts,
                      title: (DistrictModel kabupaten) => kabupaten.district,
                      onSelected: (kabupaten) => controller.setKabupaten(
                        value: kabupaten,
                      ),
                    )),
            label: 'Kabupaten / Kota*',
            isReadOnly: true,
            suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
          );
        }
      }),
      const SizedBox(height: 14),
      Obx(() {
        if (controller.isLoadingSubDistricts) {
          return const Center(
            child: CircularProgressIndicator(
              color: green,
            ),
          );
        } else {
          return EditText(
            controller: controller.etKecamatan,
            validator: (value) =>
                ValidationUtil.emptyValidate('Kecamatan', value),
            autoValidateMode: AutovalidateMode.onUserInteraction,
            onTap: () => showModalBottomSheet(
                context: context,
                builder: (context) => ChooseableWidget<SubdistrictModel>(
                      values: controller.subDistricts,
                      title: (SubdistrictModel kecamatan) =>
                          kecamatan.subDistrict,
                      onSelected: (kecamatan) =>
                          controller.setKecamatan(kecamatan),
                    )),
            label: 'Kecamatan*',
            isReadOnly: true,
            suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
          );
        }
      }),
      const SizedBox(height: 14),
      Obx(() {
        if (controller.isLoadingVillages) {
          return const Center(
            child: CircularProgressIndicator(
              color: green,
            ),
          );
        } else {
          return EditText(
            controller: controller.etDesa,
            validator: (value) => ValidationUtil.emptyValidate('Desa', value),
            autoValidateMode: AutovalidateMode.onUserInteraction,
            onTap: () => showModalBottomSheet(
                context: context,
                builder: (context) => ChooseableWidget<VillageModel>(
                      values: controller.villages,
                      title: (VillageModel desa) => desa.urbanVillage,
                      onSelected: (desa) => controller.setDesa(desa),
                    )),
            label: 'Desa*',
            isReadOnly: true,
            suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
          );
        }
      }),
      const SizedBox(height: 26),
    ];
  }
}
