import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:timelines/timelines.dart';

import '../../../app/consts/colors.dart';
import '../get/identitas_detail_controller.dart';

class IdentitasKepemilikanWidget extends GetWidget<IdentitasDetailController> {
  const IdentitasKepemilikanWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Timeline.builder(
          itemBuilder: (context, index) {
            final owner = controller.ternak!.kepemilikan;
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TimelineTile(
                nodeAlign: TimelineNodeAlign.start,
                contents: ListTile(
                  title: Text(
                      controller.date(owner?.tanggalMemilki ?? DateTime.now())),
                  subtitle: Text(owner?.nama ?? '-'),
                ),
                node: const TimelineNode(
                  indicator: DotIndicator(),
                  startConnector: SolidLineConnector(),
                  endConnector: SolidLineConnector(),
                ),
              ),
            );
          },
          itemCount: 1,
          theme: TimelineThemeData(
              connectorTheme: const ConnectorThemeData(color: greyC),
              indicatorTheme: const IndicatorThemeData(size: 16, color: gold)),
        ),
      );
}
