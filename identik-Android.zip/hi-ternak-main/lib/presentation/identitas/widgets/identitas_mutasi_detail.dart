import 'package:extended_image/extended_image.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/ternak/mutasi_identity.dart';
import '../../../utils/datetime_util.dart';
import '../../widgets/default_scaffold.dart';

class IdentitasMutasiDetail extends StatelessWidget {
  const IdentitasMutasiDetail({
    Key? key,
    required this.mutasi,
  }) : super(key: key);

  final MutasiIdentity mutasi;

  @override
  Widget build(BuildContext context) {
    return DefaultScaffold(
      appBarTitle: 'Identitas Mutasi',
      body: Container(
        color: Colors.white,
        child: ListView(
          children: [
            componentTile(
              context,
              'Tanggal',
              mutasi.tanggalMutasi.readable(),
            ),
            componentTile(
              context,
              'Status',
              mutasi.statusMutasi,
            ),
            componentTile(
              context,
              'Nama Petugas',
              mutasi.name,
            ),
            Visibility(
              visible: mutasi.rph != null,
              child: componentTile(
                context,
                'Rumah Potong Hewan',
                mutasi.rph ?? '',
              ),
            ),
            Visibility(
              visible: mutasi.namaPemilikBaru != null,
              child: componentTile(
                context,
                'Nama Pemilik Baru',
                mutasi.namaPemilikBaru ?? '-',
              ),
            ),
            Visibility(
              visible: mutasi.namaPemilikLama != null,
              child: componentTile(
                context,
                'Nama Pemilik Lama',
                mutasi.namaPemilikLama ?? '',
              ),
            ),
            Visibility(
              visible: mutasi.namaKandangBaru != null,
              child: componentTile(
                context,
                'Nama Kandang Baru',
                mutasi.namaKandangBaru ?? '',
              ),
            ),
            Visibility(
              visible: mutasi.namaKandangLama != null,
              child: componentTile(
                context,
                'Nama Kandang Lama',
                mutasi.namaKandangLama ?? '',
              ),
            ),
            componentTile(
              context,
              'Keterangan',
              mutasi.keterangan,
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Foto',
                    style: GoogleFonts.roboto(
                      color: black,
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Center(child: ExtendedImage.network(mutasi.urlImage ?? '')),
                  const Divider(color: greyE5)
                ],
              ),
            ),
            const SizedBox(height: 36),
          ],
        ),
      ),
    );
  }

  Widget componentTile(BuildContext context, String title, String value) =>
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            ListTile(
              contentPadding: const EdgeInsets.all(0),
              title: Text(title,
                  style: GoogleFonts.roboto(
                    color: black,
                    fontSize: 12,
                  )),
              subtitle: Text(value,
                  textAlign: TextAlign.justify,
                  style: GoogleFonts.roboto(
                      color: black, fontWeight: FontWeight.bold, fontSize: 16)),
            ),
            const Divider(color: greyE5, height: 0)
          ],
        ),
      );
}
