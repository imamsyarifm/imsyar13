import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../widgets/component_tile.dart';
import '../get/identitas_biodata_controller.dart';

class IdentitasPertumbuhanWidget extends GetWidget<IdentitasBiodataController> {
  const IdentitasPertumbuhanWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final biodata = controller.ternak;
    return Scaffold(
      body: ListView(children: [
        ComponentTile(title: 'Berat Badan (kg)', value: biodata
          .pertumbuhan?.last.beratBadan ?? '-'),
        ComponentTile(title: 'Panjang Badan (cm)', value: biodata
          .pertumbuhan?.last.panjangBadan ?? '-'),
        ComponentTile(title: 'Tinggi Badan (cm)', value: biodata
          .pertumbuhan?.last.tinggiBadan ?? '-'),
        ComponentTile(title: 'Tinggi Pinggul (cm)', 
          value: biodata.pertumbuhan?.last.tinggiPinggul ?? '-'),
        ComponentTile(title: 'Lebar Pinggul (cm)', 
          value: biodata.pertumbuhan?.last.lebarPinggul ?? '-'),
        ComponentTile(title: 'Lingkar Data (cm)', 
          value: biodata.pertumbuhan?.last.lingkarDada ?? '-'),
        ComponentTile(title: 'Lingkar Skrotum (cm)', 
          value: biodata.pertumbuhan?.last.lingkarSkrotum ?? '-'),
        ComponentTile(title: 'Berat Badan Induk', 
          value: biodata.pertumbuhan?.last.beratBadanInduk ?? '-'),
        const SizedBox(height: 100)
      ]),
    );
  }
}
