import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../../../data/repositories/ternak_repository.dart';
import '../pages/identitas_detail_page.dart';
import '../params/identitas_detail_params.dart';

class TernakSearchDelegate extends SearchDelegate {
  final repository = TernakRepository(
    client: Get.find<Dio>(),
  );

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          query = '';
        },
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return null;
  }

  @override
  Widget buildResults(BuildContext context) {
    return FutureBuilder<List<IdentityTernakModel>>(
      future: repository.allTernak(query: query),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          return ListView.builder(
            itemCount: snapshot.data?.length ?? 0,
            itemBuilder: (context, index) {
              final ternak = snapshot.data?[index];
              return Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 8),
                child: GestureDetector(
                  onTap: () async {
                    if (ternak != null) {
                      Get.toNamed(
                        IdentitasDetailPage.routeName,
                        arguments: IdentitasDetailParams(ternak: ternak),
                      );
                    }
                  },
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Text('${index + 1}'),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(ternak?.idEartag ?? '-'),
                                  Text(ternak?.kepemilikan?.nama ?? '-'),
                                ],
                              ),
                            ),
                          ),
                          const Icon(Icons.arrow_right),
                        ],
                      ),
                      const Divider(color: greyE5),
                    ],
                  ),
                ),
              );
            },
          );
        } else {
          return const Center(
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(green),
            ),
          );
        }
      },
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return const Center(
      child: Text('Harap masukan kata kunci'),
    );
  }
}
