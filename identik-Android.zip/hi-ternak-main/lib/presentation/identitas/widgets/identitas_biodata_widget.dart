import 'package:extended_image/extended_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../app/consts/colors.dart';
import '../../../app/consts/icons.dart';
import '../../../data/models/ternak/identity_alamat_lahir_ternak.dart';
import '../../../utils/datetime_util.dart';
import '../../../utils/validation_util.dart';
import '../../widgets/component_tile.dart';
import '../get/identitas_biodata_controller.dart';
import '../pages/identitas_biodata_edit_page.dart';

class IdentitasBiodataWidget extends GetWidget<IdentitasBiodataController> {
  const IdentitasBiodataWidget({
    Key? key,
    this.isFromForm = false,
  }) : super(key: key);

  final bool isFromForm;

  @override
  Widget build(BuildContext context) {
    final biodata = controller.ternak;
    return Scaffold(
      body: ListView(children: [
        ExtendedImage.network(
          biodata.urlImage ?? '-',
          height: 150,
          fit: BoxFit.cover,
        ),
        // ComponentTile(title: 'ID Eartag', value: biodata.idEartag ?? '-'),
        // const ComponentTile(title: 'Kategori Ternak', value: '-'),
        // ComponentTile(title: 'Asal Ternak', value: biodata.asalTernak
        //  ?? '-'),
        ComponentTile(title: 'ID Isikhnas', value: biodata.idIsikhnas ?? '-'),
        ComponentTile(title: 'Nama Ternak', value: biodata.name ?? '-'),
        ComponentTile(title: 'Jenis Ternak', value: biodata.jenisTernak ?? '-'),
        ComponentTile(title: 'Rumpun', value: biodata.rumpun ?? '-'),
        ComponentTile(
            title: 'Jenis Kelamin', value: biodata.jenisKelamin ?? '-'),
        ComponentTile(
            title: 'Tanggal Lahir Ternak',
            value: biodata.tanggalLahirTernak?.readable() ?? '-'),
        ComponentTile(title: 'Umur Ternak', value: biodata.umur ?? '-'),
        ComponentTile(
            title: 'Tanggal Terdaftar',
            value: biodata.createdAt?.readable() ?? '-'),
        ComponentTile(
            title: 'Tanggal Perolehan',
            value: biodata.tanggalPerolehan?.readable() ?? '-'),
        ComponentTile(
            title: 'Tempat Lahir Ternak',
            value: (biodata.alamatLahirTernak.isNotEmpty)
                ? alamatLahirTernak(biodata.alamatLahirTernak.first)
                : '-'),
        ComponentTile(
          title: 'Koordinat',
          value: controller.koordinatLahirTernak,
          trailing: IconButton(
            icon: const Icon(Icons.map),
            onPressed: () => controller.redirectToMap(),
          ),
        ),
        Visibility(
          visible: biodata.pertumbuhan?.isNotEmpty == true,
          replacement: const SizedBox.shrink(),
          child: ComponentTile(
              title: 'Bobot Awal (kg)',
              value: biodata.pertumbuhan?.first.beratBadan ?? '-'),
        ),
        Visibility(
          visible: biodata.pertumbuhan?.isNotEmpty == true,
          replacement: const SizedBox.shrink(),
          child: ComponentTile(
              title: 'Panjang Badan (cm)',
              value: biodata.pertumbuhan?.first.panjangBadan ?? '-'),
        ),
        Visibility(
          visible: biodata.pertumbuhan?.isNotEmpty == true,
          replacement: const SizedBox.shrink(),
          child: ComponentTile(
              title: 'Tinggi Pundak (cm)',
              value: biodata.pertumbuhan?.first.tinggiBadan ?? '-'),
        ),

        ComponentTile(title: 'Program', value: biodata.programName ?? '-'),
        // ComponentTile(title: 'ID Pejantan', value: biodata.idPenjantan
        //  ?? '-'),
        // ComponentTile(title: 'Rumpun Pejantan',
        //   value: biodata.rumpunPejantan ?? '-'),
        // ComponentTile(title: 'Tempat Lahir Ternak',
        //   value: biodata.tempatLahirTernak ?? '-'),
        // ComponentTile(title: 'Penentuan Tanggal Lahir',
        //   value: biodata.penentuanTanggalLahir ?? '-'),
        // ComponentTile(title: 'ID Induk', value: biodata.idInduk ?? '-'),
        // ComponentTile(title: 'Rumpun Induk', value: biodata.rumpunInduk
        //  ?? '-'),
        // ComponentTile(title: 'Bertanduk', value: biodata.bertanduk ?? '-'),
        // ComponentTile(title: 'Warna Kulit', value: biodata.warnaKulit
        //  ?? '-'),
        // ComponentTile(title: 'Dominan Warna',
        //   value: biodata.warnaDominan ?? '-'),
        // ComponentTile(title: 'Metode Perkawinan',
        //   value: biodata.metodePerkawinan ?? '-'),
        // ComponentTile(title: 'Tipe Kelahiran',
        //   value: biodata.tipeKelahiran ?? '-'),
        ComponentTile(
            title: 'Kandang',
            value: (biodata.kandang?.isNotEmpty == true)
                ? biodata.kandang?.first.namaKandang ?? '-'
                : '-'),
        ComponentTile(
            title: 'No. Telepon Pemilik Kandang',
            value: biodata.kepemilikan?.phone ?? '-'),
        ComponentTile(
            title: 'Email Pemilik Kandang',
            value: biodata.kepemilikan?.email ?? '-'),
        ComponentTile(
            title: 'Status Kandang',
            value: (biodata.kandang?.isNotEmpty == true)
                ? biodata.kandang?.first.statusKandang ?? '-'
                : '-'),
        const SizedBox(height: 100)
      ]),
      floatingActionButton: Visibility(
        visible: !isFromForm && !ValidationUtil.isExpiredTernak(biodata),
        child: FloatingActionButton(
          backgroundColor: yellowDark,
          onPressed: () => Get.toNamed(IdentitasBiodataEditPage.routeName,
              arguments: controller.ternak),
          child: Image.asset(pencil, width: 16, height: 16),
        ),
      ),
    );
  }

  String alamatLahirTernak(AlamatLahirTernak alamat) {
    return '${alamat.urbanVillage} RT ${alamat.rt} RW ${alamat.rw}, '
        '${alamat.subDistrict}, ${alamat.district}, ${alamat.province}';
  }
}
