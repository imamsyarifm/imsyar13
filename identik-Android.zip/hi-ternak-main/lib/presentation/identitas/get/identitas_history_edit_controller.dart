import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_connect/http/src/status/http_status.dart';
import 'package:intl/intl.dart';

import '../../../data/models/ternak/identity_ternak_history_model.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../../../data/models/ternak/update_history_ternak_request_model.dart';
import '../../../data/repositories/ternak_repository.dart';

class IdentitasHistoryEditController extends GetxController {
  final TernakRepository _ternakRepository;

  IdentitasHistoryEditController({
    required TernakRepository ternakRepository,
  }) : _ternakRepository = ternakRepository;

  final formKey = GlobalKey<FormState>();
  final etDate = TextEditingController();
  final etHistoryTernak = TextEditingController();

  final _selectedDate = DateTime.now().obs;

  DateTime get selectedDate => _selectedDate.value;

  late IdentityTernakModel ternak;

  @override
  void onReady() {
    super.onReady();
    retrieveArgs();
  }

  void retrieveArgs() {
    final args = Get.arguments;
    if (args is IdentityTernakModel) {
      ternak = args;
    }
  }

  void setDate(DateTime dateTime) {
    _selectedDate.value = dateTime;
    etDate.text = date(dateTime);
  }

  String date(DateTime dateTime) {
    final dateFormat = DateFormat('dd MMMM yyyy');
    return dateFormat.format(dateTime);
  }

  void updateHistory() async {
    final request = UpdateHistoryTernakRequest(
      idProduct: ternak.id ?? '-',
      tanggalInput: _selectedDate.value,
      history: etHistoryTernak.text,
    );
    final model = await _ternakRepository.updateHistory(request);
    if (model.code == HttpStatus.ok) {
      final history = IdentityTernakHistoryModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        idProduct: ternak.id ?? '-',
        tanggalInput: _selectedDate.value,
        history: etHistoryTernak.text,
        kepemilikan: null,
      );
      Get.back(result: history);
    }
  }
}
