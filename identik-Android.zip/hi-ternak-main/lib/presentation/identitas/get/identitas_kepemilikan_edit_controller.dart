import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_connect/http/src/status/http_status.dart';

import '../../../data/models/combo/combo_model.dart';
import '../../../data/models/ternak/identity_ternak_history_model.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../../../data/models/ternak/update_ownership_request_model.dart';
import '../../../data/repositories/ternak_repository.dart';

class IdentitasKepemilikanEditController extends GetxController {
  final TernakRepository _ternakRepository;

  IdentitasKepemilikanEditController({
    required TernakRepository ternakRepository,
  }) : _ternakRepository = ternakRepository;

  final etKepemilikan = TextEditingController();

  final _selectedKepemilikan = Rx<ComboModel?>(null);

  ComboModel? get selectedKepemilikan => _selectedKepemilikan.value;

  late IdentityTernakModel ternak;

  @override
  void onReady() {
    super.onReady();
    retrieveArgs();
  }

  void retrieveArgs() {
    final args = Get.arguments;
    if (args is IdentityTernakModel) {
      ternak = args;
    }
  }

  void setKepemilikan(ComboModel value) {
    _selectedKepemilikan.value = value;
    etKepemilikan.text = value.label;
    Get.back();
  }

  void updateOwnership() async {
    final request = UpdateOwnershipRequestModel(
      idProduct: ternak.codeProduct ?? '-',
      kepemilikan: etKepemilikan.text,
    );
    final model = await _ternakRepository.updateOwnership(request);
    if (model.code == HttpStatus.ok) {
      final history = IdentityTernakHistoryModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        idProduct: ternak.id ?? '-',
        tanggalInput: DateTime.now(),
        history: null,
        kepemilikan: etKepemilikan.text,
      );
      Get.back(result: history);
    }
  }
}
