import 'package:get/get.dart';

import 'identitas_mutasi_controller.dart';

class IdentitasMutasiBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(IdentitasMutasiController());
  }
}
