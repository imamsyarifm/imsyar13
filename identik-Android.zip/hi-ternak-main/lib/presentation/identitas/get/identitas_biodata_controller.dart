import 'package:get/get.dart';
import 'package:url_launcher/url_launcher_string.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../params/identitas_detail_params.dart';

class IdentitasBiodataController extends GetxController {
  late IdentityTernakModel ternak;
  late bool isFromForm;

  @override
  void onInit() {
    super.onInit();
    retrieveArgs;
  }

  void get retrieveArgs {
    final args = Get.arguments;
    if (args is IdentitasDetailParams) {
      ternak = args.ternak;
      isFromForm = args.isFromForm;
    }
  }

  String get koordinatLahirTernak {
    if (ternak.alamatLahirTernak.isEmpty) return '-';
    return '${ternak.alamatLahirTernak.first.latitude},'
        '${ternak.alamatLahirTernak.first.longitude}';
  }

  void redirectToMap() {
    if (ternak.alamatLahirTernak.isEmpty) {
      Get.showSnackbar(const GetSnackBar(
        message: 'Koordinat lahir ternak belum diatur, harap ubah informasi'
            ' koordinat terlebih dahulu',
        duration: Duration(seconds: 3),
      ));
      return;
    }
    final latitude = ternak.alamatLahirTernak.first.latitude;
    final longitude = ternak.alamatLahirTernak.first.longitude;
    launchUrlString(
        'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude');
  }
}
