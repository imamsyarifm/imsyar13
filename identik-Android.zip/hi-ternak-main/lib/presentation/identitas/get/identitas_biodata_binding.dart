import 'package:get/get.dart';
import 'identitas_biodata_controller.dart';

class IdentitasBiodataBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(IdentitasBiodataController());
  }
}
