import 'package:get/get.dart';

import '../params/identitas_mutasi_params.dart';

class IdentitasMutasiController extends GetxController {
  late IdentitasMutasiParams params;

  @override
  void onInit() {
    retrieveArgs();
    super.onInit();
  }

  void retrieveArgs() {
    final args = Get.arguments;
    if (args is IdentitasMutasiParams) {
      params = args;
    }
  }
}
