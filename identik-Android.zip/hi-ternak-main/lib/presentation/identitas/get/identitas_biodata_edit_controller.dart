// import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' hide FormData, MultipartFile;
import 'package:get/get_connect/http/src/status/http_status.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

import '../../../data/models/address/country_model.dart';
import '../../../data/models/address/district_model.dart';
import '../../../data/models/address/province_model.dart';
import '../../../data/models/address/subdistrict_model.dart';
import '../../../data/models/address/village_model.dart';
import '../../../data/models/combo/combo_model.dart';
import '../../../data/models/combo/rumpun_model.dart';
import '../../../data/models/distribution_area/distribution_area_model.dart';
import '../../../data/models/owner/owner_model.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../../../data/models/ternak/ternak_birthday_request.dart';
import '../../../data/models/ternak/ternak_request.dart';
import '../../../data/repositories/address_repository.dart';
import '../../../data/repositories/combo_repository.dart';
import '../../../data/repositories/keswan_repository.dart';
import '../../../data/repositories/owner_repository.dart';
import '../../../data/repositories/setting_repository.dart';
import '../../../data/repositories/ternak_repository.dart';
import '../../../utils/datetime_util.dart';
import '../../../utils/location_util.dart';
import '../../../utils/networking_util.dart';
// import '../../../utils/validation_util.dart';
import '../../main/main_page.dart';
import '../../scan/offline_scan_params.dart';
import '../../vaccine_ternak/pages/vaccine_ternak_page.dart';

class IdentitasBiodataEditController extends GetxController {
  final AddressRepository _addressRepository;
  final ComboRepository _comboRepository;
  final TernakRepository _ternakRepository;
  final SettingRepository _settingRepository;
  final OwnerRepository _ownerRepository;

  IdentitasBiodataEditController({
    required AddressRepository addressRepository,
    required ComboRepository comboRepository,
    required TernakRepository ternakRepository,
    required SettingRepository settingRepository,
    required OwnerRepository ownerRepository,
    required KeswanRepository keswanRepository,
  })  : _addressRepository = addressRepository,
        _comboRepository = comboRepository,
        _ternakRepository = ternakRepository,
        _settingRepository = settingRepository,
        _ownerRepository = ownerRepository;

  final formKey = GlobalKey<FormState>();
  final etQrCode = TextEditingController();
  final etNamaTernak = TextEditingController();
  final etRumpun = TextEditingController();
  final etGender = TextEditingController();
  final etBirthday = TextEditingController();
  final etVaccineDate = TextEditingController();
  final etVaccineMerk = TextEditingController();
  final etProgram = TextEditingController();
  final etProvinsi = TextEditingController();
  final etKabupaten = TextEditingController();
  final etWorkArea = TextEditingController();
  final etKecamatan = TextEditingController();
  final etDesa = TextEditingController();
  final etAlamat = TextEditingController();
  final etRt = TextEditingController();
  final etRw = TextEditingController();
  final etOwner = TextEditingController();
  final etStatusKandang = TextEditingController();
  final etKandang = TextEditingController();
  final etCiriKhas = TextEditingController();
  final etMutuBibit = TextEditingController();
  final etTanggalPerolehan = TextEditingController();
  final etAsalTernak = TextEditingController();
  final etAsalTernakLokasi = TextEditingController();
  final etBeratBadan = TextEditingController();
  final etBatch = TextEditingController();
  final etPanjangBadan = TextEditingController();
  final etTinggiBadan = TextEditingController();
  final etIdIsikhnas = TextEditingController();
  final etCategory = TextEditingController();
  final imagePicker = ImagePicker();

  final _selectedGender = Rx<ComboModel?>(null);
  final _selectedProgram = Rx<ComboModel?>(null);
  final _selectedRumpun = Rx<RumpunModel?>(null);
  final _selectedKandang = Rx<ComboModel?>(null);
  final _selectedOwner = Rx<OwnerModel?>(null);
  final _selectedBirthday = Rx<DateTime?>(null);
  final _selectedTanggalPerolehan = Rx<DateTime>(DateTime.now());
  final _selectedVaccineDate = Rx<DateTime>(DateTime.now());
  final _selectedPhoto = Rx<XFile?>(null);
  final _selectedStatusKandang = Rx<ComboModel?>(null);
  final _selectedAsalTernak = Rx<ComboModel?>(null);
  final _selectedAsalTernakLokasi = Rx<CountryModel?>(null);

  final _genders = Rx<List<ComboModel>>([]);
  final _allObat = Rx<List<ComboModel>>([]);
  final _isLoadingGenders = false.obs;
  final _programs = Rx<List<ComboModel>>([]);
  final _isLoadingPrograms = false.obs;
  final _areas = Rx<List<DistributionAreaModel>>([]);
  final _isLoadingAreas = false.obs;
  final _rumpun = Rx<List<RumpunModel>>([]);
  final _isLoadingRumpun = false.obs;
  final _isLoadingAsalTernak = false.obs;
  final _allKandang = Rx<List<ComboModel>>([]);
  final _allAsalTernak = Rx<List<ComboModel>>([]);
  final _isLoadingKandang = false.obs;
  final _taniGroups = Rx<List<ComboModel>>([]);
  final _isLoadingTaniGroups = false.obs;
  final _allStatusKandang = Rx<List<ComboModel>>([]);
  final _isLoadingStatusKandang = false.obs;
  final _allCountry = Rx<List<CountryModel>>([]);
  final _isLoadingCountry = false.obs;
  final _isUpdateTernak = false.obs;
  final _ternak = Rx<IdentityTernakModel?>(null);
  final _updatingTernak = false.obs;
  final _selectedProvinsi = Rx<ProvinceModel?>(null);
  final _selectedKabupaten = Rx<DistrictModel?>(null);
  final _selectedKecamatan = Rx<SubdistrictModel?>(null);
  final _selectedDesa = Rx<VillageModel?>(null);
  final _selectedIsCompany = false.obs;
  final _selectedIsVacination = true.obs;
  final _selectedObat = Rx<ComboModel?>(null);
  final _selectedCategory = Rx<ComboModel?>(null);
  final _provinces = Rx<List<ProvinceModel>>([]);
  final _districts = Rx<List<DistrictModel>>([]);
  final _subDistricts = Rx<List<SubdistrictModel>>([]);
  final _villages = Rx<List<VillageModel>>([]);
  final _categories = Rx<List<ComboModel>>([]);
  final _isLoadingProvinces = false.obs;
  final _isLoadingDistricts = false.obs;
  final _isLoadingSubDistricts = false.obs;
  final _isLoadingVillages = false.obs;
  final _isLoadingCategories = false.obs;
  final _isSameWithKandang = false.obs;
  final _scanResult = Rx<String?>(null);
  final latitude = 0.0.obs;
  final longitude = 0.0.obs;

  ComboModel? get selectedGender => _selectedGender.value;
  ComboModel? get selectedProgram => _selectedProgram.value;
  ComboModel? get selectedRumpun => _selectedRumpun.value;
  ComboModel? get selectedKandang => _selectedKandang.value;
  ComboModel? get selectedStatusKandang => _selectedStatusKandang.value;
  ComboModel? get selectedAsalTernak => _selectedAsalTernak.value;
  OwnerModel? get selectedOwner => _selectedOwner.value;
  CountryModel? get selectedAsalTernakLokasi => _selectedAsalTernakLokasi.value;
  DateTime? get selectedBirthday => _selectedBirthday.value;
  DateTime get selectedTanggalPerolehan => _selectedTanggalPerolehan.value;
  DateTime get selectedVaccineDate => _selectedVaccineDate.value;
  ComboModel? get selectedCategory => _selectedCategory.value;
  bool get isUpdateTernak => _isUpdateTernak.value;
  List<ComboModel> get genders => _genders.value;
  List<ComboModel> get allObat => _allObat.value;
  bool get isLoadingGenders => _isLoadingGenders.value;
  List<ComboModel> get programs => _programs.value;
  bool get isLoadingPrograms => _isLoadingPrograms.value;
  List<DistributionAreaModel> get areas => _areas.value;
  bool get isLoadingAreas => _isLoadingAreas.value;
  List<RumpunModel> get rumpun => _rumpun.value;
  bool get isLoadingRumpun => _isLoadingRumpun.value;
  List<ComboModel> get allKandang => _allKandang.value;
  List<ComboModel> get allAsalTernak => _allAsalTernak.value;
  bool get isLoadingKandang => _isLoadingKandang.value;
  List<ComboModel> get taniGroups => _taniGroups.value;
  bool get isLoadingTaniGroups => _isLoadingTaniGroups.value;
  List<ComboModel> get allStatusKandang => _allStatusKandang.value;
  bool get isLoadingCountry => _isLoadingCountry.value;
  List<CountryModel> get allCountry => _allCountry.value;
  bool get isLoadingStatusKandang => _isLoadingStatusKandang.value;
  bool get isLoadingAsalTernak => _isLoadingAsalTernak.value;
  IdentityTernakModel? get ternak => _ternak.value;
  XFile? get selectedPhoto => _selectedPhoto.value;
  bool get updatingTernak => _updatingTernak.value;
  ProvinceModel? get selectedProvinsi => _selectedProvinsi.value;
  DistrictModel? get selectedKabupaten => _selectedKabupaten.value;
  SubdistrictModel? get selectedKecamatan => _selectedKecamatan.value;
  VillageModel? get selectedDesa => _selectedDesa.value;
  bool get selectedIsCompany => _selectedIsCompany.value;
  bool get selectedIsVacination => _selectedIsVacination.value;
  bool get isLoadingProvinces => _isLoadingProvinces.value;
  bool get isLoadingDistricts => _isLoadingDistricts.value;
  bool get isLoadingSubDistricts => _isLoadingSubDistricts.value;
  bool get isLoadingVillages => _isLoadingVillages.value;
  bool get isLoadingCategories => _isLoadingCategories.value;
  bool get isSameWithKandang => _isSameWithKandang.value;
  List<ProvinceModel> get provinces => _provinces.value;
  List<DistrictModel> get districts => _districts.value;
  List<SubdistrictModel> get subDistricts => _subDistricts.value;
  List<VillageModel> get villages => _villages.value;
  List<ComboModel> get categories => _categories.value;
  String? get scanResult => _scanResult.value;

  @override
  void onInit() {
    retrieveArgs();
    super.onInit();
  }

  @override
  Future<void> onReady() async {
    super.onReady();
    getCurrentLocation();
    await retrieveObat;
    await retrieveGenders;
    await retrieveCategories;
    await retrievePrograms;
    await retrieveStatusKandang;
    await retrieveAsalTernak;
    await retrieveCountry;

    /// Indonesian id is 1
    await retrieveProvinces(1);

    final args = Get.arguments;
    if ((args is String) || (args is OfflineScanParams)) {
      await initialCreateData();
    } else {
      await initialValue();
    }
  }

  void setPhoto(XFile? file) {
    _selectedPhoto.value = file;
    Get.back();
  }

  Future<void> retrieveArgs() async {
    final args = Get.arguments;
    if (args is String) {
      _isUpdateTernak.value = false;
      etQrCode.text = args;
    } else if (args is OfflineScanParams) {
      _isUpdateTernak.value = false;
      etQrCode.text = args.id.toString();
      _scanResult.value = args.scanResult;
    } else if (args is IdentityTernakModel) {
      _isUpdateTernak.value = true;
      _ternak.value = args;
      etQrCode.text = args.codeProduct ?? '-';
      etBirthday.text = dateString(args.tanggalLahirTernak ?? DateTime.now());
      _selectedBirthday.value = args.tanggalLahirTernak ?? DateTime.now();
      if (args.pertumbuhan?.isNotEmpty == true) {
        etPanjangBadan.text = args.pertumbuhan?.first.panjangBadan ?? '-';
        etTinggiBadan.text = args.pertumbuhan?.first.tinggiBadan ?? '-';
      }
    }
  }

  Future<void> initialCreateData() async {
    _selectedCategory.value = _categories.value.first;
    etCategory.text = _selectedCategory.value?.label ?? '';
    if (_selectedCategory.value != null) {
      await setCategory(value: _selectedCategory.value!);
    }

    _selectedRumpun.value = _rumpun.value.first;
    etRumpun.text = _selectedRumpun.value?.label ?? '';

    _selectedGender.value = _genders.value.first;
    etGender.text = _selectedGender.value?.label ?? '';

    _selectedBirthday.value = DateTime.now();
    etBirthday.text = _selectedBirthday.value?.readable() ?? '';

    _selectedProgram.value = _programs.value.first;
    etProgram.text = _selectedProgram.value?.label ?? '';

    final defaultProvince = await _settingRepository.defaultProvince;
    final searchProvince =
        _provinces.value.where((element) => element.id == defaultProvince);
    if (searchProvince.isNotEmpty) {
      await setProvinsi(
        searchProvince.first,
      );
    }

    final defaultDistrict = await _settingRepository.defaultDistrict;
    final searchDistrict =
        _districts.value.where((element) => element.id == defaultDistrict);
    if (searchDistrict.isNotEmpty) {
      await setKabupaten(searchDistrict.first);
    }

    _selectedStatusKandang.value = _allStatusKandang.value.first;
    etStatusKandang.text = _selectedStatusKandang.value?.label ?? '';

    _selectedAsalTernak.value = _allAsalTernak.value.first;
    etAsalTernak.text = _selectedAsalTernak.value?.label ?? '';

    _selectedTanggalPerolehan.value = DateTime.now();
    etTanggalPerolehan.text = DateTime.now().readable();

    _selectedVaccineDate.value = DateTime.now();
    etVaccineDate.text = DateTime.now().readable();
  }

  Future<void> initialValue() async {
    final searchGender = genders
        .where((element) => element.value == _ternak.value?.jenisKelamin);
    if (searchGender.isNotEmpty) setGender(value: searchGender.first);

    final searchCategory = _categories.value
        .where((element) => element.label == _ternak.value?.jenisTernak);
    if (searchCategory.isNotEmpty) {
      await setCategory(value: searchCategory.first);
    }

    final searchProgram =
        programs.where((element) => element.value == _ternak.value?.program);
    if (searchProgram.isNotEmpty) setProgram(value: searchProgram.first);

    final searchRumpun =
        rumpun.where((element) => element.value == _ternak.value?.idRumpun);
    if (searchRumpun.isNotEmpty) setRumpun(value: searchRumpun.first);

    final searchStatusKandang = allStatusKandang.where((element) =>
        element.value == _ternak.value?.kandang?.first.statusKandang);
    if (searchStatusKandang.isNotEmpty) {
      await setStatusKandang(value: searchStatusKandang.first);
    }

    if (ternak?.alamatLahirTernak.isNotEmpty == true) {
      final searchProvince = _provinces.value.where((element) =>
          element.id == ternak?.alamatLahirTernak.first.idProvince);
      if (searchProvince.isNotEmpty) {
        _selectedProvinsi.value = searchProvince.first;
        etProvinsi.text = _selectedProvinsi.value?.province ?? '-';
        await retrieveDistricts(_selectedProvinsi.value!.id);
      }

      final searchDistrict = _districts.value.where((element) =>
          element.id == ternak?.alamatLahirTernak.first.idDistrict);
      if (searchDistrict.isNotEmpty) {
        _selectedKabupaten.value = searchDistrict.first;
        etKabupaten.text = _selectedKabupaten.value?.district ?? '-';
        await retrieveSubDistricts(_selectedKabupaten.value!.id);
      }

      final searchSubDistrict = _subDistricts.value.where((element) =>
          element.id == ternak?.alamatLahirTernak.first.idSubDistrict);
      if (searchSubDistrict.isNotEmpty) {
        _selectedKecamatan.value = searchSubDistrict.first;
        etKecamatan.text = _selectedKecamatan.value?.subDistrict ?? '-';
        await retrieveVillages(_selectedKecamatan.value!.id);
      }

      final searchVillage = _villages.value.where(
          (element) => element.id == ternak?.alamatLahirTernak.first.idVillage);
      if (searchVillage.isNotEmpty) {
        _selectedDesa.value = searchVillage.first;
        etDesa.text = _selectedDesa.value?.urbanVillage ?? '-';
      }

      final searchAsalTernak = _allAsalTernak.value
          .where((element) => element.value == ternak?.asalTernak);
      if (searchAsalTernak.isNotEmpty) {
        _selectedAsalTernak.value = searchAsalTernak.first;
        etAsalTernak.text = _selectedAsalTernak.value?.label ?? '-';
      }

      final searchOwner =
          await retrieveOwners(_ternak.value?.kepemilikan?.nikPemilik ?? '');
      if (searchOwner != null) {
        await setOwner(searchOwner);
      }

      etNamaTernak.text = ternak?.name ?? '';
      etIdIsikhnas.text = ternak?.idIsikhnas ?? '';
      etAlamat.text = ternak?.alamatLahirTernak.first.address ?? '-';
      etRt.text = ternak?.alamatLahirTernak.first.rt ?? '-';
      etRw.text = ternak?.alamatLahirTernak.first.rw ?? '-';
      etCiriKhas.text = ternak?.ciriKhas ?? '-';
      etMutuBibit.text = ternak?.mutuBibit ?? '-';
      etBeratBadan.text = ternak?.profilePertumbuhanAkhir?.beratBadan ?? '-';
      etPanjangBadan.text =
          ternak?.profilePertumbuhanAkhir?.panjangBadan ?? '-';
      etTinggiBadan.text = ternak?.profilePertumbuhanAkhir?.tinggiBadan ?? '-';
      etTanggalPerolehan.text = ternak?.tanggalPerolehan?.readable() ?? '';
      if (_selectedAsalTernak.value?.label == 'Import') {
        final searchAsalTernak = _allAsalTernak.value
            .where((element) => element.label == ternak?.asalTernak);
        if (searchAsalTernak.isNotEmpty) {
          setAsalTernak(
            value: searchAsalTernak.first,
          );
        }
      }
      latitude.value =
          (ternak?.alamatLahirTernak.first.latitude.isNotEmpty == true)
              ? double.parse(ternak?.alamatLahirTernak.first.latitude ?? '0')
              : 0;
      longitude.value =
          (ternak?.alamatLahirTernak.first.longitude.isNotEmpty == true)
              ? double.parse(ternak?.alamatLahirTernak.first.longitude ?? '0')
              : 0;
      final searchKandang = allKandang.where(
          (element) => element.value == _ternak.value?.kandang?.last.idKandang);
      if (searchKandang.isNotEmpty) setKandang(value: searchKandang.first);
    }
  }

  void setGender({
    required ComboModel value,
    bool isInitial = true,
  }) {
    _selectedGender.value = value;
    etGender.text = value.label;
    if (!isInitial) Get.back();
  }

  void setProgram({
    required ComboModel value,
    bool isInitial = true,
  }) {
    _selectedProgram.value = value;
    etProgram.text = value.label;
    if (!isInitial) Get.back();
  }

  void setRumpun({
    RumpunModel? value,
    bool isInitial = true,
  }) {
    _selectedRumpun.value = value;
    etRumpun.text = value?.label ?? '';
    if (!isInitial) Get.back();
  }

  void setKandang({
    required ComboModel value,
  }) {
    _selectedKandang.value = value;
    etKandang.text = value.label;
  }

  void resetKandang() {
    _selectedKandang.value = null;
    etKandang.clear();
  }

  void setAsalTernak({
    required ComboModel value,
    bool isInitial = true,
  }) {
    _selectedAsalTernak.value = value;
    etAsalTernak.text = value.label;
    if (!isInitial) Get.back();
  }

  Future<void> setStatusKandang({
    required ComboModel value,
    bool isInitial = true,
  }) async {
    _selectedStatusKandang.value = value;
    etStatusKandang.text = value.label;
    if (!isInitial) Get.back();

    resetKandang();

    await retrieveKandang(
        statusKandang: value.value,
        nik: _ternak.value?.kepemilikan?.nikPemilik ??
            _ternak.value?.kepemilikan?.nib ??
            _selectedOwner.value?.nik ??
            '-');
  }

  void setIsCompany(bool? value) {
    _selectedIsCompany.value = value ?? false;
  }

  void setIsVaciation(bool? value) {
    _selectedIsVacination.value = value ?? false;
  }

  Future<void> get retrieveGenders async {
    _isLoadingGenders.value = true;
    _genders.value = await _comboRepository.genders;
    _isLoadingGenders.value = false;
  }

  Future<void> get retrievePrograms async {
    _isLoadingPrograms.value = true;
    _programs.value = await _comboRepository.programs;
    _isLoadingPrograms.value = false;
  }

  Future<void> get retrieveDistributionAreas async {
    _isLoadingAreas.value = true;
    _areas.value = await _ternakRepository.areas;
    _isLoadingAreas.value = false;
  }

  Future<void> get retrieveTaniGroups async {
    _isLoadingTaniGroups.value = true;
    _taniGroups.value = await _ternakRepository.taniGroups;
    _isLoadingTaniGroups.value = false;
  }

  Future<void> retrieveRumpun(ComboModel combo) async {
    setRumpun(value: null, isInitial: true);
    _isLoadingRumpun.value = true;
    _rumpun.value = await _comboRepository.rumpun(category: combo.value);
    _isLoadingRumpun.value = false;
  }

  Future<void> get retrieveStatusKandang async {
    _isLoadingStatusKandang.value = true;
    _allStatusKandang.value = await _comboRepository.statusKandang;
    _isLoadingStatusKandang.value = false;
  }

  Future<void> retrieveKandang({
    required String statusKandang,
    required String nik,
  }) async {
    _isLoadingKandang.value = true;
    _allKandang.value = await _comboRepository.kandang(
      statusKandang: statusKandang,
      nik: nik,
    );
    _isLoadingKandang.value = false;
  }

  Future<void> get retrieveAsalTernak async {
    _isLoadingAsalTernak.value = true;
    _allAsalTernak.value = await _comboRepository.ternakOrigins;
    _isLoadingAsalTernak.value = false;
  }

  bool get anyMissingRequired {
    if (etQrCode.text.isEmpty) return true;
    if (etCategory.text.isEmpty) return true;
    if (etRumpun.text.isEmpty) return true;
    if (etGender.text.isEmpty) return true;
    if (etBirthday.text.isEmpty) return true;
    if (etProgram.text.isEmpty) return true;
    if (etOwner.text.isEmpty) return true;
    if (etKandang.text.isEmpty) return true;
    if (etTanggalPerolehan.text.isEmpty) return true;
    if (etAsalTernak.text.isEmpty) return true;
    if (isTernakImport) {
      if (etAsalTernakLokasi.text.isEmpty) return true;
    }
    if (!_isUpdateTernak.value && _selectedIsVacination.value) {
      if (etVaccineDate.text.isEmpty) return true;
      if (etVaccineMerk.text.isEmpty) return true;
    }

    return false;
  }

  void saveTernak() async {
    if (anyMissingRequired) return;

    final birthday = TernakBirthdayRequest(
      address: etAlamat.text,
      rt: etRt.text,
      rw: etRw.text,
      latitude: latitude.value.toString(),
      longitude: longitude.value.toString(),
      province: _selectedProvinsi.value?.id,
      district: _selectedKabupaten.value?.id,
      subDistrict: _selectedKecamatan.value?.id,
      village: _selectedDesa.value?.id,
    );

    final payload = TernakRequest(
      idIshiknas: etIdIsikhnas.text,
      ternakBirthday: birthday,
      ciriKhas: etCiriKhas.text,
      mutuBibit: etMutuBibit.text,
      tanggalPerolehan: _selectedTanggalPerolehan.value,
      asalTernakLokasi: _selectedAsalTernakLokasi.value?.id,
      beratBadan: etBeratBadan.text,
      panjangBadan: etPanjangBadan.text,
      tinggiBadan: etTinggiBadan.text,
      asalTernak: _selectedAsalTernak.value?.value,
      batchNumber: etBatch.text,
      birthday: _selectedBirthday.value,
      category: _selectedCategory.value?.value,
      codeProduct: (etQrCode.text.isNotEmpty) ? etQrCode.text : null,
      gender: _selectedGender.value?.value,
      idPemilik: _selectedOwner.value?.id,
      idProduct: _ternak.value?.id,
      isCompany: _selectedIsCompany.value,
      isSameWithKandang: _isSameWithKandang.value,
      isVaksinasi: _selectedIsVacination.value,
      kandang: _selectedKandang.value?.value,
      name: (etNamaTernak.text.isNotEmpty) ? etNamaTernak.text : null,
      pathPhoto: _selectedPhoto.value?.path,
      program: _selectedProgram.value?.value,
      rumpun: _selectedRumpun.value?.value,
      statusKandang: _selectedStatusKandang.value?.value,
      tanggalVaksinasi: _selectedVaccineDate.value,
      vaksinasi: _selectedObat.value?.value,
      scanResult: _scanResult.value,
    );

    try {
      bool statusUpdate = false;
      if (_isUpdateTernak.value) {
        final update = await _ternakRepository.updateBiodata(payload);
        if (update.code == HttpStatus.ok) statusUpdate = true;
      } else {
        final add = await _ternakRepository.addTernak(
          request: payload,
        );
        if (add.code == HttpStatus.ok) statusUpdate = true;
      }

      if (statusUpdate) {
        Get.showSnackbar(const GetSnackBar(
          message: 'Perubahan Data Ternak Berhasil',
          duration: Duration(seconds: 3),
        ));

        final isOnline = await NetworkingUtil.isConnected;

        if (_isUpdateTernak.value) {
          Get.until((route) => route.settings.name == MainPage.routeName);
        } else {
          if (isOnline) {
            Get.offNamedUntil(
              VaccineTernakPage.routeName,
              (route) => route.settings.name == MainPage.routeName,
              arguments: etQrCode.text,
            );
          } else {
            Get.until((route) => route.settings.name == MainPage.routeName);
          }
        }
      } else {
        Get.showSnackbar(const GetSnackBar(
          message: 'Perubahan Data Ternak Gagal',
          duration: Duration(seconds: 3),
        ));
      }
      _updatingTernak.value = false;
    } catch (error) {
      _updatingTernak.value = false;
      // Get.showSnackbar(GetSnackBar(
      //   message: ValidationUtil.errorMessage(error as DioError),
      //   duration: const Duration(seconds: 3),
      // ));
      Get.showSnackbar(const GetSnackBar(
        message: 'Perubahan Data Ternak Gagal',
        duration: Duration(seconds: 3),
      ));
    }
  }

  void setBirthDay(DateTime dateTime) {
    _selectedBirthday.value = dateTime;
    etBirthday.text = dateString(dateTime);
  }

  void setVaccineDate(DateTime dateTime) {
    _selectedVaccineDate.value = dateTime;
    etVaccineDate.text = dateString(dateTime);
  }

  void setTanggalPerolehan(DateTime dateTime) {
    _selectedTanggalPerolehan.value = dateTime;
    etTanggalPerolehan.text = dateString(dateTime);
  }

  void setTanggalVaksin(DateTime dateTime) {
    _selectedVaccineDate.value = dateTime;
    etVaccineDate.text = dateString(dateTime);
  }

  Future<void> setOwner(OwnerModel owner) async {
    _selectedOwner.value = owner;
    etOwner.text = owner.name;

    resetKandang();

    await retrieveKandang(
      statusKandang: _selectedStatusKandang.value?.value ?? '-',
      nik: owner.nik,
    );
  }

  void setObat(ComboModel value) {
    _selectedObat.value = value;
    etVaccineMerk.text = value.label;
    Get.back();
  }

  String dateString(DateTime dateTime) {
    final dateFormat = DateFormat('dd MMMM yyyy');
    return dateFormat.format(dateTime);
  }

  void setAsalTernakLokasi(
      {required CountryModel value, required bool isInitial}) {
    _selectedAsalTernakLokasi.value = value;
    etAsalTernakLokasi.text = value.country;
    if (!isInitial) Get.back();
  }

  Future<void> setProvinsi(ProvinceModel value) async {
    _selectedProvinsi.value = value;
    etProvinsi.text = value.province;

    setKabupaten(null);
    setKecamatan(null);
    setDesa(null);

    await retrieveDistricts(value.id);
  }

  Future<void> setKabupaten(DistrictModel? value) async {
    _selectedKabupaten.value = value;
    setKecamatan(null);

    if (value == null) {
      etKabupaten.clear();
    } else {
      etKabupaten.text = value.district;
      await retrieveSubDistricts(value.id);
    }
  }

  void setKecamatan(SubdistrictModel? value) {
    _selectedKecamatan.value = value;
    setDesa(null);

    if (value == null) {
      etKecamatan.clear();
    } else {
      etKecamatan.text = value.subDistrict;
      retrieveVillages(value.id);
    }
  }

  void setDesa(VillageModel? value) {
    _selectedDesa.value = value;
    if (value == null) {
      etDesa.clear();
    } else {
      etDesa.text = value.urbanVillage;
    }
  }

  Future<void> setCategory({
    required ComboModel value,
    bool isInitial = true,
  }) async {
    _selectedCategory.value = value;
    etCategory.text = value.label;
    await retrieveRumpun(value);
    if (!isInitial) Get.back();
  }

  Future<void> get retrieveCountry async {
    _isLoadingCountry.value = true;
    final countries = await _addressRepository.countries;
    countries.removeWhere((element) => element.country.contains('INDONESIA'));
    _allCountry.value = countries;
    _isLoadingCountry.value = false;
  }

  Future<void> retrieveProvinces(int idCountry) async {
    _isLoadingProvinces.value = true;
    final provinces = await _addressRepository.provinces(idCountry);
    _provinces.value = provinces;
    _isLoadingProvinces.value = false;
  }

  Future<void> retrieveDistricts(String idProvince) async {
    _isLoadingDistricts.value = true;
    final districts = await _addressRepository.districts(idProvince);
    _districts.value = districts;
    _isLoadingDistricts.value = false;
  }

  Future<void> retrieveSubDistricts(String idDistrict) async {
    _isLoadingSubDistricts.value = true;
    final subDistricts = await _addressRepository.subDistricts(idDistrict);
    _subDistricts.value = subDistricts;
    _isLoadingSubDistricts.value = false;
  }

  Future<void> retrieveVillages(String idSubDistrict) async {
    _isLoadingVillages.value = true;
    final villages = await _addressRepository.villages(idSubDistrict);
    _villages.value = villages;
    _isLoadingVillages.value = false;
  }

  Future<OwnerModel?> retrieveOwners(String query) async {
    final owners = await _ownerRepository.owners(query: query);
    if (owners.isEmpty) {
      return null;
    } else {
      return owners.first;
    }
  }

  Future<void> get retrieveCategories async {
    _isLoadingCategories.value = true;
    final categories = await _comboRepository.ternakCategories;
    _categories.value = categories;
    _isLoadingCategories.value = false;
  }

  void getCurrentLocation() async {
    final currentLocation = await LocationUtil.currentLocation;
    if (currentLocation != null) {
      latitude.value = currentLocation.latitude;
      longitude.value = currentLocation.longitude;
    }
  }

  bool get isTernakImport =>
      _selectedAsalTernak.value?.label.toLowerCase().contains('import') ??
      false;

  Future<void> get retrieveObat async {
    final allObat = await _comboRepository.obat('vaksin', '1');
    _allObat.value = allObat;
  }

  void setSameWithKandang(bool? value) {
    if (value != null) _isSameWithKandang.value = value;
  }
}
