import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_file_dialog/flutter_file_dialog.dart';
import 'package:get/get.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

import '../../../data/models/address/country_model.dart';
import '../../../data/models/address/district_model.dart';
import '../../../data/models/address/province_model.dart';
import '../../../data/models/address/subdistrict_model.dart';
import '../../../data/models/address/village_model.dart';
import '../../../data/models/combo/combo_model.dart';
import '../../../data/models/owner/owner_model.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../../../data/repositories/address_repository.dart';
import '../../../data/repositories/combo_repository.dart';
import '../../../data/repositories/ternak_repository.dart';
import '../../../utils/validation_util.dart';

class IdentitasController extends GetxController {
  final AddressRepository _addressRepository;
  final ComboRepository _comboRepository;
  final TernakRepository _ternakRepository;

  IdentitasController({
    required AddressRepository addressRepository,
    required ComboRepository comboRepository,
    required TernakRepository ternakRepository,
  })  : _addressRepository = addressRepository,
        _comboRepository = comboRepository,
        _ternakRepository = ternakRepository;

  final etOwner = TextEditingController();
  final etStatusKandang = TextEditingController();
  final etKandang = TextEditingController();
  final etProvinsi = TextEditingController();
  final etKabupaten = TextEditingController();
  final etWorkArea = TextEditingController();
  final etKecamatan = TextEditingController();
  final etDesa = TextEditingController();

  final _selectedOwner = Rx<OwnerModel?>(null);
  final _selectedStatusKandang = Rx<ComboModel?>(null);
  final _selectedKandang = Rx<ComboModel?>(null);
  final _isLoadingStatusKandang = false.obs;
  final _isLoadingKandang = false.obs;
  final _allStatusKandang = Rx<List<ComboModel>>([]);
  final _allKandang = Rx<List<ComboModel>>([]);
  final _isLoadingProvinces = false.obs;
  final _isLoadingDistricts = false.obs;
  final _isLoadingSubDistricts = false.obs;
  final _isLoadingVillages = false.obs;
  final _allCountry = Rx<List<CountryModel>>([]);
  final _provinces = Rx<List<ProvinceModel>>([]);
  final _districts = Rx<List<DistrictModel>>([]);
  final _subDistricts = Rx<List<SubdistrictModel>>([]);
  final _villages = Rx<List<VillageModel>>([]);
  final _selectedProvinsi = Rx<ProvinceModel?>(null);
  final _selectedKabupaten = Rx<DistrictModel?>(null);
  final _selectedKecamatan = Rx<SubdistrictModel?>(null);
  final _selectedDesa = Rx<VillageModel?>(null);

  OwnerModel? get selectedOwner => _selectedOwner.value;
  ComboModel? get selectedStatusKandang => _selectedStatusKandang.value;
  ComboModel? get selectedKandang => _selectedKandang.value;
  bool get isLoadingStatusKandang => _isLoadingStatusKandang.value;
  bool get isLoadingKandang => _isLoadingKandang.value;
  List<ComboModel> get allStatusKandang => _allStatusKandang.value;
  List<ComboModel> get allKandang => _allKandang.value;
  bool get isLoadingProvinces => _isLoadingProvinces.value;
  bool get isLoadingDistricts => _isLoadingDistricts.value;
  bool get isLoadingSubDistricts => _isLoadingSubDistricts.value;
  bool get isLoadingVillages => _isLoadingVillages.value;
  List<CountryModel> get allCountry => _allCountry.value;
  List<ProvinceModel> get provinces => _provinces.value;
  List<DistrictModel> get districts => _districts.value;
  List<SubdistrictModel> get subDistricts => _subDistricts.value;
  List<VillageModel> get villages => _villages.value;
  ProvinceModel? get selectedProvinsi => _selectedProvinsi.value;
  DistrictModel? get selectedKabupaten => _selectedKabupaten.value;
  SubdistrictModel? get selectedKecamatan => _selectedKecamatan.value;
  VillageModel? get selectedDesa => _selectedDesa.value;

  static const _pageSize = 20;
  final pagingController = PagingController<int, IdentityTernakModel>(
    firstPageKey: 0,
  );

  @override
  void onInit() {
    pagingController.addPageRequestListener((pageKey) {
      retrieveAllTernak(pageKey);
    });
    super.onInit();
  }

  @override
  void onReady() async {
    super.onReady();
    retrieveAllTernak;
    await retrieveStatusKandang;

    /// Indonesian id is 1
    await retrieveProvinces(1);
  }

  Future<void> retrieveAllTernak(int page) async {
    try {
      final newItems = await _ternakRepository.allTernak(
        offset: page,
      );
      final isLastPage = newItems.length < _pageSize;
      if (isLastPage) {
        pagingController.appendLastPage(newItems);
      } else {
        final nextPageKey = page + 1;
        pagingController.appendPage(newItems, nextPageKey);
      }
    } catch (error) {
      pagingController.error = error;
      Get.showSnackbar(GetSnackBar(
        message: ValidationUtil.errorMessage(error as DioError),
        duration: const Duration(seconds: 3),
      ));
    }
  }

  Future<void> downloadInsentif() async {
    final downloadPath = await _ternakRepository.downloadInsentif();
    if (downloadPath != null) {
      final params = SaveFileDialogParams(
        sourceFilePath: downloadPath,
      );
      final pathFile = await FlutterFileDialog.saveFile(params: params);
      if (pathFile != null) {
        Get.back();
        Get.showSnackbar(const GetSnackBar(
          message: 'Download Data Ternak Berhasil',
          duration: Duration(seconds: 3),
        ));
      }
    }
  }

  Future<void> setOwner(OwnerModel owner) async {
    _selectedOwner.value = owner;
    etOwner.text = owner.name;

    resetKandang();

    await retrieveKandang(
      statusKandang: _selectedStatusKandang.value?.value ?? '-',
      nik: owner.nik,
    );
  }

  Future<void> get retrieveStatusKandang async {
    _isLoadingStatusKandang.value = true;
    _allStatusKandang.value = await _comboRepository.statusKandang;
    _isLoadingStatusKandang.value = false;
  }

  Future<void> setStatusKandang({
    required ComboModel value,
    bool isInitial = true,
  }) async {
    _selectedStatusKandang.value = value;
    etStatusKandang.text = value.label;
    if (!isInitial) Get.back();

    resetKandang();

    await retrieveKandang(
      statusKandang: value.value,
      nik: _selectedOwner.value?.nik ?? '-',
    );
  }

  Future<void> retrieveKandang({
    required String statusKandang,
    required String nik,
  }) async {
    _isLoadingKandang.value = true;
    _allKandang.value = await _comboRepository.kandang(
      statusKandang: statusKandang,
      nik: nik,
    );
    _isLoadingKandang.value = false;
  }

  void setKandang({
    required ComboModel value,
    bool isInitial = true,
  }) {
    _selectedKandang.value = value;
    etKandang.text = value.label;
    if (!isInitial) Get.back();
  }

  void resetKandang() {
    _selectedKandang.value = null;
    etKandang.clear();
  }

  Future<void> retrieveProvinces(int idCountry) async {
    _isLoadingProvinces.value = true;
    final provinces = await _addressRepository.provinces(idCountry);
    _provinces.value = provinces;
    _isLoadingProvinces.value = false;
  }

  Future<void> setProvinsi({
    required ProvinceModel value,
    bool isInitial = false,
  }) async {
    _selectedProvinsi.value = value;
    etProvinsi.text = value.province;
    await retrieveDistricts(value.id);
    if (!isInitial) Get.back();
  }

  Future<void> retrieveDistricts(String idProvince) async {
    _isLoadingDistricts.value = true;
    final districts = await _addressRepository.districts(idProvince);
    _districts.value = districts;
    _isLoadingDistricts.value = false;
  }

  Future<void> setKabupaten({
    required DistrictModel value,
    bool isInitial = false,
  }) async {
    _selectedKabupaten.value = value;
    etKabupaten.text = value.district;
    await retrieveSubDistricts(value.id);
    if (!isInitial) Get.back();
  }

  Future<void> retrieveSubDistricts(String idDistrict) async {
    _isLoadingSubDistricts.value = true;
    final subDistricts = await _addressRepository.subDistricts(idDistrict);
    _subDistricts.value = subDistricts;
    _isLoadingSubDistricts.value = false;
  }

  void setKecamatan(SubdistrictModel value) {
    _selectedKecamatan.value = value;
    etKecamatan.text = value.subDistrict;
    retrieveVillages(value.id);
    Get.back();
  }

  Future<void> retrieveVillages(String idSubDistrict) async {
    _isLoadingVillages.value = true;
    final villages = await _addressRepository.villages(idSubDistrict);
    _villages.value = villages;
    _isLoadingVillages.value = false;
  }

  void setDesa(VillageModel value) {
    _selectedDesa.value = value;
    etDesa.text = value.urbanVillage;
    Get.back();
  }
}
