import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../data/models/ternak/identity_ternak_model.dart';
import '../../../data/repositories/ternak_repository.dart';
import '../../../utils/validation_util.dart';
import '../params/identitas_detail_params.dart';

class IdentitasDetailController extends GetxController {
  final TernakRepository _repository;

  IdentitasDetailController({
    required TernakRepository repository,
  }) : _repository = repository;

  final _ternak = Rx<IdentityTernakModel?>(null);
  final _isFromForm = false.obs;
  final _isFromScan = false.obs;

  IdentityTernakModel? get ternak => _ternak.value;
  bool get isFromForm => _isFromForm.value;
  bool get isFromScan {
    final isScan = _isFromScan.value;
    if (isScan) {
      if (ternak != null) {
        if (ValidationUtil.isExpiredTernak(ternak!)) {
          return false;
        }
      }
    }

    return isScan;
  }

  @override
  void onInit() {
    super.onInit();
    retrieveArgs;
  }

  void get retrieveArgs {
    final args = Get.arguments;
    if (args is IdentitasDetailParams) {
      _ternak.value = args.ternak;
      _isFromForm.value = args.isFromForm;
      _isFromScan.value = args.isFromScan;
    }
  }

  String date(DateTime dateTime) {
    final dateFormat = DateFormat('dd MMMM yyyy');
    return dateFormat.format(dateTime);
  }

  Future<void> get retrieveTernak async {
    final allTernak = await _repository.allTernak(
        query: _ternak.value!.codeProduct, limit: 1, offset: 0);
    if (allTernak.isNotEmpty) {
      _ternak.value = allTernak.first;
    }
  }
}
