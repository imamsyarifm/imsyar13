import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/ternak_repository.dart';
import 'identitas_kepemilikan_edit_controller.dart';

class IdentitasKepemilikanEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put<TernakRepository>(TernakRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(IdentitasKepemilikanEditController(
      ternakRepository: Get.find<TernakRepository>(),
    ));
  }
}
