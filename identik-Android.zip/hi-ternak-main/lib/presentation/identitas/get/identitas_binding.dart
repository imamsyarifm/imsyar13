import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/address_repository.dart';
import '../../../data/repositories/combo_repository.dart';
import '../../../data/repositories/ternak_repository.dart';
import 'identitas_controller.dart';

class IdentitasBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(AddressRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(ComboRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(TernakRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(IdentitasController(
      addressRepository: Get.find<AddressRepository>(),
      comboRepository: Get.find<ComboRepository>(),
      ternakRepository: Get.find<TernakRepository>(),
    ));
  }
}
