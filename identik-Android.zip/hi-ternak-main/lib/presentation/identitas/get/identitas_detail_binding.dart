import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/ternak_repository.dart';
import 'identitas_detail_controller.dart';

class IdentitasDetailBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(TernakRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(IdentitasDetailController(
      repository: Get.find<TernakRepository>(),
    ));
  }
}
