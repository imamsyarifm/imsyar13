import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/combo/combo_model.dart';
import '../../../utils/validation_util.dart';
import '../../register/widgets/chooseable_widget.dart';
import '../../widgets/default_scaffold.dart';
import '../../widgets/edit_text.dart';
import '../get/identitas_kepemilikan_edit_controller.dart';

class IdentitasKepemilikanEditPage
    extends GetView<IdentitasKepemilikanEditController> {
  const IdentitasKepemilikanEditPage({Key? key}) : super(key: key);

  static const routeName = '/identitas-kepemilikan-edit';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Identitas Ternak - Update',
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: ListView(
            children: [
              EditText(
                  label: 'Kepemilikan*',
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Kepemilikan', value),
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.done,
                  suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                  isReadOnly: true,
                  onTap: () => showModalBottomSheet(
                        context: context,
                        builder: (context) => ChooseableWidget<ComboModel>(
                          values: [
                            ComboModel(
                              value: 'sendiri',
                              label: 'Diri Sendiri',
                            ),
                            ComboModel(
                              value: 'orang_lain',
                              label: 'Orang Lain',
                            ),
                          ],
                          title: (value) => value.label,
                          onSelected: controller.setKepemilikan,
                        ),
                      ),
                  controller: controller.etKepemilikan),
            ],
          ),
        ),
        bottomNavigation: Container(
          color: Colors.white,
          child: Row(children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 12, top: 12, bottom: 12, right: 6),
                child: SizedBox(
                  height: 40,
                  child: ElevatedButton(
                      onPressed: () => Get.back(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(36))),
                      child: Text(
                        'BATAL',
                        style: GoogleFonts.roboto(
                            color: black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      )),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                    right: 12, top: 12, bottom: 12, left: 6),
                child: SizedBox(
                  height: 40,
                  child: ElevatedButton(
                      onPressed: () => controller.updateOwnership(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: yellowDark,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(36))),
                      child: Text(
                        'SIMPAN',
                        style: GoogleFonts.roboto(
                            color: black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      )),
                ),
              ),
            ),
          ]),
        ),
      );
}
