import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../utils/datetime_util.dart';
import '../../../utils/validation_util.dart';
import '../../widgets/default_scaffold.dart';
import '../../widgets/edit_text.dart';
import '../get/identitas_history_edit_controller.dart';

class IdentitasHistoryEditPage extends GetView<IdentitasHistoryEditController> {
  const IdentitasHistoryEditPage({Key? key}) : super(key: key);

  static const routeName = '/identitas-history-edit';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Identitas Hewan - Update',
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            child: ListView(children: [
              EditText(
                  label: 'Tanggal*',
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Tanggal', value),
                  keyboardType: TextInputType.datetime,
                  suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                  isReadOnly: true,
                  onTap: () async {
                    final dateTime = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime.now().add(
                          Duration(
                            days: DateTime.now().differencToOldYear(100).inDays,
                          ),
                        ),
                        lastDate: DateTime.now());
                    if (dateTime != null) controller.setDate(dateTime);
                  },
                  controller: controller.etDate),
              const SizedBox(height: 16),
              EditText(
                  label: 'Histori Ternak*',
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Histori Ternak', value),
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.done,
                  controller: controller.etHistoryTernak),
              const SizedBox(height: 16),
            ]),
          ),
        ),
        bottomNavigation: Container(
          color: Colors.white,
          child: Row(children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 12, top: 12, bottom: 12, right: 6),
                child: SizedBox(
                  height: 40,
                  child: ElevatedButton(
                      onPressed: () => Get.back(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(36))),
                      child: Text(
                        'BATAL',
                        style: GoogleFonts.roboto(
                            color: black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      )),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                    right: 12, top: 12, bottom: 12, left: 6),
                child: SizedBox(
                  height: 40,
                  child: ElevatedButton(
                      onPressed: () => controller.updateHistory(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: yellowDark,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(36))),
                      child: Text(
                        'SIMPAN',
                        style: GoogleFonts.roboto(
                            color: black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      )),
                ),
              ),
            ),
          ]),
        ),
      );
}
