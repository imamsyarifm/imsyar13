import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/consts/colors.dart';
import '../../../data/const/mutation_type.dart';
import '../../../utils/datetime_util.dart';

import '../../mutasi/pages/mutasi_edit_page.dart';
import '../../mutasi/params/mutasi_edit_params.dart';
import '../../widgets/default_scaffold.dart';
import '../get/identitas_mutasi_controller.dart';
import '../widgets/identitas_mutasi_detail.dart';

class IdentitasMutasiPage extends GetView<IdentitasMutasiController> {
  static const routeName = '/identitas/mutasi';

  const IdentitasMutasiPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultScaffold(
      appBarTitle: 'Mutasi',
      body: ListView.builder(
        itemBuilder: (context, index) {
          final mutasi = controller.params.ternak.mutasi[index];
          return ListTile(
            title: Text(mutasi.statusMutasi),
            subtitle: Text(mutasi.tanggalMutasi.readable()),
            onTap: () => Get.bottomSheet(
              IdentitasMutasiDetail(
                mutasi: mutasi,
              ),
              isScrollControlled: true,
              ignoreSafeArea: false,
            ),
          );
        },
        itemCount: controller.params.ternak.mutasi.length,
      ),
      floatingAction: Visibility(
        visible: controller.params.ternak.jenisKelamin == 'betina' &&
            controller.params.isFromScan,
        child: FloatingActionButton(
          backgroundColor: green,
          onPressed: () => onUpdateOwnership(context),
          child: const Icon(Icons.add),
        ),
      ),
    );
  }

  void onUpdateOwnership(BuildContext context) {
    Get.bottomSheet(Container(
      color: Colors.white,
      child: ListView(
        children: [
          ListTile(
            title: const Text('Potong'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => mutasiType(MutationType.potong),
          ),
          const Divider(),
          ListTile(
            title: const Text('Mati'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => mutasiType(MutationType.mati),
          ),
          const Divider(),
          ListTile(
            title: const Text('Hilang'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => mutasiType(MutationType.hilang),
          ),
          const Divider(),
          ListTile(
            title: const Text('Jual'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => mutasiType(MutationType.jual),
          ),
          const Divider(),
          ListTile(
            title: const Text('Pindah'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => mutasiType(MutationType.pindah),
          ),
        ],
      ),
    ));
  }

  void mutasiType(MutationType type) async {
    Get.toNamed(
      MutasiEditPage.routeName,
      arguments: MutasiEditParams(
        mutationType: type,
        ternak: controller.params.ternak,
        isFromProfile: true,
      ),
    );
  }
}
