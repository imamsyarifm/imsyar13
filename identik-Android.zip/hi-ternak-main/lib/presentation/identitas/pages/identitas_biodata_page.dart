import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/consts/colors.dart';
import '../../vaccine_ternak/pages/vaccine_ternak_page.dart';
import '../../widgets/default_scaffold.dart';
import '../identitas_feature.dart';

class IdentitasBiodataPage extends GetView<IdentitasBiodataController> {
  static const routeName = '/identitas-biodata';
  const IdentitasBiodataPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: DefaultScaffold(
        appBarTitle: controller.ternak.codeProduct ?? '-',
        actions: [
          IconButton(
            onPressed: () => Get.toNamed(
              VaccineTernakPage.routeName,
              arguments: controller.ternak.idEartag,
            ),
            icon: const Icon(Icons.file_open),
          ),
        ],
        bottomAppBar: const TabBar(
          indicatorColor: Colors.white,
          labelColor: Colors.white,
          unselectedLabelColor: greyDF,
          tabs: [
            Tab(
              text: 'Profil',
            ),
            Tab(
              text: 'Pertumbuhan',
            ),
            Tab(
              text: 'Pemilik',
            ),
          ],
        ),
        body: TabBarView(
          children: [
            IdentitasBiodataWidget(isFromForm: controller.isFromForm),
            const IdentitasPertumbuhanWidget(),
            IdentityOwnerWidget(
              owner: controller.ternak.kepemilikan,
              isPersonal: (controller.ternak.kepemilikan?.isCompany == 0)
                  ? true
                  : false,
              kandang: (controller.ternak.kandang?.isNotEmpty == true)
                  ? controller.ternak.kandang?.first
                  : null,
            ),
          ],
        ),
      ),
    );
  }
}
