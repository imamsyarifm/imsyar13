import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../../widgets/default_scaffold.dart';
import '../get/identitas_controller.dart';
import '../params/identitas_detail_params.dart';
import '../widgets/filter_ternak_widget.dart';
import '../widgets/ternak_search_delegate.dart';
import 'identitas_detail_page.dart';

class IdentitasPage extends GetView<IdentitasController> {
  const IdentitasPage({Key? key}) : super(key: key);

  static const routeName = '/identitas';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Identitas Ternak',
        actions: [
          IconButton(
            onPressed: () => showSearch(
              context: context,
              delegate: TernakSearchDelegate(),
            ),
            icon: const Icon(Icons.search),
          ),
          IconButton(
            onPressed: () => Get.defaultDialog(
              title: 'Unduh Data Ternak',
              middleText: 'Data yang akan di unduh adalah data H-7, '
                  'klik Lanjut untuk mengunduh',
              confirm: ElevatedButton(
                onPressed: () => controller.downloadInsentif(),
                style: ElevatedButton.styleFrom(
                  backgroundColor: green,
                ),
                child: const Text('Lanjut'),
              ),
            ),
            icon: const Icon(Icons.download),
          ),
        ],
        body: PagedListView<int, IdentityTernakModel>(
          pagingController: controller.pagingController,
          builderDelegate: PagedChildBuilderDelegate<IdentityTernakModel>(
            itemBuilder: (context, item, index) {
              return Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 8),
                child: GestureDetector(
                  onTap: () async {
                    await Get.toNamed(IdentitasDetailPage.routeName,
                        arguments: IdentitasDetailParams(ternak: item));
                    controller.pagingController.refresh();
                  },
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Text('${index + 1}'),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(item.idEartag ?? '-'),
                                  Text(item.kepemilikan?.nama ?? '-'),
                                ],
                              ),
                            ),
                          ),
                          const Icon(Icons.arrow_right),
                        ],
                      ),
                      const Divider(color: greyE5),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        // floatingAction: FloatingActionButton(
        //   backgroundColor: green,
        //   onPressed: () => doFilter(context),
        //   child: const Icon(Icons.filter_list, color: Colors.white),
        // ),
      );

  void doFilter(BuildContext context) {
    Get.toNamed(FilterTernakWidget.routeName);
  }
}
