import 'package:extended_image/extended_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../inseminasi/pages/inseminasi_page.dart';
import '../../inseminasi/params/inseminasi_params.dart';
import '../../ownership/page/ownership_detail_page.dart';
import '../../ownership/params/ownership_params.dart';
import '../../pertumbuhan_ternak/page/pertumbuhan_ternak_page.dart';
import '../../pertumbuhan_ternak/params/pertumbuhan_ternak_params.dart';
import '../../produksi_susu/page/produksi_susu_page.dart';
import '../../produksi_susu/params/produksi_susu_params.dart';
import '../../rekam_medis/page/rekam_medis_page.dart';
import '../../rekam_medis/params/rekam_medis_params.dart';
import '../../vaccine_ternak/pages/vaccine_ternak_page.dart';
import '../../widgets/default_scaffold.dart';
import '../get/identitas_detail_controller.dart';
import '../params/identitas_detail_params.dart';
import '../params/identitas_mutasi_params.dart';
import 'identitas_biodata_page.dart';
import 'identitas_mutasi_page.dart';

class IdentitasDetailPage extends GetView<IdentitasDetailController> {
  const IdentitasDetailPage({Key? key}) : super(key: key);

  static const routeName = '/identitas-detail';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Identitas Ternak',
        actions: [
          IconButton(
            onPressed: () => Get.toNamed(
              VaccineTernakPage.routeName,
              arguments: controller.ternak?.idEartag,
            ),
            icon: const Icon(Icons.file_open),
          ),
        ],
        body: ListView(
          children: [
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: ExtendedImage.network(
                    controller.ternak!.urlImage ?? '-',
                    width: 156,
                    height: 104,
                    fit: BoxFit.cover,
                  ),
                ),
                const SizedBox(width: 16),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      controller.ternak!.codeProduct ?? '-',
                      style: GoogleFonts.roboto(
                        fontSize: 12,
                        color: black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Jenis Ternak: ${controller.ternak!.jenisTernak}',
                      style: GoogleFonts.roboto(
                        fontSize: 12,
                        color: grey8,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Jenis Kelamin: ${controller.ternak!.jenisKelamin}',
                      style: GoogleFonts.roboto(
                        fontSize: 12,
                        color: grey8,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'ID Eartag: ${controller.ternak!.idEartag}',
                      style: GoogleFonts.roboto(
                        fontSize: 12,
                        color: grey8,
                      ),
                    ),
                    Visibility(
                      visible: controller.ternak!.mutasi.isNotEmpty,
                      child: const SizedBox(height: 6),
                    ),
                    (controller.ternak!.mutasi.isNotEmpty)
                        ? Text(
                            'Status Ternak: '
                            '${controller.ternak!.mutasi.first.statusMutasi}',
                            style: GoogleFonts.roboto(
                              fontSize: 12,
                              color: grey8,
                            ),
                          )
                        : const SizedBox.shrink(),
                  ],
                ),
              ],
            ),
            buildMenu(
              context: context,
              name: 'Profil Ternak',
              onTap: () async {
                await Get.toNamed(
                  IdentitasBiodataPage.routeName,
                  arguments: IdentitasDetailParams(
                    ternak: controller.ternak!,
                    isFromForm: controller.isFromForm,
                  ),
                );
                controller.retrieveTernak;
              },
            ),
            buildMenu(
              context: context,
              name: 'Pertumbuhan',
              onTap: () async {
                await controller.retrieveTernak;
                Get.toNamed(
                  PertumbuhanTernakPage.routeName,
                  arguments: PertumbuhanTernakParams(
                    ternak: controller.ternak!,
                    isFromScan: controller.isFromScan,
                  ),
                );
              },
            ),
            buildMenu(
              context: context,
              name: 'Vaksinasi',
              onTap: () async {
                await controller.retrieveTernak;
                Get.toNamed(
                  RekamMedisPage.routeName,
                  arguments: RekamMedisParams(
                    ternak: controller.ternak!,
                    isFromScan: controller.isFromScan,
                  ),
                );
              },
            ),
            buildMenu(
              context: context,
              name: 'Perkawinan',
              onTap: () async {
                await controller.retrieveTernak;
                Get.toNamed(
                  InseminasiPage.routeName,
                  arguments: InseminasiParams(
                    ternak: controller.ternak!,
                    isFromScan: controller.isFromScan,
                  ),
                );
              },
            ),
            buildMenu(
              context: context,
              name: 'Produksi Susu',
              onTap: () async {
                await controller.retrieveTernak;
                Get.toNamed(
                  ProduksiSusuPage.routeName,
                  arguments: ProduksiSusuParams(
                    ternak: controller.ternak!,
                    isFromScan: controller.isFromScan,
                  ),
                );
              },
            ),
            (controller.ternak!.kepemilikan != null)
                ? buildMenu(
                    context: context,
                    name: 'Kepemilikan',
                    onTap: () async {
                      await controller.retrieveTernak;
                      Get.toNamed(
                        OwnershipDetailPage.routeName,
                        arguments: OwnershipParams(
                          ternak: controller.ternak!,
                          isFromScan: controller.isFromScan,
                        ),
                      );
                    },
                  )
                : const SizedBox.shrink(),
            (controller.ternak!.mutasi.isNotEmpty)
                ? buildMenu(
                    context: context,
                    name: 'Mutasi',
                    onTap: () async {
                      await controller.retrieveTernak;
                      Get.toNamed(
                        IdentitasMutasiPage.routeName,
                        arguments: IdentitasMutasiParams(
                          ternak: controller.ternak!,
                          isFromScan: controller.isFromScan,
                        ),
                      );
                    },
                  )
                : const SizedBox.shrink(),
          ],
        ),
      );

  Widget buildMenu({
    required BuildContext context,
    required String name,
    VoidCallback? onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
      ),
      child: GestureDetector(
        onTap: onTap,
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(name,
                      style: GoogleFonts.roboto(
                        color: black,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      )),
                ),
                const Icon(Icons.chevron_right),
              ],
            ),
            const SizedBox(height: 8),
            const Divider(
              height: 0,
              color: greyE5,
            )
          ],
        ),
      ),
    );
  }
}
