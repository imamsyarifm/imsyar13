import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../app/consts/colors.dart';
import '../kegiatan/widgets/activity_widget.dart';
import 'news_controller.dart';

class NewsPage extends GetView<NewsController> {
  const NewsPage({Key? key}) : super(key: key);

  static const routeName = '/kegiatan';

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      if (controller.news.isEmpty) {
        return const Center(
          child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(green),
          ),
        );
      }

      return Expanded(
          child: CarouselSlider.builder(
        carouselController: controller.carouselController,
        itemCount: controller.news.length,
        itemBuilder: (context, itemIndex, pageViewIndex) => ActivityWidget(
          activity: controller.news[itemIndex],
        ),
        options: CarouselOptions(
          height: Get.height,
          onPageChanged: (index, reason) =>
              controller.changeCarouselIndex(index),
          autoPlay: true,
          disableCenter: true,
          enlargeCenterPage: true,
        ),
      ));
    });
  }
}
