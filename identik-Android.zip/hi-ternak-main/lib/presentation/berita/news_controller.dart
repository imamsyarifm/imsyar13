import 'package:carousel_slider/carousel_controller.dart';
import 'package:get/get.dart';

import '../../data/models/inbox/inbox_model.dart';
import '../../data/repositories/inbox_news_repository.dart';

class NewsController extends GetxController {
  final carouselController = CarouselController();

  final InboxNewsRepository _repository;

  NewsController({required InboxNewsRepository repository})
      : _repository = repository;

  final _news = Rx<List<InboxModel>>([]);
  final _carouselIndex = 0.obs;

  List<InboxModel> get news => _news.value;
  int get carouselIndex => _carouselIndex.value;

  @override
  void onReady() {
    super.onReady();
    retrieveNews();
  }

  void retrieveNews() async {
    final activities = await _repository.allNews;
    _news.value = activities;
  }

  void changeCarouselIndex(int index) => _carouselIndex.value = index;
}
