import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/address/district_model.dart';
import '../../../utils/validation_util.dart';
import '../../register/widgets/chooseable_widget.dart';
import '../../widgets/default_scaffold.dart';
import '../../widgets/edit_text.dart';
import '../get/akun_edit_controller.dart';

class AkunEditPage extends GetView<AkunEditController> {
  const AkunEditPage({Key? key}) : super(key: key);

  static const routeName = '/akun-edit';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
      appBarTitle: 'Edit Akun',
      body: Form(
        key: controller.formKey,
        child: ListView(children: [
          Row(
            children: [
              const SizedBox(width: 16),
              Expanded(
                child: EditText(
                  label: 'Foto',
                  controller: controller.etPhoto,
                ),
              ),
              Container(
                padding: const EdgeInsets.all(16),
                color: Colors.white,
                child: ElevatedButton(
                    onPressed: () => Get.bottomSheet(
                          Container(
                            color: Colors.white,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                ListTile(
                                  title: const Text('Galeri'),
                                  subtitle:
                                      const Text('Pilih gambar dari galeri'),
                                  onTap: () async {
                                    final file =
                                        await controller.imagePicker.pickImage(
                                      source: ImageSource.gallery,
                                      imageQuality: 25,
                                    );
                                    controller.setPhoto(file);
                                  },
                                ),
                                ListTile(
                                  title: const Text('Kamera'),
                                  subtitle:
                                      const Text('Pilih gambar dari kamera'),
                                  onTap: () async {
                                    final file =
                                        await controller.imagePicker.pickImage(
                                      source: ImageSource.camera,
                                      imageQuality: 25,
                                    );
                                    controller.setPhoto(file);
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: yellowDark,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(36))),
                    child: Text(
                      'BROWSE',
                      style: GoogleFonts.roboto(
                          color: black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                    )),
              )
            ],
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: EditText(
              label: 'Nama*',
              controller: controller.etName,
              validator: (value) => ValidationUtil.emptyValidate('Nama', value),
            ),
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: EditText(
              label: 'No. Handphone*',
              controller: controller.etPhone,
              validator: (value) =>
                  ValidationUtil.emptyValidate('No. Handphone', value),
            ),
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Obx(
              () {
                if (controller.isLoadingDistricts) {
                  return const Center(
                    child: CircularProgressIndicator(
                      color: green,
                    ),
                  );
                } else {
                  return EditText(
                    controller: controller.etDistrict,
                    validator: (value) =>
                        ValidationUtil.emptyValidate('Kota / Kabupaten', value),
                    onTap: () => showModalBottomSheet(
                      context: context,
                      builder: (context) => ChooseableWidget<DistrictModel>(
                        values: controller.districts,
                        title: (DistrictModel district) => district.district,
                        onSelected: (district) =>
                            controller.setDistrict(district),
                      ),
                    ),
                    isReadOnly: true,
                    label: 'Kota / Kabupaten*',
                    suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                  );
                }
              },
            ),
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: EditText(
              label: 'Email*',
              controller: controller.etEmail,
              validator: (value) =>
                  ValidationUtil.emptyValidate('Email', value),
            ),
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: EditText(
              label: 'Alamat*',
              minLines: 5,
              maxLines: null,
              controller: controller.etAddress,
              validator: (value) =>
                  ValidationUtil.emptyValidate('Alamat', value),
            ),
          ),
          Obx(
            () => ListTile(
              title: Text('Latitude: ${controller.latitude}',
                  style: GoogleFonts.roboto(
                    fontSize: 14,
                    color: black,
                  )),
              subtitle: Text('Longitude: ${controller.longitude}',
                  style: GoogleFonts.roboto(
                    fontSize: 14,
                    color: black,
                  )),
              trailing: IconButton(
                icon: const Icon(Icons.location_on, color: green),
                onPressed: () => controller.getCurrentLocation(),
              ),
            ),
          ),
          const SizedBox(height: 24),
        ]),
      ),
      bottomNavigation: Container(
        color: Colors.white,
        child: Row(children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 12, top: 12, bottom: 12, right: 6),
              child: SizedBox(
                height: 40,
                child: ElevatedButton(
                    onPressed: () => Get.back(),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(36))),
                    child: Text(
                      'BATAL',
                      style: GoogleFonts.roboto(
                          color: black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                    )),
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(
                  right: 12, top: 12, bottom: 12, left: 6),
              child: SizedBox(
                height: 40,
                child: ElevatedButton(
                    onPressed: () => controller.save(),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: yellowDark,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(36))),
                    child: Text(
                      'SIMPAN',
                      style: GoogleFonts.roboto(
                          color: black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                    )),
              ),
            ),
          ),
        ]),
      ));
}
