import 'package:extended_image/extended_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../passcode_edit/passcode_edit_page.dart';
import '../../password_edit/password_edit_page.dart';
import '../../widgets/component_tile.dart';
import '../../widgets/default_scaffold.dart';
import '../get/akun_controller.dart';
import 'akun_edit_page.dart';

class AkunPage extends GetView<AkunController> {
  const AkunPage({Key? key}) : super(key: key);

  static const routeName = '/akun';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Akun',
        actions: [
          Obx(
            () => IconButton(
              onPressed: () => controller.sync(),
              icon: Icon(
                Icons.cloud_sync_rounded,
                color: (controller.isOnSync) ? yellow : Colors.white,
              ),
            ),
          ),
          IconButton(
            onPressed: () {
              Get.defaultDialog(
                  title: 'Keluar Aplikasi',
                  content: const Text(
                    'Dengan keluarnya pengguna dari aplikasi maka seluruh '
                    'data yang tersimpan secara offline akan terhapus.',
                    textAlign: TextAlign.center,
                  ),
                  confirm: OutlinedButton(
                    onPressed: () => controller.logout(),
                    child: const Text('Yakin'),
                  ),
                  cancel: ElevatedButton(
                    onPressed: () => Get.back(),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: green,
                    ),
                    child: const Text('Batalkan'),
                  ));
            },
            icon: const Icon(Icons.logout),
          ),
        ],
        body: Obx(() {
          if (controller.isLoadingProfile) {
            return const Center(
                child: CircularProgressIndicator(
              color: green,
            ));
          } else {
            final profile = controller.profile;
            return ListView(children: [
              const SizedBox(height: 16),
              Center(
                child: ExtendedImage.network(
                  profile?.urlPhoto ??
                      'https://cdn.zeplin.io/5b7fae5548786d06c2cfd58a/assets/2450c94b-5e8e-435e-bb13-55827a8d4bd9.png',
                  cache: true,
                  width: 103,
                  height: 103,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: _section(context, title: 'INFORMASI PENGGUNA',
                    onTapEdit: () async {
                  final updated = await Get.toNamed(
                    AkunEditPage.routeName,
                    arguments: controller.profile,
                  );
                  if (updated) controller.retrieveProfile();
                }),
              ),
              ComponentTile(
                title: 'Nama',
                value: profile?.name ?? '',
              ),
              ComponentTile(
                title: 'No. Handphone',
                value: profile?.phone ?? '',
              ),
              ComponentTile(
                title: 'Alamat',
                value: profile?.address.address ?? '',
              ),
              ComponentTile(
                title: 'Kota / Kabupaten',
                value: profile?.address.district ?? '',
              ),
              ComponentTile(
                title: 'Email',
                value: profile?.email ?? '',
              ),
              const SizedBox(height: 24),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: _section(context,
                    title: 'KEAMANAN',
                    onTapEdit: () => Get.toNamed(PasswordEditPage.routeName)),
              ),
              const ComponentTile(title: 'Password', value: '********'),
              const SizedBox(height: 24,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: _section(context,
                    title: 'PASSCODE',
                    onTapEdit: () => Get.toNamed(PasscodeEditPage.routeName)),
              ),
              const ComponentTile(title: 'Passcode', value: '******'),
              const SizedBox(height: 30),
              Center(
                child: Text(
                  'V${controller.appVer.text}',
                  style: const TextStyle(color: Colors.grey),
                ),
              ),
              const SizedBox(height: 50),
            ]);
          }
        }),
      );

  Widget _section(BuildContext context,
          {required String title, VoidCallback? onTapEdit}) =>
      Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Text(title,
                    style: GoogleFonts.roboto(
                        color: black,
                        fontSize: 16,
                        fontWeight: FontWeight.bold)),
              ),
              GestureDetector(
                  onTap: onTapEdit,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(36),
                      color: yellowDark,
                    ),
                    child: Center(
                        child: Text('EDIT',
                            style: GoogleFonts.roboto(
                                color: black,
                                fontSize: 12,
                                fontWeight: FontWeight.bold))),
                  ))
            ],
          ),
          const SizedBox(height: 12),
          const Divider(color: greyE5, height: 0)
        ],
      );
}
