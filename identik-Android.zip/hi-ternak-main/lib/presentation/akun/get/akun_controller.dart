import 'dart:async';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:hive/hive.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../../../data/models/account/account_model.dart';
import '../../../data/repositories/address_repository.dart';
import '../../../data/repositories/authentication_repository.dart';
import '../../../data/repositories/buku_lahir_repository.dart';
import '../../../data/repositories/combo_repository.dart';
import '../../../data/repositories/inseminasi_repository.dart';
import '../../../data/repositories/kandang_repository.dart';
import '../../../data/repositories/owner_repository.dart';
import '../../../data/repositories/unit_usaha_repository.dart';
import '../../login/pages/login_page.dart';

class AkunController extends GetxController {
  final AuthenticationRepository _authRepository;
  final AddressRepository _addressRepository;
  final BukuLahirRepository _bukuLahirRepository;
  final ComboRepository _comboRepository;
  final InseminasiRepository _inseminasiRepository;
  final UnitUsahaRepository _unitUsahaRepository;
  final OwnerRepository _ownerRepository;
  final KandangRepository _kandangRepository;

  AkunController({
    required AddressRepository addressRepository,
    required BukuLahirRepository bukuLahirRepository,
    required ComboRepository comboRepository,
    required InseminasiRepository inseminasiRepository,
    required AuthenticationRepository authRepository,
    required UnitUsahaRepository unitUsahaRepository,
    required OwnerRepository ownerRepository,
    required KandangRepository kandangRepository,
  })  : _authRepository = authRepository,
        _addressRepository = addressRepository,
        _bukuLahirRepository = bukuLahirRepository,
        _comboRepository = comboRepository,
        _inseminasiRepository = inseminasiRepository,
        _unitUsahaRepository = unitUsahaRepository,
        _ownerRepository = ownerRepository,
        _kandangRepository = kandangRepository;

  final _profile = Rx<AccountModel?>(null);
  final _isLoadingProfile = true.obs;
  final _isOnSync = false.obs;
  var appVer = TextEditingController();

  AccountModel? get profile => _profile.value;
  bool get isLoadingProfile => _isLoadingProfile.value;
  bool get isOnSync => _isOnSync.value;

  @override
  void onReady() {
    super.onReady();
    retrieveProfile();
    getAppVersion();
  }

  void logout() async {
    await Hive.deleteFromDisk();
    Get.offAllNamed(LoginPage.routeName);
  }

  void retrieveProfile() async {
    _isLoadingProfile.value = true;
    _profile.value = await _authRepository.account();
    _isLoadingProfile.value = false;
  }

  Future<void> sync() async {
    _isOnSync.value = true;
    await _bukuLahirRepository.unsyncLahirInduk();
    await _bukuLahirRepository.syncLahirInduk();

    await _comboRepository.unsyncCombo();
    await _comboRepository.syncCombo();

    await _inseminasiRepository.unsyncIndukJantan();
    await _inseminasiRepository.syncIndukJantan();

    await _addressRepository.unsyncAddress();
    await _addressRepository.syncAddress();

    await _kandangRepository.unsyncAllKomoditas;
    await _kandangRepository.syncAllKomoditas;

    await _ownerRepository.unsycOwners;
    await _ownerRepository.syncOwners;

    await _unitUsahaRepository.unsyncAllUnitUsaha;
    await _unitUsahaRepository.syncAllUnitUsaha;

    await _kandangRepository.unsyncAllKandang;
    await _kandangRepository.syncAllKandang;

    _isOnSync.value = false;
  }

  Future<void> getAppVersion() async {
    final packageInfo = await PackageInfo.fromPlatform();
    final currVersion = packageInfo.version.toString();

    appVer.text = currVersion;

    return;
  }
}
