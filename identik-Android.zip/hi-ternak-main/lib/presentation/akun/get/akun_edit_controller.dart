import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' hide FormData, MultipartFile;
import 'package:image_picker/image_picker.dart';

import '../../../data/models/account/account_model.dart';
import '../../../data/models/address/district_model.dart';
import '../../../data/repositories/address_repository.dart';
import '../../../data/repositories/setting_repository.dart';
import '../../../utils/location_util.dart';
// import '../../../utils/validation_util.dart';

class AkunEditController extends GetxController {
  final AddressRepository _addressRepository;
  final SettingRepository _settingRepository;

  AkunEditController({
    required AddressRepository addressRepository,
    required SettingRepository settingRepository,
  })  : _addressRepository = addressRepository,
        _settingRepository = settingRepository;

  final etPhoto = TextEditingController();
  final etName = TextEditingController();
  final etPhone = TextEditingController();
  final etDistrict = TextEditingController();
  final etEmail = TextEditingController();
  final etAddress = TextEditingController();
  final imagePicker = ImagePicker();
  final formKey = GlobalKey<FormState>();

  final _selectedDistrict = Rx<DistrictModel?>(null);
  final _districts = Rx<List<DistrictModel>>([]);
  final _isLoadingDistricts = false.obs;
  final _selectedPhoto = Rx<XFile?>(null);
  final latitude = 0.0.obs;
  final longitude = 0.0.obs;

  DistrictModel? get selectedDistrict => _selectedDistrict.value;
  List<DistrictModel> get districts => _districts.value;
  bool get isLoadingDistricts => _isLoadingDistricts.value;
  XFile? get selectedPhoto => _selectedPhoto.value;

  @override
  void onInit() async {
    super.onInit();
    await retrieveDistricts;
    retrieveArgs;
  }

  void get retrieveArgs {
    final args = Get.arguments;
    if (args is AccountModel) {
      etName.text = args.name;
      etPhone.text = args.phone;
      etEmail.text = args.email;
      etAddress.text = args.address.address;

      final searchDistrcit =
          districts.where((element) => element.id == args.address.idDistrict);
      if (searchDistrcit.isNotEmpty) {
        etDistrict.text = searchDistrcit.first.district;
        _selectedDistrict.value = searchDistrcit.first;
      }
    }
  }

  Future<void> get retrieveDistricts async {
    _isLoadingDistricts.value = true;
    final districts = await _addressRepository.onlyDistricts;
    _districts.value = districts;
    _isLoadingDistricts.value = false;
  }

  void setDistrict(DistrictModel district) {
    _selectedDistrict.value = district;
    etDistrict.text = district.district;
    Get.back();
  }

  void setPhoto(XFile? file) {
    _selectedPhoto.value = file;
    etPhoto.text = file?.name ?? '-';
    Get.back();
  }

  void getCurrentLocation() async {
    final currentLocation = await LocationUtil.currentLocation;
    if (currentLocation != null) {
      latitude.value = currentLocation.latitude;
      longitude.value = currentLocation.longitude;
    }
  }

  Future<void> save() async {
    if (formKey.currentState?.validate() == false) {
      return;
    }

    final payload = FormData.fromMap({
      'name': etName.text,
      'phone': etPhone.text,
      'email': etEmail.text,
      'id_district': _selectedDistrict.value?.id,
      'address': etAddress.text,
      'zip_code': null,
      'latitude': latitude.value.toString(),
      'longitude': longitude.value.toString(),
    });

    if (_selectedPhoto.value != null) {
      final multipartFile =
          await MultipartFile.fromFile(_selectedPhoto.value!.path);
      payload.files.add(MapEntry('path_photo', multipartFile));
    }

    try {
      final response = await _settingRepository.updateProfile(payload);
      if (response) {
        Get.back(result: true);
        Get.showSnackbar(const GetSnackBar(
          message: 'Perubahan Data Profile Berhasil',
          duration: Duration(seconds: 3),
        ));
      } else {
        Get.showSnackbar(const GetSnackBar(
          message: 'Perubahan Data Profile Gagal',
          duration: Duration(seconds: 3),
        ));
      }
    } catch (error) {
      // Get.showSnackbar(GetSnackBar(
      //   message: ValidationUtil.errorMessage(error as DioError),
      //   duration: const Duration(seconds: 3),
      // ));
      Get.showSnackbar(const GetSnackBar(
        message: 'Perubahan Data Profile Gagal',
        duration: Duration(seconds: 3),
      ));
    }
  }
}
