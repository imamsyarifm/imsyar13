import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/address_repository.dart';
import '../../../data/repositories/authentication_repository.dart';
import '../../../data/repositories/buku_lahir_repository.dart';
import '../../../data/repositories/combo_repository.dart';
import '../../../data/repositories/inseminasi_repository.dart';
import '../../../data/repositories/kandang_repository.dart';
import '../../../data/repositories/owner_repository.dart';
import '../../../data/repositories/unit_usaha_repository.dart';
import 'akun_controller.dart';

class AkunBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(AuthenticationRepository(
      dio: Get.find<Dio>(),
    ));

    Get.put(AddressRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(BukuLahirRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(ComboRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(InseminasiRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(UnitUsahaRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(OwnerRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(KandangRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(AkunController(
      authRepository: Get.find<AuthenticationRepository>(),
      addressRepository: Get.find<AddressRepository>(),
      bukuLahirRepository: Get.find<BukuLahirRepository>(),
      comboRepository: Get.find<ComboRepository>(),
      inseminasiRepository: Get.find<InseminasiRepository>(),
      ownerRepository: Get.find<OwnerRepository>(),
      unitUsahaRepository: Get.find<UnitUsahaRepository>(),
      kandangRepository: Get.find<KandangRepository>(),
    ));
  }
}
