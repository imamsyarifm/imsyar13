import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/address_repository.dart';
import '../../../data/repositories/setting_repository.dart';
import 'akun_edit_controller.dart';

class AkunEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(AddressRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(SettingRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(AkunEditController(
      addressRepository: Get.find<AddressRepository>(),
      settingRepository: Get.find<SettingRepository>(),
    ));
  }
}
