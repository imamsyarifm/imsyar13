import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../data/models/ternak/identity_ternak_model.dart';
import '../pages/offline_ternak_page.dart';

class OfflineTernakController extends GetxController {
  final form = GlobalKey<FormState>();
  final etCode = TextEditingController();
  final etLocation = TextEditingController();
  final etNumber = TextEditingController();
  late OfflineTernakParams params;

  @override
  void onInit() {
    retrieveParams();
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
    defaultValue();
  }

  void defaultValue() {
    etCode.text = 'AAA';
    etLocation.text = '00';
    etNumber.text = '0000000000';
  }

  void retrieveParams() {
    final args = Get.arguments;
    if (args is OfflineTernakParams) {
      params = args;
    }
  }

  void setCode(String value) {
    etCode.text = value;
  }

  void setLocation(String value) {
    etLocation.text = value;
  }

  void setNumber(String value) {
    etNumber.text = value;
  }

  String get result {
    return '${etCode.text} ${etLocation.text} ${etNumber.text}';
  }

  String? validator(int length, String? value) {
    if (value == null) {
      return 'Tidak boleh kosong, harap isi minimal $length karakter';
    } else if (value.length < length) {
      return 'Harap isi minimal $length karakter';
    } else {
      return null;
    }
  }

  void save() {
    final model = IdentityTernakModel(
      idEartag: result,
      codeProduct: result,
    );
    params.onScanned?.call(model);
  }
}
