import 'package:get/get.dart';

import 'offline_ternak_controller.dart';

class OfflineTernakBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(OfflineTernakController());
  }
}
