import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../get/offline_ternak_controller.dart';

class OfflineTernakPage extends GetView<OfflineTernakController> {
  static const routeName = '/offline-ternak';

  const OfflineTernakPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: green,
        title: const Text('Eartag Ternak'),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Form(
          key: controller.form,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          child: ListView(
            children: [
              const SizedBox(
                height: 50,
              ),
              TextFormField(
                controller: controller.etCode,
                maxLength: 3,
                validator: (value) => controller.validator(3, value),
              ),
              const SizedBox(
                height: 16,
              ),
              TextFormField(
                controller: controller.etLocation,
                maxLength: 2,
                validator: (value) => controller.validator(2, value),
              ),
              const SizedBox(
                height: 16,
              ),
              TextFormField(
                controller: controller.etNumber,
                maxLength: 10,
                validator: (value) => controller.validator(10, value),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: buildBottom(context),
    );
  }

  Widget buildBottom(BuildContext context) {
    final paddingBottom = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: paddingBottom,
      ),
      child: ElevatedButton(
        onPressed: () => controller.save(),
        style: ElevatedButton.styleFrom(
          backgroundColor: green,
        ),
        child: const Text('Simpan'),
      ),
    );
  }
}

class OfflineTernakParams {
  final bool isTransaction;
  final bool isProduksiSusu;
  final bool isPublic;
  final Function(IdentityTernakModel)? onScanned;

  OfflineTernakParams({
    this.isTransaction = true,
    this.isProduksiSusu = false,
    this.isPublic = false,
    this.onScanned,
  });
}
