import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../app/consts/colors.dart';
import '../../utils/validation_util.dart';
import '../widgets/default_scaffold.dart';
import '../widgets/edit_text.dart';
import 'password_edit_controller.dart';

class PasswordEditPage extends GetView<PasswordEditController> {
  const PasswordEditPage({Key? key}) : super(key: key);

  static const routeName = '/password-edit';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Edit Password',
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: controller.formKey,
            child: ListView(
              children: [
                const SizedBox(height: 16),
                EditText(
                  label: 'Password Baru*',
                  controller: controller.etNewPassword,
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Password Baru', value),
                  isSecret: true,
                ),
                const SizedBox(height: 16),
                EditText(
                  label: 'Password Baru (sekali lagi)*',
                  controller: controller.etConfirmPassword,
                  validator: (value) => ValidationUtil.emptyValidate(
                      'Konfirmasi Password', value),
                  isSecret: true,
                )
              ],
            ),
          ),
        ),
        bottomNavigation: Container(
          color: Colors.white,
          child: Row(children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 12, top: 12, bottom: 12, right: 6),
                child: SizedBox(
                  height: 40,
                  child: ElevatedButton(
                      onPressed: () => Get.back(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(36))),
                      child: Text(
                        'BATAL',
                        style: GoogleFonts.roboto(
                            color: black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      )),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                    right: 12, top: 12, bottom: 12, left: 6),
                child: SizedBox(
                  height: 40,
                  child: ElevatedButton(
                      onPressed: () => controller.changePassword(),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: yellowDark,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(36))),
                      child: Text(
                        'SIMPAN',
                        style: GoogleFonts.roboto(
                            color: black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      )),
                ),
              ),
            ),
          ]),
        ),
      );
}
