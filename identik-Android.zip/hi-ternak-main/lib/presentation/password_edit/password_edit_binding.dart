import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../data/repositories/authentication_repository.dart';
import 'password_edit_controller.dart';

class PasswordEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(AuthenticationRepository(
      dio: Get.find<Dio>(),
    ));

    Get.put(PasswordEditController(
      repository: Get.find<AuthenticationRepository>(),
    ));
  }
}
