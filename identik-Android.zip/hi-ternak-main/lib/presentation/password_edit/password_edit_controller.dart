// import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../data/models/change_password/change_password_request.dart';
import '../../data/repositories/authentication_repository.dart';
// import '../../utils/validation_util.dart';
import '../main/main_page.dart';

class PasswordEditController extends GetxController {
  PasswordEditController({
    required AuthenticationRepository repository,
  }) : _repository = repository;

  final AuthenticationRepository _repository;

  final formKey = GlobalKey<FormState>();
  final etNewPassword = TextEditingController();
  final etConfirmPassword = TextEditingController();

  void changePassword() async {
    if (formKey.currentState?.validate() == false) {
      return;
    }

    final newPass = etNewPassword.text;
    final confirmPass = etConfirmPassword.text;

    if (newPass != confirmPass) {
      Get.showSnackbar(const GetSnackBar(
        message: 'Terdapat perbedaan antara password baru dengan '
            'konfirmasi password, harap cek kembali',
        duration: Duration(seconds: 3),
      ));
      return;
    }

    final payload = ChangePasswordRequest(
      password: etNewPassword.text,
      confirmPassword: etConfirmPassword.text,
    );

    try {
      final response = await _repository.changePassword(payload);
      if (response) {
        Get.offAllNamed(MainPage.routeName);
        Get.showSnackbar(const GetSnackBar(
          message: 'Perubahan Password Berhasil',
          duration: Duration(seconds: 3),
        ));
      } else {
        Get.showSnackbar(const GetSnackBar(
          message: 'Perubahan Password Gagal',
          duration: Duration(seconds: 3),
        ));
      }
    } catch (error) {
      // Get.showSnackbar(GetSnackBar(
      //   message: ValidationUtil.errorMessage(error as DioError),
      //   duration: const Duration(seconds: 3),
      // ));
      Get.showSnackbar(const GetSnackBar(
        message: 'Perubahan Password Gagal',
        duration: Duration(seconds: 3),
      ));
    }
  }
}
