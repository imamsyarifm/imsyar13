import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/kandang/kandang_model.dart';
import '../../../data/repositories/kandang_repository.dart';
import '../pages/kandang_detail_page.dart';

class KandangSearchDelegate extends SearchDelegate {
  KandangSearchDelegate({
    this.isForm = false,
  });

  final bool isForm;

  final repository = KandangRepository(
    client: Get.find<Dio>(),
  );

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          query = '';
        },
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () {
        Get.back();
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return FutureBuilder<List<KandangModel>>(
      future: repository.all(query: query),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          return ListView.builder(
            itemCount: snapshot.data?.length ?? 0,
            itemBuilder: (context, index) {
              final kandang = snapshot.data![index];
              return Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 8),
                child: GestureDetector(
                  onTap: () async {
                    if (isForm) {
                      Get.back(result: kandang);
                    } else {
                      await Get.toNamed(
                        KandangDetailPage.routeName,
                        arguments: kandang,
                      );
                    }
                  },
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                              child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(kandang.namaKandang,
                                  style: GoogleFonts.roboto(
                                      fontWeight: FontWeight.bold)),
                              Text(kandang.pemilikKandang?.name ?? '-'),
                              Text(kandang.kodeFarm != ''
                                  ? kandang.kodeFarm
                                  : '-'),
                              Text(
                                  '${kandang.address.province}, '
                                  '${kandang.address.district}, '
                                  '${kandang.address.subDistrict}',
                                  style: GoogleFonts.roboto(color: grey8))
                            ],
                          )),
                          const Icon(Icons.arrow_right)
                        ],
                      ),
                      const Divider(color: greyE5)
                    ],
                  ),
                ),
              );
            },
          );
        } else {
          return const Center(
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(green),
            ),
          );
        }
      },
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return const Center(
      child: Text('Harap masukan kata kunci'),
    );
  }
}
