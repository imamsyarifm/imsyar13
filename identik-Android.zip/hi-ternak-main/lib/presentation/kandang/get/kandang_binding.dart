import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/kandang_repository.dart';
import 'kandang_controller.dart';

class KandangBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(KandangRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(KandangController(
      repository: Get.find<KandangRepository>(),
    ));
  }
}
