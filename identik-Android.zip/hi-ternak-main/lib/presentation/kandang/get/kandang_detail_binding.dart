import 'package:get/get.dart';

import 'kandang_detail_controller.dart';

class KandangDetailBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(KandangDetailController());
  }
}
