import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../data/models/address/district_model.dart';
import '../../../data/models/address/province_model.dart';
import '../../../data/models/address/subdistrict_model.dart';
import '../../../data/models/address/village_model.dart';
import '../../../data/models/combo/combo_model.dart';
import '../../../data/models/kandang/add_kandang_address_request_model.dart';
import '../../../data/models/kandang/add_kandang_request_model.dart';
import '../../../data/models/kandang/kandang_model.dart';
import '../../../data/models/kandang/komoditas_model.dart';
import '../../../data/models/owner/owner_model.dart';
import '../../../data/repositories/address_repository.dart';
import '../../../data/repositories/combo_repository.dart';
import '../../../data/repositories/kandang_repository.dart';
import '../../../data/repositories/owner_repository.dart';
import '../../../data/repositories/setting_repository.dart';
import '../../../utils/datetime_util.dart';
import '../../../utils/location_util.dart';
import '../pages/kandang_page.dart';

class KandangEditController extends GetxController {
  final AddressRepository _addressRepository;
  final ComboRepository _comboRepository;
  final KandangRepository _kandangRepository;
  final OwnerRepository _ownerRepository;
  final SettingRepository _settingRepository;

  KandangEditController({
    required AddressRepository addressRepository,
    required ComboRepository comboRepository,
    required KandangRepository kandangRepository,
    required OwnerRepository ownerRepository,
    required SettingRepository settingRepository,
  })  : _addressRepository = addressRepository,
        _comboRepository = comboRepository,
        _kandangRepository = kandangRepository,
        _ownerRepository = ownerRepository,
        _settingRepository = settingRepository;

  final formKey = GlobalKey<FormState>();
  final etNamaKandang = TextEditingController();
  final etPemilik = TextEditingController();
  final etKapasitas = TextEditingController();
  final etTglPembangunan = TextEditingController();
  final etWorkArea = TextEditingController();
  final etKecamatan = TextEditingController();
  final etDesa = TextEditingController();
  final etAlamat = TextEditingController();
  final etKomoditas = TextEditingController();

  final _selectedStatusKandang = Rx<ComboModel?>(null);
  final _selectedPemilik = Rx<OwnerModel?>(null);
  final _provinces = Rx<List<ProvinceModel>>([]);
  final _districts = Rx<List<DistrictModel>>([]);
  final _subDistricts = Rx<List<SubdistrictModel>>([]);
  final _villages = Rx<List<VillageModel>>([]);
  final _selectedProvinsi = Rx<ProvinceModel?>(null);
  final _selectedKabupaten = Rx<DistrictModel?>(null);
  final _selectedKecamatan = Rx<SubdistrictModel?>(null);
  final _selectedDesa = Rx<VillageModel?>(null);
  final _selectedKomoditas = Rx<KomoditasModel?>(null);
  final _owners = Rx<List<OwnerModel>>([]);
  final _allStatus = Rx<List<ComboModel>>([]);
  final _isLoadingSubDistricts = false.obs;
  final _isLoadingVillages = false.obs;
  final _isLoadingProvinces = false.obs;
  final _isLoadingDistricts = false.obs;
  final _isLoadingOwners = false.obs;
  final _isLoadingStatus = false.obs;
  final _isUpdatingData = false.obs;
  final _isSameWithOwner = false.obs;
  final _isLoadingKomoditas = false.obs;
  final latitude = 0.0.obs;
  final longitude = 0.0.obs;
  final _kandang = Rx<KandangModel?>(null);
  final _komoditas = Rx<List<KomoditasModel>>([]);

  ComboModel? get selectedStatusKandang => _selectedStatusKandang.value;
  OwnerModel? get selectedPemilik => _selectedPemilik.value;
  ProvinceModel? get selectedProvinsi => _selectedProvinsi.value;
  DistrictModel? get selectedKabupaten => _selectedKabupaten.value;
  SubdistrictModel? get selectedKecamatan => _selectedKecamatan.value;
  VillageModel? get selectedDesa => _selectedDesa.value;
  List<ProvinceModel> get provinces => _provinces.value;
  List<DistrictModel> get districts => _districts.value;
  List<SubdistrictModel> get subDistricts => _subDistricts.value;
  List<VillageModel> get villages => _villages.value;
  List<OwnerModel> get owners => _owners.value;
  List<ComboModel> get allStatus => _allStatus.value;
  bool get isLoadingProvinces => _isLoadingProvinces.value;
  bool get isLoadingDistricts => _isLoadingDistricts.value;
  bool get isLoadingSubDistricts => _isLoadingSubDistricts.value;
  bool get isLoadingVillages => _isLoadingVillages.value;
  bool get isLoadingOwners => _isLoadingOwners.value;
  bool get isLoadingStatus => _isLoadingStatus.value;
  bool get isUpdatingData => _isUpdatingData.value;
  bool get isSameWithOwner => _isSameWithOwner.value;
  KandangModel? get kandang => _kandang.value;
  List<KomoditasModel> get allKomoditas => _komoditas.value;

  @override
  Future<void> onReady() async {
    super.onReady();

    getCurrentLocation();

    /// Indonesian id is 1
    await retrieveProvinces(1);
    await retrieveStatus;
    await retrieveArgs;
    await retrieveKomoditas;
  }

  Future<void> get retrieveArgs async {
    final args = Get.arguments;
    if (args is KandangModel) {
      _kandang.value = args;
      await retrieveOwners(_kandang.value?.pemilikKandang?.nik);
      await fillFormUpdate(args);
    } else {
      await initialAddData();
    }
  }

  Future<void> initialAddData() async {
    final searchStatus =
        _allStatus.value.where((element) => element.value == 'individu');
    if (searchStatus.isNotEmpty) {
      _selectedStatusKandang.value = searchStatus.first;
    }

    final defaultProvince = await _settingRepository.defaultProvince;
    final searchProvince =
        _provinces.value.where((element) => element.id == defaultProvince);
    if (searchProvince.isNotEmpty) {
      await setProvinsi(
        value: searchProvince.first,
        isInitial: true,
      );
    }

    final defaultDistrict = await _settingRepository.defaultDistrict;
    final searchDistrict =
        _districts.value.where((element) => element.id == defaultDistrict);
    if (searchDistrict.isNotEmpty) {
      await setKabupaten(
        value: searchDistrict.first,
        isInitial: true,
      );
    }
  }

  Future<void> fillFormUpdate(KandangModel kandang) async {
    etNamaKandang.text = kandang.namaKandang;

    final searchStatusKandang = _allStatus.value
        .where((element) => element.value == kandang.statusKandang)
        .toList();
    if (searchStatusKandang.isNotEmpty) {
      _selectedStatusKandang.value = searchStatusKandang.first;
    }

    final searchOwner = _owners.value
        .where((element) => element.id == kandang.pemilikKandang?.id);
    if (searchOwner.isNotEmpty) {
      setPemilik(searchOwner.first);
    }

    etKapasitas.text = kandang.kapasitas;
    etTglPembangunan.text = kandang.tanggalDibangun.readable();

    final searchProvince = _provinces.value
        .where((element) => element.id == kandang.address.idProvince);
    if (searchProvince.isNotEmpty) {
      await setProvinsi(value: searchProvince.first, isInitial: true);
    }

    final searchDistrict = _districts.value
        .where((element) => element.id == kandang.address.idDistrict);
    if (searchDistrict.isNotEmpty) {
      await setKabupaten(value: searchDistrict.first, isInitial: true);
    }

    final searchSubDistrict = _subDistricts.value
        .where((element) => element.id == kandang.address.idSubDistrict);
    if (searchSubDistrict.isNotEmpty) {
      _selectedKecamatan.value = searchSubDistrict.first;
      etKecamatan.text = _selectedKecamatan.value?.subDistrict ?? '-';
      await retrieveVillages(_selectedKecamatan.value!.id);
    }

    final searchVillage = _villages.value
        .where((element) => element.id == kandang.address.idVillage);
    if (searchVillage.isNotEmpty) {
      _selectedDesa.value = searchVillage.first;
      etDesa.text = _selectedDesa.value?.urbanVillage ?? '-';
    }

    etAlamat.text = kandang.address.address;
    latitude.value = double.parse(kandang.address.latitude);
    longitude.value = double.parse(kandang.address.longitude);

    setSameWithOwner(kandang.isEqual == '1');

    await retrieveKomoditas;
    final searchKomoditas = _komoditas.value
        .where((element) => element.komoditas == kandang.komoditas);
    if (searchKomoditas.isNotEmpty) {
      _selectedKomoditas.value = searchKomoditas.first;
      etKomoditas.text = _selectedKomoditas.value?.keterangan ?? '-';
    }
  }

  void setPemilik(OwnerModel value) {
    _selectedPemilik.value = value;
    etPemilik.text = value.name;
  }

  Future<void> retrieveProvinces(int idCountry) async {
    _isLoadingProvinces.value = true;
    final provinces = await _addressRepository.provinces(idCountry);
    _provinces.value = provinces;
    _isLoadingProvinces.value = false;
  }

  Future<void> retrieveDistricts(String idProvince) async {
    _isLoadingDistricts.value = true;
    final districts = await _addressRepository.districts(idProvince);
    _districts.value = districts;
    _isLoadingDistricts.value = false;
  }

  Future<void> retrieveSubDistricts(String idDistrict) async {
    _isLoadingSubDistricts.value = true;
    final subDistricts = await _addressRepository.subDistricts(idDistrict);
    _subDistricts.value = subDistricts;
    _isLoadingSubDistricts.value = false;
  }

  Future<void> retrieveVillages(String idSubDistrict) async {
    _isLoadingVillages.value = true;
    final villages = await _addressRepository.villages(idSubDistrict);
    _villages.value = villages;
    _isLoadingVillages.value = false;
  }

  Future<void> setProvinsi({
    required ProvinceModel value,
    bool isInitial = false,
  }) async {
    _selectedProvinsi.value = value;
    await retrieveDistricts(value.id);
    if (!isInitial) Get.back();
  }

  Future<void> setKabupaten({
    required DistrictModel value,
    bool isInitial = false,
  }) async {
    _selectedKabupaten.value = value;
    await retrieveSubDistricts(value.id);
    if (!isInitial) Get.back();
  }

  Future<void> setKecamatan(SubdistrictModel value) async {
    _selectedKecamatan.value = value;
    etKecamatan.text = value.subDistrict;
    await retrieveVillages(value.id);
    etDesa.clear();
    _selectedDesa.value = null;
    Get.back();
  }

  void setDesa(VillageModel value) {
    _selectedDesa.value = value;
    etDesa.text = value.urbanVillage;
    Get.back();
  }

  void getCurrentLocation() async {
    final currentLocation = await LocationUtil.currentLocation;
    if (currentLocation != null) {
      latitude.value = currentLocation.latitude;
      longitude.value = currentLocation.longitude;
    }
  }

  Future<void> retrieveOwners(String? query) async {
    _isLoadingOwners.value = true;
    final owners = await _ownerRepository.owners(query: query);
    _owners.value = owners;
    _isLoadingOwners.value = false;
  }

  Future<void> get retrieveKomoditas async {
    _isLoadingKomoditas.value = true;
    final komoditas = await _kandangRepository.komoditas;
    _komoditas.value = komoditas;
    _isLoadingKomoditas.value = false;
  }

  Future<void> get retrieveStatus async {
    _isLoadingStatus.value = true;
    final status = await _comboRepository.kandangStatus;
    _allStatus.value = status;
    _isLoadingStatus.value = false;
  }

  bool get isAnyMissingForm {
    if (etNamaKandang.text.isEmpty) return true;
    if (_selectedPemilik.value == null) return true;
    if (etKapasitas.text.isEmpty) return true;

    return false;
  }

  void updateDataKandang() async {
    _isUpdatingData.value = true;
    if (isAnyMissingForm) {
      _isUpdatingData.value = false;
      return;
    }

    final addressRequest = AddKandangAddressRequestModel(
      idProvince: _selectedProvinsi.value?.id.toString(),
      idDistrict: _selectedKabupaten.value?.id.toString(),
      idSubDistrict: _selectedKecamatan.value?.id.toString(),
      idVillage: _selectedDesa.value?.id.toString(),
      address: etAlamat.text,
      latitude: latitude.value.toString(),
      longitude: longitude.value.toString(),
    );

    if (_kandang.value == null) {
      insert(addressRequest);
    } else {
      edit(_kandang.value!.id, addressRequest);
    }

    _isUpdatingData.value = false;
  }

  Future<void> setKomoditas({required KomoditasModel value}) async {
    _selectedKomoditas.value = value;
    etKomoditas.text = value.keterangan.toString();
    Get.back();
  }

  void insert(AddKandangAddressRequestModel address) async {
    final kandangRequest = AddKandangRequestModel(
      id: null,
      namaKandang: etNamaKandang.text,
      idPemilik: _selectedPemilik.value!.id,
      tanggalDibangun: DateTime.now(),
      kapasitas: etKapasitas.text,
      statusKandang: _selectedStatusKandang.value!.value,
      isEqual: (_isSameWithOwner.value) ? '1' : '0',
      address: address,
      komoditasId: _selectedKomoditas.value!.id.toString(),
    );

    final update = await _kandangRepository.insert(kandangRequest);
    if (update) {
      Get.until((route) => route.settings.name == KandangPage.routeName);
      Get.showSnackbar(const GetSnackBar(
        message: 'Penambahan Data Kandang Berhasil',
        duration: Duration(seconds: 3),
      ));
    } else {
      Get.showSnackbar(const GetSnackBar(
        message: 'Penambahan Data Kandang Gagal',
        duration: Duration(seconds: 3),
      ));
    }
  }

  void edit(String idKandang, AddKandangAddressRequestModel address) async {
    final kandangRequest = AddKandangRequestModel(
      id: idKandang,
      namaKandang: etNamaKandang.text,
      idPemilik: _selectedPemilik.value!.id,
      tanggalDibangun: _kandang.value?.tanggalDibangun ?? DateTime.now(),
      kapasitas: etKapasitas.text,
      statusKandang: _selectedStatusKandang.value!.value,
      isEqual: (_isSameWithOwner.value) ? '1' : '0',
      address: address,
      komoditasId: _selectedKomoditas.value!.id.toString(),
    );

    final update = await _kandangRepository.insert(kandangRequest);
    if (update) {
      Get.until((route) => route.settings.name == KandangPage.routeName);
      Get.showSnackbar(const GetSnackBar(
        message: 'Perubahan Data Kandang Berhasil',
        duration: Duration(seconds: 3),
      ));
    } else {
      Get.showSnackbar(const GetSnackBar(
        message: 'Perubahan Data Kandang Gagal',
        duration: Duration(seconds: 3),
      ));
    }
  }

  void setSameWithOwner(bool? value) async {
    if (value != null) {
      _isSameWithOwner.value = value;
      if (value == true) {
        final address = _selectedPemilik.value?.address;
        // print(address!.district);
        await retrieveSubDistricts(address!.idDistrict);
        final searchSubDistrict = _subDistricts.value
            .where((element) => element.id == address.idSubDistrict);
        if (searchSubDistrict.isNotEmpty) {
          _selectedKecamatan.value = searchSubDistrict.first;
          etKecamatan.text = _selectedKecamatan.value?.subDistrict ?? '-';
        }
      }
    }
  }

  String get ownerAddress {
    final address = _selectedPemilik.value?.address;
    final fullAddress = address?.address;
    final rt = address?.rt;
    final rw = address?.rw;
    final village = address?.urbanVillage;
    final subDistrict = address?.subDistrict;
    final district = address?.district;
    final province = address?.province;
    return '$fullAddress RT $rt RW $rw, $village, $subDistrict, $district, '
        '$province';
  }
}
