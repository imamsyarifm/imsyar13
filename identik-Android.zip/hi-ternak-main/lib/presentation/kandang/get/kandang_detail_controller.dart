import 'package:get/get.dart';

import '../../../data/models/kandang/kandang_model.dart';

class KandangDetailController extends GetxController {
  final _kandang = Rx<KandangModel?>(null);

  KandangModel? get kandang => _kandang.value;

  @override
  void onReady() {
    super.onReady();
    retrieveArgs;
  }

  void get retrieveArgs {
    final args = Get.arguments;
    if (args is KandangModel) {
      _kandang.value = args;
    }
  }

  String get address {
    final kandang = _kandang.value!.address;
    return '${kandang.address} '
        'RT ${kandang.rt}'
        'RW ${kandang.rw}'
        '${kandang.district}';
  }
}
