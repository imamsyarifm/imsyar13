import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/address_repository.dart';
import '../../../data/repositories/combo_repository.dart';
import '../../../data/repositories/kandang_repository.dart';
import '../../../data/repositories/owner_repository.dart';
import '../../../data/repositories/setting_repository.dart';
import 'kandang_edit_controller.dart';

class KandangEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(AddressRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(ComboRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(KandangRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(OwnerRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(SettingRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(KandangEditController(
      addressRepository: Get.find<AddressRepository>(),
      comboRepository: Get.find<ComboRepository>(),
      kandangRepository: Get.find<KandangRepository>(),
      ownerRepository: Get.find<OwnerRepository>(),
      settingRepository: Get.find<SettingRepository>(),
    ));
  }
}
