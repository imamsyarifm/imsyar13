import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/kandang/kandang_model.dart';
import '../../widgets/default_scaffold.dart';
import '../get/kandang_controller.dart';
import '../widgets/kandang_search_delegate.dart';
import 'kandang_detail_page.dart';
import 'kandang_edit_page.dart';

class KandangPage extends GetView<KandangController> {
  const KandangPage({Key? key}) : super(key: key);

  static const routeName = '/kandang';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Kandang',
        actions: [
          IconButton(
            onPressed: () => showSearch(
              context: context,
              delegate: KandangSearchDelegate(),
            ),
            icon: const Icon(Icons.search),
          ),
        ],
        body: PagedListView<int, KandangModel>(
          pagingController: controller.pagingController,
          builderDelegate: PagedChildBuilderDelegate<KandangModel>(
            itemBuilder: (context, item, index) {
              return Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 8),
                child: GestureDetector(
                  onTap: () async {
                    await Get.toNamed(
                      KandangDetailPage.routeName,
                      arguments: item,
                    );
                    controller.retrieveKandang;
                  },
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                              child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item.namaKandang,
                                style: GoogleFonts.roboto(
                                    fontWeight: FontWeight.bold),
                              ),
                              Text(item.pemilikKandang?.name ?? '-'),
                              Text(item.kodeFarm != '' ? item.kodeFarm : '-'),
                              Text(
                                  '${item.address.province}, '
                                  '${item.address.district}, '
                                  '${item.address.subDistrict}',
                                  style: GoogleFonts.roboto(color: grey8))
                            ],
                          )),
                          const Icon(Icons.arrow_right)
                        ],
                      ),
                      const Divider(color: greyE5)
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        floatingAction: Obx(
          () => Visibility(
            visible: controller.isConnectedToNetwork,
            replacement: const SizedBox.shrink(),
            child: FloatingActionButton(
              onPressed: () async {
                await Get.toNamed(KandangEditPage.routeName);
                controller.pagingController.refresh();
              },
              backgroundColor: green,
              child: const Icon(Icons.add),
            ),
          ),
        ),
      );
}
