import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../app/consts/colors.dart';
import '../../../app/consts/icons.dart';
import '../../../utils/datetime_util.dart';
import '../../widgets/component_tile.dart';
import '../../widgets/default_scaffold.dart';
import '../get/kandang_detail_controller.dart';
import 'kandang_edit_page.dart';

class KandangDetailPage extends GetView<KandangDetailController> {
  static const routeName = '/kandang-detail';

  const KandangDetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      if (controller.kandang == null) {
        return DefaultScaffold(
          appBarTitle: 'Detail Kandang',
          body: Container(
            color: Colors.white,
            child: const Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(green),
              ),
            ),
          ),
        );
      }

      return DefaultScaffold(
        appBarTitle: controller.kandang!.namaKandang,
        body: ListView(children: [
          ComponentTile(
              title: 'Kapasitas',
              value: '${controller.kandang!.kapasitas} ekor'),
          ComponentTile(
              title: 'Tanggal Dibangun',
              value: controller.kandang!.tanggalDibangun.readable()),
          ComponentTile(
              title: 'Status Kandang',
              value: controller.kandang!.statusKandang),
          ComponentTile(
              title: 'Kode Farm',
              value: controller.kandang!.kodeFarm),
          ComponentTile(
              title: 'Tanggal Terdaftar',
              value: controller.kandang!.createdAt.readable()),
          ComponentTile(title: 'Alamat', value: controller.address),
          ComponentTile(
              title: 'Nama Pemilik',
              value: controller.kandang?.pemilikKandang?.name ?? '-'),
          ComponentTile(
              title: 'NIK',
              value: controller.kandang?.pemilikKandang?.nik ?? '-'),
          ComponentTile(
              title: 'No. Telepon Pemilik',
              value: controller.kandang?.pemilikKandang?.phone ?? '-'),
          ComponentTile(
              title: 'Email Pemilik',
              value: controller.kandang?.pemilikKandang?.email ?? '-'),
          ComponentTile(
              title: 'Jenis Kelamin Pemilik',
              value: controller.kandang?.pemilikKandang?.gender ?? '-'),
          ComponentTile(
              title: 'Tanggal Lahir Pemilik',
              value:
                  controller.kandang?.pemilikKandang?.birthdate?.readable() ??
                      '-'),
          ComponentTile(
              title: 'Alamat',
              value: controller.kandang?.pemilikKandang?.alamat ?? '-'),
        ]),
        floatingAction: FloatingActionButton(
          backgroundColor: green,
          onPressed: () => Get.toNamed(KandangEditPage.routeName,
              arguments: controller.kandang),
          child:
              Image.asset(pencil, width: 16, height: 16, color: Colors.white),
        ),
      );
    });
  }
}
