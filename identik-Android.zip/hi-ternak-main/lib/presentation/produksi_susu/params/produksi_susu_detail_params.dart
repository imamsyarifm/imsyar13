import '../../../data/models/ternak/identity_kualitas_susu_model.dart';
import '../../../data/models/ternak/identity_produksi_susu_model.dart';
class ProduksiSusuDetailParams {
  final IdentityProduksiSusuModel produksiSusu;
  final IdentityKualitasSusuModel kualitasSusu;

  ProduksiSusuDetailParams({
    required this.produksiSusu,
    required this.kualitasSusu,
  });
}
