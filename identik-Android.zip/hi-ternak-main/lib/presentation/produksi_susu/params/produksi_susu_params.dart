import '../../../data/models/ternak/identity_ternak_model.dart';

class ProduksiSusuParams {
  final IdentityTernakModel ternak;
  final bool isFromScan;

  ProduksiSusuParams({
    required this.ternak,
    this.isFromScan = false,
  });
}
