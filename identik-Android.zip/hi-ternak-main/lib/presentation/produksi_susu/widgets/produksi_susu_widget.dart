import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../data/models/ternak/identity_produksi_susu_model.dart';
import '../../../utils/datetime_util.dart';
import '../../widgets/component_tile.dart';
import '../get/produksi_susu_detail_controller.dart';

class ProduksiSusuWidget extends GetWidget<ProduksiSusuDetailController> {
  final IdentityProduksiSusuModel produksiSusu;

  const ProduksiSusuWidget({
    Key? key,
    required this.produksiSusu,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) => Scaffold(
        body: ListView(children: [
          ComponentTile(
              title: 'Laktasi Ke', value: produksiSusu.laktasiKe.toString()),
          ComponentTile(
              title: 'Tanggal Sampling',
              value: produksiSusu.tanggalSampling?.readable() ?? '-'),
          ComponentTile(
              title: 'Produksi (liter)',
              value: produksiSusu.productTotalLiter ?? '-'),
          ComponentTile(
              title: 'Keterangan', value: produksiSusu.keterangan ?? '-'),
        ]),
        // bottomNavigationBar: Container(
        //   height: 45,
        //   margin:
        //       const EdgeInsets.only(left: 16, right: 16, top: 20,
        //  bottom: 20),
        //   child: ElevatedButton(
        //       onPressed: () => Get.toNamed(ProduksiSusuGrafikPage.routeName),
        //       child: Text(
        //         'Grafik Produksi Susu',
        //         style: GoogleFonts.roboto(
        //             color: black, fontSize: 14, fontWeight: FontWeight.bold),
        //       ),
        //       style: ElevatedButton.styleFrom(
        //           primary: yellowDark,
        //           shape: RoundedRectangleBorder(
        //               borderRadius: BorderRadius.circular(36)))),
        // ),
      );
}
