import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../data/models/ternak/identity_kualitas_susu_model.dart';

import '../../widgets/component_tile.dart';
import '../get/produksi_susu_detail_controller.dart';

class KualitasSusuWidget extends GetWidget<ProduksiSusuDetailController> {
  final IdentityKualitasSusuModel kualitasSusu;
  
  const KualitasSusuWidget({
    Key? key,
    required this.kualitasSusu,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) => ListView(children: [
        ComponentTile(title: 'Warna', 
          value: kualitasSusu.warna ?? '-'),
        ComponentTile(title: 'Bau', 
          value: kualitasSusu.bau ?? '-'),
        ComponentTile(title: 'Lemak', 
          value: kualitasSusu.lemak ?? '-'),
        ComponentTile(title: 'Protein', 
          value: kualitasSusu.protein ?? '-'),
        ComponentTile(title: 'TS', 
          value: kualitasSusu.ts ?? '-'),
        ComponentTile(title: 'NSF', 
          value: kualitasSusu.snf ?? '-'),
        ComponentTile(title: 'Laktosa', 
          value: kualitasSusu.laktosa ?? '-'),
        ComponentTile(title: 'Density', 
          value: kualitasSusu.density ?? '-'),
        ComponentTile(title: 'FPD', 
          value: kualitasSusu.fpd ?? '-'),
        ComponentTile(title: 'Acidity', 
          value: kualitasSusu.acidity ?? '-'),
        ComponentTile(title: 'TPC', 
          value: kualitasSusu.tpc ?? '-'),
        ComponentTile(title: 'PH', 
          value: kualitasSusu.ph ?? '-'),
      ]);
}
