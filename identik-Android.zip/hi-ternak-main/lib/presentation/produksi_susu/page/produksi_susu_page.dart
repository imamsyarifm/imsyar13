import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../utils/datetime_util.dart';
import '../../widgets/default_scaffold.dart';
import '../get/produksi_susu_controller.dart';
import '../params/produksi_susu_detail_params.dart';
import 'produksi_susu_detail_page.dart';
import 'produksi_susu_edit_page.dart';

class ProduksiSusuPage extends GetView<ProduksiSusuController> {
  static const routeName = '/produksi-susu';

  const ProduksiSusuPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Produksi Susu',
        body: buildBody(context),
        floatingAction: Visibility(
          visible: controller.params.ternak.jenisKelamin == 'betina' &&
              controller.params.isFromScan,
          child: FloatingActionButton(
            backgroundColor: green,
            onPressed: () => onUpdateProduksiSusu(context),
            child: const Icon(Icons.add),
          ),
        ),
      );

  Widget buildBody(BuildContext context) {
    return ListView.builder(
      itemCount: controller.allSusu.length,
      itemBuilder: (context, index) {
        final susu = controller.allSusu[index];
        final kualitas = controller.allKualitas[index];

        return Padding(
          padding: const EdgeInsets.only(left: 16, right: 16, top: 8),
          child: GestureDetector(
            onTap: () => Get.toNamed(
              ProduksiSusuDetailPage.routeName,
              arguments: ProduksiSusuDetailParams(
                produksiSusu: susu,
                kualitasSusu: kualitas,
              ),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                          Text('Laktasi Ke ${susu.laktasiKe}'),
                          Text(
                              '${susu.tanggalSampling?.readable()} ● '
                              '${susu.productTotalLiter} (Liter)',
                              style: GoogleFonts.roboto(color: grey8))
                        ])),
                    const Icon(Icons.arrow_right)
                  ],
                ),
                const Divider(color: greyE5)
              ],
            ),
          ),
        );
      },
    );
  }

  void onUpdateProduksiSusu(BuildContext context) {
    Get.toNamed(
      ProduksiSusuEditPage.routeName,
      arguments: controller.params,
    );
  }
}
