import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../app/consts/colors.dart';
import '../get/produksi_susu_edit_controller.dart';
import 'passcode_produksi_susu_page.dart';

class PreviewProduksiSusuPage extends GetView<ProduksiSusuEditController> {
  const PreviewProduksiSusuPage({Key? key}) : super(key: key);

  static const routeName = '/preview-produksi-susu';

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: green,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: green,
          title: const Text('Check Data Produksi Susu'),
        ),
        body: Container(
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(16), topRight: Radius.circular(16)),
            color: Colors.white,
          ),
          child: Form(
            key: controller.formKey,
            child: ListView(children: [
              Padding(
                padding: const EdgeInsets.only(
                    left: 16, right: 16, top: 16, bottom: 26),
                child: Text(
                  'Mohon Periksa Kembali Data Yang Telah '
                  'Diinputkan Pada Produksi Susu',
                  style: GoogleFonts.roboto(
                      fontSize: 18, fontWeight: FontWeight.w500),
                  textAlign: TextAlign.center,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('QR Code'),
                    const SizedBox(width: 64),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.ternak.codeProduct.toString())
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Laktasi Ke'),
                    const SizedBox(width: 56),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etLactationNumber.text)
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Tanggal Sampling'),
                    const SizedBox(width: 10),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etSamplingDate.text)
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Produksi'),
                    const SizedBox(width: 67),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etProduksi.text != ''
                        ? '${controller.etProduksi.text} liter'
                        : '-')
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: Row(
                  children: [
                    const Text('Keterangan'),
                    const SizedBox(width: 52),
                    const Text(':'),
                    const SizedBox(width: 5),
                    Text(controller.etKeterangan.text != ''
                        ? controller.etKeterangan.text
                        : '-')
                  ],
                ),
              ),
            ]),
          ),
        ),
        bottomNavigationBar: Obx(() {
          return (controller.isProcessing)
              ? const LinearProgressIndicator(
                  color: green,
                )
              : Container(
                  color: Colors.white,
                  child: Row(
                    children: [
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(
                              left: 12, top: 12, bottom: 12, right: 6),
                          child: SizedBox(
                            height: 40,
                            child: ElevatedButton(
                                onPressed: () => Get.back(),
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.white,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(36))),
                                child: Text(
                                  'BATAL',
                                  style: GoogleFonts.roboto(
                                      color: black,
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold),
                                )),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(
                              right: 12, top: 12, bottom: 12, left: 6),
                          child: SizedBox(
                            height: 40,
                            child: ElevatedButton(
                                onPressed: () async {
                                  final prefs =
                                      await SharedPreferences.getInstance();
                                  final bool? isInput =
                                      prefs.getBool('isInput');
                                  if (isInput == true) {
                                    Get.toNamed(
                                        PasscodeProduksiSusuPage.routeName);
                                  } else {
                                    controller.save();
                                  }
                                },
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: yellowDark,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(36))),
                                child: Text(
                                  'SIMPAN',
                                  style: GoogleFonts.roboto(
                                      color: black,
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold),
                                )),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
        }),
      );
}
