import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../widgets/default_scaffold.dart';
import '../get/produksi_susu_detail_controller.dart';
import '../widgets/produksi_susu_widget.dart';

class ProduksiSusuDetailPage extends GetView<ProduksiSusuDetailController> {
  static const routeName = '/produksi-susu-detail';

  const ProduksiSusuDetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => DefaultScaffold(
      appBarTitle: 'Produksi Susu',
      body: ProduksiSusuWidget(
        produksiSusu: controller.produksiSusu,
      ));
}
