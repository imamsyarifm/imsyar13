import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../utils/datetime_util.dart';
import '../../../utils/validation_util.dart';
import '../../widgets/default_scaffold.dart';
import '../../widgets/edit_text.dart';
import '../get/produksi_susu_edit_controller.dart';
import 'preview_produksi_susu_page.dart';

class ProduksiSusuEditPage extends GetView<ProduksiSusuEditController> {
  static const routeName = '/edit-produksi-susu';
  const ProduksiSusuEditPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Produksi Susu',
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: controller.formKey,
            child: ListView(children: [
              EditText(
                label: 'QR Code*',
                validator: (value) =>
                    ValidationUtil.emptyValidate('QR Code', value),
                isReadOnly: true,
                controller: controller.etQrCode,
              ),
              const SizedBox(height: 16),
              EditText(
                label: 'Laktasi ke*',
                validator: (value) =>
                    ValidationUtil.emptyValidate('Laktasi', value),
                keyboardType: TextInputType.number,
                controller: controller.etLactationNumber,
              ),
              const SizedBox(height: 16),
              EditText(
                  label: 'Tanggal Sampling*',
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Tanggal Sampling', value),
                  keyboardType: TextInputType.datetime,
                  suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                  isReadOnly: true,
                  onTap: () async {
                    final dateTime = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime.now().add(
                          Duration(
                            days: DateTime.now().differencToOldYear(100).inDays,
                          ),
                        ),
                        lastDate: DateTime.now());
                    if (dateTime != null) controller.setSampling(dateTime);
                  },
                  controller: controller.etSamplingDate),
              const SizedBox(height: 16),
              EditText(
                label: 'Produksi (liter)*',
                validator: (value) =>
                    ValidationUtil.emptyValidate('Produksi (liter)', value),
                keyboardType: TextInputType.number,
                controller: controller.etProduksi,
                onUpdated: (value) {
                  controller.updateProduksi(int.tryParse(value ?? '0') ?? 0);
                },
              ),
              const SizedBox(height: 16),
              EditText(
                label: 'Keterangan',
                keyboardType: TextInputType.text,
                textInputAction: TextInputAction.done,
                controller: controller.etKeterangan,
                minLines: 5,
                maxLines: null,
              ),
              const SizedBox(height: 16),
            ]),
          ),
        ),
        bottomNavigation: Obx(() {
          return (controller.isProcessing)
              ? const LinearProgressIndicator(
                  color: green,
                )
              : Container(
                  color: Colors.white,
                  child: Row(children: [
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 12, top: 12, bottom: 12, right: 6),
                        child: SizedBox(
                          height: 40,
                          child: ElevatedButton(
                              onPressed: () => Get.back(),
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.white,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(36))),
                              child: Text(
                                'BATAL',
                                style: GoogleFonts.roboto(
                                    color: black,
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold),
                              )),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(
                            right: 12, top: 12, bottom: 12, left: 6),
                        child: SizedBox(
                          height: 40,
                          child: ElevatedButton(
                              onPressed: () {
                                Get.toNamed(PreviewProduksiSusuPage.routeName);
                              },
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: yellowDark,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(36))),
                              child: Text(
                                'SIMPAN',
                                style: GoogleFonts.roboto(
                                    color: black,
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold),
                              )),
                        ),
                      ),
                    ),
                  ]),
                );
        }),
      );
}
