// import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../data/models/susu/produksi_susu_request.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../../../data/repositories/susu_repository.dart';
import '../../../utils/datetime_util.dart';
// import '../../../utils/validation_util.dart';
import '../../identitas/pages/identitas_detail_page.dart';
import '../../main/main_page.dart';
import '../params/produksi_susu_params.dart';

class ProduksiSusuEditController extends GetxController {
  final SusuRepository _susuRepository;

  ProduksiSusuEditController({
    required SusuRepository susuRepository,
  }) : _susuRepository = susuRepository;

  final formKey = GlobalKey<FormState>();
  final etQrCode = TextEditingController();
  final etLactationNumber = TextEditingController();
  final etSamplingDate = TextEditingController();
  final etProduksi = TextEditingController();
  final etKeterangan = TextEditingController();
  final pinController = TextEditingController();
  final focusNode = FocusNode();

  final _selectedSamplingDate = DateTime.now().obs;
  final _isProcessing = false.obs;
  final _isFromProfile = false.obs;
  final _produksi = 0.obs;
  late IdentityTernakModel ternak;

  DateTime get selectedSamplingDate => _selectedSamplingDate.value;
  bool get isProcessing => _isProcessing.value;

  @override
  void onInit() {
    super.onInit();
    retrieveArgs();
    initialValue();
  }

  void initialValue() {
    etLactationNumber.text = '1';
    etSamplingDate.text = DateTime.now().readable();
    etProduksi.text = '0';
  }

  void updateProduksi(int value) {
    _produksi.value = value;
  }

  void retrieveArgs() {
    final args = Get.arguments;
    if (args is IdentityTernakModel) {
      ternak = args;
    } else if (args is ProduksiSusuParams) {
      ternak = args.ternak;
      _isFromProfile.value = true;
    }

    etQrCode.text = ternak.idEartag ?? '-';
  }

  void setSampling(DateTime dateTime) {
    _selectedSamplingDate.value = dateTime;
    final dateFormat = DateFormat('dd MMMM yyyy');
    etSamplingDate.text = dateFormat.format(dateTime);
  }

  void save() async {
    _isProcessing.value = true;

    if (formKey.currentState?.validate() == false) {
      _isProcessing.value = false;
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    final bool? isInputPasscode = prefs.getBool('isInput');

    final request = ProduksiSusuRequest(
      idProduct: etQrCode.text,
      keterangan: etKeterangan.text,
      laktasiKe: etLactationNumber.text,
      productTotalLiter: etProduksi.text,
      tanggalSampling: _selectedSamplingDate.value,
      id: DateTime.now().millisecondsSinceEpoch,
      isInput: isInputPasscode! ? 1 : 0,
      passcode: isInputPasscode ? pinController.text : '',
    );

    try {
      if (isInputPasscode) {
        if (pinController.text.length != 6) {
          Get.showSnackbar(const GetSnackBar(
            message: 'Passcode harus 6 digit',
            duration: Duration(seconds: 3),
          ));
          return;
        }
      }

      final update = await _susuRepository.manageSusu(
        request: request,
      );
      _isProcessing.value = false;
      if (update) {
        if (_isFromProfile.value) {
          Get.until(
              (route) => route.settings.name == IdentitasDetailPage.routeName);
        } else {
          Get.until((route) => route.settings.name == MainPage.routeName);
        }
        Get.showSnackbar(const GetSnackBar(
          message: 'Perubahan Data Produksi Susu Berhasil',
          duration: Duration(seconds: 3),
        ));
      } else {
        Get.showSnackbar(const GetSnackBar(
          message: 'Perubahan Data Produksi Susu Gagal',
          duration: Duration(seconds: 3),
        ));
      }
    } catch (error) {
      // Get.showSnackbar(GetSnackBar(
      //   message: ValidationUtil.errorMessage(error as DioError),
      //   duration: const Duration(seconds: 3),
      // ));
      Get.showSnackbar(const GetSnackBar(
        message: 'Perubahan Data Produksi Susu Gagal',
        duration: Duration(seconds: 3),
      ));
    }
  }
}
