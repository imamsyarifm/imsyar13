import 'package:get/get.dart';
import 'produksi_susu_detail_controller.dart';

class ProduksiSusuDetailBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(ProduksiSusuDetailController());
  }
}
