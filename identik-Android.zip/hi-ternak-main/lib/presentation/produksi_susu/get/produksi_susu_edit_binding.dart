import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/susu_repository.dart';
import 'produksi_susu_edit_controller.dart';

class ProduksiSusuEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(SusuRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(ProduksiSusuEditController(
      susuRepository: Get.find<SusuRepository>(),
    ));
  }
}
