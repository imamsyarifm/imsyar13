import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../data/models/ternak/identity_kualitas_susu_model.dart';
import '../../../data/models/ternak/identity_produksi_susu_model.dart';
import '../params/produksi_susu_detail_params.dart';

class ProduksiSusuDetailController extends GetxController
    with GetSingleTickerProviderStateMixin {
  late TabController tabController;

  late IdentityProduksiSusuModel produksiSusu;
  late IdentityKualitasSusuModel kualitasSusu;

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(length: 2, vsync: this);
    retrieveArgs();
  }

  void retrieveArgs() {
    final args = Get.arguments;
    if (args is ProduksiSusuDetailParams) {
      produksiSusu = args.produksiSusu;
      kualitasSusu = args.kualitasSusu;
    }
  }
}
