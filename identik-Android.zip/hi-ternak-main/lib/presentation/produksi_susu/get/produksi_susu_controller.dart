import 'package:get/get.dart';
import '../../../data/models/ternak/identity_kualitas_susu_model.dart';
import '../../../data/models/ternak/identity_produksi_susu_model.dart';
import '../params/produksi_susu_params.dart';

class ProduksiSusuController extends GetxController {
  late ProduksiSusuParams params;
  final allSusu = <IdentityProduksiSusuModel>[];
  final allKualitas = <IdentityKualitasSusuModel>[];

  @override
  void onInit() {
    super.onInit();
    retrieveArgs();
  }

  void retrieveArgs() {
    final args = Get.arguments;
    if (args is ProduksiSusuParams) {
      params = args;

      allSusu.clear();
      allSusu.addAll(args.ternak.produksiSusu ?? []);

      allKualitas.clear();
      allKualitas.addAll(args.ternak.kualitasSusu ?? []);
    }
  }
}
