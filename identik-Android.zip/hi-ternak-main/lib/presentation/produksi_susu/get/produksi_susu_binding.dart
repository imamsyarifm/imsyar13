import 'package:get/get.dart';
import 'produksi_susu_controller.dart';

class ProduksiSusuBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(ProduksiSusuController());
  }
}
