import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../utils/validation_util.dart';
import '../../widgets/default_scaffold.dart';
import '../../widgets/edit_text.dart';
import 'preview_panen_page.dart';

class PanenPage extends StatelessWidget {
  const PanenPage({Key? key}) : super(key: key);

  static const routeName = '/panen-page';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Panen',
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Stack(
            children: [
              Container(
                margin: const EdgeInsets.only(bottom: 50),
                child: buildForm(context),
              ),
            ],
          ),
        ),
        bottomNavigation: buildAction(context),
      );

  Widget buildForm(BuildContext context) {
    return Form(
      child: ListView(
        children: [
          EditText(
            label: 'Scan Code*',
            validator: (value) =>
                ValidationUtil.emptyValidate('Scan Code', value),
            autoValidateMode: AutovalidateMode.onUserInteraction,
            keyboardType: TextInputType.number,
            enableInteractiveSelection: false,
          ),
          const SizedBox(height: 16),
          EditText(
            label: 'Tanggal Panen',
            validator: (value) =>
                ValidationUtil.emptyValidate('Tanggal Subtitusi', value),
            keyboardType: TextInputType.datetime,
            isReadOnly: true,
            onTap: () {},
          ),
          const SizedBox(height: 16),
          const EditText(
            label: 'Jumlah',
            maxLength: 5,
            enableInteractiveSelection: false,
          ),
          const SizedBox(height: 16),
          const EditText(
            label: 'Usia Ternak(hari)',
            maxLength: 3,
            enableInteractiveSelection: false,
          ),
          const SizedBox(
            height: 16,
          ),
          const EditText(
            label: 'Bobot Ternak(kg)',
            maxLength: 3,
            enableInteractiveSelection: false,
          ),
          const SizedBox(
            height: 16,
          ),
          const EditText(
            label: 'Keterangan',
            enableInteractiveSelection: false,
          ),
        ],
      ),
    );
  }

  Widget buildAction(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Row(children: [
        Expanded(
          child: Padding(
            padding:
                const EdgeInsets.only(left: 12, top: 12, bottom: 12, right: 6),
            child: SizedBox(
              height: 40,
              child: ElevatedButton(
                  onPressed: () => Get.back(),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(36))),
                  child: Text(
                    'BATAL',
                    style: GoogleFonts.roboto(
                        color: black,
                        fontSize: 14,
                        fontWeight: FontWeight.bold),
                  )),
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding:
                const EdgeInsets.only(right: 12, top: 12, bottom: 12, left: 6),
            child: SizedBox(
                height: 40,
                child: ElevatedButton(
                  onPressed: () => Get.to(const PreviewPanenPage()),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: yellowDark,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(36))),
                  child: Text(
                    'SIMPAN',
                    style: GoogleFonts.roboto(
                        color: black,
                        fontSize: 14,
                        fontWeight: FontWeight.bold),
                  ),
                )),
          ),
        ),
      ]),
    );
  }
}
