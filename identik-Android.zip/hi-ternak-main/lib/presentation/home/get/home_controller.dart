import 'package:carousel_slider/carousel_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../app/consts/local_keys.dart';
import '../../../data/models/news/news_model.dart';
import '../../../utils/local_helper.dart';

class HomeController extends GetxController
    with GetSingleTickerProviderStateMixin {
  late TabController tabController;
  final carouselController = CarouselController();

  final _selectedTabIndex = 0.obs;
  final _carouselIndex = 0.obs;
  final _isAccountIndividu = true.obs;
  final _isLoadingNews = false.obs;
  final _allNews = Rx<List<NewsModel>>([]);

  int get selectedTabIndex => _selectedTabIndex.value;
  int get carouselIndex => _carouselIndex.value;
  bool get isAccountIndividu => _isAccountIndividu.value;
  bool get isLoadingNews => _isLoadingNews.value;
  List<NewsModel> get allNews => _allNews.value;

  @override
  void onInit() async {
    super.onInit();
    tabController = TabController(length: 2, vsync: this);
    tabController.addListener(_handleTabSelection);
    retrieveAccountType();
  }

  void _handleTabSelection() {
    if (tabController.indexIsChanging) {
      changeTab(tabController.index);
    }
  }

  void changeTab(int index) => _selectedTabIndex.value = index;

  void changeCarouselIndex(int index) => _carouselIndex.value = index;

  Future<void> retrieveAccountType() async {
    final accountType = await LocalHelper.getKey(LocalKeys.isIndividu);
    _isAccountIndividu.value = accountType;
  }

  bool get isAnyPendingTransaction => true;

  @override
  void onClose() {
    tabController.removeListener(_handleTabSelection);
    tabController.dispose();
    super.onClose();
  }
}
