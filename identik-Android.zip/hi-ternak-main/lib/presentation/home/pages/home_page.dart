import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../app/consts/colors.dart';
import '../../../app/consts/images.dart';
import '../../../data/const/mutation_type.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../../../utils/networking_util.dart';
import '../../berita/news_page.dart';
import '../../buku_induk/pages/buku_induk_edit_page.dart';
import '../../input_eartag/pages/input_eartag_page.dart';
import '../../inseminasi/inseminasi_feature.dart';
import '../../kandang/pages/kandang_page.dart';
import '../../kandang_unggas/kandang_unggas_featured.dart';
import '../../kegiatan/kegiatan_page.dart';
import '../../keswan/pages/keswan_edit_page.dart';
import '../../keswan/pages/keswan_health_edit_page.dart';
import '../../main/main_page.dart';
import '../../mutasi/pages/mutasi_edit_page.dart';
import '../../mutasi/pages/mutasi_subtitusi_show_data_page.dart';
import '../../mutasi/params/mutasi_edit_params.dart';
import '../../offline_ternak/pages/offline_ternak_page.dart';
import '../../owner/pages/owner_page.dart';
import '../../pakan/pages/pakan_page.dart';
import '../../panen/panen_featured.dart';
import '../../pembenihan/pembenihan_featured.dart';
import '../../pending_transaction/pages/pending_transaction_page.dart';
import '../../privacy_policy/privacy_policy_page.dart';
import '../../produksi_susu/page/produksi_susu_edit_page.dart';
import '../../scan/scan_page.dart';
import '../../unit_usaha/pages/unit_usaha_page.dart';
import '../home_feature.dart';

class HomePage extends GetView<HomeController> {
  const HomePage({Key? key}) : super(key: key);

  static const routeName = '/home';

  @override
  Widget build(BuildContext context) => Scaffold(
        body: NestedScrollView(
          headerSliverBuilder: (context, isScrolled) {
            return [
              SliverAppBar(
                backgroundColor: green,
                expandedHeight: 140,
                floating: false,
                pinned: true,
                centerTitle: true,
                title: Text(
                  'IDENTIK PKH',
                  style: GoogleFonts.roboto(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                flexibleSpace: FlexibleSpaceBar(
                  background: Stack(
                    children: [
                      ColorFiltered(
                          colorFilter:
                              const ColorFilter.mode(green, BlendMode.color),
                          child: Image.asset(
                            appBarBackground,
                            fit: BoxFit.cover,
                            height: 170,
                          )),
                      Padding(
                        padding: const EdgeInsets.all(24.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 40),
                            Center(
                                child: Image.asset(logo, width: 70, height: 70))
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                actions: [
                  IconButton(
                    onPressed: () =>
                        Get.toNamed(PendingTransactionPage.routeName),
                    icon: Visibility(
                      visible: controller.isAnyPendingTransaction,
                      replacement: const Icon(Icons.sync),
                      child: const Badge(
                        child: Icon(Icons.sync),
                      ),
                    ),
                  ),
                ],
              )
            ];
          },
          body: SingleChildScrollView(
            child: Column(
              children: [
                menuPeternak1(context),
                menuPeternak2(context),
                menuPeternak3(context),
                // menuPeternak4(context),
                GestureDetector(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.info, color: green),
                      const SizedBox(width: 6),
                      Text(
                        'Kebijakan Privasi',
                        style: GoogleFonts.roboto(
                          color: green,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  onTap: () {
                    const baseUrl = String.fromEnvironment('BASE_URL');
                    Get.to(const PrivacyPolicyPage(
                        url: '$baseUrl/privacy-policy-view'));
                  },
                ),
                const SizedBox(height: 6),
                const Padding(
                  padding: EdgeInsets.only(left: 16, right: 16),
                  child: Divider(color: greyC, thickness: 1),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: TabBar(
                      controller: controller.tabController,
                      labelColor: black,
                      unselectedLabelColor: grey9B,
                      indicatorColor: green,
                      labelStyle: GoogleFonts.roboto(
                          color: black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                      tabs: const [
                        Tab(
                          text: 'Kegiatan',
                        ),
                        Tab(
                          text: 'Berita',
                        ),
                      ]),
                ),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Obx(
                    () => const [
                      KegiatanPage(),
                      NewsPage(),
                    ][controller.selectedTabIndex],
                  ),
                )
              ],
            ),
          ),
        ),
      );

  Widget menuTile(String imagePath, String title,
          {GestureTapCallback? onTap}) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          width: 103,
          height: 103,
          padding: const EdgeInsets.symmetric(
            horizontal: 8,
          ),
          child: Card(
            color: (controller.isAccountIndividu)
                ? Colors.white
                : Colors.yellow.shade100,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                Image.asset(imagePath, width: 42, height: 36),
                const SizedBox(height: 6),
                Text(title, textAlign: TextAlign.center)
              ],
            ),
          ),
        ),
      );

  Widget menuPeternak1(BuildContext context) => Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            Expanded(
              child: menuTile(
                business,
                'Unit Usaha',
                onTap: () => Get.toNamed(UnitUsahaPage.routeName),
              ),
            ),
            Expanded(
              child: menuTile(
                farmer,
                'Pemilik',
                onTap: () => Get.toNamed(OwnerPage.routeName),
              ),
            ),
            Expanded(
              child: menuTile(
                kandang,
                'Kandang',
                onTap: () => Get.toNamed(KandangPage.routeName),
              ),
            ),
          ],
        ),
      );

  Widget menuPeternak2(BuildContext context) => Padding(
        padding: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
        child: Row(
          children: [
            Expanded(
              child: menuTile(
                keswan,
                'Kartu Ternak',
                onTap: () {
                  Get.bottomSheet(Container(
                    color: Colors.white,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        ListTile(
                          title: const Text('Pertumbuhan'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () async =>
                              await conditionalTransaction(onScanned: (ternak) {
                            Get.offNamed(
                              KeswanEditPage.routeName,
                              arguments: ternak,
                            );
                          }),
                        ),
                        const Divider(),
                        ListTile(
                          title: const Text('Vaksinasi'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () async =>
                              await conditionalTransaction(onScanned: (ternak) {
                            Get.offNamed(
                              KeswanHealthEditPage.routeName,
                              arguments: ternak,
                            );
                          }),
                        ),
                      ],
                    ),
                  ));
                },
              ),
            ),
            Expanded(
                child: menuTile(mutasi, 'Mutasi', onTap: () {
              Get.bottomSheet(Container(
                color: Colors.white,
                child: ListView(
                  children: [
                    ListTile(
                      title: const Text('Potong'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () async => await mutasiType(MutationType.potong),
                    ),
                    const Divider(),
                    ListTile(
                      title: const Text('Mati'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () async => await mutasiType(MutationType.mati),
                    ),
                    const Divider(),
                    ListTile(
                      title: const Text('Hilang'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () async => await mutasiType(MutationType.hilang),
                    ),
                    // const Divider(),
                    // ListTile(
                    //   title: const Text('Jual'),
                    //   trailing: const Icon(Icons.chevron_right),
                    //   onTap: () async => await mutasiType(MutationType.jual),
                    // ),
                    const Divider(),
                    ListTile(
                      title: const Text('Pindah'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () async => await mutasiType(MutationType.pindah),
                    ),
                    // ListTile(
                    //   title: const Text('Aktivasi'),
                    //   trailing: const Icon(Icons.chevron_right),
                    //   onTap: () async => await conditionalTransaction(
                    //     onScanned: (ternak) {
                    //       Get.offNamed(
                    //         MutasiAktivasiEditPage.routeName,
                    //         arguments: MutasiEditParams(
                    //           mutationType: MutationType.mati,
                    //           ternak: ternak,
                    //           isInput: true,
                    //         ),
                    //       );
                    //     },
                    //     isMutasiAktivasi: true,
                    //   ),
                    // ),
                    ListTile(
                      title: const Text('Ganti Nomer Eartag'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () async =>
                          await conditionalTransaction(onScanned: (ternak) {
                        Get.offNamed(
                          MutasiSubtitusiShowPage.routeName,
                          arguments: MutasiEditParams(
                            mutationType: MutationType.potong,
                            ternak: ternak,
                          ),
                        );
                      }),
                    ),
                    const Divider(),
                    ListTile(
                      title: const Text('Ganti Eartag Hilang/Rusak'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () async {
                        final prefs = await SharedPreferences.getInstance();
                        await prefs.setBool('isInput', false);
                        Get.toNamed(
                          ScanPage.routeName,
                          arguments: ScanPageParams(
                            isProduksiSusu: false,
                            isPublic: false,
                            isTransaction: false,
                            isInput: false,
                            inputNumber: '',
                            isNewSubtitusi: true,
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ));
            })),
            Expanded(
              child: menuTile(
                pakan,
                'Pakan',
                onTap: () => Get.toNamed(PakanPage.routeName),
              ),
            ),
          ],
        ),
      );

  Widget menuPeternak3(BuildContext context) => Padding(
        padding: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
        child: Row(
          children: [
            Expanded(
              child: menuTile(
                produksiSusu,
                'Produksi Susu',
                onTap: () async => await conditionalTransaction(
                  onScanned: (ternak) {
                    Get.offNamed(
                      ProduksiSusuEditPage.routeName,
                      arguments: ternak,
                    );
                  },
                  isProduksiSusu: true,
                ),
              ),
            ),
            Expanded(
                child: menuTile(inseminasi, 'Perkawinan', onTap: () {
              Get.bottomSheet(Container(
                color: Colors.white,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ListTile(
                      title: const Text('Inseminasi Buatan'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () async => await conditionalTransaction(
                        onScanned: (ternak) {
                          Get.offNamed(
                            InseminasiBuatanEditPage.routeName,
                            arguments: ternak,
                          );
                        },
                        isProduksiSusu: true,
                      ),
                    ),
                    const Divider(),
                    ListTile(
                      title: const Text('Alami'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () async => await conditionalTransaction(
                        onScanned: (ternak) {
                          Get.offNamed(
                            InseminasiAlamiEditPage.routeName,
                            arguments: ternak,
                          );
                        },
                        isProduksiSusu: true,
                      ),
                    ),
                    const Divider(),
                    ListTile(
                      title: const Text('Transfer Embrio'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () async => await conditionalTransaction(
                        onScanned: (ternak) {
                          Get.offNamed(
                            InseminasiTransferEmbrioEditPage.routeName,
                            arguments: ternak,
                          );
                        },
                        isProduksiSusu: true,
                      ),
                    ),
                    const Divider(),
                    ListTile(
                      title: const Text('Pemeriksaan Kebuntingan (PKB)'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () async => await conditionalTransaction(
                        onScanned: (ternak) {
                          Get.offNamed(
                            PemeriksaanKebuntinganEditPage.routeName,
                            arguments: ternak,
                          );
                        },
                        isProduksiSusu: true,
                      ),
                    ),
                  ],
                ),
              ));
            })),
            Expanded(
              child: menuTile(
                bukuInduk,
                'Buku Lahir',
                onTap: () async => await conditionalTransaction(
                  onScanned: (ternak) {
                    Get.offNamed(
                      BukuIndukEditPage.routeName,
                      arguments: ternak,
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      );

  Widget menuPeternak4(BuildContext context) => Padding(
        padding: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
        child: Row(
          children: [
            Expanded(
              child: menuTile(
                unggas,
                'Kandang Unggas',
                onTap: () => Get.toNamed(KandangUnggasPage.routeName),
              ),
            ),
            Expanded(
              child: menuTile(
                benih,
                'Pembenihan',
                onTap: () async => await conditionalTransaction(
                  onScanned: (ternak) {
                    Get.offNamed(
                      PembenihanPage.routeName,
                      arguments: ternak,
                    );
                  },
                ),
              ),
            ),
            Expanded(
              child: menuTile(
                panen,
                'Panen',
                onTap: () async => await conditionalTransaction(
                  onScanned: (ternak) {
                    Get.offNamed(
                      PanenPage.routeName,
                      arguments: ternak,
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      );

  Future<void> mutasiType(MutationType type) async {
    return await conditionalTransaction(onScanned: (ternak) {
      Get.until((route) => route.settings.name == MainPage.routeName);
      Get.toNamed(
        MutasiEditPage.routeName,
        arguments: MutasiEditParams(
          mutationType: type,
          ternak: ternak,
        ),
      );
    });
  }

  Future<void> conditionalTransaction({
    bool isTransaction = true,
    bool isProduksiSusu = false,
    bool isPublic = false,
    bool isMutasiAktivasi = false,
    bool isInput = false,
    Function(IdentityTernakModel)? onScanned,
  }) async {
    // Obtain shared preferences.
    final prefs = await SharedPreferences.getInstance();
    final isConnected = await NetworkingUtil.isConnected;
    if (isConnected) {
      Get.back();
      Get.bottomSheet(Container(
        color: Colors.white,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text('Scan Eartag'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () async {
                await prefs.setBool('isInput', false);
                Get.toNamed(
                  ScanPage.routeName,
                  arguments: ScanPageParams(
                    onScanned: onScanned,
                    isProduksiSusu: isProduksiSusu,
                    isPublic: isPublic,
                    isTransaction: isTransaction,
                    isInput: isInput,
                    inputNumber: '',
                    isMutasiAktivasi: isMutasiAktivasi,
                  ),
                );
              },
            ),
            const Divider(),
            ListTile(
              title: const Text('Input Eartag'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () async {
                //use shared preff
                await prefs.setBool('isInput', true);
                Get.toNamed(
                  InputEartagPage.routeName,
                  arguments: InputEartagParams(
                    onScanned: onScanned,
                    isProduksiSusu: isProduksiSusu,
                    isPublic: isPublic,
                    isTransaction: isTransaction,
                    isMutasiAktivasi: isMutasiAktivasi,
                  ),
                );
              },
            ),
          ],
        ),
      ));
      // Get.toNamed(
      //   ScanPage.routeName,
      //   arguments: ScanPageParams(
      //     onScanned: onScanned,
      //     isProduksiSusu: isProduksiSusu,
      //     isPublic: isPublic,
      //     isInput: true,
      //     inputNumber: 'BBB 11 0000000001',
      //     isTransaction: isTransaction,
      //   ),
      // );
    } else {
      Get.back();
      Get.toNamed(
        OfflineTernakPage.routeName,
        arguments: OfflineTernakParams(
          onScanned: onScanned,
          isProduksiSusu: isProduksiSusu,
          isPublic: isPublic,
          isTransaction: isTransaction,
        ),
      );
    }
  }
}
