export 'get/home_binding.dart';
export 'get/home_controller.dart';

export 'pages/home_page.dart';
