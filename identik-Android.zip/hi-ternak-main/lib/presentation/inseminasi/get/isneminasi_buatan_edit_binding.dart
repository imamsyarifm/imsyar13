import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/inseminasi_repository.dart';
import 'inseminasi_buatan_edit_controller.dart';

class InseminasiBuatanEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(InseminasiRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(InseminasiBuatanEditController(
      repository: Get.find<InseminasiRepository>(),
    ));
  }
}
