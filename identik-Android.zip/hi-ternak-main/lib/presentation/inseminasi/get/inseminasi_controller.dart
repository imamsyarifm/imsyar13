import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../data/models/ternak/identity_inseminasi_model.dart';
import '../pages/inseminasi_detail_page.dart';
import '../params/inseminasi_params.dart';

class InseminasiController extends GetxController
    with GetSingleTickerProviderStateMixin {
  late TabController tabController;
  late InseminasiParams params;
  final _selectedInseminasi = Rx<IdentityInseminasiModel?>(null);

  IdentityInseminasiModel? get selectedInseminasi => _selectedInseminasi.value;

  @override
  void onInit() {
    super.onInit();

    tabController = TabController(length: 2, vsync: this);
    retrieveArgs();
  }

  void retrieveArgs() {
    final args = Get.arguments;
    if (args is InseminasiParams) {
      params = args;
    }
  }

  String date() {
    final dateFormat = DateFormat('dd MMMM yyyy');
    return dateFormat.format(DateTime.now());
  }

  void selectInseminasi(IdentityInseminasiModel? inseminasi) {
    _selectedInseminasi.value = inseminasi;
    Get.toNamed(InseminasiDetailPage.routeName);
  }
}
