import 'package:get/get.dart';
import 'inseminasi_controller.dart';

class InseminasiBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(InseminasiController());
  }
}
