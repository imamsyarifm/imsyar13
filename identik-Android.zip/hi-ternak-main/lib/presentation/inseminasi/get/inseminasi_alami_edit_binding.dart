import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/inseminasi_repository.dart';
import 'inseminasi_alami_edit_controller.dart';

class InseminasiAlamiEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(InseminasiRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(InseminasiAlamiEditController(
      repository: Get.find<InseminasiRepository>(),
    ));
  }
}
