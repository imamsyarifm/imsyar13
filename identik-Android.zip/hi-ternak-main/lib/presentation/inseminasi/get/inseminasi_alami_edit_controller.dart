// import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../data/models/inseminasi/induk_jantan.dart';
import '../../../data/models/inseminasi/inseminasi_request.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../../../data/repositories/inseminasi_repository.dart';
// import '../../../utils/validation_util.dart';
import '../../identitas/pages/identitas_detail_page.dart';
import '../../main/main_page.dart';
import '../pages/preview_data/preview_inseminasi_alami_page.dart';
import '../params/inseminasi_params.dart';

class InseminasiAlamiEditController extends GetxController {
  final InseminasiRepository _repository;

  InseminasiAlamiEditController({
    required InseminasiRepository repository,
  }) : _repository = repository;

  final formKey = GlobalKey<FormState>();
  final etTanggalInseminasi = TextEditingController();
  final etIndukJantan = TextEditingController();
  final etKeterangan = TextEditingController();
  final pinController = TextEditingController();
  final focusNode = FocusNode();

  final _selectedInseminasiDate = DateTime.now().obs;
  final _selectedInseminasiDateSebelumnya = DateTime.now().obs;
  final _selectedUrutanInseminasi = 1.obs;
  final _selectedIndukJantan = Rx<IndukJantan?>(null);
  final _ternak = Rx<IdentityTernakModel?>(null);
  final _isFromProfile = false.obs;
  final _isUpdating = false.obs;

  DateTime get selectedInseminasiDate => _selectedInseminasiDate.value;
  DateTime get selectedInseminasiDateSebelumnya =>
      _selectedInseminasiDateSebelumnya.value;
  int get selectedUrutanInseminasi => _selectedUrutanInseminasi.value;
  IndukJantan? get selectedIndukJantan => _selectedIndukJantan.value;
  bool get isUpdating => _isUpdating.value;

  IdentityTernakModel? get ternak => _ternak.value;

  @override
  void onInit() {
    retrieveArgs();
    super.onInit();
  }

  void retrieveArgs() {
    final args = Get.arguments;
    if (args is IdentityTernakModel) {
      _ternak.value = args;
    } else if (args is InseminasiParams) {
      _ternak.value = args.ternak;
      _isFromProfile.value = true;
    }

    setTanggalInseminasi(DateTime.now());
  }

  String dateString(DateTime dateTime) {
    final dateFormat = DateFormat('dd MMMM yyyy');
    return dateFormat.format(dateTime);
  }

  void setTanggalInseminasi(DateTime dateTime) {
    _selectedInseminasiDate.value = dateTime;
    etTanggalInseminasi.text = dateString(dateTime);
  }

  void setIndukJantan(IndukJantan value) {
    _selectedIndukJantan.value = value;
    etIndukJantan.text = value.codeProduct;
  }

  void next() {
    if (formKey.currentState?.validate() == false) {
      return;
    }

    if (etIndukJantan.text == '') {
      Get.showSnackbar(const GetSnackBar(
        message: 'Induk Jantan Harus Diisi',
        duration: Duration(seconds: 3),
      ));
    } else {
      Get.toNamed(PreviewInseminasiAlamiPage.routeName);
    }
  }

  Future<void> save() async {
    if (formKey.currentState?.validate() == false) {
      return;
    }

    _isUpdating.value = true;

    final prefs = await SharedPreferences.getInstance();
    final bool? isInputPasscode = prefs.getBool('isInput');

    final payload = InseminasiRequest(
      idProduct: _ternak.value?.idEartag ?? '',
      metodePerkawinan: 'alami',
      tanggalInseminasi: _selectedInseminasiDate.value,
      idPenjantan: _selectedIndukJantan.value?.codeProduct,
      keterangan: etKeterangan.text,
      id: DateTime.now().millisecondsSinceEpoch,
      isInput: isInputPasscode! ? 1 : 0,
      passcode: isInputPasscode ? pinController.text : '',
    );

    try {
      if (isInputPasscode) {
        if (pinController.text.length != 6) {
          Get.showSnackbar(const GetSnackBar(
            message: 'Passcode harus 6 digit',
            duration: Duration(seconds: 3),
          ));
          return;
        }
      }

      final save = await _repository.update(
        request: payload,
      );
      if (save) {
        _isUpdating.value = false;
        if (_isFromProfile.value) {
          Get.until(
              (route) => route.settings.name == IdentitasDetailPage.routeName);
        } else {
          Get.until((route) => route.settings.name == MainPage.routeName);
        }
        Get.showSnackbar(const GetSnackBar(
          message: 'Update inseminasi alami berhasil',
          duration: Duration(seconds: 3),
        ));
      } else {
        _isUpdating.value = false;
        Get.showSnackbar(const GetSnackBar(
          message: 'Update inseminasi alami gagal',
          duration: Duration(seconds: 3),
        ));
      }
    } catch (error) {
      _isUpdating.value = false;
      // Get.showSnackbar(GetSnackBar(
      //   message: ValidationUtil.errorMessage(error as DioError),
      //   duration: const Duration(seconds: 3),
      // ));
      Get.showSnackbar(const GetSnackBar(
        message: 'Update inseminasi alami gagal',
        duration: Duration(seconds: 3),
      ));
    }
  }
}
