import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/inseminasi_repository.dart';
import 'inseminasi_transfer_embrio_edit_controller.dart';

class InseminasiTransferEmbrioEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(InseminasiRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(InseminasiTransferEmbrioEditController(
      repository: Get.find<InseminasiRepository>(),
    ));
  }
}