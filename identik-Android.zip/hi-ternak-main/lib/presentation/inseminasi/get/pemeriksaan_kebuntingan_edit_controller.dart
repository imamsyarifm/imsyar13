// import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../data/models/inseminasi/pemeriksaan_kebuntingan_request.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../../../data/repositories/inseminasi_repository.dart';
// import '../../../utils/validation_util.dart';
import '../../identitas/pages/identitas_detail_page.dart';
import '../../main/main_page.dart';
import '../params/inseminasi_params.dart';

class PemeriksaanKebuntinganEditController extends GetxController {
  final InseminasiRepository _repository;

  PemeriksaanKebuntinganEditController({
    required InseminasiRepository repository,
  }) : _repository = repository;

  final formKey = GlobalKey<FormState>();
  final etTanggalPkb = TextEditingController();
  final etKeterangan = TextEditingController();
  final pinController = TextEditingController();
  final focusNode = FocusNode();
  final etKebuntingan = TextEditingController();
  final etUsiaBunting = TextEditingController();
  final etEstimasiKelahiran = TextEditingController();

  final _selectedInseminasiDate = DateTime.now().obs;
  final _isFromProfile = false.obs;
  final _isUpdating = false.obs;
  final _selectedBunting = false.obs;

  final _ternak = Rx<IdentityTernakModel?>(null);

  DateTime get selectedInseminasiDate => _selectedInseminasiDate.value;
  bool get isUpdating => _isUpdating.value;
  bool get selectedBunting => _selectedBunting.value;

  IdentityTernakModel? get ternak => _ternak.value;

  @override
  void onInit() {
    retrieveArgs();
    retrieveBunting();
    super.onInit();
  }

  void retrieveArgs() {
    final args = Get.arguments;
    if (args is IdentityTernakModel) {
      _ternak.value = args;
    } else if (args is InseminasiParams) {
      _ternak.value = args.ternak;
      _isFromProfile.value = true;
    }

    setTanggalInseminasi(DateTime.now());
  }

  void retrieveBunting() async {
    final bunting = await _repository.checkBunting(
        qrCode: _ternak.value?.idEartag.toString());

    etUsiaBunting.text = bunting.umurBunting.toString();

    etKebuntingan.text =
        bunting.isInseminasi.toString() == '1' ? 'Bunting' : 'Tidak Bunting';
  }

  String dateString(DateTime dateTime) {
    final dateFormat = DateFormat('dd MMMM yyyy');
    return dateFormat.format(dateTime);
  }

  void setTanggalInseminasi(DateTime dateTime) {
    _selectedInseminasiDate.value = dateTime;
    etTanggalPkb.text = dateString(dateTime);
  }

  void setKebuntingan({required bool isBunting}) {
    _selectedBunting.value = isBunting;
    etKebuntingan.text = (isBunting) ? 'Bunting' : 'Tidak Bunting';
    Get.back();
  }

  Future<void> save() async {
    if (formKey.currentState?.validate() == false) {
      return;
    }

    _isUpdating.value = true;

    final prefs = await SharedPreferences.getInstance();
    final bool? isInputPasscode = prefs.getBool('isInput');

    final payload = PemeriksaanKebuntinganRequest(
      idProduct: _ternak.value?.idEartag ?? '',
      tanggal: _selectedInseminasiDate.value,
      isBunting: etKebuntingan.text == 'Bunting' ? '1' : '0',
      usiaBunting: etUsiaBunting.text,
      estimasiKelahiran: '0',
      keterangan: etKeterangan.text,
      isInput: isInputPasscode! ? 1 : 0,
      passcode: isInputPasscode ? pinController.text : '',
    );

    try {
      if (isInputPasscode) {
        if (pinController.text.length != 6) {
          Get.showSnackbar(const GetSnackBar(
            message: 'Passcode harus 6 digit',
            duration: Duration(seconds: 3),
          ));
          return;
        }
      }

      final save = await _repository.updatePemeriksaanKebutingan(
        request: payload,
      );
      if (save) {
        _isUpdating.value = false;
        if (_isFromProfile.value) {
          Get.until(
              (route) => route.settings.name == IdentitasDetailPage.routeName);
        } else {
          Get.until((route) => route.settings.name == MainPage.routeName);
        }
        Get.showSnackbar(const GetSnackBar(
          message: 'Update pemeriksaan kebuntingan berhasil',
          duration: Duration(seconds: 3),
        ));
      } else {
        _isUpdating.value = false;
        Get.showSnackbar(const GetSnackBar(
          message: 'Update pemeriksaan kebuntingan gagal',
          duration: Duration(seconds: 3),
        ));
      }
    } catch (error) {
      _isUpdating.value = false;
      // Get.showSnackbar(GetSnackBar(
      //   message: ValidationUtil.errorMessage(error as DioError),
      //   duration: const Duration(seconds: 3),
      // ));
      Get.showSnackbar(const GetSnackBar(
        message: 'Update pemeriksaan kebuntingan gagal',
        duration: Duration(seconds: 3),
      ));
    }
  }
}
