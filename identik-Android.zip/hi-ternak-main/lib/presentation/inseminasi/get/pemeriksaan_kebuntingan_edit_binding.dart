import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/inseminasi_repository.dart';
import 'pemeriksaan_kebuntingan_edit_controller.dart';

class PemeriksaanKebuntinganEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(InseminasiRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(PemeriksaanKebuntinganEditController(
      repository: Get.find<InseminasiRepository>(),
    ));
  }
}