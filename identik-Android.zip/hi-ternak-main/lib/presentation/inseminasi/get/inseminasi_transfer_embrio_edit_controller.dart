// import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../data/models/combo/combo_model.dart';
import '../../../data/models/inseminasi/inseminasi_request.dart';
import '../../../data/models/inseminasi/kode_embrio_model.dart';
import '../../../data/models/ternak/identity_ternak_model.dart';
import '../../../data/repositories/inseminasi_repository.dart';
// import '../../../utils/validation_util.dart';
import '../../identitas/pages/identitas_detail_page.dart';
import '../../main/main_page.dart';
import '../pages/preview_data/preview_transfer_embrio_page.dart';
import '../params/inseminasi_params.dart';

class InseminasiTransferEmbrioEditController extends GetxController {
  final InseminasiRepository _repository;

  InseminasiTransferEmbrioEditController({
    required InseminasiRepository repository,
  }) : _repository = repository;

  final formKey = GlobalKey<FormState>();
  final etTanggalInseminasi = TextEditingController();
  final etKodeStraw = TextEditingController();
  final etInseminasiKe = TextEditingController();
  final etPetugas = TextEditingController();
  final etTanggalTerakhirInseminasi = TextEditingController();
  final etKeterangan = TextEditingController();
  final pinController = TextEditingController();
  final focusNode = FocusNode();

  final _selectedInseminasiDate = DateTime.now().obs;
  final _selectedInseminasiDateSebelumnya = DateTime.now().obs;
  final _selectedUrutanInseminasi = 1.obs;
  final _selectedEmbrioCode = Rx<KodeEmbrioModel?>(null);
  final _selectedPetugas = Rx<ComboModel?>(null);
  final _isFromProfile = false.obs;
  final _isUpdating = false.obs;

  final _ternak = Rx<IdentityTernakModel?>(null);

  DateTime get selectedInseminasiDate => _selectedInseminasiDate.value;
  DateTime get selectedInseminasiDateSebelumnya =>
      _selectedInseminasiDateSebelumnya.value;
  int get selectedUrutanInseminasi => _selectedUrutanInseminasi.value;
  KodeEmbrioModel? get selectedEmbrioCode => _selectedEmbrioCode.value;
  ComboModel? get selectedPetugas => _selectedPetugas.value;
  bool get isUpdating => _isUpdating.value;

  IdentityTernakModel? get ternak => _ternak.value;

  @override
  void onInit() {
    retrieveArgs();
    super.onInit();
  }

  void retrieveArgs() {
    final args = Get.arguments;
    if (args is IdentityTernakModel) {
      _ternak.value = args;
    } else if (args is InseminasiParams) {
      _ternak.value = args.ternak;
      _isFromProfile.value = true;
    }

    setTanggalInseminasi(DateTime.now());
    setLastInseminationDate(DateTime.now());
  }

  String dateString(DateTime dateTime) {
    final dateFormat = DateFormat('dd MMMM yyyy');
    return dateFormat.format(dateTime);
  }

  void setTanggalInseminasi(DateTime dateTime) {
    _selectedInseminasiDate.value = dateTime;
    etTanggalInseminasi.text = dateString(dateTime);
  }

  void setUrutanInseminasi(int value) {
    _selectedUrutanInseminasi.value = value;
    etInseminasiKe.text = value.toString();
    Get.back();
  }

  void setKodeEmbrio(KodeEmbrioModel value) {
    _selectedEmbrioCode.value = value;
    etKodeStraw.text = value.idDonor.toString();
  }

  void setLastInseminationDate(DateTime dateTime) {
    _selectedInseminasiDateSebelumnya.value = dateTime;
    etTanggalTerakhirInseminasi.text = dateString(dateTime);
  }

  void setPetugas(ComboModel petugas) {
    _selectedPetugas.value = petugas;
    etPetugas.text = petugas.label;
  }

  void next() {
    if (formKey.currentState?.validate() == false) {
      return;
    }

    if (etKodeStraw.text == '') {
      Get.showSnackbar(const GetSnackBar(
        message: 'Kode Embrio Harus Diisi',
        duration: Duration(seconds: 3),
      ));
    } else if (etInseminasiKe.text == '') {
      Get.showSnackbar(const GetSnackBar(
        message: 'Urutan Transfer Harus Diisi',
        duration: Duration(seconds: 3),
      ));
    } else {
      Get.toNamed(PreviewInseminasiTransferEmbrioPage.routeName);
    }
  }

  Future<void> save() async {
    if (formKey.currentState?.validate() == false) {
      return;
    }

    _isUpdating.value = true;

    final prefs = await SharedPreferences.getInstance();
    final bool? isInputPasscode = prefs.getBool('isInput');

    final payload = InseminasiRequest(
      idProduct: _ternak.value?.idEartag ?? '',
      metodePerkawinan: 'transfer_embrio',
      tanggalInseminasi: _selectedInseminasiDate.value,
      keterangan: etKeterangan.text,
      kodeStraw: '',
      inseminasiKe: etInseminasiKe.text,
      tanggalInseminasiTerakhir: _selectedInseminasiDateSebelumnya.value,
      idPetugas: _selectedPetugas.value?.value,
      id: DateTime.now().millisecondsSinceEpoch,
      isInput: isInputPasscode! ? 1 : 0,
      passcode: isInputPasscode ? pinController.text : '',
      kodeEmbrio: _selectedEmbrioCode.value?.id,
    );

    try {
      if (isInputPasscode) {
        if (pinController.text.length != 6) {
          Get.showSnackbar(const GetSnackBar(
            message: 'Passcode harus 6 digit',
            duration: Duration(seconds: 3),
          ));
          return;
        }
      }

      final save = await _repository.update(
        request: payload,
      );
      if (save) {
        _isUpdating.value = false;
        if (_isFromProfile.value) {
          Get.until(
              (route) => route.settings.name == IdentitasDetailPage.routeName);
        } else {
          Get.until((route) => route.settings.name == MainPage.routeName);
        }
        Get.showSnackbar(const GetSnackBar(
          message: 'Update inseminasi trasfer embrio berhasil',
          duration: Duration(seconds: 3),
        ));
      } else {
        _isUpdating.value = false;
        Get.showSnackbar(const GetSnackBar(
          message: 'Update inseminasi transfer embrio gagal',
          duration: Duration(seconds: 3),
        ));
      }
    } catch (error) {
      _isUpdating.value = false;
      // Get.showSnackbar(GetSnackBar(
      //   message: ValidationUtil.errorMessage(error as DioError),
      //   duration: const Duration(seconds: 3),
      // ));
      Get.showSnackbar(const GetSnackBar(
        message: 'Update inseminasi transfer embrio gagal',
        duration: Duration(seconds: 3),
      ));
    }
  }
}
