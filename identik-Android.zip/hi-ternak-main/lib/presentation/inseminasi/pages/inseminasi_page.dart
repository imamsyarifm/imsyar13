import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../utils/datetime_util.dart';
import '../../widgets/default_scaffold.dart';
import '../get/inseminasi_controller.dart';
import 'inseminasi_alami_edit_page.dart';
import 'inseminasi_buatan_edit_page.dart';

class InseminasiPage extends GetView<InseminasiController> {
  const InseminasiPage({Key? key}) : super(key: key);

  static const routeName = '/inseminasi';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Perkawinan',
        body: ListView.builder(
          itemCount: controller.params.ternak.inseminasi?.length ?? 0,
          itemBuilder: (context, index) {
            final inseminasi = controller.params.ternak.inseminasi?[index];
            return Padding(
              padding: const EdgeInsets.only(left: 16, right: 16, top: 8),
              child: GestureDetector(
                onTap: () => controller.selectInseminasi(inseminasi),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                              Text(inseminasi?.keterangan ?? '-'),
                              Text(
                                '${inseminasi?.metodePerkawinan ?? '-'} '
                                '(${inseminasi?.inseminasiKe ?? '-'}) ● '
                                '${inseminasi?.tanggalInseminasi?.readable()}',
                                style: GoogleFonts.roboto(color: grey8),
                              ),
                            ])),
                        const Icon(Icons.arrow_right)
                      ],
                    ),
                    const Divider(color: greyE5)
                  ],
                ),
              ),
            );
          },
        ),
        // floatingAction: Visibility(
        //   visible: controller.params.isFromScan,
        //   child: FloatingActionButton(
        //     backgroundColor: green,
        //     onPressed: () => onUpdateInseminasi(context),
        //     child: const Icon(Icons.add),
        //   ),
        // ),
      );

  void onUpdateInseminasi(BuildContext context) {
    Get.bottomSheet(Container(
      color: Colors.white,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            title: const Text('Buatan'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () async {
              Get.toNamed(
                InseminasiBuatanEditPage.routeName,
                arguments: controller.params,
              );
            },
          ),
          const Divider(),
          ListTile(
            title: const Text('Alami'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () async {
              Get.toNamed(
                InseminasiAlamiEditPage.routeName,
                arguments: controller.params,
              );
            },
          ),
        ],
      ),
    ));
  }
}
