import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../../app/consts/colors.dart';
import '../../../widgets/default_scaffold.dart';
import '../../inseminasi_feature.dart';

class PreviewPemeriksaanKebuntinganPage
    extends GetView<PemeriksaanKebuntinganEditController> {
  const PreviewPemeriksaanKebuntinganPage({Key? key}) : super(key: key);

  static const routeName = '/preview-pemeriksaan-kebuntingan';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Check Data PKB',
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Obx(
            () => Stack(
              children: [
                Container(
                  margin: const EdgeInsets.only(bottom: 50),
                  child: buildForm(context),
                ),
              ],
            ),
          ),
        ),
        bottomNavigation: buildAction(context),
      );

  Widget buildForm(BuildContext context) {
    return Form(
      child: ListView(
        children: [
          const SizedBox(height: 16),
          Text(
            'Mohon Periksa Kembali Data Yang Telah '
            'Diinputkan Pada PKB',
            style:
                GoogleFonts.roboto(fontSize: 18, fontWeight: FontWeight.w500),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 26),
          Row(
            children: [
              const Text('QR Code'),
              const SizedBox(width: 37),
              const Text(':'),
              const SizedBox(width: 5),
              Text(controller.ternak!.codeProduct.toString())
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text('Tanggal PKB'),
              const SizedBox(width: 12),
              const Text(':'),
              const SizedBox(width: 5),
              Text(controller.etTanggalPkb.text)
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text('Status \nKebuntingan'),
              const SizedBox(width: 14),
              const Text(':'),
              const SizedBox(width: 5),
              Text(controller.etKebuntingan.text)
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text('Usia Bunting'),
              const SizedBox(width: 13),
              const Text(':'),
              const SizedBox(width: 5),
              Text('${controller.etUsiaBunting.text} bulan')
            ],
          ),
          const SizedBox(height: 16),
          // Row(
          //   children: [
          //     const Text('Estimasi \nKelahiran'),
          //     const SizedBox(width: 35),
          //     const Text(':'),
          //     const SizedBox(width: 5),
          //     Text('${controller.etEstimasiKelahiran.text} bulan')
          //   ],
          // ),
          // const SizedBox(height: 16),
          Row(
            children: [
              const Text('Keterangan'),
              const SizedBox(width: 22),
              const Text(':'),
              const SizedBox(width: 5),
              Text(controller.etKeterangan.text)
            ],
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget buildAction(BuildContext context) {
    return Obx(() {
      if (controller.isUpdating) {
        return const LinearProgressIndicator(
          color: green,
        );
      }

      return Container(
        color: Colors.white,
        child: Row(children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 12, top: 12, bottom: 12, right: 6),
              child: SizedBox(
                height: 40,
                child: ElevatedButton(
                    onPressed: () => Get.back(),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(36))),
                    child: Text(
                      'BATAL',
                      style: GoogleFonts.roboto(
                          color: black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                    )),
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(
                  right: 12, top: 12, bottom: 12, left: 6),
              child: SizedBox(
                height: 40,
                child: ElevatedButton(
                    onPressed: () async {
                      final prefs = await SharedPreferences.getInstance();
                      final bool? isInput = prefs.getBool('isInput');
                      if (isInput == true) {
                        Get.toNamed(
                            PasscodePemeriksaanKebuntingannPage.routeName);
                      } else {
                        controller.save();
                      }
                    },
                    style: ElevatedButton.styleFrom(
                        backgroundColor: yellowDark,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(36))),
                    child: Text(
                      'SIMPAN',
                      style: GoogleFonts.roboto(
                          color: black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                    )),
              ),
            ),
          ),
        ]),
      );
    });
  }
}
