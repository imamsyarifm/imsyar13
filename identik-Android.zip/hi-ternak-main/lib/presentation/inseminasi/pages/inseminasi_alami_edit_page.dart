import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
// import '../../../utils/datetime_util.dart';
import '../../../utils/validation_util.dart';
import '../../widgets/default_scaffold.dart';
import '../../widgets/edit_text.dart';
import '../../widgets/ternak_information_dragable.dart';
import '../inseminasi_feature.dart';
import '../widgets/search_induk_jantan_delegate.dart';

class InseminasiAlamiEditPage extends GetView<InseminasiAlamiEditController> {
  const InseminasiAlamiEditPage({Key? key}) : super(key: key);

  static const routeName = '/inseminasi-alami-edit';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Inseminasi Alami',
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Obx(
            () => Stack(
              children: [
                Container(
                  margin: const EdgeInsets.only(bottom: 50),
                  child: buildForm(context),
                ),
                Visibility(
                  visible: controller.ternak != null,
                  child: DraggableScrollableSheet(
                    initialChildSize: 0.25,
                    minChildSize: 0.10,
                    maxChildSize: 1,
                    builder: (context, scrollController) {
                      return SingleChildScrollView(
                        controller: scrollController,
                        child: TernakInformationDragable(
                          ternak: controller.ternak!,
                        ),
                      );
                    },
                  ),
                )
              ],
            ),
          ),
        ),
        bottomNavigation: buildAction(context),
      );

  Widget buildForm(BuildContext context) {
    return Form(
      child: ListView(
        children: [
          EditText(
            label: 'Tanggal Inseminasi*',
            validator: (value) =>
                ValidationUtil.emptyValidate('Tanggal Inseminasi', value),
            keyboardType: TextInputType.datetime,
            controller: controller.etTanggalInseminasi,
            isReadOnly: true,
            onTap: () {},
            // onTap: () async {
            //   final dateTime = await showDatePicker(
            //       context: context,
            //       initialDate: DateTime.now(),
            //       firstDate: DateTime.now().add(
            //         Duration(
            //           days: DateTime.now().differencToOldYear(100).inDays,
            //         ),
            //       ),
            //       lastDate: DateTime.now());
            //   if (dateTime != null) {
            //     controller.setTanggalInseminasi(dateTime);
            //   }
            // },
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: EditText(
                  label: 'Induk Jantan*',
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Induk Jantan', value),
                  keyboardType: TextInputType.number,
                  controller: controller.etIndukJantan,
                  isReadOnly: true,
                  onTap: () async {
                    final context = Get.context;
                    if (context != null) {
                      final ternak = await showSearch(
                        context: context,
                        delegate: SearchIndukJantanDelegate(),
                      );
                      controller.setIndukJantan(ternak);
                    }
                  },
                ),
              ),
              // Visibility(
              //   visible: controller.selectedIndukJantan != null,
              //   child: IconButton(
              //     onPressed: () => Get.toNamed(
              //       IdentitasDetailPage.routeName,
              //       arguments: IdentitasDetailParams(
              //         ternak: controller.selectedIndukJantan!,
              //         isFromForm: true,
              //       ),
              //     ),
              //     icon: const Icon(Icons.info, color: green),
              //   ),
              // ),
            ],
          ),
          const SizedBox(height: 16),
          EditText(
            label: 'Keterangan',
            keyboardType: TextInputType.text,
            textInputAction: TextInputAction.done,
            minLines: 5,
            maxLines: null,
            controller: controller.etKeterangan,
          ),
        ],
      ),
    );
  }

  Widget buildAction(BuildContext context) {
    return Obx(() {
      if (controller.isUpdating) {
        return const LinearProgressIndicator(
          color: green,
        );
      }

      return Container(
        color: Colors.white,
        child: Row(children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 12, top: 12, bottom: 12, right: 6),
              child: SizedBox(
                height: 40,
                child: ElevatedButton(
                    onPressed: () => Get.back(),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(36))),
                    child: Text(
                      'BATAL',
                      style: GoogleFonts.roboto(
                          color: black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                    )),
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(
                  right: 12, top: 12, bottom: 12, left: 6),
              child: SizedBox(
                height: 40,
                child: ElevatedButton(
                    onPressed: () {
                      if (controller.formKey.currentState?.validate() ==
                          false) {
                        return;
                      }

                      controller.next();
                    },
                    style: ElevatedButton.styleFrom(
                        backgroundColor: yellowDark,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(36))),
                    child: Text(
                      'SIMPAN',
                      style: GoogleFonts.roboto(
                          color: black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                    )),
              ),
            ),
          ),
        ]),
      );
    });
  }
}
