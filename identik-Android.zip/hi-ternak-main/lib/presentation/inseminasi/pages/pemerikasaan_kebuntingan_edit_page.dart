import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../utils/validation_util.dart';
import '../../register/widgets/chooseable_widget.dart';
import '../../widgets/default_scaffold.dart';
import '../../widgets/edit_text.dart';
import '../../widgets/ternak_information_dragable.dart';
import '../inseminasi_feature.dart';
import '../pages/preview_data/preview_pemeriksaan_kebuntingan_page.dart';

class PemeriksaanKebuntinganEditPage
    extends GetView<PemeriksaanKebuntinganEditController> {
  const PemeriksaanKebuntinganEditPage({Key? key}) : super(key: key);

  static const routeName = '/pemeriksaan-kebuntingan-edit';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Pemeriksaan Kebuntingan',
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Obx(
            () => Stack(
              children: [
                Container(
                  margin: const EdgeInsets.only(bottom: 50),
                  child: buildForm(context),
                ),
                Visibility(
                  visible: controller.ternak != null,
                  child: DraggableScrollableSheet(
                    initialChildSize: 0.25,
                    minChildSize: 0.10,
                    maxChildSize: 1,
                    builder: (context, scrollController) {
                      return SingleChildScrollView(
                        controller: scrollController,
                        child: TernakInformationDragable(
                          ternak: controller.ternak!,
                        ),
                      );
                    },
                  ),
                )
              ],
            ),
          ),
        ),
        bottomNavigation: buildAction(context),
      );

  Widget buildForm(BuildContext context) {
    return Form(
      child: ListView(
        children: [
          EditText(
            label: 'Tanggal PKB*',
            validator: (value) =>
                ValidationUtil.emptyValidate('Tanggal PKB', value),
            keyboardType: TextInputType.datetime,
            controller: controller.etTanggalPkb,
            isReadOnly: true,
            onTap: () {},
          ),
          const SizedBox(height: 16),
          EditText(
            label: 'Status Kebuntingan*',
            validator: (value) =>
                ValidationUtil.emptyValidate('Status Kebuntingan', value),
            keyboardType: TextInputType.number,
            textInputAction: TextInputAction.done,
            suffixIcon: const Icon(Icons.arrow_drop_down),
            isReadOnly: true,
            onTap: () => showModalBottomSheet(
                context: context,
                builder: (context) => ChooseableWidget<bool>(
                    values: List.generate(2, (index) => index % 2 == 0),
                    title: (value) => (value) ? 'Bunting' : 'Tidak Bunting',
                    onSelected: (value) =>
                        controller.setKebuntingan(isBunting: value))),
            controller: controller.etKebuntingan,
          ),
          if (controller.selectedBunting == true) ...buildBunting(),
          const SizedBox(height: 16),
          EditText(
            label: 'Keterangan',
            keyboardType: TextInputType.text,
            textInputAction: TextInputAction.done,
            minLines: 5,
            maxLines: null,
            controller: controller.etKeterangan,
          ),
        ],
      ),
    );
  }

  Widget buildAction(BuildContext context) {
    return Obx(() {
      if (controller.isUpdating) {
        return const LinearProgressIndicator(
          color: green,
        );
      }

      return Container(
        color: Colors.white,
        child: Row(children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 12, top: 12, bottom: 12, right: 6),
              child: SizedBox(
                height: 40,
                child: ElevatedButton(
                    onPressed: () => Get.back(),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(36))),
                    child: Text(
                      'BATAL',
                      style: GoogleFonts.roboto(
                          color: black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                    )),
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(
                  right: 12, top: 12, bottom: 12, left: 6),
              child: SizedBox(
                height: 40,
                child: ElevatedButton(
                    onPressed: () {
                      Get.toNamed(
                          PreviewPemeriksaanKebuntinganPage.routeName);
                    },
                    style: ElevatedButton.styleFrom(
                        backgroundColor: yellowDark,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(36))),
                    child: Text(
                      'SIMPAN',
                      style: GoogleFonts.roboto(
                          color: black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                    )),
              ),
            ),
          ),
        ]),
      );
    });
  }

  List<Widget> buildBunting() => [
        const SizedBox(height: 16),
        EditText(
            label: 'Usia Bunting (Bulan)*',
            validator: (value) =>
                ValidationUtil.emptyValidate('Usia Bunting', value),
            keyboardType: TextInputType.number,
            controller: controller.etUsiaBunting),
      ];
}
