import 'package:flutter/material.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../utils/datetime_util.dart';
import '../../widgets/default_scaffold.dart';
import '../get/inseminasi_controller.dart';

class InseminasiDetailPage extends GetView<InseminasiController> {
  const InseminasiDetailPage({Key? key}) : super(key: key);

  static const routeName = '/inseminasi-detail';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: controller.selectedInseminasi?.metodePerkawinan ?? '-',
        body: ListView(
          children: [
            componentTile(
                context,
                controller.selectedInseminasi?.metodePerkawinan ==
                        'transfer_embrio'
                    ? 'Tanggal Transfer'
                    : 'Tanggal Inseminasi',
                controller.selectedInseminasi?.tanggalInseminasi?.readable() ??
                    '-'),
            componentTile(
                context,
                controller.selectedInseminasi?.metodePerkawinan ==
                        'transfer_embrio'
                    ? 'Transfer Ke'
                    : 'Inseminasi ke',
                controller.selectedInseminasi?.inseminasiKe.toString() ?? '-'),
            controller.selectedInseminasi?.metodePerkawinan == 'alami'
                ? Container()
                : componentTile(
                    context,
                    controller.selectedInseminasi?.metodePerkawinan ==
                            'transfer_embrio'
                        ? 'Kode Kualitas'
                        : 'Kode Produksi',
                    controller.selectedInseminasi?.kodeProduksi ?? '-'),
            controller.selectedInseminasi?.metodePerkawinan == 'alami'
                ? Container()
                : componentTile(context, 'Produsen',
                    controller.selectedInseminasi?.produsen ?? '-'),
            componentTile(context, 'Eartag Pejantan',
                controller.selectedInseminasi?.eartagPejantan ?? '-'),
            controller.selectedInseminasi?.metodePerkawinan == 'alami'
                ? Container()
                : componentTile(context, 'Tanggal Produksi',
                    controller.selectedInseminasi?.tglProduksi ?? '-'),
            componentTile(context, 'Petugas',
                controller.selectedInseminasi?.petugas ?? '-'),
            componentTile(
              context,
              controller.selectedInseminasi?.metodePerkawinan ==
                      'transfer_embrio'
                  ? 'Tanggal Transfer Sebelumnya'
                  : 'Tanggal Inseminasi Sebelumnya',
              controller.selectedInseminasi?.tanggalInseminasiTerakhir
                      ?.readable() ??
                  '-',
            ),
            componentTile(context, 'Keterangan',
                controller.selectedInseminasi?.keterangan ?? '-'),
          ],
        ),
      );

  Widget componentTile(BuildContext context, String title, String value) =>
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            ListTile(
              contentPadding: const EdgeInsets.all(0),
              title: Text(title,
                  style: GoogleFonts.roboto(
                    color: black,
                    fontSize: 12,
                  )),
              subtitle: Text(value,
                  textAlign: TextAlign.justify,
                  style: GoogleFonts.roboto(
                      color: black, fontWeight: FontWeight.bold, fontSize: 16)),
            ),
            const Divider(color: greyE5, height: 0)
          ],
        ),
      );
}
