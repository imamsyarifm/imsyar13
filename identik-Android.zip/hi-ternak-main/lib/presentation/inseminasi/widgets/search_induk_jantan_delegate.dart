import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/inseminasi/induk_jantan.dart';
import '../../../data/repositories/inseminasi_repository.dart';

class SearchIndukJantanDelegate extends SearchDelegate {
  final repository = InseminasiRepository(
    client: Get.find<Dio>(),
  );

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          query = '';
        },
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () {
        Get.back();
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    if (query.length > 17) {
      return const Center(
          child: Text('No Eartag Yang Diinputkan Terlalu Panjang'));
    } else {
      return FutureBuilder<List<IndukJantan>>(
        future: repository.allInduk(search: query),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
              itemCount: snapshot.data?.length ?? 0,
              itemBuilder: (context, index) {
                final ternak = snapshot.data?[index];
                return ListTile(
                  title: Text(ternak?.codeProduct ?? '-'),
                  subtitle: Text(ternak?.pemilik ?? '-'),
                  onTap: () => Get.back(
                    result: ternak,
                  ),
                );
              },
            );
          } else {
            return const Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(green),
              ),
            );
          }
        },
      );
    }
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return const Center(
      child: Text('Harap masukan kata kunci'),
    );
  }
}
