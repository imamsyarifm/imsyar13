import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../app/consts/icons.dart';
import '../get/inseminasi_controller.dart';
import '../pages/inseminasi_buatan_edit_page.dart';

class InseminasiBuatanWidget extends GetWidget<InseminasiController> {
  const InseminasiBuatanWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => Scaffold(
        body: ListView(children: [
          componentTile(context, 'Tanggal Inseminasi', controller.date()),
          componentTile(context, 'Inseminasi ke', '4'),
          componentTile(context, 'Kode Semen', '4220'),
          componentTile(context, 'Petugas', 'Chandra Abdul Fattah'),
          componentTile(
              context, 'Tanggal Inseminasi Sebelumnya', controller.date()),
          componentTile(context, 'Keterangan', '-'),
        ]),
        floatingActionButton: FloatingActionButton(
          backgroundColor: yellowDark,
          onPressed: () => Get.toNamed(InseminasiBuatanEditPage.routeName),
          child: Image.asset(pencil, width: 16, height: 16),
        ),
      );

  Widget componentTile(BuildContext context, String title, String value) =>
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            ListTile(
              contentPadding: const EdgeInsets.all(0),
              title: Text(title,
                  style: GoogleFonts.roboto(
                    color: black,
                    fontSize: 12,
                  )),
              subtitle: Text(value,
                  textAlign: TextAlign.justify,
                  style: GoogleFonts.roboto(
                      color: black, fontWeight: FontWeight.bold, fontSize: 16)),
            ),
            const Divider(color: greyE5, height: 0)
          ],
        ),
      );
}
