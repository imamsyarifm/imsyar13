import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/inseminasi/kode_embrio_model.dart';
import '../../../data/repositories/inseminasi_repository.dart';

class SearchEmbrioCodeDelegate extends SearchDelegate {
  final repository = InseminasiRepository(
    client: Get.find<Dio>(),
  );

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          query = '';
        },
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () {
        Get.back();
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return FutureBuilder<List<KodeEmbrioModel>>(
      future: repository.embrioCodesOnline(search: query),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          return ListView.builder(
            itemCount: snapshot.data?.length ?? 0,
            itemBuilder: (context, index) {
              final ternak = snapshot.data?[index];
              return ListTile(
                title: Text(
                  ternak?.idDonor ?? '-',
                  style: GoogleFonts.roboto(fontWeight: FontWeight.bold),
                ),
                subtitle: Column(
                  children: [
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        const Text('Eartag Betina : '),
                        Text(ternak?.eartagBetina ?? '-')
                      ],
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        const Text('Rumpun Betina : '),
                        Text(ternak?.rumpunBetina ?? '-')
                      ],
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        const Text('Eartah Pejantan : '),
                        Text(ternak?.eartagPenjantan ?? '-')
                      ],
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        const Text('Rumpun Penjantan : '),
                        Text(ternak?.rumpunPenjantan ?? '-')
                      ],
                    ),
                    const SizedBox(height: 3),
                    const Divider(height: 1, color: Colors.grey,)
                  ],
                ),
                onTap: () => Get.back(
                  result: ternak,
                ),
              );
            },
          );
        } else {
          return const Center(
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(green),
            ),
          );
        }
      },
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return const Center(
      child: Text('Harap masukan kata kunci'),
    );
  }
}
