import '../../../data/models/ternak/identity_ternak_model.dart';

class InseminasiParams {
  final IdentityTernakModel ternak;
  final bool isFromScan;

  InseminasiParams({
    required this.ternak,
    this.isFromScan = false,
  });
}
