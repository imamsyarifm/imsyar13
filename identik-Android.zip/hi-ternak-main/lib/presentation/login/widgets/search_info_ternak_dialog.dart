import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../utils/validation_util.dart';
import '../../widgets/edit_text.dart';
import '../get/search_info_ternak_controller.dart';

class SearchInfoTernakDialog extends GetWidget<SearchInfoTernakController> {
  const SearchInfoTernakDialog({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          EditText(
            controller: controller.etIdTernak,
            validator: (value) =>
                ValidationUtil.emptyValidate('ID Ternak', value),
            autoValidateMode: AutovalidateMode.onUserInteraction,
            label: 'ID Ternak*',
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () =>
                  controller.searchTernak(controller.etIdTernak.text),
              style: ElevatedButton.styleFrom(
                backgroundColor: yellowDark,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(36),
                ),
              ),
              child: Text('Cari',
                  style: GoogleFonts.roboto(
                    color: black,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  )),
            ),
          ),
        ],
      ),
    );
  }
}
