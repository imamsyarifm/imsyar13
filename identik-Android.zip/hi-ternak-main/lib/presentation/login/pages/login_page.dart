import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../utils/networking_util.dart';
import '../../../utils/validation_util.dart';
import '../../input_eartag/pages/input_eartag_page.dart';
import '../../scan/scan_page.dart';
import '../../widgets/edit_text.dart';
import '../../widgets/top_authentication_widget.dart';
import '../get/login_controller.dart';

class LoginPage extends GetView<LoginController> {
  const LoginPage({Key? key}) : super(key: key);

  static const routeName = '/login';

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Form(
          key: controller.formLoginKey,
          child: ListView(
            children: [
              const TopAuthenticationWidget(
                title: 'IDENTIK PKH',
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
                child: EditText(
                  controller: controller.etUsername,
                  validator: (value) => ValidationUtil.emptyValidate(
                      'Nama Pengguna / Email', value),
                  autoValidateMode: AutovalidateMode.onUserInteraction,
                  label: 'Nama Pengguna / Email*',
                  keyboardType: TextInputType.emailAddress,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 20),
                child: EditText(
                  controller: controller.etPassword,
                  validator: (value) =>
                      ValidationUtil.emptyValidate('Kata Sandi', value),
                  autoValidateMode: AutovalidateMode.onUserInteraction,
                  label: 'Kata Sandi*',
                  isSecret: true,
                ),
              ),
              Obx(() {
                if (controller.isLoginChecking) {
                  return const Center(
                      child: CircularProgressIndicator(
                    color: green,
                  ));
                } else {
                  return Container(
                    height: 45,
                    margin: const EdgeInsets.only(
                        left: 16, right: 16, top: 20, bottom: 40),
                    child: ElevatedButton(
                        onPressed: () => controller.login(),
                        style: ElevatedButton.styleFrom(
                            backgroundColor: yellowDark,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(36))),
                        child: Text(
                          'LOGIN',
                          style: GoogleFonts.roboto(
                              color: black,
                              fontSize: 14,
                              fontWeight: FontWeight.bold),
                        )),
                  );
                }
              }),
              // Center(
              //   child: Text(
              //     'V${controller.appVer.text}',
              //     style: const TextStyle(color: Colors.grey),
              //   ),
              // ),
              // Padding(
              //   padding: const EdgeInsets.only(top: 55),
              //   child: Row(
              //     mainAxisAlignment: MainAxisAlignment.center,
              //     children: [
              //       Text('Belum punya akun?',
              //           style: GoogleFonts.roboto(
              //               color: black,
              //               fontSize: 14,
              //               fontWeight: FontWeight.bold)),
              //       const SizedBox(width: 6),
              //       GestureDetector(
              //         onTap: () =>
              //             Get.toNamed(RegisterPage.routeName, arguments:
              //  true),
              //         child: Text('Daftar disini',
              //             style: GoogleFonts.roboto(
              //                 color: gold,
              //                 fontSize: 14,
              //                 fontWeight: FontWeight.bold)),
              //       )
              //     ],
              //   ),
              // ),
            ],
          ),
        ),
        bottomNavigationBar: GestureDetector(
          onTap: () async {
            final isConnected = await NetworkingUtil.isConnected;
            if (isConnected) {
              Get.bottomSheet(Container(
                color: Colors.white,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ListTile(
                      title: const Text('Scan Eartag'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () {
                        Get.toNamed(
                          ScanPage.routeName,
                          arguments: ScanPageParams(
                            isPublic: true,
                            isInput: false,
                            inputNumber: '',
                          ),
                        );
                      },
                    ),
                    const Divider(),
                    ListTile(
                      title: const Text('Input Eartag'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () {
                        Get.toNamed(
                          InputEartagPage.routeName,
                          arguments: InputEartagParams(
                            isPublic: true,
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ));
              // Get.toNamed(
              //   ScanPage.routeName,
              //   arguments: ScanPageParams(isPublic: true),
              // );
            } else {
              Get.showSnackbar(const GetSnackBar(
                title: 'Tidak Ada Koneksi Internet',
                message: 'Pastikan anda terhubung dengan koneksi internet '
                    'untuk menggunakan fitur ini',
                duration: Duration(seconds: 3),
              ));
            }
          },
          child: Container(
            margin: const EdgeInsets.only(bottom: 16),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.qr_code, color: green),
                const SizedBox(width: 6),
                Text('INFORMASI TERNAK',
                    style: GoogleFonts.roboto(
                      color: green,
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    )),
              ],
            ),
          ),
        ),
      );
}
