import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/authentication_repository.dart';
import 'login_controller.dart';
import 'search_info_ternak_controller.dart';

class LoginBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(AuthenticationRepository(
      dio: Get.find<Dio>(),
    ));
    Get.put(LoginController(
      authRepository: Get.find<AuthenticationRepository>(),
    ));
    Get.put(SearchInfoTernakController());
  }
}
