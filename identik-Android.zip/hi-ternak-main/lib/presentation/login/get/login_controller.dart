// import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../../../data/models/login/login_request_model.dart';
import '../../../data/repositories/authentication_repository.dart';
// import '../../../utils/validation_util.dart';
import '../../main/main_page.dart';

class LoginController extends GetxController {
  final AuthenticationRepository _authRepository;

  LoginController({
    required AuthenticationRepository authRepository,
  }) : _authRepository = authRepository;

  final formLoginKey = GlobalKey<FormState>();
  final etUsername = TextEditingController();
  final etPassword = TextEditingController();
  var appVer = TextEditingController();

  @override
  void onInit() {
    super.onInit();
    getAppVersion();
  }

  final _isLoginChecking = false.obs;

  bool get isLoginChecking => _isLoginChecking.value;

  void login() async {
    if (formLoginKey.currentState!.validate()) {
      _isLoginChecking.value = true;

      final request = LoginRequestModel(
        email: etUsername.text,
        password: etPassword.text,
      );
      try {
        final isLoginSuccess = await _authRepository.login(request);

        if (isLoginSuccess) {
          Get.offAllNamed(MainPage.routeName);
        } else {
          Get.showSnackbar(const GetSnackBar(
            message: 'Login gagal harap periksa kembali email / password',
            duration: Duration(seconds: 3),
          ));
        }
      } catch (error) {
        debugPrint(error.toString());
        _isLoginChecking.value = false;
        // Get.showSnackbar(GetSnackBar(
        //   message: ValidationUtil.errorMessage(error as DioError),
        //   duration: const Duration(seconds: 3),
        // ));
        Get.showSnackbar(const GetSnackBar(
          message: 'Login gagal harap periksa kembali email / password',
          duration: Duration(seconds: 3),
        ));
      }
      _isLoginChecking.value = false;
    }
  }

  Future<void> getAppVersion() async {
    final packageInfo = await PackageInfo.fromPlatform();
    final currVersion = packageInfo.version.toString();
    appVer.text = currVersion;

    return;
  }
}
