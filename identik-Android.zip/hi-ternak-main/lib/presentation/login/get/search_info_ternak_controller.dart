import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SearchInfoTernakController extends GetxController {
  final etIdTernak = TextEditingController();

  void searchTernak(String idTernak) {
    Get.back();
    Get.showSnackbar(GetSnackBar(
      message: 'Search Ternak based on ID $idTernak',
      duration: const Duration(seconds: 3),
    ));
  }
}
