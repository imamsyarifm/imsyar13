import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../widgets/default_scaffold.dart';
import '../get/buku_induk_controller.dart';
import 'buku_induk_detail_page.dart';

class BukuIndukPage extends GetView<BukuIndukController> {
  const BukuIndukPage({Key? key}) : super(key: key);

  static const routeName = '/buku-induk';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
      appBarTitle: 'Buku Induk',
      body: ListView.builder(
          itemBuilder: (context, index) => Padding(
              padding: const EdgeInsets.only(left: 16, right: 16, top: 8),
              child: GestureDetector(
                onTap: () => Get.toNamed(BukuIndukDetailPage.routeName),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                            child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Buku Induk $index'),
                            Text('25 Juni 2021 ● Tunggal',
                                style: GoogleFonts.roboto(color: grey8))
                          ],
                        )),
                        const Icon(Icons.arrow_right)
                      ],
                    ),
                    const Divider(color: greyE5)
                  ],
                ),
              ))));
}
