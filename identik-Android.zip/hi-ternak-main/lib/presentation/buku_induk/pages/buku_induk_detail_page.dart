import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../app/consts/icons.dart';
import '../../widgets/default_scaffold.dart';
import '../get/buku_induk_controller.dart';
import 'buku_induk_edit_page.dart';

class BukuIndukDetailPage extends GetView<BukuIndukController> {
  static const routeName = '/buku-induk-detail';

  const BukuIndukDetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Buku Induk 1',
        body: ListView(children: [
          componentTile(context, 'ID Inseminasi', '14'),
          componentTile(context, 'Tanggal Lahir', controller.date()),
          componentTile(
              context, 'Normal / Distoksia (opsional)', controller.date()),
          componentTile(context, 'Tipe Kelahiran', 'Tunggal'),
          componentTile(context, 'Keadaan Waktu Dilahirkan', 'Sehat'),
          componentTile(context, 'ID Anak Sapi', '-'),
          componentTile(context, 'Jenis Kelamin', 'Jantan'),
          componentTile(context, 'Berat Badan (kg)', '350'),
          componentTile(context, 'Panjang Badan (cm)', '300'),
          componentTile(context, 'Tinggi Badan (cm)', '102'),
          componentTile(context, 'Tinggi Pinggul (cm)', '102'),
          componentTile(context, 'Lebar Pinggul (cm)', '102'),
          componentTile(context, 'Lingkar Dada (cm)', '102'),
          componentTile(context, 'Lingkar Skrotum (cm)', '102'),
          componentTile(context, 'Keterangan', '-'),
          const SizedBox(height: 100)
        ]),
        floatingAction: FloatingActionButton(
          backgroundColor: yellowDark,
          onPressed: () => Get.toNamed(BukuIndukEditPage.routeName),
          child: Image.asset(pencil, width: 16, height: 16),
        ),
      );

  Widget componentTile(BuildContext context, String title, String value) =>
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            ListTile(
              contentPadding: const EdgeInsets.all(0),
              title: Text(title,
                  style: GoogleFonts.roboto(
                    color: black,
                    fontSize: 12,
                  )),
              subtitle: Text(value,
                  textAlign: TextAlign.justify,
                  style: GoogleFonts.roboto(
                      color: black, fontWeight: FontWeight.bold, fontSize: 16)),
            ),
            const Divider(color: greyE5, height: 0)
          ],
        ),
      );
}
