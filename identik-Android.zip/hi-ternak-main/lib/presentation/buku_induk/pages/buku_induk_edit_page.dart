import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../../data/models/combo/combo_model.dart';
import '../../../utils/datetime_util.dart';
import '../../../utils/validation_util.dart';
import '../../register/widgets/chooseable_widget.dart';
import '../../widgets/default_scaffold.dart';
import '../../widgets/edit_text.dart';
import '../buku_induk_feature.dart';
import '../widgets/search_lahir_induk_delegate.dart';
import 'preview_buku_induk_page.dart';

class BukuIndukEditPage extends GetView<BukuIndukEditController> {
  const BukuIndukEditPage({Key? key}) : super(key: key);

  static const routeName = '/buku-induk-edit';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Buku Lahir',
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            child: Obx(() => ListView(
                  children: [
                    EditText(
                      label: 'No Eartag Induk Betina*',
                      validator: (value) => ValidationUtil.emptyValidate(
                          'No Eartag Induk Betina', value),
                      keyboardType: TextInputType.number,
                      controller: controller.etIdInseminasi,
                      isReadOnly: true,
                      onTap: () async {
                        final context = Get.context;
                        if (context != null) {
                          final lahirInduk = await showSearch(
                            context: context,
                            delegate: SearchLahirIndukDelegate(),
                          );
                          controller.setIdInseminasi(
                            lahirInduk,
                          );
                        }
                      },
                    ),
                    const SizedBox(height: 16),
                    EditText(
                      label: 'Tanggal Lahir*',
                      validator: (value) =>
                          ValidationUtil.emptyValidate('Tanggal Lahir', value),
                      keyboardType: TextInputType.datetime,
                      suffixIcon:
                          const Icon(Icons.arrow_drop_down, color: black),
                      isReadOnly: true,
                      onTap: () async {
                        final dateTime = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime.now().add(
                              Duration(
                                days: DateTime.now()
                                    .differencToOldYear(100)
                                    .inDays,
                              ),
                            ),
                            lastDate: DateTime.now());
                        if (dateTime != null) controller.setBirthDay(dateTime);
                      },
                      controller: controller.etBirthday,
                    ),
                    const SizedBox(height: 16),
                    EditText(
                      label: 'Jenis Kelahiran*',
                      validator: (value) => ValidationUtil.emptyValidate(
                          'Jenis Kelahiran', value),
                      keyboardType: TextInputType.text,
                      textInputAction: TextInputAction.done,
                      suffixIcon:
                          const Icon(Icons.arrow_drop_down, color: black),
                      isReadOnly: true,
                      onTap: () => showModalBottomSheet(
                        context: context,
                        builder: (context) => ChooseableWidget<ComboModel>(
                          values: controller.allJenisKelahiran,
                          title: (value) => value.label,
                          onSelected: controller.setTipeKelahiran,
                        ),
                      ),
                      controller: controller.etTipeKelahiran,
                    ),
                    const SizedBox(height: 16),
                    if (controller.selectedTipeKelahiran?.value !=
                            'keguguran' &&
                        controller.selectedTipeKelahiran?.value != null)
                      ...buildKenormalan(context),
                    if (controller.selectedTipeKelahiran?.value == 'keguguran')
                      ...buildKeguguran(),
                    EditText(
                        label: 'Keterangan*',
                        validator: (value) =>
                            ValidationUtil.emptyValidate('Keterangan', value),
                        keyboardType: TextInputType.text,
                        textInputAction: TextInputAction.done,
                        minLines: 5,
                        maxLines: null,
                        controller: controller.etKeterangan),
                    const SizedBox(height: 16),
                  ],
                )),
          ),
        ),
        bottomNavigation: Obx(() {
          return Visibility(
            visible: controller.isUpdating,
            replacement: Container(
              color: Colors.white,
              child: Row(children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                        left: 12, top: 12, bottom: 12, right: 6),
                    child: SizedBox(
                      height: 40,
                      child: ElevatedButton(
                          onPressed: () => Get.back(),
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(36))),
                          child: Text(
                            'BATAL',
                            style: GoogleFonts.roboto(
                                color: black,
                                fontSize: 14,
                                fontWeight: FontWeight.bold),
                          )),
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                        right: 12, top: 12, bottom: 12, left: 6),
                    child: SizedBox(
                      height: 40,
                      child: ElevatedButton(
                          onPressed: () async {
                            if (controller.formKey.currentState?.validate() ==
                                false) {
                              return;
                            }

                            Get.toNamed(PreviewBukuIndukPage.routeName);
                          },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: yellowDark,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(36))),
                          child: Text(
                            'SIMPAN',
                            style: GoogleFonts.roboto(
                                color: black,
                                fontSize: 14,
                                fontWeight: FontWeight.bold),
                          )),
                    ),
                  ),
                ),
              ]),
            ),
            child: const LinearProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(green),
            ),
          );
        }),
      );

  List<Widget> buildKenormalan(BuildContext context) => [
        EditText(
            label: 'Jenis Kelamin*',
            validator: (value) =>
                ValidationUtil.emptyValidate('Jenis Kelamin', value),
            keyboardType: TextInputType.text,
            textInputAction: TextInputAction.done,
            suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
            isReadOnly: true,
            onTap: () => showModalBottomSheet(
                context: context,
                builder: (context) => ChooseableWidget<ComboModel>(
                    values: controller.allGenderTernak,
                    title: (value) => value.label,
                    onSelected: controller.setGender)),
            controller: controller.etGender),
        const SizedBox(height: 16),
        EditText(
          label: 'Keadaan Waktu Dilahirkan',
          keyboardType: TextInputType.text,
          textInputAction: TextInputAction.done,
          controller: controller.etKeadaanWaktuDilahirkan,
          suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
          isReadOnly: true,
          onTap: () => showModalBottomSheet(
            context: context,
            builder: (context) => ChooseableWidget<ComboModel>(
              values: controller.allKondisiTernak,
              title: (value) => value.label,
              onSelected: (value) =>
                  controller.setKeadaanWaktuDilahirkan(value),
            ),
          ),
        ),
        const SizedBox(height: 16),
        EditText(
            label: 'Berat Badan (kg)*',
            validator: (value) =>
                ValidationUtil.emptyValidate('Berat Badan', value),
            keyboardType: TextInputType.number,
            controller: controller.etBeratBadan),
        const SizedBox(height: 16),
        EditText(
            label: 'Panjang Badan (cm)*',
            validator: (value) =>
                ValidationUtil.emptyValidate('Panjang Badan', value),
            keyboardType: TextInputType.number,
            controller: controller.etPanjangBadan),
        const SizedBox(height: 16),
        EditText(
            label: 'Tinggi Pundak (cm)*',
            validator: (value) =>
                ValidationUtil.emptyValidate('Tinggi Pundak', value),
            keyboardType: TextInputType.number,
            controller: controller.etTinggiBadan),
        const SizedBox(height: 16),
        EditText(
            label: 'Lingkar Dada (cm)*',
            validator: (value) =>
                ValidationUtil.emptyValidate('Lingkar Dada', value),
            keyboardType: TextInputType.number,
            controller: controller.etLingkarDada),
        const SizedBox(height: 16),
        EditText(
          label: 'Kategori Ternak*',
          validator: (value) =>
              ValidationUtil.emptyValidate('Kategori Ternak', value),
          keyboardType: TextInputType.text,
          textInputAction: TextInputAction.done,
          isReadOnly: true,
          controller: controller.etCategory,
          onTap: () => showModalBottomSheet(
            context: context,
            builder: (context) => ChooseableWidget<ComboModel>(
              values: controller.categories,
              title: (value) => value.label,
              onSelected: (value) =>
                  controller.setCategory(value: value, isInitial: false),
            ),
          ),
        ),
        const SizedBox(height: 16),
        EditText(
          label: 'Rumpun*',
          validator: (value) => ValidationUtil.emptyValidate('Rumpun', value),
          keyboardType: TextInputType.text,
          textInputAction: TextInputAction.done,
          isReadOnly: true,
          controller: controller.etRumpun,
          onTap: () => showModalBottomSheet(
            context: context,
            builder: (context) => ChooseableWidget<ComboModel>(
              values: controller.rumpun,
              title: (value) => value.label,
              onSelected: (value) =>
                  controller.setRumpun(value: value, isInitial: false),
            ),
          ),
        ),
        const SizedBox(height: 16),
        EditText(
          label: 'Program*',
          validator: (value) => ValidationUtil.emptyValidate('Program', value),
          keyboardType: TextInputType.number,
          isReadOnly: true,
          onTap: () => showModalBottomSheet(
            context: context,
            builder: (context) => ChooseableWidget<ComboModel>(
              values: controller.programs,
              title: (value) => value.label,
              onSelected: (value) =>
                  controller.setProgram(value: value, isInitial: false),
            ),
          ),
          controller: controller.etProgram,
        ),
        const SizedBox(height: 16),
      ];

  List<Widget> buildKeguguran() => [
        EditText(
          label: 'Umur Janin*',
          validator: (value) =>
              ValidationUtil.emptyValidate('Umur Janin', value),
          keyboardType: TextInputType.number,
          controller: controller.etUmurJanin,
        ),
        const SizedBox(height: 16),
        EditText(
          label: 'Sebab*',
          validator: (value) => ValidationUtil.emptyValidate('Sebab', value),
          keyboardType: TextInputType.text,
          textInputAction: TextInputAction.done,
          controller: controller.etSebab,
        ),
        const SizedBox(height: 16),
      ];
}
