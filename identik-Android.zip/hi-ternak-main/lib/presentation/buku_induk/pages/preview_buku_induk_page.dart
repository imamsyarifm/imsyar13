import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../../app/consts/colors.dart';
import '../../widgets/default_scaffold.dart';
import '../buku_induk_feature.dart';

class PreviewBukuIndukPage extends GetView<BukuIndukEditController> {
  const PreviewBukuIndukPage({Key? key}) : super(key: key);

  static const routeName = '/preview-buku-induk';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Check Data Buku Lahir',
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Obx(
            () => Stack(
              children: [
                Container(
                  margin: const EdgeInsets.only(bottom: 50),
                  child: buildForm(context),
                ),
              ],
            ),
          ),
        ),
        bottomNavigation: buildAction(context),
      );

  Widget buildForm(BuildContext context) {
    return Form(
      child: ListView(
        children: [
          const SizedBox(height: 16),
          Text(
            'Mohon Periksa Kembali Data Yang Telah '
            'Diinputkan Pada Buku Lahir',
            style:
                GoogleFonts.roboto(fontSize: 18, fontWeight: FontWeight.w500),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text('ID Inseminasi'),
              const SizedBox(width: 19),
              const Text(':'),
              const SizedBox(width: 5),
              Text(controller.etIdInseminasi.text)
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text('Tanggal Lahir'),
              const SizedBox(width: 19),
              const Text(':'),
              const SizedBox(width: 5),
              Text(controller.etBirthday.text)
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text('Jenis Kelahiran'),
              const SizedBox(width: 10),
              const Text(':'),
              const SizedBox(width: 5),
              Text(controller.etTipeKelahiran.text)
            ],
          ),
          const SizedBox(height: 16),
          if (controller.selectedTipeKelahiran?.value != 'keguguran' &&
              controller.selectedTipeKelahiran?.value != null)
            ...buildKenormalan(context),
          if (controller.selectedTipeKelahiran?.value == 'keguguran')
            ...buildKeguguran(),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text('Keterangan'),
              const SizedBox(width: 35),
              const Text(':'),
              const SizedBox(width: 5),
              Text(controller.etKeterangan.text)
            ],
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget buildAction(BuildContext context) {
    return Obx(() {
      if (controller.isUpdating) {
        return const LinearProgressIndicator(
          color: green,
        );
      }

      return Container(
        color: Colors.white,
        child: Row(children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 12, top: 12, bottom: 12, right: 6),
              child: SizedBox(
                height: 40,
                child: ElevatedButton(
                    onPressed: () => Get.back(),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(36))),
                    child: Text(
                      'BATAL',
                      style: GoogleFonts.roboto(
                          color: black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                    )),
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(
                  right: 12, top: 12, bottom: 12, left: 6),
              child: SizedBox(
                height: 40,
                child: ElevatedButton(
                    onPressed: () async {
                      final prefs = await SharedPreferences.getInstance();
                      final bool? isInput = prefs.getBool('isInput');
                      if (isInput == true) {
                        Get.toNamed(PasscodeBukuIndukPage.routeName);
                      } else {
                        controller.save();
                      }
                    },
                    style: ElevatedButton.styleFrom(
                        backgroundColor: yellowDark,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(36))),
                    child: Text(
                      'SIMPAN',
                      style: GoogleFonts.roboto(
                          color: black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                    )),
              ),
            ),
          ),
        ]),
      );
    });
  }

  List<Widget> buildKenormalan(BuildContext context) => [
        Row(
          children: [
            const Text('Jenis Kelamin'),
            const SizedBox(width: 18),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etGender.text)
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('Keadaan Waktu \nDilahirkan'),
            const SizedBox(width: 6),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etKeadaanWaktuDilahirkan.text)
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('Berat Badan'),
            const SizedBox(width: 32),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etBeratBadan.text)
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('Panjang Badan'),
            const SizedBox(width: 15),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etPanjangBadan.text != ''
                ? '${controller.etPanjangBadan.text} cm'
                : '')
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('Tinggi Pundak'),
            const SizedBox(width: 20),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etTinggiBadan.text != ''
                ? '${controller.etTinggiBadan} cm'
                : '')
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('Lingkar Dada'),
            const SizedBox(width: 27),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etLingkarDada.text != ''
                ? '${controller.etLingkarDada.text} cm'
                : '')
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('Kategori Ternak'),
            const SizedBox(width: 12),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etCategory.text)
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('Rumpun'),
            const SizedBox(width: 58),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etRumpun.text)
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('Program'),
            const SizedBox(width: 57),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etProgram.text)
          ],
        ),
      ];

  List<Widget> buildKeguguran() => [
        Row(
          children: [
            const Text('Umur Janin'),
            const SizedBox(width: 32),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etUmurJanin.text)
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('Sebab'),
            const SizedBox(width: 64),
            const Text(':'),
            const SizedBox(width: 5),
            Text(controller.etSebab.text)
          ],
        ),
      ];
}
