import 'package:get/get.dart';
import 'buku_induk_controller.dart';

class BukuIndukBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(BukuIndukController());
  }
}
