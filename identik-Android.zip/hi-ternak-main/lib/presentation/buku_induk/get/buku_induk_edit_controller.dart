// import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../data/models/buku_lahir/buku_induk_request.dart';
import '../../../data/models/buku_lahir/buku_lahir_induk.dart';
import '../../../data/models/combo/combo_model.dart';
import '../../../data/repositories/buku_lahir_repository.dart';
import '../../../data/repositories/combo_repository.dart';
import '../../../data/repositories/ternak_repository.dart';
import '../../../utils/datetime_util.dart';
// import '../../../utils/validation_util.dart';
import '../../main/main_page.dart';

class BukuIndukEditController extends GetxController {
  BukuIndukEditController({
    required BukuLahirRepository bukuLahirRepository,
    required ComboRepository comboRepository,
    required TernakRepository ternakRepository,
  })  : _bukuLahirRepository = bukuLahirRepository,
        _comboRepository = comboRepository;

  final BukuLahirRepository _bukuLahirRepository;
  final ComboRepository _comboRepository;

  final formKey = GlobalKey<FormState>();
  final etIdInseminasi = TextEditingController();
  final etBirthday = TextEditingController();
  final etTipeKelahiran = TextEditingController();
  final etKeadaanWaktuDilahirkan = TextEditingController();
  final etGender = TextEditingController();
  final etBeratBadan = TextEditingController();
  final etPanjangBadan = TextEditingController();
  final etTinggiBadan = TextEditingController();
  final etLingkarDada = TextEditingController();
  final etKeterangan = TextEditingController();
  final etCategory = TextEditingController();
  final etRumpun = TextEditingController();
  final etProgram = TextEditingController();
  final etUmurJanin = TextEditingController();
  final etSebab = TextEditingController();
  final pinController = TextEditingController();
  final focusNode = FocusNode();

  final _selectedIdInseminasi = Rx<BukuLahirInduk?>(null);
  final _selectedBirthday = DateTime.now().obs;
  final _selectedGender = Rx<ComboModel?>(null);
  final _selectedTipeKelahiran = Rx<ComboModel?>(null);
  final _selectedKeadaanWaktuDilahirkan = Rx<ComboModel?>(null);
  final _selectedCategory = Rx<ComboModel?>(null);
  final _selectedRumpun = Rx<ComboModel?>(null);
  final _selectedProgram = Rx<ComboModel?>(null);
  final _isUpdating = false.obs;

  final _categories = Rx<List<ComboModel>>([]);
  final _rumpun = Rx<List<ComboModel>>([]);
  final _programs = Rx<List<ComboModel>>([]);
  final _allLahirInduk = Rx<List<BukuLahirInduk>>([]);
  final _allJenisKelahiran = Rx<List<ComboModel>>([]);
  final _allKondisiTernak = Rx<List<ComboModel>>([]);
  final _allGenderTernak = Rx<List<ComboModel>>([]);

  BukuLahirInduk? get selectedIdInseminasi => _selectedIdInseminasi.value;
  DateTime get selectedBirthday => _selectedBirthday.value;
  ComboModel? get selectedGender => _selectedGender.value;
  ComboModel? get selectedTipeKelahiran => _selectedTipeKelahiran.value;
  ComboModel? get selectedKeadaanWaktuDilahirkan =>
      _selectedKeadaanWaktuDilahirkan.value;
  ComboModel? get selectedCategory => _selectedCategory.value;
  ComboModel? get selectedRumpun => _selectedRumpun.value;
  ComboModel? get selectedProgram => _selectedProgram.value;

  List<ComboModel> get categories => _categories.value;
  List<ComboModel> get rumpun => _rumpun.value;
  List<ComboModel> get programs => _programs.value;
  List<BukuLahirInduk> get allLahirInduk => _allLahirInduk.value;
  List<ComboModel> get allJenisKelahiran => _allJenisKelahiran.value;
  List<ComboModel> get allKondisiTernak => _allKondisiTernak.value;
  List<ComboModel> get allGenderTernak => _allGenderTernak.value;
  bool get isUpdating => _isUpdating.value;

  @override
  void onInit() {
    retrieveCategories;
    retrieveRumpun;
    retrievePrograms;
    retrieveJenisKelahiran;
    retrieveKondisiTernak;
    retrieveGenders;
    super.onInit();
  }

  void initValue() {
    etBirthday.text = DateTime.now().readable();
    _selectedBirthday.value = DateTime.now();
  }

  void setIdInseminasi(BukuLahirInduk value) {
    _selectedIdInseminasi.value = value;
    etIdInseminasi.text = value.idInseminasi;
  }

  String dateString(DateTime dateTime) {
    final dateFormat = DateFormat('dd MMMM yyyy');
    return dateFormat.format(dateTime);
  }

  void setBirthDay(DateTime dateTime) {
    _selectedBirthday.value = dateTime;
    etBirthday.text = dateString(dateTime);
  }

  void setTipeKelahiran(ComboModel value) {
    _selectedTipeKelahiran.value = value;
    etTipeKelahiran.text = value.label;
    Get.back();
  }

  void setKeadaanWaktuDilahirkan(ComboModel state) {
    _selectedKeadaanWaktuDilahirkan.value = state;
    etKeadaanWaktuDilahirkan.text = state.label;
    Get.back();
  }

  void setGender(ComboModel value) {
    _selectedGender.value = value;
    etGender.text = value.label;
    Get.back();
  }

  Future<void> get retrieveCategories async {
    final categories = await _comboRepository.ternakCategories;
    _categories.value = categories;
  }

  void setCategory({
    required ComboModel value,
    bool isInitial = true,
  }) {
    _selectedCategory.value = value;
    etCategory.text = value.label;
    if (!isInitial) Get.back();
  }

  Future<void> get retrieveRumpun async {
    _rumpun.value = await _comboRepository.rumpun(category: '2');
  }

  void setRumpun({
    required ComboModel value,
    bool isInitial = true,
  }) {
    _selectedRumpun.value = value;
    etRumpun.text = value.label;
    if (!isInitial) Get.back();
  }

  Future<void> get retrievePrograms async {
    _programs.value = await _comboRepository.programs;
  }

  void setProgram({
    required ComboModel value,
    bool isInitial = true,
  }) {
    _selectedProgram.value = value;
    etProgram.text = value.label;
    if (!isInitial) Get.back();
  }

  Future<void> retrieveLahirInduk({
    String? search,
    int offset = 0,
    int limit = 20,
  }) async {
    final values = await _bukuLahirRepository.allLahirInduk(
      limit: limit,
      offset: offset,
      search: search,
    );

    _allLahirInduk.value = values;
  }

  Future<void> get retrieveJenisKelahiran async {
    final values = await _comboRepository.allJenisKelahiran;
    _allJenisKelahiran.value = values;
  }

  Future<void> get retrieveKondisiTernak async {
    final values = await _comboRepository.allKondisiTernak;
    _allKondisiTernak.value = values;
  }

  Future<void> get retrieveGenders async {
    final values = await _comboRepository.genderTernak();
    _allGenderTernak.value = values;
  }

  Future<void> save() async {
    _isUpdating.value = false;

    final prefs = await SharedPreferences.getInstance();
    final bool? isInputPasscode = prefs.getBool('isInput');

    final payload = BukuIndukRequest(
      idProduct: _selectedIdInseminasi.value?.idProduct,
      idInseminasi: _selectedIdInseminasi.value?.idInseminasi,
      tanggalLahir: _selectedBirthday.value,
      jenisKelahiran: _selectedTipeKelahiran.value?.value,
      idCategory: _selectedCategory.value?.value,
      jenisKelamin: _selectedGender.value?.value,
      kondisiTernak: _selectedKeadaanWaktuDilahirkan.value?.value,
      beratBadan: etBeratBadan.text,
      panjangBadan: etPanjangBadan.text,
      tinggiPundak: etTinggiBadan.text,
      lingkarDada: etLingkarDada.text,
      idRumpun: _selectedRumpun.value?.value,
      program: _selectedProgram.value?.value,
      umurJanin: etUmurJanin.text,
      sebabKeguguran: etSebab.text,
      keterangan: etKeterangan.text,
      id: DateTime.now().millisecondsSinceEpoch,
      isInput: isInputPasscode! ? 1 : 0,
      passcode: isInputPasscode ? pinController.text : '',
    );

    try {
      if (isInputPasscode) {
        if (pinController.text.length != 6) {
          Get.showSnackbar(const GetSnackBar(
            message: 'Passcode harus 6 digit',
            duration: Duration(seconds: 3),
          ));
          return;
        }
      }

      final update = await _bukuLahirRepository.save(
        payload: payload,
      );
      _isUpdating.value = false;
      if (update) {
        Get.until((route) => route.settings.name == MainPage.routeName);
        Get.showSnackbar(const GetSnackBar(
          message: 'Perubahan Data Buku Lahir Berhasil',
          duration: Duration(seconds: 3),
        ));
      } else {
        Get.showSnackbar(const GetSnackBar(
          message: 'Perubahan Data Ternak Gagal',
          duration: Duration(seconds: 3),
        ));
      }
    } catch (error) {
      _isUpdating.value = false;
      // Get.showSnackbar(GetSnackBar(
      //   message: ValidationUtil.errorMessage(error as DioError),
      //   duration: const Duration(seconds: 3),
      // ));
      Get.showSnackbar(const GetSnackBar(
        message: 'Perubahan Data Ternak Gagal',
        duration: Duration(seconds: 3),
      ));
    }
  }
}
