import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/buku_lahir_repository.dart';
import '../../../data/repositories/combo_repository.dart';
import '../../../data/repositories/ternak_repository.dart';
import 'buku_induk_edit_controller.dart';

class BukuIndukEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(BukuLahirRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(ComboRepository(
      client: Get.find<Dio>(),
    ));
    Get.put(TernakRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(BukuIndukEditController(
      bukuLahirRepository: Get.find<BukuLahirRepository>(),
      comboRepository: Get.find<ComboRepository>(),
      ternakRepository: Get.find<TernakRepository>(),
    ));
  }
}
