export 'get/kandang_unggas_binding.dart';
export 'get/kandang_unggas_controller.dart';
export 'get/kandang_unggas_detail_binding.dart';
export 'get/kandang_unggas_detail_controller.dart';
export 'get/kandang_unggas_edit_binding.dart';
export 'get/kandang_unggas_edit_controller.dart';

export 'pages/kandang_unggas_detail_page.dart';
export 'pages/kandang_unggas_edit_page.dart';
export 'pages/kandang_unggas_page.dart';