import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import './kandang_unggas_page.dart';
import '../../../app/consts/colors.dart';
import '../../../data/models/address/subdistrict_model.dart';
import '../../../data/models/address/village_model.dart';
import '../../../utils/validation_util.dart';
import '../../identitas/widgets/search_owner_delegate.dart';
import '../../register/widgets/chooseable_widget.dart';
import '../../widgets/confirm_update_widget.dart';
import '../../widgets/default_scaffold.dart';
import '../../widgets/edit_text.dart';
import '../get/kandang_unggas_edit_controller.dart';

class KandangUnggasEditPage extends GetView<KandangUnggasEditController> {
  const KandangUnggasEditPage({Key? key}) : super(key: key);

  static const routeName = '/kandang-unggas-edit';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
      appBarTitle: 'Ubah Kandang Unggas',
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: controller.formKey,
          child: ListView(
            children: [
              EditText(
                label: 'Scan Code*',
                validator: (value) =>
                    ValidationUtil.emptyValidate('scan codq', value),
                controller: controller.etScanQode,
              ),
              const SizedBox(height: 16),
              EditText(
                label: 'Nama Kandang Unggas*',
                validator: (value) => ValidationUtil.emptyMinLengthValidate(
                    formName: 'Nama Kandang', value: value, minLength: 3),
                autoValidateMode: AutovalidateMode.onUserInteraction,
                keyboardType: TextInputType.text,
                textInputAction: TextInputAction.done,
                controller: controller.etNamaKandang,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(
                      RegExp(r'[A-Za-z0-9.,-\s]')),
                ],
                enableInteractiveSelection: false,
                maxLength: 30,
              ),
              const SizedBox(height: 16),
              EditText(
                label: 'Kapasitas*',
                validator: (value) =>
                    ValidationUtil.emptyValidate('Kapasitas', value),
                autoValidateMode: AutovalidateMode.onUserInteraction,
                keyboardType: TextInputType.number,
                controller: controller.etKapasitas,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                ],
                enableInteractiveSelection: false,
                maxLength: 5,
              ),
              EditText(
                label: 'Komoditas*',
                validator: (value) =>
                    ValidationUtil.emptyValidate('Komoditas', value),
                autoValidateMode: AutovalidateMode.onUserInteraction,
                keyboardType: TextInputType.text,
                textInputAction: TextInputAction.done,
                suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
                isReadOnly: true,
                onTap: () => showModalBottomSheet(
                  context: context,
                  builder: (context) => ChooseableWidget<String>(
                    values: controller.dataKomoditas,
                    title: (value) => value,
                    onSelected: (value) =>
                        controller.setKomoditas(value: value, isInitial: false),
                  ),
                ),
                controller: controller.etKomoditas,
              ),
              const SizedBox(height: 16),
              const SizedBox(height: 16),
              EditText(
                label: 'Pemilik*',
                validator: (value) =>
                    ValidationUtil.emptyValidate('Pemilik', value),
                autoValidateMode: AutovalidateMode.onUserInteraction,
                keyboardType: TextInputType.text,
                textInputAction: TextInputAction.done,
                controller: controller.etPemilik,
                isReadOnly: true,
                onTap: () async {
                  final context = Get.context;
                  if (context != null) {
                    final owner = await showSearch(
                      context: context,
                      delegate: SearchOwnerDelegate(),
                    );
                    controller.setPemilik(owner);
                  }
                },
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Obx(
                    () => Checkbox(
                      value: controller.isSameWithOwner,
                      onChanged: (controller.selectedPemilik != null)
                          ? controller.setSameWithOwner
                          : null,
                      activeColor: green,
                    ),
                  ),
                  const Text('Sama dengan alamat pemilik')
                ],
              ),
              const SizedBox(height: 8),
              Obx(
                () => Visibility(
                  visible: !controller.isSameWithOwner,
                  replacement: Text(controller.ownerAddress),
                  child: Column(children: buildAddress(context)),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigation: Container(
        color: Colors.white,
        child: Row(children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 12, top: 12, bottom: 12, right: 6),
              child: SizedBox(
                height: 40,
                child: ElevatedButton(
                    onPressed: () => Get.dialog(ConfirmUpdateWidget(
                          content: 'Apakah anda yakin ingin membatalkan '
                              'perubahan ini?',
                          onCancelPressed: () => Get.back(),
                          onConfirmedPressed: () {
                            Get.until((route) =>
                                route.settings.name ==
                                 KandangUnggasEditPage.routeName);
                          },
                        )),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(36))),
                    child: Text(
                      'BATAL',
                      style: GoogleFonts.roboto(
                          color: black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                    )),
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(
                  right: 12, top: 12, bottom: 12, left: 6),
              child: SizedBox(
                height: 40,
                child: Obx(() {
                  if (controller.isUpdatingData) {
                    return const Center(
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(green),
                      ),
                    );
                  }

                  return ElevatedButton(
                    onPressed: () {
                      // if (controller.formKey.currentState?.validate() ==
                      //     false) {
                      //   return;
                      // }

                      // if ((int.tryParse(controller.etKapasitas.text) ?? 0) <
                      //     1) {
                      //   Get.showSnackbar(const GetSnackBar(
                      //     message: 'Harap isi kapasitas minimal 1',
                      //     duration: Duration(seconds: 3),
                      //   ));
                      //   return;
                      // }

                      // if (controller.latitude.value == 0 ||
                      //     controller.longitude.value == 0) {
                      //   Get.showSnackbar(const GetSnackBar(
                      //     message:
                      //         'Mohon pastikan titik koordinat sudah sesuai',
                      //     duration: Duration(seconds: 3),
                      //   ));
                      //   return;
                      // }

                      // Get.dialog(ConfirmUpdateWidget(
                      //   onCancelPressed: () => Get.back(),
                      //   onConfirmedPressed: () =>
                      //       controller.updateDataKandang(),
                      // ));

                      Get.toNamed(KandangUnggasPage.routeName);
                    },
                    style: ElevatedButton.styleFrom(
                        backgroundColor: yellowDark,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(36))),
                    child: Text(
                      'SIMPAN',
                      style: GoogleFonts.roboto(
                          color: black,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                    ),
                  );
                }),
              ),
            ),
          ),
        ]),
      ));

  List<Widget> buildAddress(BuildContext context) {
    return [
      Obx(() {
        if (controller.isLoadingSubDistricts) {
          return const Center(
            child: CircularProgressIndicator(
              color: green,
            ),
          );
        } else {
          return EditText(
            controller: controller.etKecamatan,
            validator: (value) =>
                ValidationUtil.emptyValidate('Kecamatan', value),
            autoValidateMode: AutovalidateMode.onUserInteraction,
            onTap: () => showModalBottomSheet(
                context: context,
                builder: (context) => ChooseableWidget<SubdistrictModel>(
                      values: controller.subDistricts,
                      title: (SubdistrictModel kecamatan) =>
                          kecamatan.subDistrict,
                      onSelected: (kecamatan) =>
                          controller.setKecamatan(kecamatan),
                    )),
            label: 'Kecamatan*',
            isReadOnly: true,
            suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
          );
        }
      }),
      const SizedBox(height: 14),
      Obx(() {
        if (controller.isLoadingVillages) {
          return const Center(
            child: CircularProgressIndicator(
              color: green,
            ),
          );
        } else {
          return EditText(
            controller: controller.etDesa,
            validator: (value) => ValidationUtil.emptyValidate('Desa', value),
            autoValidateMode: AutovalidateMode.onUserInteraction,
            onTap: () => showModalBottomSheet(
                context: context,
                builder: (context) => ChooseableWidget<VillageModel>(
                      values: controller.villages,
                      title: (VillageModel desa) => desa.urbanVillage,
                      onSelected: (desa) => controller.setDesa(desa),
                    )),
            label: 'Desa*',
            isReadOnly: true,
            suffixIcon: const Icon(Icons.arrow_drop_down, color: black),
          );
        }
      }),
      const SizedBox(height: 14),
      EditText(
        controller: controller.etAlamat,
        keyboardType: TextInputType.streetAddress,
        validator: (value) => ValidationUtil.emptyMinLengthValidate(
          formName: 'Alamat Lengkap',
          value: value,
          minLength: 10,
        ),
        autoValidateMode: AutovalidateMode.onUserInteraction,
        label: 'Alamat Lengkap*',
        minLines: 5,
        maxLines: null,
        inputFormatters: <TextInputFormatter>[
          FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9.,-\s]')),
        ],
        enableInteractiveSelection: false,
        maxLength: 50,
      ),
      const SizedBox(height: 14),
      Obx(
        () => ListTile(
          title: Text('Latitude: ${controller.latitude}',
              style: GoogleFonts.roboto(
                fontSize: 14,
                color: black,
              )),
          subtitle: Text('Longitude: ${controller.longitude}',
              style: GoogleFonts.roboto(
                fontSize: 14,
                color: black,
              )),
          trailing: IconButton(
            icon: const Icon(Icons.location_on, color: green),
            onPressed: () => controller.getCurrentLocation(),
          ),
        ),
      ),
    ];
  }
}
