// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../app/consts/colors.dart';
import '../../scan/scan_page.dart';
import '../../widgets/default_scaffold.dart';
import '../get/kandang_unggas_controller.dart';
import '../widgets/kandang_unggas_search_delegate.dart';
import 'kandang_unggas_detail_page.dart';

class KandangUnggasPage extends GetView<KandangUnggasController> {
  const KandangUnggasPage({Key? key}) : super(key: key);

  static const routeName = '/kandang-unggas';

  @override
  Widget build(BuildContext context) => DefaultScaffold(
        appBarTitle: 'Kandang Unggas',
        actions: [
          IconButton(
            onPressed: () => showSearch(
              context: context,
              delegate: KandangUnggasSearchDelegate(),
            ),
            icon: const Icon(Icons.search),
          ),
        ],
        body: Padding(
          padding: const EdgeInsets.only(left: 16, right: 16, top: 8),
          child: GestureDetector(
            onTap: () async {
              await Get.toNamed(
                KandangUnggasDetailPage.routeName,
                // arguments: item,
              );
              controller.retrieveKandang;
            },
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                        child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Kandang Ayam Dummy 1',
                          style:
                              GoogleFonts.roboto(fontWeight: FontWeight.bold),
                        ),
                        const Text('100 Ekor'),
                        Text(
                            'Jawa Barat, '
                            'Sukabumi, '
                            'Sukabumi',
                            style: GoogleFonts.roboto(color: grey8)),
                        Text('AYMTEST123123123'),
                      ],
                    )),
                    const Icon(Icons.arrow_right)
                  ],
                ),
                const Divider(color: greyE5)
              ],
            ),
          ),
        ),
        // body: PagedListView<int, KandangUnggasModel>(
        //   pagingController: controller.pagingController,
        //   builderDelegate: PagedChildBuilderDelegate<KandangUnggasModel>(
        //     itemBuilder: (context, item, index) {
        //       return Padding(
        //         padding: const EdgeInsets.only(left: 16, right: 16, top: 8),
        //         child: GestureDetector(
        //           onTap: () async {
        //             await Get.toNamed(
        //               KandangUnggasDetailPage.routeName,
        //               // arguments: item,
        //             );
        //             controller.retrieveKandang;
        //           },
        //           child: Column(
        //             children: [
        //               Row(
        //                 children: [
        //                   Expanded(
        //                       child: Column(
        //                     crossAxisAlignment: CrossAxisAlignment.start,
        //                     children: [
        //                       Text(
        //                         'Kandang Ayam Dummy 1',
        //                         style: GoogleFonts.roboto(
        //                             fontWeight: FontWeight.bold),
        //                       ),
        //                       const Text('100 Ekor'),
        //                       Text(
        //                           'Jawa Barat, '
        //                           'Sukabumi, '
        //                           'Sukabumi',
        //                           style: GoogleFonts.roboto(color: grey8)),
        //                       Text('AYMTEST123123123'),
        //                     ],
        //                   )),
        //                   const Icon(Icons.arrow_right)
        //                 ],
        //               ),
        //               const Divider(color: greyE5)
        //             ],
        //           ),
        //         ),
        //       );
        //     },
        //   ),
        // ),
        floatingAction: Obx(
          () => Visibility(
            visible: controller.isConnectedToNetwork,
            replacement: const SizedBox.shrink(),
            child: FloatingActionButton(
              onPressed: () async {
                await Get.toNamed(
                  ScanPage.routeName,
                  arguments: ScanPageParams(
                    isKandangUnggas: true,
                    isInput: false,
                    inputNumber: '',
                  ),
                );
                controller.pagingController.refresh();
              },
              backgroundColor: green,
              child: const Icon(Icons.add),
            ),
          ),
        ),
      );
}
