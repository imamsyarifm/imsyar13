import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../app/consts/colors.dart';
import '../../../app/consts/icons.dart';
import '../../widgets/component_tile.dart';
import '../../widgets/default_scaffold.dart';
import '../get/kandang_unggas_detail_controller.dart';
import 'kandang_unggas_edit_page.dart';

class KandangUnggasDetailPage extends GetView<KandangUnggasDetailController> {
  static const routeName = '/kandang-unggas-detail';

  const KandangUnggasDetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      if (controller.kandang == null) {
        return DefaultScaffold(
          appBarTitle: 'Kandang Ayam Dummy 1',
          body: ListView(children: const [
            ComponentTile(title: 'Komoditas', value: 'Ayam'),
            ComponentTile(title: 'Kapasitas', value: '100 Ekor'),
            ComponentTile(title: 'Taggal Daftar', value: '25 Mei 2023'),
            ComponentTile(title: 'Nama Pemilik', value: 'Pak Bambang'),
            ComponentTile(title: 'NIK', value: '123123123'),
            ComponentTile(title: 'No. Telepon Pemilik', value: '08121231231'),
            ComponentTile(title: 'Email Pemilik', value: 'bmbng@test.com'),
            ComponentTile(title: 'Jenis Kelamin Pemilik', value: 'Laki-Laki'),
            ComponentTile(title: 'Alamat', value: 'Sukabumi'),
            ComponentTile(title: 'No Farm', value: 'AYM1213123123'),
          ]),
          floatingAction: FloatingActionButton(
            backgroundColor: green,
            onPressed: () => Get.toNamed(KandangUnggasEditPage.routeName,
                arguments: controller.kandang),
            child:
                Image.asset(pencil, width: 16, height: 16, color: Colors.white),
          ),
        );
        // return DefaultScaffold(
        //   appBarTitle: 'Detail Kandang Unggas',
        //   body: Container(
        //     color: Colors.white,
        //     child: const Center(
        //       child: CircularProgressIndicator(
        //         valueColor: AlwaysStoppedAnimation<Color>(green),
        //       ),
        //     ),
        //   ),
        // );
      }

      return DefaultScaffold(
        appBarTitle: 'Kandang Ayam Dummy 1',
        body: ListView(children: const [
          ComponentTile(title: 'Kapasitas', value: '100 ekor'),
          ComponentTile(title: 'Tanggal Dibangun', value: '11'),
          ComponentTile(title: 'Status Kandang', value: 'status'),
          ComponentTile(title: 'Nama Pemilik', value: '-'),
          ComponentTile(title: 'NIK', value: '-'),
          ComponentTile(title: 'No. Telepon Pemilik', value: '-'),
          ComponentTile(title: 'Email Pemilik', value: '-'),
          ComponentTile(title: 'Jenis Kelamin Pemilik', value: '-'),
          ComponentTile(title: 'Alamat', value: '-'),
        ]),
        floatingAction: FloatingActionButton(
          backgroundColor: green,
          onPressed: () => Get.toNamed(KandangUnggasEditPage.routeName,
              arguments: controller.kandang),
          child:
              Image.asset(pencil, width: 16, height: 16, color: Colors.white),
        ),
      );
    });
  }
}
