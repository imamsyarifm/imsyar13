import 'package:get/get.dart';

import 'kandang_unggas_detail_controller.dart';

class KandangUnggasDetailBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(KandangUnggasDetailController());
  }
}
