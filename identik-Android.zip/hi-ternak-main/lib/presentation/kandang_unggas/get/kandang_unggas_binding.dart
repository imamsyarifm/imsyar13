import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../../../data/repositories/kandang_unggas_repository.dart';
import 'kandang_unggas_controller.dart';

class KandangUnggasBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(KandangUnggasRepository(
      client: Get.find<Dio>(),
    ));

    Get.put(KandangUnggasController(
      repository: Get.find<KandangUnggasRepository>(),
    ));
  }
}
