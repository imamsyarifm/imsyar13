import 'package:dio/dio.dart';
import 'package:get/get.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

import '../../../data/models/kandang/kandang_model.dart';
import '../../../data/repositories/kandang_unggas_repository.dart';
import '../../../utils/networking_util.dart';
import '../../../utils/validation_util.dart';

class KandangUnggasController extends GetxController {
  final KandangUnggasRepository _repository;

  KandangUnggasController({
    required KandangUnggasRepository repository,
  }) : _repository = repository;

  static const _pageSize = 20;
  final pagingController = PagingController<int, KandangModel>(
    firstPageKey: 0,
  );

  final _kandang = Rx<KandangModel?>(null);
  final _isConnectedToNetwork = false.obs;

  KandangModel? get kandang => _kandang.value;
  bool get isConnectedToNetwork => _isConnectedToNetwork.value;

  @override
  void onInit() {
    pagingController.addPageRequestListener((pageKey) {
      retrieveKandang(pageKey);
    });
    super.onInit();
  }

  @override
  void onReady() async {
    _isConnectedToNetwork.value = await NetworkingUtil.isConnected;
    super.onReady();
    retrieveKandang;
    retrieveArgs;
  }

  void get retrieveArgs {
    final args = Get.arguments;
    if (args is KandangModel) {
      _kandang.value = args;
    }
  }

  void retrieveKandang(int page) async {
    try {
      final newItems = await _repository.all(
        offset: page,
      );

      final isOffline = await NetworkingUtil.isConnected == false;
      if (isOffline) {
        pagingController.appendLastPage(newItems);
        return;
      }

      final isLastPage = newItems.length < _pageSize;
      if (isLastPage) {
        pagingController.appendLastPage(newItems);
      } else {
        final nextPageKey = page + 1;
        pagingController.appendPage(newItems, nextPageKey);
      }
    } catch (error) {
      pagingController.error = error;
      Get.showSnackbar(GetSnackBar(
        message: ValidationUtil.errorMessage(error as DioError),
        duration: const Duration(seconds: 3),
      ));
    }
  }

  String get address {
    final kandang = _kandang.value!.address;
    return '${kandang.address} '
        'RT ${kandang.rt}'
        'RW ${kandang.rw}'
        '${kandang.district}';
  }

  @override
  void dispose() {
    pagingController.dispose();
    super.dispose();
  }
}
