import 'package:get/get.dart';

import '../../../data/models/kandang/kandang_unggas_model.dart';

class KandangUnggasDetailController extends GetxController {
  final _kandang = Rx<KandangUnggasModel?>(null);

  KandangUnggasModel? get kandang => _kandang.value;

  @override
  void onReady() {
    super.onReady();
    retrieveArgs;
  }

  void get retrieveArgs {
    final args = Get.arguments;
    if (args is KandangUnggasModel) {
      _kandang.value = args;
    }
  }

  String get address {
    final kandang = _kandang.value!.address;
    return '${kandang.address} '
        'RT ${kandang.rt}'
        'RW ${kandang.rw}'
        '${kandang.district}';
  }
}
