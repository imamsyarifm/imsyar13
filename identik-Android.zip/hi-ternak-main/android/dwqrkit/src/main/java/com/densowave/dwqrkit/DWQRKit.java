package com.densowave.dwqrkit;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;
import java.util.Map.Entry;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.util.Log;

import com.densowave.dwqrkit.data.DWQRRequestData;

/**
 * QR configuration parameter class
 */
public class DWQRKit{
	protected static final String DWQR_HISTORY_NAME = "DWQR_HISTORY_NAME";		// file name for saving history data in the terminal (for SharedPreferences)
	private static final String DWQR_LIBRARY_VERSION = "2.1.6";					// Library version
	private String paramDecode="";
	private static DWQRKit dwQrKit = null;										// Singletonize the class.
	private static DWQRLogoType dwEncoder = new DWQRLogoType();					// Logo data

	private DWQRRequestData dwQrRequestData = DWQRRequestData.sharedManager();	// Data to be used when requesting a server

	private Bitmap imageHistoryIcon = dwEncoder.getHistoryLogotype();			// History Screen Icons
	private int mode = DWQRScanMode.DWQR_NOMALMODE.ordinal();					// QR reading mode

	private int soundResourceID;			// The resource ID of the sound

	/**
	 * Color Setting
	 * Starting from the top, each byte is marked in the order of "transparency, red, green, and blue".
	 */
	private int pointScanFrameColor = 0xffff0000;			// Color of the sight in point-scan mode (default: red)
	private int qrFrameColor = 0xffff0000;					// Color of the outline frame (default: red)
	private int qrFrameDecodedColor = 0xffff0000;			// Color of the outline frame for a successful reading (default: red)

//	public static final boolean DWQR_isDEBUG_FLG = false;	// Log display flag (true: log display, false: log non-display)
	public static final boolean DWQR_isDEBUG_FLG = true;	// Log display flag (true: log display, false: log non-display)

	/**
	 * Create a DWQRKit class as a singleton (common class).
	 * @return dwQrKit	Singleton's DWQRKit class
	 */
	public static DWQRKit sharedManager() {
		if( dwQrKit == null ) {
			dwQrKit = new DWQRKit();
		}
		return dwQrKit;
	}

	/**
	 * Get the library version
	 * @return LIBLARY_VERSION　version information
	 */
	public static String getLibraryVersion() {
		return DWQR_LIBRARY_VERSION;
	}

	/**
	 * log output
	 * @param tag　tag
	 * @param msg　log message
	 */
	public static void setLog(String tag, String msg){
		if (DWQR_isDEBUG_FLG) {
			Log.d(tag, msg);
		}
	}

	/**
	 * Various setting items Initial setting
	 * false：OFF、true：ON
	 */
	public boolean isVibrationEnable = false;				// Vibration on/off at the completion of QR scanning
	public boolean isAudioEnable = false;					// Sound on/off at the completion of QR scanning
	public boolean isFlashEnable = false;					// Turn the LED light on/off
	public boolean isStopCapture = false;					// Capture stop on/off

	/**
	 * Outline Frame Setting for the Detected QR Code Initial Setting
	 * false：OFF、true：ON
	 */
	public boolean isQRFrameEnable = false;					// Outline frame Show/hide
	public boolean isQRFrameAnimation = false;				// Animation of the outer frame ON/OFF

	/**
	 * Server Connection Permissions/Prohibitions Initial Settings
	 * false : prohibited, true : permitted
	 */
	public boolean isServerConnectionEnable = true;			// server connections permitted/prohibit

	/**
	 * Show/Hide Company Logo Settings Initial Settings
	 * false : hide, true : show
	 */
	public boolean isLogoDisplayEnable = true;				// company logo Show/hide

	/**
	 * Decode permission/prohibition setting Initial setting
	 * false: Prohibited, true: Permitted
	 * Permission/prohibition of decoding is maintained in the license file, which can be accessed from the following properties I can't switch over.
	 */
	public boolean isParamQRcodeEnable = true;			// QR code
	public boolean isParamMicroQREnable = true;			// Micro QR
	public boolean isParamSQRCEnable = true;				// SRQC
	public boolean isParamFrameQREnable = true;			// Frame QR
	public boolean isParamUPCA_EAN13Enable = true;		// UPC-A and EAN-13
	public boolean isParamUPCEEnable = true;				// UPC-E
	public boolean isParamEAN8Enable = true;				// EAN-8

	public boolean isParamAddon2digitEnable = true;			// Add-on 2-digit decode
	public boolean isParamAddon5digitEnable = true;			// Add-on 5-digit decode
	public boolean isParamAddonCodeOnlyEnable = false;		// Code with add-ons only
	public boolean isParamConnectionQRBatchEnable = false;	// Batch editing mode for QR consolidated code
	public boolean isParamReversalCodeEnable = false;		// black-and-white code

	/**
	 * Get the ID for basic authentication to be used for server transmission
	 * @return ID used for basic authentication
	 */
	public String getRequestID(){
		return "";
	}

	/**
	 * Set the ID for basic authentication to be used for server transmission
	 * @param requestID ID used for basic authentication
	 */
	public void setRequestID(String requestID){
	}
	public void setParamDecode( String paramDecode ) {
		this.paramDecode = paramDecode;
	}
	public String getParamDecode() {
		return paramDecode;
	}
	/**
	 * Get the password to be used for server transmission
	 * @return password
	 */
	public String getRequestPassword(){
		return "";
	}

	/**
	 * Set the password to be used for server transmission
	 * @param requestPassword password
	 */
	public void setRequestPassword(String requestPassword){
	}

	/**
	 * Get AppID to be used for server transmission
	 * @return AppID
	 */
	public String getRequestAppID(){
		return "";
	}

	/**
	 * Set AppID to be used for server transmission
	 * @param requestAppID AppID
	 */
	public void setRequestAppID(String requestAppID){
	}

	/**
	 * Get the service ID to be used for server transmission
	 * @return requestServiceID
	 */
	public String getRequestServiceID(){
		return "";
	}

	/**
	 * Set the service ID to be used for server transmission
	 * @param requestServiceID service ID
	 */
	public void setRequestServiceID(String requestServiceID){
	}

	/**
	 * Get the options to be used for server transmission
	 * @return requestOption
	 */
	public String getRequestOption(){
		return "";
	}

	/**
	 * Set the options to be used for server transmission
	 * @param requestOption option
	 */
	public void setRequestOption(String requestOption){
	}

	/**
	 * Get the URL for decoding to be used for server transmission
	 * @return requestDecodeUrl
	 */
	public String getRequestDecodeUrl(){
		return "";
	}

	/**
	 * Set the URL for decoding to be used for server transmission
	 * @param requestDecodeUrl　URL for decoding
	 */
	public void setRequestDecodeUrl(String requestDecodeUrl){
	}

	/**
	 * Get the log URL
	 * @return log URL
	 */
	public String getRequestLogUrl() {
		return "";
	}

	/**
	 * Get the expiration date of the license file
	 * @return expiration date
	 */
	public String getExpirationDate() {
		return this.dwQrRequestData.getExpirationDate();
	}

	/**
	 * Get a color sight for point-scan mode
	 * @return pointScanFrameColor　color code
	 */
	public int getPointScanFrameColor() {
		return pointScanFrameColor;
	}

	/**
	 * Set a color sight for point-scan mode
	 * @param pointScanFrameColor　color code
	 */
	public void setPointScanFrameColor( int pointScanFrameColor ) {
		this.pointScanFrameColor = pointScanFrameColor;
	}

	/**
	 * Get the color of the outline frame.
	 * @return qrFrameColor　color code
	 */
	public int getQrFrameColor() {
		return qrFrameColor;
	}

	/**
	 * Set the color of the outline frame.
	 * @param qrFrameColor　color code
	 */
	public void setQrFrameColor( int qrFrameColor ) {
		this.qrFrameColor = qrFrameColor;
	}

	/**
	 * Get the color of the outline frame for a successful reading
	 * @return qrFrameDecodedColor　color code
	 */
	public int getQrFrameDecodedColor() {
		return qrFrameDecodedColor;
	}

	/**
	 * Set the color of the outline frame for a successful reading
	 * @param qrframeDecodedColor　color code
	 */
	public void setQrFrameDecodedColor( int qrframeDecodedColor ) {
		this.qrFrameDecodedColor = qrframeDecodedColor;
	}

	/**
	 * Get QR reading mode
	 * @return mode　QR reading mode
	 */
	public int getMode() {
		return mode;
	}

	/**
	 * Set QR reading mode
	 * @param mode　QR reading mode
	 */
	public void setMode( int mode ) {
		this.mode = mode;
	}

	/**
	 * Get the resource ID of the sound on completion of a QR scan
	 * @return soundResourceID The resource ID of the sound
	 */
	public int getSoundResourceID(){
		return this.soundResourceID;
	}

	/**
	 * Set the resource ID of the sound on completion of a QR scan
	 * @param soundResourceID
	 */
	public void setSoundResourceID(int soundResourceID){
		this.soundResourceID = soundResourceID;
	}

	/**
	 * Get history data
	 * @param context　context
	 * @return list　history data sorted in descending order
	 */
	public ArrayList<DWQRHistory> getHistoryData(Context context){
		DWQRHistory history;			// history data
		ArrayList<DWQRHistory> list = new ArrayList<DWQRHistory>();		// ArrayList for storing history data
		SharedPreferences sharedPreferences = context.getSharedPreferences(DWQR_HISTORY_NAME, Context.MODE_PRIVATE);	// history data stored in the device

		// Extracting history data stored in the device
		Map<String,?> map = sharedPreferences.getAll();
		for( Entry<String, ?> entry : map.entrySet() ) {
			history = new DWQRHistory( entry.getKey(), (String) entry.getValue() );
			list.add( history );
		}

		// Sort in descending order
		Collections.sort( list, new Comparator<DWQRHistory>() {
			@Override
			public int compare(DWQRHistory lhs, DWQRHistory rhs) {
				if (lhs.date == null || rhs.date == null){
					return 0;
				}
				// Comparison of two data objects
				int result = lhs.date.compareTo(rhs.date) * -1;
				return result;
			}
		});
		return list;
	}

	/**
	 * Delete individual history data
	 * @param context　context
	 * @param data　History data to be deleted
	 * @return result　Deletion Results
	 */
	public boolean deleteHistoryData(Context context, String data){
		boolean result = false;		// Initialization of Deletion Results
		SharedPreferences sharedPreferences = context.getSharedPreferences(DWQR_HISTORY_NAME, Context.MODE_PRIVATE);	// History data stored in the device

		// Extracting history data stored in the device
		Editor editor = sharedPreferences.edit();
		Map<String,?> map = sharedPreferences.getAll();

		// If the data is in a key or object, delete it.
		for( Entry<String, ?> entry : map.entrySet() ){
			String key = entry.getKey();
			String value = (String) entry.getValue();
			if( data.equals(key) || data.equals(value) ){
				result = editor.remove(key).commit();
			}
		}
		return result;
	}

	/**
	 * Delete all history data
	 * @param context　context
	 * @return editor.clear().commit()　All delete process results
	 */
	public boolean deleteAllHistoryData(Context context){
		// Delete all history data stored in the device
		SharedPreferences sharedPreferences = context.getSharedPreferences(DWQR_HISTORY_NAME, Context.MODE_PRIVATE);
		Editor editor = sharedPreferences.edit();
		return editor.clear().commit();
	}

	/**
	 * Get the history logo
	 * @return imageHistoryIcon　history logo
	 */
	public Bitmap getImageHistoryIcon(){
		return imageHistoryIcon;
	}

	/**
	 * Set the history logo
	 * @param imageHistoryIcon　history logo
	 */
	public void setImageHistoryIcon(Bitmap imageHistoryIcon){
		Bitmap tmpBmp;
		Matrix matrix = new Matrix();
		// expansion ratio
		float resizeW = (float) 0.3;
		float resizeH = (float) 0.3;
		// Set the ratio to Matrix.
		matrix.postScale( resizeW, resizeH );
		// Resize Image
		tmpBmp = Bitmap.createBitmap(imageHistoryIcon, 0, 0, imageHistoryIcon.getWidth(),imageHistoryIcon.getHeight(), matrix,true);
		this.imageHistoryIcon = tmpBmp;
	}
}
