package com.densowave.dwqrkit;

import android.os.AsyncTask;

import com.densowave.dwqrkit.data.DWQRRequestData;

import okhttp3.Authenticator;
import okhttp3.Credentials;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.Route;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

public class DWQRLogServerConnection extends AsyncTask<String, Integer, String> {
    /**
     * constant
     */
    private static final String DWQR_TAG = DWQRLogServerConnection.class.getSimpleName();	// Tab settings
    private static final String DWQR_SERVER_ERROR_TIMEOUT = "DWQR_SERVER_ERROR_TIMEOUT";	// time out
    private static final String DWQR_SERVER_ERROR_FAILED = "DWQR_SERVER_ERROR_FAILED";		// failure

    /**
     * instance declaration
     */
    private DWQRKit dwqrKit = DWQRKit.sharedManager();
    private DWQRRequestData requestData = DWQRRequestData.sharedManager();
    private ResponseServerCallback responseServerCallback = null;   // callback
    private OkHttpClient httpClient;       // HTTP request

    /**
     * interface
     */
    public interface ResponseServerCallback {
        void onPostExecute(int statusCode);
        void onCancelled();
    }

    /**
     * DWQRLogDataServerConnection constructor
     * @param responseServerCallback Response server callbacks (asynchronous processing)
     */
    public DWQRLogServerConnection( DWQRLogServerConnection.ResponseServerCallback responseServerCallback ) {
        this.responseServerCallback = responseServerCallback;
    }

    /**
     * Start sending the log
     * @return The string of the request result
     */
    private String requestLogData() {
        DWQRKit.setLog(DWQR_TAG, "Start Request.");
        String resultString = null;					// result of a communication
        String sendData = requestData.createLogData();   		// Get transmission log data

        httpClient = new OkHttpClient.Builder()
                .connectTimeout(5000, TimeUnit.MILLISECONDS)    // Connection establishment timeout
                .writeTimeout(5000, TimeUnit.MILLISECONDS)      // Timeout after connection
                .readTimeout(5000, TimeUnit.MILLISECONDS)       // Timeout after connection
                .hostnameVerifier(new HostnameVerifier() {
                    @Override
                    public boolean verify(String s, SSLSession sslSession) {
                        // Allow all hosts to skip hostname validation
                        return true;
                    }
                })
                .authenticator(new Authenticator() {
                    @Override
                    public Request authenticate(Route route, Response response) throws IOException {
                        // Basic authentication is required, but the password and ID are blank because they are not used
                        String credential = Credentials.basic("", "");
                        return response.request().newBuilder().header("Authorization", credential).build();
                    }
                })
                .build();

        if (!sendData.equals("")) {
            try {
                DWQRKit.setLog(DWQR_TAG, "request data = " + sendData);

                // Perform a POST transmission
                RequestBody body = RequestBody.create(sendData, MediaType.get("application/json; charset=utf-8"));
                Request httpRequest = new Request.Builder()
                        .url(requestData.getRequestLogUrl())
                        .post(body)
                        .build();
                try (Response httpResponse = httpClient.newCall(httpRequest).execute()) {
                    if( httpResponse.code() == 200 ){
                        resultString = httpResponse.body().string();
                    }else{
                        DWQRKit.setLog(DWQR_TAG, "Failed request log data.");
                    }
                }
            } catch (IOException | NullPointerException e){
                resultString = DWQR_SERVER_ERROR_FAILED;							// Set the communication result
            }
        } else {
            DWQRKit.setLog(DWQR_TAG, "No request data.");
        }
        return resultString;
    }

    @Override
    protected String doInBackground( String... params ) {
        return requestLogData();
    }

    @Override
    protected void onPostExecute( String result ) {
        int statusCode = DWQRStatusCode.DWQR_SUCCESS.ordinal();
        if( result == null ){
            // Deleting Log Data
            requestData.deleteLogData();
        } else if (result.equals(DWQR_SERVER_ERROR_TIMEOUT)) {
            DWQRKit.setLog(DWQR_TAG, "Timeout send lod data.");
            statusCode = DWQRStatusCode.DWQR_TIMEOUT.ordinal();
        } else if (result.equals(DWQR_SERVER_ERROR_FAILED)) {
            DWQRKit.setLog(DWQR_TAG, "Failed send lod data.");
            statusCode = DWQRStatusCode.DWQR_FAILED.ordinal();
        }

        if( responseServerCallback != null ){
            responseServerCallback.onPostExecute(statusCode);
        }
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
        if( responseServerCallback != null ){
            responseServerCallback.onCancelled();
        }
    }
}
