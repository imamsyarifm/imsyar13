package com.densowave.dwqrkit;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentActivity;
import android.util.DisplayMetrics;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

/**
 * indicator class
 */
public class DWQRIndicator extends DialogFragment {

	private DWQRKit dwqrkit = DWQRKit.sharedManager();							// Singleton's DWQRKit class

	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {

		RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);	// RelativeLayout layout parameters
		RelativeLayout layout = new RelativeLayout(getActivity());				// RelativeLayout
		layout.setLayoutParams(params);											// Layout settings
		layout.setBackgroundColor(0xFF000000);									// Background color (black)

		params.addRule(RelativeLayout.CENTER_HORIZONTAL);
		params.addRule(RelativeLayout.CENTER_VERTICAL);
		ProgressBar progressBar = new ProgressBar(getActivity(), null, android.R.attr.progressBarStyleLarge);
		progressBar.setLayoutParams(params);

		layout.addView(progressBar);

		Dialog dialog = new Dialog(getActivity());
		// Hide the title
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        // full screen
        dialog.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        dialog.setContentView(layout);
        // Make the background transparent.
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.RED));

		return dialog;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		Dialog dialog = getDialog();
		WindowManager.LayoutParams lp = dialog.getWindow().getAttributes();

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        int dialogWidth = (int) (metrics.widthPixels * 0.3);
        int dialogHeight = (int) (metrics.widthPixels * 0.3);

        lp.width = dialogWidth;
        lp.height = dialogHeight;
        dialog.getWindow().setAttributes(lp);

        // Disabling indexage tapping events
        dialog.setCanceledOnTouchOutside(false);
	}

	/**
	 * indicator display
	 * @param context    context
	 */
	public void showIndicator(Context context){
		dwqrkit.isStopCapture = true;
		show(((FragmentActivity)context).getSupportFragmentManager(), "dwqrIndicator");
	}

	/**
	 * indicator removal
	 */
	public void deleteIndicator(){
		dwqrkit.isStopCapture = false;
		dismiss();
	}
}
