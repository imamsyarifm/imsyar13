package com.densowave.dwqrkit.common;

import android.os.Environment;

/**
 * common class
 */
public class DWQRCommon {
    /**
     * To get free space in the external storage area
     * @return Free Space in External Storage Area [MB]
     */
    public static long getExternalStorage(){
        final long megaByte = (1024 * 1024);	// Conversion factor to Mbyte
        long freeByteSize = 0;
        String state = Environment.getExternalStorageState();

        //Check if external storage space is available
        if( Environment.MEDIA_MOUNTED.equals(state) || Environment.MEDIA_MOUNTED_READ_ONLY.equals(state) ){
            //Get Size
            freeByteSize = Environment.getExternalStorageDirectory().getFreeSpace() / megaByte;
        }
        return freeByteSize;
    }
}
