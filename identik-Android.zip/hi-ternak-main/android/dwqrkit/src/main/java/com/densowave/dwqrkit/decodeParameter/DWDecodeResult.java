package com.densowave.dwqrkit.decodeParameter;

import android.graphics.Point;

/**
 * Class for storing the decode result
 */
public class DWDecodeResult {

	private static final int DWQR_COORDINATES = 4;	// The number of vertices of the exterior

	private int status;							// 		Stores the result of prDecoder.DCD_DecodeSymbol()
	private int codeNum;							// Number of codes to be decoded
	private String foundQRCodeString;			// 		QR string results
	private String foundQRCodeCellString;		// 		Cell data in QR
	private String codeMark;						// Get the resulting Code Mark
    private boolean localDecode;				// 		Local decode or server decode?
    private Point[][] codeOutline;				// 		Code Outline Location
    private byte[] binariData;					// 		Stores the binary data of the decode result

    /**
     * Set the outline coordinates
     */
	public DWDecodeResult(){
		codeOutline = new Point[DWDecodeConstants.DWQR_MAX_CODENUM][DWQR_COORDINATES];
		codeOutline[0][0] = new Point(0, 0);
		codeOutline[0][1] = new Point(0, 0);
		codeOutline[0][2] = new Point(0, 0);
		codeOutline[0][3] = new Point(0, 0);
		codeOutline[1][0] = new Point(0, 0);
		codeOutline[1][1] = new Point(0, 0);
		codeOutline[1][2] = new Point(0, 0);
		codeOutline[1][3] = new Point(0, 0);
	}

	/**
	 * Get Status
	 * @return status　status
	 */
	public int getStatus() {
		return status;
	}

	/**
	 * Set Status
	 * @param status　status
	 */
	public void setStatus(int status) {
		this.status = status;
	}

	/**
	 * Get the number of detected QR codes
	 * @return codeNum　Number of QR Codes Detected
	 */
	public int getCodeNum() {
		return codeNum;
	}

	/**
	 * Set the number of detectable QR codes
	 * @param codeNum　Number of QR Codes Detected
	 */
	public void setCodeNum( int codeNum ) {
		this.codeNum = codeNum;
	}

	/**
	 * Get QR character string result
	 * @return foundQRCodeString　QR string results
	 */
	public String getFoundQRCodeString() {
		return foundQRCodeString;
	}

	/**
	 * Set the QR string result
	 * @param foundQRCodeString　QR string results
	 */
	public void setFoundQRCodeString(String foundQRCodeString) {
		this.foundQRCodeString = foundQRCodeString;
	}

	/**
	 * Get the QR Cell data
	 * @return foundQRCodeCellString　 the QR Cell data
	 */
	public String getFoundQRCodeCellString() {
		return foundQRCodeCellString;
	}

	/**
	 * Set the QR Cell data
	 * @param foundQRCodeCellString　 the QR Cell data
	 */
	public void setFoundQRCodeCellString(String foundQRCodeCellString) {
		this.foundQRCodeCellString = foundQRCodeCellString;
	}

	/**
	 * Get code type
	 * @return codeMark　code type
	 */
	public String getCodeMark() {
		return codeMark;
	}

	/**
	 * Set code type
	 * @param codeMark　code type
	 */
	public void setCodeMark(String codeMark) {
		this.codeMark = codeMark;
	}

	/**
	 * Get processing results
	 * @return success (true: success, false: failure)
	 */
	public boolean isSuccess(){
		boolean success = false;
		// Determine by looking at status values
		if(getStatus() == DWDecodeConstants.SUCCESS ) {
			success = true;
		}
		return success;
	}

	/**
     * Set Local Decode
     * @param value（true：local decode, false: not local decode）
     */
    public void setLocalDecode(boolean value) {
        localDecode = value;
    }

    /**
     * Get Local Decode
     * @return localDecode（true：local decode, false: not local decode)
     */
    public boolean isLocalDecode() {
        return localDecode;
    }

    /**
     *  Get the outline coordinates of the QR Code
     * @param pos_n　Corner position
     * @param n　Decode buffer number
     * @return codeOutline　external coordinates
     */
    public Point getCodeOutline(int pos_n, int n) {
    	return codeOutline[n][pos_n];
    }

    /**
     *  Set the Coordinates of the QR Code
     * @param pos　position
     * @param n　Decode buffer number
     */
    public void setCodeOutline(int[] pos, int n) {
    	codeOutline[n][0].x = pos[0];
       	codeOutline[n][0].y = pos[1];
    	codeOutline[n][1].x = pos[2];
       	codeOutline[n][1].y = pos[3];
    	codeOutline[n][2].x = pos[4];
       	codeOutline[n][2].y = pos[5];
    	codeOutline[n][3].x = pos[6];
       	codeOutline[n][3].y = pos[7];
    }

    /**
     *  Get binary data of decode results
     * @return Decoded binary data
     */
    public byte[] getBinaryData(){
    	return this.binariData;
    }

    /**
     * Set binary data of decode results
     * @param binaryData Decoded binary data
     */
    public void setBinaryData(byte[] binaryData){
    	this.binariData = binaryData;
    }
}
