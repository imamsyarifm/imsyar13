package com.densowave.dwqrkit.decodeParameter;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;

import com.densowave.dwqrkit.DWQRScanMode;
import com.densowave.dwqrkit.DWQRStatusCode;
import com.densowave.dwqrkit.data.DWQRRequestData;
import com.densowave.dwqrkit.decodeParameter.DWDecodeParameter.DWDecodeBarcodeType;
import com.densowave.dwqrkit.decodeParameter.DWDecodeParameter.DWDecodeCombinedQR;
import com.densowave.dwqrkit.decodeParameter.DWDecodeParameter.DWDecodeMultipleQR;
import com.densowave.dwqrkit.decodeParameter.DWDecodeParameter.DWDecodePointScanQR;
import com.densowave.dwqrkit.decodeParameter.DWDecodeParameter.DWDecodeQRType;
import com.densowave.dwqrkit.decodeParameter.DWDecodeParameter.DWDecodeUPCAddonType;
import com.densowave.dwqrkit.decodeParameter.DWDecodeParameter.DWDecodeReversalCode;
import com.densowave.qrdecodelib.QRDecoder;


/**
 * decoding process
 */
public final class DWDecoder {
	private int[] parameterData;				// Decode settings
	private QRDecoder qrDecoder;					// decoder

	/**
	 * Decode settings
	 */
	public DWDecoder() {
		parameterData = new int[5];				// Decode settings
		resetDecodeParameterData();
		qrDecoder = new QRDecoder();
	}

	/**
	 * Initializing Decode Settings
	 */
	public void resetDecodeParameterData() {
		parameterData[DWDecodeQRType.PARAM_INDEX] = 0;			// QR Code Setting
		parameterData[DWDecodeBarcodeType.PARAM_INDEX] = 0;		// Barcode Setting
		parameterData[DWDecodeUPCAddonType.PARAM_INDEX] = 0;	// UPC Add-on Setting
		parameterData[DWDecodeMultipleQR.PARAM_INDEX] = 0;		// Multiple Code Batch Decode Setting
		parameterData[DWDecodeCombinedQR.PARAM_INDEX] = 0;		// QR consolidated code decode mode Setting
	}

	/**
	 * Image data decoding
	 * @param yuvData　image data
	 * @param previewWidth　Screen Preview: Width
	 * @param previewHeight　Screen Preview: Height
	 * @param mode　QR reading mode
	 * @return result　Decode Result (nativeDecode Result)
	 */
	public DWDecodeResult decodeData( byte[] yuvData, int previewWidth, int previewHeight, int mode ) {
		return nativeDecode( yuvData, previewWidth, previewHeight, mode );
	}

	/**
	 * Method for decoding yuv conversion
	 * @param buffnum　QR Code Identification Value to be decoded
	 * @param result　Decoding result obtained by nativeDecode
	 * @return result　Decoding result (nativeYuvDecode processing result)
	 */
	public DWDecodeResult getDecodeData( int buffnum, DWDecodeResult result ) {
		return getDecodeDataResulet( buffnum, result );
	}

	/**
	 * Method for decoding from a photo (Bitmap)
	 * @param grayscaleData　image data
	 * @param buffnum　QR Code Identification Value to be decoded
	 * @return result　Decoding result (nativeBitmapDecoder processing result)
	 */
	public DWDecodeResult decodeBitmap(byte[] grayscaleData, int buffnum, DWDecodeResult result) {
		return nativeBitmapDecoder(grayscaleData, buffnum, result);
	}

	/**
	 * Method for decoding from a photo (Bitmap)
	 *
	 * @param grayscaleData　image data
	 * @return nativeBitmapDecode　BitmapDecode Call Result
	 */
	public DWDecodeResult decodeBitmap(byte[] grayscaleData) {
		return nativeBitmapDecode(grayscaleData);
	}

	/**
	 * Specifying the reading code (2D code)
	 * @param decodeQRCodeType 2D Code Setting
	 */
	public void setDecodeQRCodeType(int decodeQRCodeType) {
		parameterData[DWDecodeQRType.PARAM_INDEX] |= decodeQRCodeType;
	}

	/**
	 * Specifying the reading code (barcode)
	 * @param barcodeType　Barcode Setting
	 */
	public void setDecodeBarcodeType(int barcodeType) {
		parameterData[DWDecodeBarcodeType.PARAM_INDEX] |= barcodeType;
	}

	/**
	 * Designation of reading code (barcode with add-on)
	 * @param decodeUPCAddonType　Barcode Setting
	 */
	public void setDecodeUPCAddonType(int decodeUPCAddonType) {
		parameterData[DWDecodeUPCAddonType.PARAM_INDEX] |= decodeUPCAddonType;
	}

	/**
	 * Specifying multi-code batch decoding
	 * @param decodeMultipleQRFlag　Multiple Batch Decode Setting
	 */
	public void setDecodeMultipleQRFlag(int decodeMultipleQRFlag) {
		parameterData[DWDecodeMultipleQR.PARAM_INDEX] |= decodeMultipleQRFlag;
	}

	/**
	 * Specifying the QR consolidated code decoding mode
	 * @param decodeCombinedQRFlag　QR consolidated code decode Setting
	 */
	public void setDecodeCombinedQRFlag(int decodeCombinedQRFlag) {
		parameterData[DWDecodeCombinedQR.PARAM_INDEX] |= decodeCombinedQRFlag;
	}

	/**
	 * Specifying the point scanning mode
	 * @param decodePointScanFlag　Point-scan mode Setting
	 */
	public void setDecodePointScanFlag(int decodePointScanFlag) {
		parameterData[DWDecodePointScanQR.PARAM_INDEX] |= decodePointScanFlag;
	}

	/**
	 * Specify the black-and-white inversion mode
	 * @param decodeReversalCodeFlag Black-and-white inversion mode Setting
	 */
	public void setDecodeReversalCodeFlag(int decodeReversalCodeFlag) {
		parameterData[DWDecodeReversalCode.PARAM_INDEX] |= decodeReversalCodeFlag;
	}

	/**
	 * Get the expiration date status of a license file
	 * @return Expiration Date Status
	 */
	public int getLicenseStatus() {
		return qrDecoder.DCD_GetExpirationDateInfo();
	}

	/**
	 * Checking whether the code type is 2D code
	 * @param codeMark
	 * @return isResult　Code type confirmation result (true: 2D code, false: not 2D code)
	 */
	private boolean codeMark2DCheck(String codeMark){
		boolean isResult = false;		// Confirmation Results
		isResult = Arrays.asList(DWDecodeConstants.DWQR_CODEMARK_QR).contains(codeMark);		// true: 2D code, false: not 2D code
		return isResult;
	}

	/**
	 * decoding process
	 * @param yuvData　image data
	 * @param previewWidth　Screen Preview: Width
	 * @param previewHeight　Screen Preview: Height
	 * @param mode　QR reading mode
	 * @return result　decode results
	 */
	private DWDecodeResult nativeDecode( byte[] yuvData, int previewWidth, int previewHeight, int mode ) {
		DWDecodeResult result = new DWDecodeResult();		// decode results
		// Get Decode Information
		int ret = qrDecoder.DCD_YUVDecodeSymbol( yuvData, previewHeight, previewWidth, parameterData );
		if ( ret == DWDecodeConstants.DCD_SUCCESS ) {		// decoding success
			int codeNum = qrDecoder.DCD_GetCodeNum();		// Number of QR Codes Detected
			result.setCodeNum( codeNum );					// Set the number of detected QR codes to the decode result

			boolean[] isCodeMark2d = {false, false};		// 2D Barcode Flag
			for(int cnt=0; cnt<codeNum; cnt++) {
				// Get Code type
				byte codemark[] = new byte[DWDecodeConstants.DWQR_MAX_CODENUM];
				qrDecoder.DCD_GetCodeMark( codemark, 0 );	// In case of multiple detections, it will be done in a later process (nativeYuvDecode), so at this point the first Get the code type
				try {
					String strCodemark = new String( codemark, "UTF-8" );	// Convert to UTF-8
					result.setCodeMark( strCodemark );										// Set the code type to the decode result
				} catch ( UnsupportedEncodingException e ) {
					e.printStackTrace();
				}

				String codeMark = result.getCodeMark();					// Get the code type
				if(codeMark != null) {
					isCodeMark2d[cnt] = codeMark2DCheck(codeMark);		// Confirmation of 2D barcode
				}
			}

			// code outline storage
            int pos[] = new int[8];	// For storing outline coordinates
			int outlineCode;			// Corner position
			for ( int i = 0; i < DWDecodeConstants.DWQR_MAX_CODENUM; i++ ) {
            	if( (isCodeMark2d[i] == true) || ( mode == DWQRScanMode.DWQR_POINTSCANMODE.ordinal() ) ) {
	                outlineCode = qrDecoder.DCD_GetOutlineCode( i );	// Checking the presence or absence of the corner position of the code to be decoded
	                if ( outlineCode != 0 ) {							// Corner available
						qrDecoder.DCD_GetCodeOutline( pos, i );		// Get the Coordinates of the QR Code
	                	result.setCodeOutline( pos, i );				// Set the outline coordinates of the QR Code to the decoding result
	                }
            	}
            }
            result.setStatus( DWDecodeConstants.SUCCESS );				// Set the status to the decode result (success)
		}else{	//Failure to get decode information
			result.setStatus(DWDecodeConstants.ERROR);					// Set the status to the decode result (failure)
		}
		return result;
	}

	/**
	 * decoding process
	 * @param buffnum　QR Code to be decoded
	 * @param result　Decoding result obtained by nativeDecode
	 * @return result　decode results
	 */
	private DWDecodeResult getDecodeDataResulet( int buffnum, DWDecodeResult result ) {
		int decodedCodeNum = 0;					// Decode buffer initialization
		if ( buffnum == DWDecodeConstants.DWQR_MAX_CODENUM ) {
			decodedCodeNum = DWDecodeConstants.DEC_BUFFNUM1;		// Decode buffer: 1
		} else {
			decodedCodeNum = DWDecodeConstants.DEC_BUFFNUM0;		// Decode buffer: 0
		}

		// Get the Code type
		byte codemark[] = new byte[DWDecodeConstants.DWQR_MAX_CODENUM];
		qrDecoder.DCD_GetCodeMark( codemark, decodedCodeNum );
		try {
			String strCodemark = new String( codemark, "UTF-8" );	// Convert to UTF-8
			result.setCodeMark( strCodemark );										// Set the code type to the decode result
		} catch ( UnsupportedEncodingException e ) {
			e.printStackTrace();
		}

		boolean isCodeMark2d = false;							// 2D Barcode Flag
		String codeMark = result.getCodeMark();					// Get the code type
		isCodeMark2d = codeMark2DCheck(codeMark);				// Confirmation of 2D barcode

		// code outline storage
		int pos[] = new int[8];	// For storing code outline coordinates
		int outlineCode;			// Corner position
		for( int i = 0; i < DWDecodeConstants.DWQR_MAX_CODENUM; i++ ){
			if(isCodeMark2d == true) {
				outlineCode = qrDecoder.DCD_GetOutlineCode(i);	// Check the corner positions
				// Corner available
				if (outlineCode != 0) {
					qrDecoder.DCD_GetCodeOutline(pos, i);
					result.setCodeOutline(pos, i);
				}
			}
		}

		int decodedDataCode = qrDecoder.DCD_GetDecodedCode( decodedCodeNum );	// Check for the presence of decoded data
		int decLen;															// Number of bytes of decoded data
		byte decodeData[] = null;												// Initialization of the array for storing decode data
		//Decoded data available
		if ( decodedDataCode != 0 ) {
			//local decode
			decLen = qrDecoder.DCD_GetDecodedLen( decodedCodeNum );			// Get the number of decoded data bytes
			decodeData = new byte[decLen];										// For storing decode data
			qrDecoder.DCD_GetDecodedData( decodeData, decodedCodeNum );		// Get decoded data
			result.setBinaryData(decodeData);									// Binary data storage of decode data
			result.setLocalDecode( true );										// Update the local decode flag of the decode result (true: local decode)
		}

		int cellDataCode = qrDecoder.DCD_GetCellDataCode( decodedCodeNum );	// Check for the existence of cell's B/W information data in decoded data.
		int decCellLen;														// Number of bytes in the cell's B/W information data.
		byte decodeCellData[] = null;											// Get cell's B/W information data
		// cell information available
		if ( cellDataCode != 0 ) {
			decCellLen = qrDecoder.DCD_GetCellDataLen( decodedCodeNum );		// Get the number of bytes of the cell's B/W information data
			decodeCellData = new byte[decCellLen];								// For storing cell's B/W information data
			qrDecoder.DCD_GetCellData( decodeCellData, decodedCodeNum );		// Get cell's B/W information data
			result.setLocalDecode( false );									// Update the local decode flag of the decode result (false: not local decode)
		}

		// encode
		try {
			String encoding = "UTF-8";
			// Decoded data available
			if (decodedDataCode != 0) {
				// decoded data
				String strDecodeData = new String(decodeData, encoding);
				result.setFoundQRCodeString(strDecodeData);
			}
			// cell information available
			if (cellDataCode != 0) {
				// server decoded data
				String strDecodeCellData = new String(decodeCellData, encoding);
				result.setFoundQRCodeCellString(strDecodeCellData);
			}
			result.setStatus(DWDecodeConstants.SUCCESS);	// Set the status to the decode result (success)
		} catch (UnsupportedEncodingException e) {
			result.setStatus(DWDecodeConstants.ERROR);		// Set the status to the decode result (failure)
		}

		return result;
	}

	/**
	 * Decode the selected Bitmap from the camera roll
	 * @param grayscaleData　Bitmap data to be decoded
	 * @param buffnum　QR Code Identification Value to be decoded
	 * @param result　Decoding results (obtained by nativeBitmapDecode)
	 * @return result　decode results
	 */
	private DWDecodeResult nativeBitmapDecoder(byte[] grayscaleData, int buffnum, DWDecodeResult result) {
		// Get decode information
		int ret = qrDecoder.DCD_DecodeSymbol( grayscaleData, parameterData );
		if ( ret == DWDecodeConstants.DCD_SUCCESS ) {	// success
			int decodedCodeNum = 0;									// Decode buffer initialization
			if ( buffnum == DWDecodeConstants.DWQR_MAX_CODENUM ) {
				decodedCodeNum = DWDecodeConstants.DEC_BUFFNUM1;		// Decode buffer: 1
			} else {
				decodedCodeNum = DWDecodeConstants.DEC_BUFFNUM0;		// Decode buffer: 0
			}

			// Get the code type
			byte codemark[] = new byte[DWDecodeConstants.DWQR_MAX_CODENUM];
			qrDecoder.DCD_GetCodeMark( codemark, decodedCodeNum );
			try {
				String strCodemark = new String( codemark, "UTF-8" );	// Convert to UTF-8
				result.setCodeMark( strCodemark );									// Set the code type to the decode result
			} catch ( UnsupportedEncodingException e ) {
				e.printStackTrace();
			}

			int decodedDataCode = qrDecoder.DCD_GetDecodedCode( decodedCodeNum );	// Check for the existence of decoded data
			int decLen;															// Number of bytes of decoded data
			byte decodeData[] = null;												// Initialization of the array for storing decode data
			if ( decodedDataCode != 0 ) {	//Decoded data available
				//local decode
				decLen = qrDecoder.DCD_GetDecodedLen( decodedCodeNum );			// Get the number of decoded data bytes
				decodeData = new byte[decLen];										// For storing decode data
				qrDecoder.DCD_GetDecodedData( decodeData, decodedCodeNum );		// Get decoded data
				result.setBinaryData(decodeData);									// Binary data storage of decode data
				result.setLocalDecode( true );										// Update the local decode flag of the decode result (true: local decode)
			}

			int cellDataCode = qrDecoder.DCD_GetCellDataCode( decodedCodeNum );	// Check for the existence of cell's B/W information data in decoded data
			int decCellLen;						// Number of bytes in the cell's B/W information data
			byte decodeCellData[] = null;		// Get cell's B/W information data
			if ( cellDataCode != 0 ) {		// cell information available
				//cell data != 0 -> Data for server decoding
				decCellLen = qrDecoder.DCD_GetCellDataLen( decodedCodeNum );		// Get the number of bytes in the cell's B/W information data
				decodeCellData = new byte[decCellLen];								// For storing cell's B/W information data
				qrDecoder.DCD_GetCellData( decodeCellData, decodedCodeNum );		// Get cell's B/W information data
				result.setLocalDecode( false );									// Update the local decode flag of the decode result (false: not local decode)
			}
			// encode
			try {
				String encoding = "UTF-8";

				if (decodedDataCode != 0) {	// Decoded data available
					// decoded data
					String strDecodeData = new String(decodeData, encoding);
					result.setFoundQRCodeString(strDecodeData);
				}

				if (cellDataCode != 0) {	// cell information available
					// server decoded data
					String strDecodeCellData = new String(decodeCellData, encoding);
					result.setFoundQRCodeCellString(strDecodeCellData);
				}
				result.setStatus(DWDecodeConstants.SUCCESS);		// Set the status to the decode result (success)
			} catch (UnsupportedEncodingException e) {
				result.setStatus(DWDecodeConstants.ERROR);			// Set the status to the decode result (failure)
			}

			boolean isCodeMark2d = false;							// 2D Barcode Flag
			String codeMark = result.getCodeMark();					// Get the code type
			isCodeMark2d = codeMark2DCheck(codeMark);				// Confirmation of 2D barcode

			// code outline storage
			int pos[] = new int[8];		// For storing code outline coordinates
			int outlineCode;			// Corner position
			for( int i = 0; i < DWDecodeConstants.DWQR_MAX_CODENUM; i++ )
			{
				if(isCodeMark2d == true) {
					outlineCode = qrDecoder.DCD_GetOutlineCode(i);	// Check the corner positions
					if (outlineCode != 0) {		// Corner available
						qrDecoder.DCD_GetCodeOutline(pos, i);
						result.setCodeOutline(pos, i);
					}
				}
			}
			int codeNum = qrDecoder.DCD_GetCodeNum();				// Number of QR Codes Detected
			result.setCodeNum( codeNum );							// Set the number of detected QRQ codes to the decode result
		} else {	//Failure to get decode information
			result.setStatus(DWDecodeConstants.ERROR);				// Set the status to decode results (error)
		}
		return result;
	}

	/**
	 * Detecting QR from a selected Bitmap from the camera roll
	 * @param grayscaleData　image data
	 * @return result　decode results
	 */
	private DWDecodeResult nativeBitmapDecode(byte[] grayscaleData) {
		DWDecodeResult result = new DWDecodeResult();
		if(grayscaleData == null){	// When the image data does not exist
			result.setStatus(DWDecodeConstants.ERROR);
		}else{
			int ret = qrDecoder.DCD_DecodeSymbol(grayscaleData, parameterData );
			if ( ret == DWDecodeConstants.DCD_SUCCESS ) { // When you succeed.
				int codeNum = qrDecoder.DCD_GetCodeNum();
				result.setCodeNum( codeNum );									// Number of QR Codes Detected

				boolean[] isCodeMark2d = {false, false};						// 2D Barcode Flag
				for(int cnt=0; cnt<codeNum; cnt++) {
					// Code type acquisition
					byte codemark[] = new byte[DWDecodeConstants.DWQR_MAX_CODENUM];
					qrDecoder.DCD_GetCodeMark( codemark, 0 );					// In case of multiple detection, it will be done in the later process (nativeYuvDecode), so at this point, the first Get the code type
					try {
						String strCodemark = new String( codemark, "UTF-8" );	// Convert to UTF-8
						result.setCodeMark( strCodemark );									// Set the code type to the decode result
					} catch ( UnsupportedEncodingException e ) {
						e.printStackTrace();
					}

					String codeMark = result.getCodeMark();						// Get the code type
					if(codeMark != null) {
						isCodeMark2d[cnt] = codeMark2DCheck(codeMark);			// Check the 2D barcode
					}
				}

				// code outline storage
				int pos[] = new int[8];								// For storing code outline coordinates
				int outlineCode;										// Corner position
				for ( int i = 0; i < DWDecodeConstants.DWQR_MAX_CODENUM; i++ ) {
					if( isCodeMark2d[i] == true){
						outlineCode = qrDecoder.DCD_GetOutlineCode( i );	// Check the corner positions
						if ( outlineCode != 0 ) {	// Corner available
							qrDecoder.DCD_GetCodeOutline( pos, i );
							result.setCodeOutline( pos, i );
						}
					}
				}
				result.setStatus( DWDecodeConstants.SUCCESS );		// Set the status to the decode result (success)
			}else{
				result.setStatus(DWDecodeConstants.ERROR);			// Set the status to the decode result (error)
			}
		}
		return result;
	}

	/**
	 * Analyzing License Data
	 * @param licenseData license data
	 * @return status code
	 */
	public int decodeLicenseData(String licenseData) {
		int result = DWQRStatusCode.DWQR_SUCCESS.ordinal();
		// If the analysis is successful
		if (DWDecodeConstants.DCD_SUCCESS == qrDecoder.DCD_SetLicenseData(licenseData)){
			// If it has not expired
			if (DWDecodeConstants.DCD_EXPIRED != qrDecoder.DCD_GetExpirationDateInfo()) {
				// Update each request data
				DWQRRequestData requestData = DWQRRequestData.sharedManager();
				requestData.setRequestID(qrDecoder.DCD_GetRequestID());
				requestData.setRequestPassword(qrDecoder.DCD_GetRequestPassword());
				requestData.setRequestAppID(qrDecoder.DCD_GetRequestAppID());
				requestData.setRequestServiceID(qrDecoder.DCD_GetRequestServiceID());
				requestData.setRequestDecodeUrl(qrDecoder.DCD_GetRequestDecodeUrl());
				requestData.setRequestLogUrl(qrDecoder.DCD_GetRequestLogUrl());
				// If not set
				if (requestData.getRequestLogUrl().equals("")) {
					requestData.isSendQRLogDataEnable = false;
					requestData.isSendBarcodeLogDataEnable = false;
				} else {
					requestData.isSendQRLogDataEnable = true;
					requestData.isSendBarcodeLogDataEnable = true;
				}
				requestData.setRequestLogInterval(qrDecoder.DCD_GetLogInterval());
				requestData.setExpirationDate(qrDecoder.DCD_GetExpirationDate());
				// If a warning is occurring
				if (DWDecodeConstants.DCD_WARNING_EXPIRED == qrDecoder.DCD_GetExpirationDateInfo()) {
					result = DWQRStatusCode.DWQR_WARNING_LICENSE.ordinal();
				}
			} else {
				result = DWQRStatusCode.DWQR_EXPIRED_LICENSE.ordinal();
			}
		} else {
			result = DWQRStatusCode.DWQR_ANALYZE_LICENSE.ordinal();
		}
		return result;
	}

	/**
	 * Check the configuration of the SQRC
	 * @return SQRC Setting Information
	 */
	public boolean checkSQRConly() {
		boolean ret;

		int SQRConly = qrDecoder.DCD_GetSQRCsetInfo();
		if (SQRConly != 0) {
			ret = true;
		}
		else {
			ret = false;
		}
		return ret;
	}
}
