package com.densowave.dwqrkit;

import java.util.List;
import java.util.Locale;

import com.densowave.dwqrkit.listener.DWQRHistoryListener;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

/**
 * History Data Display Class
 */
public class DWQRHistoryView extends ListView implements android.widget.AdapterView.OnItemClickListener, android.widget.AdapterView.OnItemLongClickListener{
	/**
	 * constant
	 */
	private static String DWQR_TRADITIONAL_MO = "zh_MO_#Hant";		// Traditional Chinese characters (Macao)
	private static String DWQR_TRADITIONAL_TW = "zh_TW_#Hant";		// Traditional Chinese characters (Hong Kong)
	private static String DWQR_TRADITIONAL_HK = "zh_HK_#Hant";		// Traditional Chinese characters (Taiwan)
	private static String DWQR_SIMPLIFICATION_CN = "zh_CN_#Hans";	// Simplified Chinese
	private static String DWQR_SIMPLIFICATION_MO = "zh_MO_#Hans";	// Simplified Chinese (Macao)
	private static String DWQR_SIMPLIFICATION_HK = "zh_HK_#Hans";	// Simplified Chinese (Hong Kong)
	private static String DWQR_SIMPLIFICATION_SG = "zh_SG_#Hans";	// Simplified Chinese (Singapore)

	private DWQRKit dwQrKit = DWQRKit.sharedManager();			// Singleton's DWQRKit class
	private DWQRHistoryListener qrHistoryListener;				// History Interface

	/**
	 * DWQRHistoryView constructor
	 * @param context　context
	 */
	public DWQRHistoryView( Context context ) {
		super( context );
		historyViewInitialization( context );
	}

	/**
	 * DWQRHistoryView constructor
	 * @param context　context
	 * @param attrs　Layout Parameters
	 */
	public DWQRHistoryView( Context context, AttributeSet attrs ) {
		super( context, attrs );
		historyViewInitialization( context );
	}

	/**
	 * DWQRHistoryView constructor
	 * @param context　context
	 * @param attrs　Layout Parameters
	 * @param defStyle　Style Information
	 */
	public DWQRHistoryView( Context context, AttributeSet attrs, int defStyle ) {
		super( context, attrs, defStyle );
		historyViewInitialization( context );
	}

	@Override
	public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
		if( qrHistoryListener != null ){
			DWQRHistoryView parent = (DWQRHistoryView)adapter;								// Adapter Settings
			DWQRHistory selectedHistroy = (DWQRHistory) parent.getItemAtPosition(position);	// Get selected history data
			qrHistoryListener.qrDecodeHistoryData (selectedHistroy.history);				// Notification of history information
		}
	}

	@Override
	public boolean onItemLongClick(AdapterView<?> adapter, View view, int position,	long id) {
		DWQRHistoryView parent = (DWQRHistoryView)adapter;										// Adapter Settings
		final DWQRHistory selectedHistroy = (DWQRHistory) parent.getItemAtPosition(position);	// Get selected historical data
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(getContext());				// alert dialog
		Locale locale = Locale.getDefault();													// Get information on the selected language
		String localeStr = locale.toString();													// Get language information
		String lang = locale.getLanguage();														// Get the language settings
		String copyButtonName = "", deleteButtonName = "", cancelButtonName = "";				// Names of buttons

		// Change the name of the button according to the language setting
		if(Locale.JAPAN.toString().equals(localeStr)){			// Japanese
			cancelButtonName = "キャンセル";
			copyButtonName = "コピー";
			deleteButtonName = "削除";
		}else if(Locale.CHINA.toString().equals(localeStr) ||
				DWQR_TRADITIONAL_MO.equals(localeStr) ||
				DWQR_TRADITIONAL_TW.equals(localeStr) ||
				DWQR_TRADITIONAL_HK.equals(localeStr)) {		// Macau, Taiwan and Hong Kong
			cancelButtonName = "廢除";
			copyButtonName = "拷貝";
			deleteButtonName = "刪除";
		}else if(Locale.TAIWAN.toString().equals(localeStr) ||
				"zh_HK".toString().equals(localeStr) ||
				DWQR_SIMPLIFICATION_CN.equals(localeStr) ||
				DWQR_SIMPLIFICATION_HK.equals(localeStr) ||
				DWQR_SIMPLIFICATION_MO.equals(localeStr) ||
				DWQR_SIMPLIFICATION_SG.equals(localeStr)) {		// China, Macao, Singapore and Hong Kong
			cancelButtonName = "废除";
			copyButtonName = "拷贝";
			deleteButtonName = "删除";
		}else if(Locale.KOREAN.toString().equals(lang)){		// Korea
			cancelButtonName = "취소";
			copyButtonName = "카피";
			deleteButtonName = "삭제";
		}else if(Locale.FRENCH.toString().equals(lang)){		// France
			cancelButtonName = "annulation";
			copyButtonName = "copie";
			deleteButtonName = "effacer";
		}else if(Locale.GERMAN.toString().equals(lang)){		// Germany
			cancelButtonName = "Stornierung";
			copyButtonName = "Kopie";
			deleteButtonName = "löschen";
		}else if(Locale.ITALIAN.toString().equals(lang)){		// Italy
			cancelButtonName = "cancellazione";
			copyButtonName = "copia";
			deleteButtonName = "cancellare";
		}else if("es".toString().equals(lang)){					// Spain
			cancelButtonName = "cancelación";
			copyButtonName = "copia";
			deleteButtonName = "borrar";
		}else if("pt".toString().equals(lang)){					// Portugal or Brazil
			cancelButtonName = "cancelamento";
			copyButtonName = "cópia";
			deleteButtonName = "excluir";
		}else{													// other
			cancelButtonName = "Cancel";
			copyButtonName = "Copy";
			deleteButtonName = "Delete";
		}

	    //Content (message) settings
	    alertDialog.setMessage( selectedHistroy.date + "\n" + selectedHistroy.history );

	    // Create Delete button
	    alertDialog.setPositiveButton( deleteButtonName, new DialogInterface.OnClickListener() {
	        public void onClick( DialogInterface dialog, int which ) {
	        	dwQrKit.deleteHistoryData(getContext(), selectedHistroy.history);	// selected data deletion
				setAdapter(new HistoryListAdapter(getContext()));					// Set the history data adapter after the deletion process.
			}
	    });

	    // Create Copy button
	    alertDialog.setNeutralButton(copyButtonName, new DialogInterface.OnClickListener(){
	    	public void onClick(DialogInterface dialog, int witch){
	    		// Get target history data
	    		String data = selectedHistroy.history;

				// Set the text on the clipboard
				ClipboardManager cm = (ClipboardManager)getContext().getSystemService(Context.CLIPBOARD_SERVICE);
				ClipData clip = ClipData.newPlainText("", data);
				cm.setPrimaryClip(clip);
	    	}
	    });

	    // Create Cancel button
	    alertDialog.setNegativeButton( cancelButtonName, new DialogInterface.OnClickListener() {
	        public void onClick( DialogInterface dialog, int which ) {
	            // When the CANCEL button is pressed, there is no special processing.
	        }
	    });
	    alertDialog.show();
		return true;
	}

	/**
	 * Initial processing of historical data
	 * @param context　context
	 */
	public void historyViewInitialization( Context context ) {
    	// Creating a list view
    	setAdapter(new HistoryListAdapter(context));

    	setOnItemClickListener(this);		// Tap one history data
		setOnItemLongClickListener(this);	// Press and hold one history data
	}

	/**
	 * history interface
	 * @param qrHistoryListener　Processing of history data selection
	 */
	public void setQrHistoryListener( DWQRHistoryListener qrHistoryListener ){
		this.qrHistoryListener = qrHistoryListener;
	}

	/**
	 * Delete all history data
	 * @param context　context
	 */
	public void qrHistoryDataAllDelete(Context context){
		dwQrKit.deleteAllHistoryData(context);
		setAdapter(new HistoryListAdapter(context));
	}

	/**
	 * Class for displaying history data
	 */
	private class HistoryListAdapter extends BaseAdapter{
		private Context context;			// context
		private List<DWQRHistory> list;		// History Data List
		public HistoryListAdapter(Context context){
			super();
			this.context = context;
			list = dwQrKit.getHistoryData(context);		// Get history data
		}
		@Override
		public int getCount() {
			return list.size();			// History data size
		}

		@Override
		public Object getItem(int position) {
			return list.get(position);	// History data
		}

		@Override
		public long getItemId(int position) {
			return position;			// History data ID
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			DWQRHistory dwQrHistory = (DWQRHistory) getItem(position);	// Get the history data specified by position
			ViewHolder holder;		// For View retention

			if( convertView == null ){
				LinearLayout layout = new LinearLayout(context);
				layout.setOrientation(LinearLayout.HORIZONTAL);		// Layout direction: Vertical
				convertView = layout;								// View settings

				LinearLayout layoutText = new LinearLayout(context);
				layoutText.setOrientation(LinearLayout.VERTICAL);	// Layout direction: Horizontal
				holder = new ViewHolder();							// For View retention
				holder.image = new ImageView(context);				// ImageView
				holder.image.setImageBitmap(dwQrKit.getImageHistoryIcon());		// Set the history logo
				holder.textDate = new TextView(context);						// Set the history date
				holder.textHistory = new TextView(context);						// Set history results

				// セットしたデータを追加
				layoutText.addView(holder.textDate);
				layoutText.addView(holder.textHistory);
				layout.addView(holder.image);
				layout.addView(layoutText);

				convertView.setTag(holder);		// Set the tag
			}else{
				holder = (ViewHolder) convertView.getTag();		// Get the tag
			}
			holder.textDate.setText(dwQrHistory.date);			// Get the history date
			holder.textHistory.setText(dwQrHistory.history);	// Get the history data

			return convertView;
		}
	}

	/**
	 * View保持用クラス
	 */
	private static class ViewHolder {
		ImageView image;		// 履歴ロゴView
		TextView textDate;		// 履歴日付View
		TextView textHistory;	// 履歴結果View
	}
}
