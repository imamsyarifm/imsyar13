package com.densowave.dwqrkit;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;

public class DWQRDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME ="datadecode.db";
    private static final int DATABASE_VERSION =1;

    public DWQRDatabase(Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE DataDecode(id INTEGER PRIMARY KEY AUTOINCREMENT, param TEXT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public void insertParam(String param){
        SQLiteDatabase db= getWritableDatabase();

        SQLiteStatement sqLiteStatement =db.compileStatement("INSERT INTO DataDecode(param) VALUES(?)");
        sqLiteStatement.bindString(1,param);
        sqLiteStatement.executeInsert();

    }
}
