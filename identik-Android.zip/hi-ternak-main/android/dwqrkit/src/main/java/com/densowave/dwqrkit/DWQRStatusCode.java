package com.densowave.dwqrkit;

/**
 * status
 */
public enum DWQRStatusCode {
	DWQR_SUCCESS(0),						// success
	DWQR_TIMEOUT(1),						// timeout
	DWQR_FAILED(2),							// failure
	DWQR_DISABLE(3),						// Server connection prohibition
	DWQR_NO_FEATURECAMERA(4),				// Without camera function
	DWQR_NO_FEATURECAMERA_AUTOFOCUS(5),		// Without autofocus function
	DWQR_NO_FEATURECAMERA_FLASH(6),			// Without flashlight function
	DWQR_NO_FEATURELOCATION(7),				// Without locate function
	DWQR_NO_FEATURELOCATION_GPS(8),			// Without GPS function
	DWQR_NO_FEATURELOCATION_NETWORK(9),		// Without network location function
	DWQR_NOT_FOUND_LICENSE(10),				// not find license
	DWQR_READ_LICENSE(11),					// Failed to read license file
	DWQR_ANALYZE_LICENSE(12),				// Failed to parse license file
	DWQR_EXPIRED_LICENSE(13),				// License file expired
	DWQR_WARNING_LICENSE(14);				// The license file is about to expire

	private int statusCode;					// status

	/**
	 * DWQRStatusCode
	 * @param statusCode initial value
	 */
	DWQRStatusCode(int statusCode){
		this.statusCode = statusCode;
	}

	/**
	 * Returns the status value
	 * @return status
	 */
	public int getValue(){
		return this.statusCode;
	}
};
