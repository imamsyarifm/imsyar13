package com.densowave.dwqrkit;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.View;

/**
 * Class that displays the center position of point scan mode
 */
public class DWQRARCrossView extends View{

	private static final int DWQR_STROKE_WIDTH = 5;				// Line thickness when drawing

	/**
	 * Coordinate value in point scan mode
	 */
	private Point posT;		// top
	private Point posB;		// bottom
	private Point posL;		// left
	private Point posR;		// rigght

	private DWQRKit dwqrkit = DWQRKit.sharedManager();

	/**
	 * DWQRARView
	 * @param context
	 */
	public DWQRARCrossView(Context context) {
        super(context);
        // 初期化
        posT = new Point(0,0);
        posB = new Point(0,0);
        posL = new Point(0,0);
        posR = new Point(0,0);
    }

	/**
     * Point scan mode aiming coordinates
     * @param posT　aim : top
     * @param posB　aim : bottom
     * @param posL　aim : left
     * @param posR　aim : right
     */
	public void drawScreen(Point posT, Point posB, Point posL, Point posR) {
		// Setting each coordinate
		this.posT = posT;
		this.posB = posB;
		this.posL = posL;
		this.posR = posR;

        // redraw
        invalidate();
    }

	// draw
    @SuppressLint("DrawAllocation")
	@Override
    protected void onDraw(Canvas canvas) {
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        drawCross( canvas, paint );
    }

    /**
	 * For point scan
     * Aim position drawing
     * @param canvas drawing
     * @param paint Settings for drawing
     */
    private void drawCross(Canvas canvas, Paint paint) {
    	/**
    	 * Color setting Divide the specified color code into each setting value.
    	 */
    	int frameColor = dwqrkit.getPointScanFrameColor();									// get color
    	int alpha = frameColor >>> DWQRARView.DWQR_SHIFT_3BYTE;								// Settings for drawing
    	int red = ( frameColor >>> DWQRARView.DWQR_SHIFT_2BYTE ) & DWQRARView.DWQR_MASK;	// red
    	int green = ( frameColor >>> DWQRARView.DWQR_SHIFT_1BYTE ) & DWQRARView.DWQR_MASK;	// green
    	int blue = frameColor & DWQRARView.DWQR_MASK;										// blue

		// drawing setting
		paint.setStyle( Paint.Style.FILL );
		paint.setARGB( alpha, red, green, blue );
		paint.setStrokeWidth( DWQR_STROKE_WIDTH );

		canvas.drawLine(posT.x, posT.y, posB.x, posB.y, paint);		// Settings for drawing
		canvas.drawLine(posL.x, posL.y, posR.x, posR.y, paint);		// Settings for drawing
    }
}
