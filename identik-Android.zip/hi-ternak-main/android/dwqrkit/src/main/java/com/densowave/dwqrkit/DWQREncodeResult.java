package com.densowave.dwqrkit;

/**
 * Encoded results of local decode data
 */
public enum DWQREncodeResult {
	DWQR_ENCODE_FAILED(-1),				// failed to encode
	DWQR_ENCODE_UTF8_SUCCESS(0);		// Successfully encoded in UTF-8

	private int result;					// Encoded value

	/**
	 * constructor
	 * @param result Initial Encoding Result
	 */
	DWQREncodeResult(int result){
		this.result = result;
	}

	/**
	 * Returns the value of the encoding result
	 * @return Encoded results
	 */
	public int getValue(){
		return this.result;
	}
};