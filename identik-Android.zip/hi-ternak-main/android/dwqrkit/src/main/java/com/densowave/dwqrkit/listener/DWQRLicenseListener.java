package com.densowave.dwqrkit.listener;

/**
 * Interface to notify you when your license file has expired
 */
public interface DWQRLicenseListener {
    public void onNoticeLicenseExpired(int statusCode);
}
