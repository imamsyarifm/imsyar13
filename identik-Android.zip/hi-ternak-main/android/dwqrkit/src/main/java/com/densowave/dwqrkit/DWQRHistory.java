package com.densowave.dwqrkit;

/**
 * Holds the date and content of historical data, respectively
 */
public class DWQRHistory{
	public String history;		// history Data
	public String date;			// history Date

	/**
	 * Stores the history data specified in the argument
	 * @param history　history data
	 * @param date　history date
	 */
	public DWQRHistory(String history, String date){
		this.history = history;	// Set the history date
		this.date = date;			// Set the history date
	}
}