package com.densowave.dwqrkit;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.camera2.CameraAccessException;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import androidx.fragment.app.Fragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.densowave.dwqrkit.data.DWQRRequestData;
import com.densowave.dwqrkit.decodeParameter.DWDecodeConstants;
import com.densowave.dwqrkit.decodeParameter.DWDecoder;
import com.densowave.dwqrkit.listener.DWQRCodeNoticeListener;
import com.densowave.dwqrkit.listener.DWQRCodeNoticeExListener;
import com.densowave.dwqrkit.listener.DWQRLicenseListener;
import com.densowave.dwqrkit.listener.DWQRScanViewCreateListener;

/**
 * QRコード読み取り表示画面のクラス
 */
public class DWQRScanView extends Fragment implements LocationListener, DWQRCodeNoticePublisher {
	/**
	 * ログ出力
	 */
	private static final String DWQR_TAG = DWQRScanView.class.getSimpleName();				// タグ設定
	private static final int DWQR_BITMAP_SIZE = 500;										// スケール取得取得時に使用する基準サイズ
	private static final int DWQR_MIN_SCALE_SIZE = 2;									// 最小のスケールサイズ
	private static final String LICENSE_FILE_NAME = "license.txt";						// ライセンスファイルの名称
	private static final String START_STRING = "-START--------------------------";	// データ領域の開始位置を表す文字列
	private static final String END_STRING = "----------------------------END-";		// データ領域の終了位置を表す文字列
    private static final int MAX_LICENSE_DATA_SIZE = 8192;								// データ領域の最大サイズ
    private static final int REQUEST_LOD_DATA_INTERVAL = 10000;                 		// ログ送信周期(10秒)

	/**
	 * インスタンス設定
	 */
	private DWQRCodeNoticeListenerProxy qrCodeNoticeListener;						// デコード結果を通知するインターフェース 1.0.5対応
	private DWQRScanViewCreateListener dwQrScanViewCreateListener;				// プレビューサイズ設定時に通知するインターフェース
	private DWQRLicenseListener dwQrLicenseListener;								// 有効期限を通知するインターフェース
	private DWQRCameraSurfaceView cameraSurfaceView;								// カメラのプレビュー制御
	private DWQRImageSurfaceView imageSurfaceView;									// 既存画像からの取り込み
	private FrameLayout fl_camera;													// カメラプレビューのフレームレイアウト
	private ImageView logoImageView;													// 会社ロゴのイメージビュー
	private Timer observer;															// 監視用タイマー
	private Handler handler;															// 会社ロゴの表示・非表示とカメラプレビューの再開・停止を行うpost用ハンドラ
	private DWQRKit dwqrkit = DWQRKit.sharedManager();								// シングルトンのDWQRKitクラス
	private SimpleDateFormat dayFormat = new SimpleDateFormat("yyyyMMdd");// 日時フォーマット
	private static String previewDate = "";											// 前回通知した日時
    private LocationManager locationManager;										// 位置情報取得サービス
    private DWQRRequestData dwqrRequestData;										// リクエストデ－タ
	private boolean isSendingLogData;												// ログ送信中か否かのフラグ
	private SendLogDataThread sendLogDataThread;									// ログデータ送信用のスレッド

	/**
	 * デバイス機能確認用
	 */
	private int[] hardwareChecked;				// デバイス機能確認結果

	public DWQRScanView() {
	}


	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		DWQRKit.setLog(DWQR_TAG,"DWQR onCreateView");						// ログ設定
		if (container == null) {
			return null;
		}
		handler = new Handler();												// 会社ロゴの表示・非表示とカメラプレビューの再開・停止を行うpost用ハンドラ
		fl_camera = new FrameLayout(getActivity());								// カメラプレビューのフレームレイアウト
		fl_camera.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

		cameraSurfaceView = new DWQRCameraSurfaceView(getActivity());			// カメラのプレビュー制御（背面カメラを使用）
		hardwareChecked = cameraSurfaceView.getHardwareChecked();				// デバイス搭載機能　確認結果取得
		imageSurfaceView = new DWQRImageSurfaceView(getActivity());				// 既存画像からの取り込み

        // リクエストデータの初期化
        this.dwqrRequestData = DWQRRequestData.sharedManager();
		this.dwqrRequestData.setContext(this.getActivity().getApplicationContext());
		this.dwqrRequestData.setLogData();

		// オートフォーカス機能が搭載されていないときの通知
		if(hardwareChecked[1] == DWQRStatusCode.DWQR_NO_FEATURECAMERA_AUTOFOCUS.ordinal()) {
			if (qrCodeNoticeListener != null) {
				qrCodeNoticeListener.onNoticeDecodeResult("", "", null, 0, "", DWQRStatusCode.DWQR_NO_FEATURECAMERA_AUTOFOCUS.ordinal(), "");
			}
		}
		if(hardwareChecked[0] != DWQRStatusCode.DWQR_NO_FEATURECAMERA.ordinal()) {
			// 端末により画像デコード時にイメージが描画されない事象を回避するため、image、cameraの順にレイヤ－追加
			fl_camera.addView(imageSurfaceView);
			fl_camera.addView(cameraSurfaceView);

			// 端末画面サイズ取得（ステータスバー、コントロールバー、ナビゲーションバーを除いた画面サイズ）
			ViewTreeObserver viewTreeObserver = cameraSurfaceView.getViewTreeObserver();
	        viewTreeObserver.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
	            @Override public void onGlobalLayout() {
	            	cameraSurfaceView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
	            	int width = cameraSurfaceView.getMeasuredWidth();		// 画面サイズ：幅
	            	int height = cameraSurfaceView.getMeasuredHeight();		// 画面サイズ：高さ
					try {
						cameraSurfaceView.setDisplaySize(width, height);
					} catch (CameraAccessException e) {
						e.printStackTrace();
					}
				}
	        });

			if( qrCodeNoticeListener != null ){
				qrCodeNoticeListener.subscribe(cameraSurfaceView);
			}

			if( dwQrScanViewCreateListener != null ){
				dwQrScanViewCreateListener.onCreateScanView(fl_camera);
			}
			createLogo(container);

            // 位置情報取得機能
            if(hardwareChecked[3] == DWQRStatusCode.DWQR_NO_FEATURELOCATION.ordinal()) {
                if (qrCodeNoticeListener != null) {
                    qrCodeNoticeListener.onNoticeDecodeResult("", "", null, 0, "", DWQRStatusCode.DWQR_NO_FEATURELOCATION.ordinal(), "");
                }
            }
            // GPS位置情報取得
            if(hardwareChecked[4] == DWQRStatusCode.DWQR_NO_FEATURELOCATION_GPS.ordinal()) {
                if (qrCodeNoticeListener != null) {
                    qrCodeNoticeListener.onNoticeDecodeResult("", "", null, 0, "", DWQRStatusCode.DWQR_NO_FEATURELOCATION_GPS.ordinal(), "");
                }
            }
            // ネットワーク位置情報取得
            if(hardwareChecked[5] == DWQRStatusCode.DWQR_NO_FEATURELOCATION_NETWORK.ordinal()) {
                if (qrCodeNoticeListener != null) {
                    qrCodeNoticeListener.onNoticeDecodeResult("", "", null, 0, "", DWQRStatusCode.DWQR_NO_FEATURELOCATION_NETWORK.ordinal(), "");
                }
            }
            initLocation();

			return fl_camera;

		} else {		// 端末に背面カメラがなかった場合
			// onServerDecodeResultのstatusCodeのみを通知するので、他の引数には何も入れない
			String decodeData = "";
			String codeType = "";
			String decodePrivateData = "";
			int cameraStatusCode = DWQRStatusCode.DWQR_NO_FEATURECAMERA.ordinal();
            if( qrCodeNoticeListener != null ) {
				qrCodeNoticeListener.subscribe(cameraSurfaceView);
				qrCodeNoticeListener.onNoticeDecodeResult(decodeData, codeType, null, 0, decodePrivateData, cameraStatusCode, "" );
			}
			return null;
		}
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
	}

	@Override
	public void onStart() {
		super.onStart();
		cameraSurfaceView.isBackground = false;	// バックグラウンドに待機
		startObserver();								// 監視用スレッドを起動
		cameraSurfaceView.clearIndicator();			// インジケータを削除する
	}

	@Override
	public void onStop() {
		super.onStop();
		stopObserver();									// 監視用スレッドを停止
		cameraSurfaceView.releaseObject();			// 生成済みのオブジェクトを破棄
		cameraSurfaceView.isBackground = true;	// バックグラウンドに遷移
	}

	@Override
	public void onResume() {
		super.onResume();

		// サウンドのリソースIDからサウンドを取得
		cameraSurfaceView.loadSoundResourceID();

		// 端末によりDWQRCameraSurfaceViewとDWQRImageSurfaceViewのsurfaceChangedが実行されないため、
		// surfaceChangedで実行されている処理をonResumeで実行する
		if (!cameraSurfaceView.isCalledDestroy) {
			cameraSurfaceView.decodeBitmapImage();
			imageSurfaceView.createDrawThread();
		}

		// ライセンスファイルの有効期限切れを通知
        int licenseStatus = cameraSurfaceView.getDwDecoder().getLicenseStatus();
        if ((licenseStatus == DWDecodeConstants.DCD_WARNING_EXPIRED) || (licenseStatus == DWDecodeConstants.DCD_EXPIRED)) {
            // 日付を取得
			Calendar cal = Calendar.getInstance();
			String strDate = dayFormat.format(cal.getTime());
			// 日付が変わった場合
			if (!previewDate.equals(strDate)) {
				if (dwQrLicenseListener != null) {
					// 有効期限が切れている場合
					if (licenseStatus == DWDecodeConstants.DCD_EXPIRED) {
						dwQrLicenseListener.onNoticeLicenseExpired(DWQRStatusCode.DWQR_EXPIRED_LICENSE.ordinal());
						// 警告が出ている場合
					} else if (licenseStatus == DWDecodeConstants.DCD_WARNING_EXPIRED) {
						dwQrLicenseListener.onNoticeLicenseExpired(DWQRStatusCode.DWQR_WARNING_LICENSE.ordinal());
					}
					previewDate = strDate;
				}
			}
		}

		// アクティブになったときに位置情報取得処理、デバイス情報取得処理、ログ送信用のスレッド作成処理
        initLocation();
        getDeviceInformation();
		isSendingLogData = false;
		sendLogDataThread = new SendLogDataThread();
		sendLogDataThread.setPriority(Thread.MIN_PRIORITY);
		sendLogDataThread.start();
	}

	@Override
	public void onPause() {
        super.onPause();

        // バックグラウンドに遷移時、位置情報取得処理、ログ送信処理を停止する
        if (locationManager != null) {
            DWQRKit.setLog(DWQR_TAG, "LocationManager stop.");
            locationManager.removeUpdates(this);
        }
		sendLogDataThread.stopThread();
		sendLogDataThread = null;

	}

	@Override
	public void setArguments(Bundle args) {
		super.setArguments(args);
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if( requestCode == 0 && resultCode == Activity.RESULT_OK ){
			try{
				// メモリにBitmap展開せずにサイズやMimeTypeだけを取得する
				BitmapFactory.Options options = new BitmapFactory.Options();
				options.inJustDecodeBounds = true;

				// 取得した画像データを取得
				InputStream is = getActivity().getContentResolver().openInputStream(data.getData());

				// 端末により大きい画像を取得時にOutOffMemoryが発生するため、
				// アスペクト比を維持して画像を縮小して取得する
				BitmapFactory.decodeStream(is, null, options);
				DWQRKit.setLog(DWQR_TAG, "get Image Size : " + options.outWidth + " x " + options.outHeight);
				is.close();

				// サイズ取得後、再度画像データを取得する
				is = getActivity().getContentResolver().openInputStream(data.getData());
				Bitmap colorImage;
				float imageScaleWidth = (float)options.outWidth / DWQR_BITMAP_SIZE;
				float imageScaleHeight = (float)options.outHeight / DWQR_BITMAP_SIZE;
				// 1000*1000よりも大きいサイズの場合
				if (imageScaleWidth > DWQR_MIN_SCALE_SIZE && imageScaleHeight > DWQR_MIN_SCALE_SIZE) {
					BitmapFactory.Options resizeOptions = new BitmapFactory.Options();
					// スケールの小さい方に合わせる
					int imageScale = (int)Math.floor((imageScaleWidth > imageScaleHeight ? imageScaleHeight : imageScaleWidth));
					// 低解像度で読み込むために縮小サイズを設定する
					// inSampleSizeは、２のべき乗を指定しない場合処理速度が遅くなるため、
					// 2のべき乗を指定するようにする
					for (int inSampleSize = DWQR_MIN_SCALE_SIZE; inSampleSize <= imageScale; inSampleSize *= 2) {
						resizeOptions.inSampleSize = inSampleSize;
					}
					// 縮小して画像を取得
					colorImage = BitmapFactory.decodeStream(is, null, resizeOptions);
				} else {
					// 小さい画像の場合はそのまま取得する
					colorImage = BitmapFactory.decodeStream(is);
				}
				is.close();

				DWQRKit.setLog(DWQR_TAG, "color Image Size : " + colorImage.getWidth() + " x " + colorImage.getHeight());

				// 取得したBitmapとDWQRImageSurfaceViewのインスタンスを渡し、加工して設定する
				cameraSurfaceView.setDecodeImage(colorImage, imageSurfaceView);
			}catch( Exception e ){
				DWQRKit.setLog(DWQR_TAG,e.getLocalizedMessage());		// ログ設定
			}
		}else{
			dwqrkit.isStopCapture = false;
		}
	}

	@Override
	public void onLocationChanged(Location location) {
        DWQRKit.setLog(DWQR_TAG, "LocationProvider param change(" + location.getLatitude() + ", " +
                                                                  + location.getLongitude() + ")");
        dwqrRequestData.setRequestLatitude(location.getLatitude());
        dwqrRequestData.setRequestLongitude(location.getLongitude());
	}

	@Override
	public void onProviderDisabled(String provider) {
        DWQRKit.setLog(DWQR_TAG, "LocationProvider disabled(" + provider.toString() + ")");
        dwqrRequestData.setRequestLatitude(0.0);
        dwqrRequestData.setRequestLongitude(0.0);
    }

	@Override
	public void onProviderEnabled(String provider) {
        DWQRKit.setLog(DWQR_TAG, "LocationProvider enabled(" + provider.toString() + ")");
    }

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		DWQRKit.setLog(DWQR_TAG, "LocationProvider statusChanged(" + provider.toString() + ", +" + status + ")");
	}

	/**
	 * ギャラリーを表示する
	 */
	public void showGalaryImageView() {
		dwqrkit.isStopCapture = true;
		Intent intent = new Intent();
		intent.setType("image/*");					// ギャラリーをセット
		intent.setAction(Intent.ACTION_GET_CONTENT);	// 移動先を指定
		startActivityForResult(intent, 0);	// ギャラリーを表示する
	}

	/**
	 * インターフェイスの設定
	 * @param listener
	 */
	public void setOnQRCodeFoundNoticeListener( DWQRCodeNoticeListener listener ) {
		qrCodeNoticeListener = new DWQRCodeNoticeListenerProxy(listener);
	}
	public void setOnQRCodeFoundNoticeListener( DWQRCodeNoticeExListener listener ) {
		qrCodeNoticeListener = new DWQRCodeNoticeListenerProxy(listener);
	}

	/**
	 * レイアウト情報通知インターフェースの設定
	 * @param listener
	 */
	public void setDwQrScanViewCreateListener( DWQRScanViewCreateListener listener ){
		this.dwQrScanViewCreateListener = listener;
	}

	/**
	 * 有効期限通知インターフェースの設定
	 * @param listener
	 */
	public void setDwQrLicenseListener( DWQRLicenseListener listener){
		this.dwQrLicenseListener = listener;
	}

	/**
	 * 監視用タイマーを生成する
	 */
	private void startObserver() {
		observer = new Timer(true);									// タスク終了時にタイマも終了
		observer.scheduleAtFixedRate(new ObserverTask(), 0, 1);	// タスクの実行間隔：1ms
	}

	/**
	 * 監視用タイマーを停止する
	 */
	private void stopObserver() {
		if( observer != null ){		// 監視用タイマーが生成されているとき
			observer.cancel();
			observer.purge();
			observer = null;
		}
	}

	/**
	 * ロゴの作成と表示をする
	 * @param container RootViewの画面サイズ
	 */
	private void createLogo(ViewGroup container) {
		int W = container.getWidth();		// 幅
		int H = container.getHeight();		// 高さ
		FrameLayout.LayoutParams params = new FrameLayout.LayoutParams( (int)(H/10*1.641), H/10 );
		params.setMargins( W - (int)(H/10*1.641) - 5, H - (H/10) - 5, 0, 0 );
		params.gravity = Gravity.NO_GRAVITY;
		logoImageView = new ImageView(getActivity());
		logoImageView.setImageBitmap(DWQRLogoType.getDensoLogotype());
		logoImageView.setLayoutParams(params);

		if(dwqrkit.isLogoDisplayEnable){		// 表示するとき
			logoImageView.setVisibility(View.VISIBLE);
		}else{
			logoImageView.setVisibility(View.INVISIBLE);
		}
		fl_camera.addView(logoImageView);
	}

	/**
	 * ライセンスファイルの読み取りを行う
	 * @return ステータスコード
	 */
	public int readLicenseFile(){
		// ファイルパスを設定
		String filepath = getActivity().getApplicationContext().getFilesDir().toString() + "/" + LICENSE_FILE_NAME;
		int result;

		File licenseFile = new File(filepath);
		if (licenseFile.exists()) {
			String licenseData = readLicenseData(licenseFile);
			// ライセンスデータを取得できた場合
			if (!licenseData.equals("")) {
				DWDecoder decoder = cameraSurfaceView.getDwDecoder();
				// ライセンスデータを解析する
				result = decoder.decodeLicenseData(licenseData);
				// 警告が発生している場合
				if (result == DWQRStatusCode.DWQR_WARNING_LICENSE.ordinal()) {
					// 成功とみなす
					result = DWQRStatusCode.DWQR_SUCCESS.ordinal();
				}
			} else {
				result = DWQRStatusCode.DWQR_READ_LICENSE.ordinal();
			}
		} else {
			result = DWQRStatusCode.DWQR_NOT_FOUND_LICENSE.ordinal();
		}

		return result;
	}

	/**
	 * ライセンスファイルから文字列を取得し、データ領域を取得する
	 * @param file  ライセンスファイル
	 * @return ライセンスデータ
	 */
	private String readLicenseData(File file) {
		StringBuffer sb = new StringBuffer();
		String licenseData = "";

		try {
			// ファイルを読み込むバッファドリーダを作成します。
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			// ファイルから読み込んだ一文字を保存する変数です。
			int c;
			// ファイルから１文字ずつ読み込み、バッファへ追加します。
			while ((c = br.read()) != -1) {
				sb.append((char) c);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
			return licenseData;
		}

		/* データ領域を抜き出す */
		// 開始位置と終了位置を取得する
		int startPosition = sb.toString().indexOf(START_STRING) + START_STRING.length();
		int endPosition = sb.toString().indexOf(END_STRING);

		// 開始位置と終了位置を取得できた場合、データ領域を抜き出す
		if (startPosition != -1 && endPosition != -1) {
			licenseData = sb.toString().substring(startPosition, endPosition);
			// 改行コードを""に変換する
			licenseData = licenseData
				.replaceAll("\\r", "")
				.replaceAll("\\n", "");
			// 最大サイズを上回っている場合
			if (licenseData.length() > MAX_LICENSE_DATA_SIZE) {
				// 読み取り失敗とするため、空白を設定する
				licenseData = "";
			}
		}
		DWQRKit.setLog(DWQR_TAG, "startPosition[" + startPosition +
				"] endPosition[" + endPosition +
				"] licenseData[" + licenseData + "]");
		// 開始位置と終了位置の間のデータを返す
		return licenseData;
	}

    /**
     * 位置情報取得処理の初期化
     */
    private void initLocation() {
        DWQRKit.setLog(DWQR_TAG, "LocationManager start.");
        PackageManager pm = getActivity().getPackageManager();

        // 位置情報取得機能が搭載されている
        if (hardwareChecked[3] != DWQRStatusCode.DWQR_NO_FEATURELOCATION.ordinal()) {
            locationManager = (LocationManager)getActivity().getSystemService(Context.LOCATION_SERVICE);

            boolean isGPSEnable = false;
            boolean isNetworkEnable = false;
            // GPSサービスが有効になっている場合
            if ((hardwareChecked[4] != DWQRStatusCode.DWQR_NO_FEATURELOCATION_GPS.ordinal()) &&
                (PackageManager.PERMISSION_GRANTED == pm.checkPermission("android.permission.ACCESS_FINE_LOCATION", getActivity().getPackageName())) &&
                locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                DWQRKit.setLog(DWQR_TAG, "GPS Service enable.");
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
                isGPSEnable = true;
            }
            // ネットワーク位置情報取得サービスが有効になっている場合
            if (hardwareChecked[5] != DWQRStatusCode.DWQR_NO_FEATURELOCATION_NETWORK.ordinal() &&
                (PackageManager.PERMISSION_GRANTED == pm.checkPermission("android.permission.ACCESS_COARSE_LOCATION", getActivity().getPackageName())) &&
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                DWQRKit.setLog(DWQR_TAG, "Network Service enable.");
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, this);
                isNetworkEnable = true;
            }
            // GPSとネットワークが両方とも無効の場合
            if (!isGPSEnable && !isNetworkEnable) {
                DWQRKit.setLog(DWQR_TAG, "Disabled Service.");
                dwqrRequestData.setRequestLatitude(0.0);
                dwqrRequestData.setRequestLongitude(0.0);
            }
        } else {
            DWQRKit.setLog(DWQR_TAG, "Disabled location.");
            dwqrRequestData.setRequestLatitude(0.0);
            dwqrRequestData.setRequestLongitude(0.0);
        }
    }

    /**
     * 端末情報の取得
     */
    private void getDeviceInformation() {
        // 端末ID
		dwqrRequestData.setRequestDeviceID(Settings.Secure.getString(getActivity().getContentResolver(), Settings.Secure.ANDROID_ID));

        // 端末言語
        dwqrRequestData.setRequestDeviceLanguage(Locale.getDefault().getLanguage());

        // 端末OS
        dwqrRequestData.setRequestDeviceOS(Build.VERSION.RELEASE);

        // 端末モデル
        dwqrRequestData.setRequestDeviceModel(Build.MODEL);

        DWQRKit.setLog(DWQR_TAG, "Get device Information.(" + dwqrRequestData.getRequestDeviceID() + ", " +
                dwqrRequestData.getRequestDeviceLanguage() + ", " +
                dwqrRequestData.getRequestDeviceOS() + ", " +
                dwqrRequestData.getRequestDeviceModel() + ")");
    }

	/**
	 * ログデータの送信結果の受け取り
	 */
	private final DWQRLogServerConnection.ResponseServerCallback responseLogServerCallback = new DWQRLogServerConnection.ResponseServerCallback() {
		@Override
		public void onPostExecute( int statusCode ) {
			DWQRKit.setLog(DWQR_TAG, "Complete send Log.(" + statusCode +")");
			isSendingLogData = false;			// ログ送信処理停止
		}

		@Override
		public void onCancelled() {
			DWQRKit.setLog(DWQR_TAG, "Cancel send Log.");
			isSendingLogData = false;			// ログ送信処理停止
		}
	};

	/**
	 * ログ送信用のスレッドクラス
	 */
	public class SendLogDataThread extends Thread {
		boolean isRun = true;			// 実行するか否かのフラグ

		@Override
		public void run() {
			// 端末により即座に実行すると強制終了する場合があるので、2秒程度スリープする
			try {
				Thread.sleep(2000);				// 2秒待機
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			while (isRun) {
				if (!isSendingLogData) {
					isSendingLogData = true;
					DWQRLogServerConnection lodDataServerConnection = new DWQRLogServerConnection(responseLogServerCallback);
					lodDataServerConnection.execute();
				}
				try {
					// ログ送信周期設定
					int logInterval = dwqrRequestData.getRequestLogInterval() * 1000; /* ms */
					Thread.sleep(logInterval);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		/**
		 * スレッドの停止処理
		 */
		public void stopThread() {
			isRun = false;
		}
	}

	/**
	 * 監視タイマー　クラス
	 */
	public class ObserverTask extends TimerTask{
		boolean isLogoDisplayEnableOld = true;	// 会社ロゴ設定の前回値
		boolean isStopCaptureOld = false;			// ストップキャプチャ設定の前回値

		/**
		 * 監視用メソッド
		 */
		@Override
		public void run(){
			try{
				Thread.sleep(1);
			}catch(InterruptedException e){
				e.printStackTrace();
			}

			// 会社ロゴ表示・非表示の監視
			if(dwqrkit.isLogoDisplayEnable != isLogoDisplayEnableOld){	// 変更があったとき
				// isLogoDisplayEnableの監視
				handler.post(new Runnable() {
					@Override
					public void run() {
						isLogoDisplayEnableOld = dwqrkit.isLogoDisplayEnable;
						fl_camera.removeView(logoImageView);
						if(dwqrkit.isLogoDisplayEnable){		// 表示するとき
							logoImageView.setVisibility(View.VISIBLE);
						}else{
							logoImageView.setVisibility(View.INVISIBLE);
						}
						fl_camera.addView(logoImageView);
					}
				});
			}

			// プレビュー停止・再開の監視
			if( isStopCaptureOld != dwqrkit.isStopCapture ){			// 変更があったとき
				// カメラのプレビューを再開するとき、フレームの消去を行うため別スレッドで行う
				if (dwqrkit.isStopCapture) {
					isStopCaptureOld = dwqrkit.isStopCapture;
				} else{
					handler.post(new Runnable() {
						@Override
						public void run() {
							// 変更があったとき
							if( isStopCaptureOld != dwqrkit.isStopCapture ){
								isStopCaptureOld = dwqrkit.isStopCapture;
								cameraSurfaceView.resumeCameraPreview();
							}
						}
					});
				}
			}
		}
	}
}
