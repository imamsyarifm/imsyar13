package com.densowave.dwqrkit.listener;

/**
 * History Data Interface
 */
public interface DWQRHistoryListener {
	public void qrDecodeHistoryData ( String historyData );		// History Data Interface
}
