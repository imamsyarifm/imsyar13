package com.densowave.dwqrkit;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.densowave.dwqrkit.decodeParameter.DWDecodeConstants;

/**
 * Previewing images stored in the device
 */
public class DWQRImageSurfaceView extends SurfaceView implements SurfaceHolder.Callback, Runnable {

	//For log output
	private static final String DWQR_TAG = DWQRImageSurfaceView.class.getSimpleName();	// Tag settings

	// For resizing decoded images
	private final static int DWQR_RESIZE_BITMAP_WIDTH = 640;					// Decode size: width
	private final static int DWQR_RESIZE_BITMAP_HEIGHT = 480;					// Decode size: height

	// color code division
	private static final int DWQR_COLORCODE_RED = 0x00ff0000;					// Extract the red
	private static final int DWQR_COLORCODE_GREEN = 0x0000ff00;					// Extracting Green
	private static final int DWQR_COLORCODE_BLUE = 0x000000ff;					// Extract the blue
	private static final int DWQR_SIFT_RED = 16;								// For calculating the shift after extracting the red color code
	private static final int DWQR_SIFT_GREEN = 8;								// For calculating the shift after extracting the green color code
	private static final int DWQR_COLOR_DENOMINATOR = 3;						// The denominator for calculating the color average

	// Instance Settings
	private DWQRKit dwqrkit = DWQRKit.sharedManager();							// Singleton's DWQRKit class
	private SurfaceHolder holder;													// Surface Access and Monitoring
	private Thread drawThread;													// drawing thread
	private boolean isDrawImage;												// Drawing flag (true: drawing completion, false: not yet drawn)

	// image data
	private Bitmap colorImage = null;											// Image data to be displayed on the display
	private int displayWidth;													// Display width
	private int displayHeight;													// Display height
	private static final int DWQR_STROKE_WIDTH = 5;							// Line thickness when drawing

	// Picture frame coordinates
	private Point[] posTopLeft = new Point[DWDecodeConstants.DWQR_MAX_CODENUM];		// left-upper
	private Point[] posTopRight = new Point[DWDecodeConstants.DWQR_MAX_CODENUM];		// right-upper
	private Point[] posBottomRight = new Point[DWDecodeConstants.DWQR_MAX_CODENUM];	// right-lower
	private Point[] posBottomLeft = new Point[DWDecodeConstants.DWQR_MAX_CODENUM];	// left-lower
	private int paintColor[] = {0x00000000,0x00000000};		// 外形枠のカラー

	/**
	 * constructor
	 * @param context
	 */
	public DWQRImageSurfaceView(Context context) {
		super(context);
		DWQRKit.setLog(DWQR_TAG,"DWQRImageSurfaceView()");

		// Initialize the coordinate positions of the external frame.
		posTopLeft[0] = new Point();
		posTopLeft[1] = new Point();
		posTopRight[0] = new Point();
		posTopRight[1] = new Point();
		posBottomRight[0] = new Point();
		posBottomRight[1] = new Point();
		posBottomLeft[0] = new Point();
		posBottomLeft[1] = new Point();

		this.holder = getHolder();
		this.holder.addCallback(this);							// callback processing
		isDrawImage = false;										// undrawn
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		DWQRKit.setLog(DWQR_TAG,"surfaceCreated()");
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
		DWQRKit.setLog(DWQR_TAG,"surfaceChanged(" + "width=" + width  + ", height="+ height + ") start");
		createDrawThread();
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// Performed when the surface is destroyed
		DWQRKit.setLog(DWQR_TAG,"surfaceDestroyed()");
		releaseDecodeImage();							// Release the image for display
		isDrawImage = false;							// undrawn
	}

	/**
	 * Threads for image drawing
	 */
	@Override
	public void run() {
		while (drawThread != null) { 					// When a drawing thread is being created
			if( colorImage != null && !isDrawImage ){	// When there is a drawing image and it has never been drawn
				drawDecodeImage(holder);				// Drawing.
			}
			//sleep
			try{
				Thread.sleep(1);					// 1ms sleep
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}

	/**
	 * Creating the drawing thread
	 */
	public void createDrawThread() {
		this.holder.setFormat(PixelFormat.RGBA_8888);	// Setting the background color
		if(drawThread == null){// When the drawing thread is not created
			drawThread = new Thread(this);		// Create a drawing thread
			drawThread.start();							// Start
		}
	}

	/**
	 * To clear the image on the display
	 */
	public void clearDecodeImage() {
		getHolder().setFormat(PixelFormat.TRANSLUCENT);			// Make the view background color transparent
		Canvas decodeView = this.holder.lockCanvas();				// lock up
		decodeView.drawColor(Color.TRANSPARENT, Mode.CLEAR);		// Clear the displayed image.
		this.holder.unlockCanvasAndPost(decodeView);				// release
		isDrawImage = false;										// undrawn
	}

	/**
	 * Release the image for display
	 */
	public void releaseDecodeImage(){
		if( colorImage != null ){
			colorImage.recycle();		// release the use area
		}
		colorImage = null;			// Delete the display image
		drawThread = null;			// Stop the drawing thread.
	}

	/**
	 * Return the size of the image displayed on the display
	 * @return Point	Size of the image to be displayed on the display
	 */
	public Point getColorImageSize(){
		return new Point(colorImage.getWidth(), colorImage.getHeight());
	}

	/**
	 * Set the drawing position of the outline frame.
	 * @param posTopLeft		Top left position.
	 * @param posTopRight	Top right position.
	 * @param posBottomRight	Bottom right position.
	 * @param posBottomLeft	Bottom left position.
	 * @param paintColor		Foreground color of the frame
	 */
	public void setArParameter(Point[] posTopLeft, Point[] posTopRight, Point[] posBottomRight, Point[] posBottomLeft, int[] paintColor){
		for( int i = 0; i < DWDecodeConstants.DWQR_MAX_CODENUM; i++ ){
			// Setting of each coordinate value
			this.posTopLeft[i] = posTopLeft[i];
			this.posTopRight[i] = posTopRight[i];
			this.posBottomRight[i] = posBottomRight[i];
			this.posBottomLeft[i] = posBottomLeft[i];
		}
		this.paintColor = paintColor;
	}

	/**
	 * Use the acquired images to create images for decoding and display
	 * @param image 			image data
	 * @param displayWidth	Device display size (width)
	 * @param displayHeight 	Device display size (height)
	 * @return decodeImageData Decoded image binary data
	 */
	public byte[] createDecodeImage(Bitmap image, int displayWidth, int displayHeight){
		DWQRKit.setLog(DWQR_TAG,"createDecodeBitmap(" + "displayWidth=" + displayWidth  + ", displayHeight="+ displayHeight + ") start");

		// Must keep the aspect ratio of the specified image within the 640x480 decoded image Because there is a
		// modify the image resizing process
		Bitmap tmpImage = null;

		// Save the width of the display to draw a black background
		this.displayWidth = displayWidth;
		this.displayHeight = displayHeight;

		// Resize the specified image
		int tmpImageWidth = image.getWidth();										// width
		int tmpImageHeight = image.getHeight();									// height
		float aspectImage = (float)image.getWidth() / (float)image.getHeight();	// The aspect ratio of the specified image

		// For horizontal images
		if (tmpImageWidth > tmpImageHeight) {
			tmpImageWidth = DWQR_RESIZE_BITMAP_WIDTH;
			tmpImageHeight = (int)(tmpImageWidth / aspectImage);
			// When the calculated height exceeds the height of the decoded image
			if (tmpImageHeight > DWQR_RESIZE_BITMAP_HEIGHT) {
				tmpImageHeight = DWQR_RESIZE_BITMAP_HEIGHT;
				tmpImageWidth = (int)(tmpImageHeight * aspectImage);
			}
		// For other images (square and vertical images)
		} else {
			tmpImageHeight = DWQR_RESIZE_BITMAP_HEIGHT;
			tmpImageWidth = (int)(tmpImageHeight * aspectImage);
		}

		try {
			// Create a resized image using the calculated height and width
			this.colorImage = Bitmap.createScaledBitmap(image, tmpImageWidth, tmpImageHeight, false);

			// Creating a decode image
			tmpImage = Bitmap.createBitmap(DWQR_RESIZE_BITMAP_WIDTH, DWQR_RESIZE_BITMAP_HEIGHT, Config.ARGB_8888);
			Canvas c = new Canvas(tmpImage);
			// Set the background color to white.
			c.drawColor(Color.WHITE);
			// Paste a resized image to be in the middle of the decoded image.
			c.drawBitmap(this.colorImage,
				(DWQR_RESIZE_BITMAP_WIDTH / 2) - (float)(tmpImageWidth / 2),
				(DWQR_RESIZE_BITMAP_HEIGHT / 2) - (float)(tmpImageHeight / 2),
				null);
			this.colorImage = tmpImage;

			// Enlarge the image to fit the size of the display
			tmpImageWidth = displayWidth;
			// The decoded image is 4:3 (640x480), so the aspect ratio is fixed and the height is calculated
			tmpImageHeight = (int)(tmpImageWidth / ((float)DWQR_RESIZE_BITMAP_WIDTH / DWQR_RESIZE_BITMAP_HEIGHT));
			this.colorImage = Bitmap.createScaledBitmap(this.colorImage, tmpImageWidth, tmpImageHeight, false);
		} catch(Exception e){
			DWQRKit.setLog(DWQR_TAG, e.getLocalizedMessage());
			// When the tmpImage exists
			if (tmpImage != null) {
				tmpImage.recycle();
				tmpImage = null;
			}
		}

		// Create images for decoding
		byte decodeImageData[];	// decoded data
		if (tmpImage != null) {
			int imageWidth  = tmpImage.getWidth();												// width
			int imageHeight = tmpImage.getHeight();												// height
			int imageSize   = imageHeight * imageWidth;											// Size.
			int imagePixel[]  = new int[imageSize];												// pixel size
			tmpImage.getPixels(imagePixel, 0, imageWidth, 0, 0, imageWidth, imageHeight);		// Get Bitmap pixel data
			decodeImageData  = new byte[imageSize];

			// Perform grayscale using the simple average method
			for (int y = 0; y < imageHeight; y++) {
				for (int x = 0; x < imageWidth; x++) {
					int index = x + (y * imageWidth);											// Indexing
					int red   = imagePixel[index] & DWQR_COLORCODE_RED >> DWQR_SIFT_RED;		// Extract the red color from the color code
					int green = imagePixel[index] & DWQR_COLORCODE_GREEN >> DWQR_SIFT_GREEN;	// Extract the green color from the color code
					int blue  = imagePixel[index] & DWQR_COLORCODE_BLUE;						// Extract the blue color from the color code
					int gray  = (red + green + blue) / DWQR_COLOR_DENOMINATOR;					// lower the tone
					decodeImageData[index] = (byte)gray;
					imagePixel[index] = Color.rgb(gray, gray, gray);
				}
			}
		} else {
			decodeImageData = null;
		}

		// When the tmpImage exists
		if (tmpImage != null) {
			tmpImage.recycle();
			tmpImage = null;
		}

		return decodeImageData;
	}

	/**
	 * Draw an image to be displayed on the display.
	 */
	private void drawDecodeImage(SurfaceHolder holder) {
		DWQRKit.setLog(DWQR_TAG,"drawDecodeImage");
		Canvas decodeView = this.holder.lockCanvas();					// Locking the Canvas

		// When there is an image to be displayed, it is drawn.
		if( decodeView != null && colorImage != null ){
			// Drawing a Black Painted Background
			Paint paint = new Paint();
			paint.setColor(Color.argb(255, 0, 0, 0));
			Rect rect = new Rect(0, 0, this.displayWidth, this.displayHeight);
			decodeView.drawRect(rect, paint);

			if (dwqrkit.isQRFrameEnable) {
				// Drawing an outline frame
				drawArView(decodeView);
			}

			// Calculate the height of the drawing position.
			float positionHeight = (this.displayHeight / 2) - (float)(colorImage.getHeight() / 2);
			decodeView.drawBitmap(colorImage, 0, positionHeight, new Paint());		// Drawing Display Images
			this.holder.unlockCanvasAndPost(decodeView);				// Updating the Canvas
			isDrawImage = true;										// Finish drawing.
		}
	}

	/**
	 * Drawing an outline frame
	 * @param canvas	The canvas to draw on
	 */
	private void drawArView(Canvas canvas){
		// Draw a line on the outline frame
		for( int i = 0; i < DWDecodeConstants.DWQR_MAX_CODENUM; i++ ){
			Paint outLinePaint = new Paint();
			outLinePaint.setAntiAlias(true);
			int frameColor = paintColor[i];
			int alpha = frameColor >>> DWQRARView.DWQR_SHIFT_3BYTE;								// clarity
			int red = ( frameColor >>> DWQRARView.DWQR_SHIFT_2BYTE ) & DWQRARView.DWQR_MASK;	// red
			int green = ( frameColor >>> DWQRARView.DWQR_SHIFT_1BYTE ) & DWQRARView.DWQR_MASK;	// green
			int blue = frameColor & DWQRARView.DWQR_MASK;											// blue

			// Drawing Settings
			outLinePaint.setStyle(Paint.Style.FILL);
			outLinePaint.setARGB(alpha, red, green, blue);
			outLinePaint.setStrokeWidth(DWQR_STROKE_WIDTH);

			// Drawings from top left to top right X-coordinate start point, Y-coordinate start point, X-coordinate end point, and Y-coordinate end point
			canvas.drawLine( posTopLeft[i].x,
					posTopLeft[i].y,
					posTopRight[i].x,
					posTopRight[i].y,
					outLinePaint );
			// Drawing from top right to bottom right
			canvas.drawLine( posTopRight[i].x,
					posTopRight[i].y,
					posBottomRight[i].x,
					posBottomRight[i].y,
					outLinePaint );
			// Drawing from bottom right to bottom left
			canvas.drawLine( posBottomRight[i].x,
					posBottomRight[i].y,
					posBottomLeft[i].x,
					posBottomLeft[i].y,
					outLinePaint );
			// Drawing from bottom left to top left
			canvas.drawLine( posBottomLeft[i].x,
					posBottomLeft[i].y,
					posTopLeft[i].x,
					posTopLeft[i].y,
					outLinePaint );
		}
	}
}