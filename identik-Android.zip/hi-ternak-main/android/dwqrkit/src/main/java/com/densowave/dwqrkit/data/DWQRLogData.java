package com.densowave.dwqrkit.data;

public class DWQRLogData {

    private String logData = "";        // log data
    private String date = "";           // getting time
    public boolean isQRCode = false;    // QR code flag

    /**
     * Constructor
     */
    public DWQRLogData() {
        this.logData = "";
        this.isQRCode = false;
    }

    /**
     * Get time to get
     * @return time to get
     */
    public String getDate() {
        return this.date;
    }

    /**
     * Set time to get
     * @param date time to get
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * Get Log Data
     * @return log data
     */
    public String getLogData() {
        return this.logData;
    }

    /**
     * Set Log Data
     * @param logData log data
     */
    public void setLogData(String logData) {
        this.logData = logData;
    }
}
