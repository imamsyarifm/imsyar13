package com.densowave.dwqrkit;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;

import com.densowave.dwqrkit.decodeParameter.DWDecodeConstants;


/**
 * Class that displays rectangle when reading QR
 */
public class DWQRARView extends View implements AnimationListener{

	private static final String DWQR_TAG = DWQRARView.class.getSimpleName();	// tag setting

	private static final int DWQR_STROKE_WIDTH = 5;								// Line thickness when drawing

	private AlphaAnimation alpha;
	private AnimationSet set;

	/**
	 * QR code outline frame
	 */
	private Point[] posTopLeft = new Point[DWDecodeConstants.DWQR_MAX_CODENUM];							// upper left
	private Point[] posTopRight = new Point[DWDecodeConstants.DWQR_MAX_CODENUM];						// upper right
	private Point[] posBottomRight = new Point[DWDecodeConstants.DWQR_MAX_CODENUM];						// lower right
	private Point[] posBottomLeft = new Point[DWDecodeConstants.DWQR_MAX_CODENUM];						// lower left

	public int paintColor[] = {0x00000000,0x00000000};		// color

	/**
	 * for bit arithmetic
	 */
	public static final int DWQR_SHIFT_1BYTE = 0x08;		// 1byte shift
	public static final int DWQR_SHIFT_2BYTE = 0x10;		// 2byte shift
	public static final int DWQR_SHIFT_3BYTE = 0x18;		// 3byte shift
	public static final int DWQR_MASK = 0x000000FF;			// mask

	public boolean isAnimationExetute = false;				// animation flag

	/**
	 * DWQRARView
	 * @param context
	 */
	public DWQRARView(Context context) {
        super(context);

        // initialize
		posTopLeft[0] = new Point();
		posTopLeft[1] = new Point();
		posTopRight[0] = new Point();
		posTopRight[1] = new Point();
		posBottomRight[0] = new Point();
		posBottomRight[1] = new Point();
		posBottomLeft[0] = new Point();
		posBottomLeft[1] = new Point();

        for( int i = 0; i < DWDecodeConstants.DWQR_MAX_CODENUM; i++ ){
			// initialize
			posTopLeft[i] = new Point(0, 0);
	        posTopRight[i] = new Point(0, 0);
	        posBottomRight[i] = new Point(0, 0);
	        posBottomLeft[i] = new Point(0, 0);
		}
    }

	// drawing
    @SuppressLint("DrawAllocation")
	@Override
    protected void onDraw(Canvas canvas) {
        Paint paint = new Paint();
        paint.setAntiAlias(true);

        // Draw code outline
        drawCodeOutline( canvas, paint );
    }

	@Override
	public void onAnimationEnd(Animation animation) {
		DWQRKit.setLog(DWQR_TAG,"endAnimation");
		isAnimationExetute = false;							// flag off
		for( int i = 0; i < DWDecodeConstants.DWQR_MAX_CODENUM; i++ ){
			// initialize
			posTopLeft[i] = new Point(0, 0);
	        posTopRight[i] = new Point(0, 0);
	        posBottomRight[i] = new Point(0, 0);
	        posBottomLeft[i] = new Point(0, 0);
		}
		invalidate();
	}

	@Override
	public void onAnimationRepeat(Animation animation) {
	}

	@Override
	public void onAnimationStart(Animation animation) {
		DWQRKit.setLog(DWQR_TAG,"startAnimation");
	}

    /**
     * Acquisition of code outline position and redrawing
     * @param pos1 upper left
     * @param pos2 upper right
     * @param pos3 lower right
     * @param pos4 lower left
     */
	public void drawScreen(Point[] pos1, Point[] pos2, Point[] pos3, Point[] pos4) {
		for( int i = 0; i < DWDecodeConstants.DWQR_MAX_CODENUM; i++ ){
			// Setting each coordinate
			posTopLeft[i] = pos1[i];
			posTopRight[i] = pos2[i];
			posBottomRight[i] = pos3[i];
			posBottomLeft[i] = pos4[i];
		}
    }

	/**
	 * animation setting（fade out）
	 * @param isQRFrameAnimation
	 */
	public void startFadeoutAnimation(boolean isQRFrameAnimation){
		if( isQRFrameAnimation ){
			DWQRKit.setLog(DWQR_TAG,"initAnimation");
			isAnimationExetute = true;						// flag on
			alpha = new AlphaAnimation(1.0f, 0.0f);			// fade out setting
			set = new AnimationSet(false);	// Animation synthesis
			alpha.setDuration(500);							// Fade out time setting (ms)
			set.addAnimation(alpha);						// add animation
			set.setAnimationListener(this);					// Animation listener registration
			startAnimation(set);							// start animation
		}else{
			// Erase outline
			for( int i = 0; i < DWDecodeConstants.DWQR_MAX_CODENUM; i++ ){
				// initialize
				posTopLeft[i] = new Point(0, 0);
		        posTopRight[i] = new Point(0, 0);
		        posBottomRight[i] = new Point(0, 0);
		        posBottomLeft[i] = new Point(0, 0);
			}
			invalidate();
		}
	}

	/**
	 * stop animation
	 */
	public void stopFadeoutAnimation(){
		if( alpha != null ){
			clearAnimation();
			alpha.cancel();
			alpha.reset();
			alpha = null;
			set.cancel();
			set.reset();
			set = null;
		}
	}

	/**
	 * Outline frame color setting
	 * @param paintColor
	 */
	public void setPaintColor( int[] paintColor ) {
		this.paintColor = paintColor;
	}

    /**
     * Outline drawing
     * @param canvas
     * @param paint
     */
    private void drawCodeOutline(Canvas canvas, Paint paint) {

		// Outline frame draw a line
		for( int i = 0; i < DWDecodeConstants.DWQR_MAX_CODENUM; i++ ){
			Paint outLinePaint = new Paint();
			outLinePaint.setAntiAlias(true);
			int frameColor = paintColor[i];
	    	int alpha = frameColor >>> DWQR_SHIFT_3BYTE;					// Transparency
	    	int red = ( frameColor >>> DWQR_SHIFT_2BYTE ) & DWQR_MASK;		// red
	    	int green = ( frameColor >>> DWQR_SHIFT_1BYTE ) & DWQR_MASK;	// green
	    	int blue = frameColor & DWQR_MASK;								// blue

			// drawing setting
	    	outLinePaint.setStyle( Paint.Style.FILL );
	    	outLinePaint.setARGB( alpha, red, green, blue );
	    	outLinePaint.setStrokeWidth( DWQR_STROKE_WIDTH );

			canvas.drawLine( posTopLeft[i].x, posTopLeft[i].y, posTopRight[i].x, posTopRight[i].y, outLinePaint );				// Upper left to upper right drawing
			canvas.drawLine( posTopRight[i].x, posTopRight[i].y, posBottomRight[i].x, posBottomRight[i].y, outLinePaint );		// Upper right to lower right drawing
			canvas.drawLine( posBottomRight[i].x, posBottomRight[i].y, posBottomLeft[i].x, posBottomLeft[i].y, outLinePaint );	// Lower right to lower left drawing
			canvas.drawLine( posBottomLeft[i].x, posBottomLeft[i].y, posTopLeft[i].x, posTopLeft[i].y, outLinePaint );			// Lower left to upper right
		}
    }
}
