package com.densowave.dwqrkit.listener;

import android.widget.FrameLayout;

/**
 * Interface to notify the QR reading history data of the tapped cell
 */
public interface DWQRScanViewCreateListener {
	public void onCreateScanView(FrameLayout frameLayout);	// Notify the QR reading history data of the tapped cell
}
