package com.densowave.dwqrkit;

import com.densowave.dwqrkit.listener.DWQRCodeNoticeExListener;
import com.densowave.dwqrkit.listener.DWQRCodeNoticeListener;

/**
 * Class that relays the decoding result notification to the listener
 */
class DWQRCodeNoticeListenerProxy {
    private DWQRCodeNoticeListener qrCodeNoticeListener;
    private DWQRCodeNoticeExListener qrCodeNoticeExListener;

    DWQRCodeNoticeListenerProxy(DWQRCodeNoticeListener listener) {
        qrCodeNoticeListener = listener;
    }

    DWQRCodeNoticeListenerProxy(DWQRCodeNoticeExListener listener) {
        qrCodeNoticeExListener = listener;
    }

    public void onNoticeDecodeResult(String decodeData, String codeType, byte[] binaryData, int binaryLength, String decodePrivateData, int statusCode, String srvAppData) {
        if (qrCodeNoticeExListener != null) {
            qrCodeNoticeExListener.onNoticeDecodeResult(decodeData, codeType, binaryData, binaryLength, decodePrivateData, statusCode, srvAppData);
        } else if (qrCodeNoticeListener != null) {
            qrCodeNoticeListener.onNoticeDecodeResult(decodeData, codeType, binaryData, binaryLength, decodePrivateData, statusCode);
        }
    }

    public void subscribe(DWQRCodeNoticePublisher publisher) {
        if (qrCodeNoticeExListener != null) {
            publisher.setOnQRCodeFoundNoticeListener(qrCodeNoticeExListener);
        } else if (qrCodeNoticeListener != null) {
            publisher.setOnQRCodeFoundNoticeListener(qrCodeNoticeListener);
        }
    }

}
