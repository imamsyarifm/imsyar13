package com.densowave.dwqrkit.listener;

/**
 * Interface to receive the decode results
 */
public interface DWQRCodeNoticeListener {
	public void onNoticeDecodeResult(String decodeData, String codeType, byte[] binaryData, int binaryLength, String decodePrivateData, int statusCode);
}
