package com.densowave.dwqrkit;

import android.content.Context;
import android.content.SharedPreferences;

import com.densowave.dwqrkit.common.DWQRCommon;
import com.densowave.dwqrkit.data.DWQRLogData;
import com.densowave.dwqrkit.decodeParameter.DWDecodeConstants;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class DWQRRequestData {
    private static final String LOG_DATA_NAME = "logData";      // Log data storage name
    private static final int DEFAULT_LOG_COUNT = 1000;          // Default number of log data stored
    private static final int DWQR_TARGET_APPID_LENGTH = 5;	    // The threshold for the number of characters to be modified in the APPID
    private static final char DWQR_SQRC_REPLACE_PARAM = '2';    // Changed value of the APPID at SQRC
    private static final char DWQR_FQR_REPLACE_PARAM = '3';	    // Changed value of APPID at FrameQR
    private static final String DWQR_DECODE_VERSION = "0000";   // Data format version
    private static final String DWQR_SEPARATE = "<:sep>";       // separator

    private static DWQRRequestData dwQrRequestData = null;		// Singletonize the class
    private Context context;                                    // Context for storing log data

    /* サーバリクエスト時に指定するデータ */
    private String requestID = "";					    // request ID
    private String requestPassword = "";			    // Password
    private String requestAppID = "";				    // App ID
    private String requestServiceID = "";			    // service ID
    private String requestOption = "";				    // option
    private String requestDecodeUrl = "";			    // url : decode server
    private String requestLogUrl = "";                  // url : log server
    private int requestLogInterval = 10;                // log transmission cycle
    private String expirationDate = "";                 // expiration date
    private String requestDeviceID = "";                // device ID
    private String requestDeviceLanguage = "";          // language
    private String requestDeviceOS = "";                // OS
    private String requestDeviceModel = "";             // device model
    private double requestLatitude = 0.0;               // latitude
    private double requestLongitude = 0.0;              // longitude
    public boolean isSendQRLogDataEnable = false;       // Enable/Disable the transmission of QR Code log data
    public boolean isSendBarcodeLogDataEnable = false;	// Enable/Disable the transmission of Barcode log data
    private List<DWQRLogData> logDataList = new ArrayList<DWQRLogData>();           // List of log data
    private List<DWQRLogData> deleteTargetList = new ArrayList<DWQRLogData>();      // List of log data to be deleted

    /**
     * Create the DWQRRequestData class as a singleton (common class)
     * @return dwQrRequestData	Singleton's DWQRequestData class
     */
    public static DWQRRequestData sharedManager() {
        if( dwQrRequestData == null ) {
            dwQrRequestData = new DWQRRequestData();
        }
        return dwQrRequestData;
    }

    /**
     * Set the Context
     * @param context context
     */
    public void setContext(Context context) {
        this.context = context;
    }

    /**
     * get request ID
     * @return request ID
     */
    public String getRequestID(){
        return this.requestID;
    }

    /**
     * set request ID
     * @param requestID
     */
    public void setRequestID(String requestID){
        this.requestID = requestID;
    }

    /**
     * get password
     * @return password
     */
    public String getRequestPassword(){
        return this.requestPassword;
    }

    /**
     * set password
     * @param requestPassword
     */
    public void setRequestPassword(String requestPassword){
        this.requestPassword = requestPassword;
    }

    /**
     * Get the AppID to be used for server transmission
     * @return AppID
     */
    public String getRequestAppID(){
        return this.requestAppID;
    }

    /**
     * Set the AppID to be used for server transmission
     * @param requestAppID AppID
     */
    public void setRequestAppID(String requestAppID){
        this.requestAppID = requestAppID;
    }

    /**
     * Get the service ID to be used for server transmission
     * @return requestServiceID
     */
    public String getRequestServiceID(){
        return this.requestServiceID;
    }

    /**
     * Set the service ID to be used for server transmission
     * @param requestServiceID requestServiceID
     */
    public void setRequestServiceID(String requestServiceID){
        this.requestServiceID = requestServiceID;
    }

    /**
     * Get the options to be used for server transmission
     * @return requestOption
     */
    public String getRequestOption(){
        return this.requestOption;
    }

    /**
     * Set the options to be used for server transmission
     * @param requestOption option
     */
    public void setRequestOption(String requestOption){
        this.requestOption = requestOption;
    }

    /**
     * Get the url : decode server
     * @return url : decode server
     */
    public String getRequestDecodeUrl(){
        return this.requestDecodeUrl;
    }

    /**
     * Set the url : decode server
     * @param requestDecodeUrl url : decode server
     */
    public void setRequestDecodeUrl(String requestDecodeUrl){
        this.requestDecodeUrl = requestDecodeUrl;
    }

    /**
     * Get the url : log server
     * @return url : log server
     */
    public String getRequestLogUrl() {
        return this.requestLogUrl;
    }

    /**
     * Set the url : log server
     */
    public void setRequestLogUrl(String requestLogUrl) {
        this.requestLogUrl = requestLogUrl;
    }

    /**
     * Get the log transmission cycle
     * @return log transmission cycle
     */
    public int getRequestLogInterval() {
        return this.requestLogInterval;
    }

    /**
     * Set the log transmission cycle
     */
    public  void setRequestLogInterval(int requestLogInterval) {
        this.requestLogInterval = requestLogInterval;
    }

    /**
     * Get an expiration date
     * @return expiration date
     */
    public String getExpirationDate() {
        return this.expirationDate;
    }

    /**
     * Set an expiration date
     * @param expirationDate expiration date
     */
    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    /**
     * Get a device ID
     * @return device ID
     */
    public String getRequestDeviceID() {
        return requestDeviceID;
    }

    /**
     * Set the device ID
     * @param requestDeviceID device ID
     */
    public void setRequestDeviceID(String requestDeviceID) {
        this.requestDeviceID = requestDeviceID;
    }

    /**
     * Get the device language
     * @return device language
     */
    public String getRequestDeviceLanguage() {
        return requestDeviceLanguage;
    }

    /**
     * Set the device language
     * @param requestDeviceLanguage device language
     */
    public void setRequestDeviceLanguage(String requestDeviceLanguage) {
        this.requestDeviceLanguage = requestDeviceLanguage;
    }

    /**
     * Get the device OS
     * @return device OS
     */
    public String getRequestDeviceOS() {
        return requestDeviceOS;
    }

    /**
     * Set the device OS
     * @param requestDeviceOS device OS
     */
    public void setRequestDeviceOS(String requestDeviceOS) {
        this.requestDeviceOS = requestDeviceOS;
    }

    /**
     * Get the device model
     * @return device model
     */
    public String getRequestDeviceModel() {
        return requestDeviceModel;
    }

    /**
     * Set the device model
     * @param requestDeviceModel device model
     */
    public void setRequestDeviceModel(String requestDeviceModel) {
        this.requestDeviceModel = requestDeviceModel;
    }

    /**
     * Set the latitude
     * @param requestLatitude latitude
     */
    public void setRequestLatitude(double requestLatitude) {
        this.requestLatitude = requestLatitude;
    }

    /**
     * Set the longitude
     * @param requestLongitude longitude
     */
    public void setRequestLongitude(double requestLongitude) {
        this.requestLongitude = requestLongitude;
    }

    /**
     * Saving Log Data
     * @param codeType code type
     */
    public void saveLogData(String codeType) {
        DWQRLogData dwQrLogData = new DWQRLogData();
        JSONObject jsonObject = new JSONObject();

        // Set the reading time of the log
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat dayFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");		    // Date and time format
        SimpleDateFormat keyFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");	    // Key Format for Preference Registration
        String key = keyFormat.format(cal.getTime());
        dwQrLogData.setDate(key);

        // Set the app ID
        if( requestAppID == null || requestAppID.length() < 1 ) {
            requestAppID = "(null)";
        }
        String requestAppID = changeAppID(this.requestAppID, codeType);

        // Set a Service ID
        if( requestServiceID == null || requestServiceID.length() < 1 ) {
            requestServiceID = "(null)";
        }

        try {
            // Create data for transmission
            jsonObject.put( "appid", requestAppID);					        // AppID
            jsonObject.put( "srvid", this.requestServiceID);					// service ID
            jsonObject.put( "symbol", codeType);							    // code type
            jsonObject.put( "rd_time", dayFormat.format(cal.getTime()));		// Specify the acquisition time
            jsonObject.put( "cli_id", dwQrRequestData.getRequestDeviceID());	// Specify the Terminal ID
            jsonObject.put( "cli_lat", this.requestLatitude);						// Specify the latitude
            jsonObject.put( "cli_lon", this.requestLongitude);						// Specify longitude
            jsonObject.put( "cli_lang", this.requestDeviceLanguage);	        // Specify the terminal language
            jsonObject.put( "cli_os", this.requestDeviceOS);			        // Specify the device OS
            jsonObject.put( "cli_model", this.requestDeviceModel);		    // Specify the terminal model
            dwQrLogData.setLogData(jsonObject.toString());

            // Check the code type
            if (codeType.equals(DWDecodeConstants.CODEMARK_QR) ||
                    codeType.equals(DWDecodeConstants.CODEMARK_QR_GS1) ||
                    codeType.equals(DWDecodeConstants.CODEMARK_MICRO_QR) ||
                    codeType.equals(DWDecodeConstants.CODEMARK_QR_COMBINE_EDIT_NONE) ||
                    codeType.equals(DWDecodeConstants.CODEMARK_QR_COMBINE_EDIT_NONE_GS1)){
                dwQrLogData.isQRCode = true;
            }

            long freeByteSize = DWQRCommon.getExternalStorage();					// Get free space in the storage area
            int logDataNum = this.logDataList.size();								// Number of log data
            int addDataSize = dwQrLogData.getLogData().getBytes().length;			// Get the data size of additional data
            boolean addDataFlag = true;												// Data addition flag

            SharedPreferences data = context.getSharedPreferences(LOG_DATA_NAME, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = data.edit();

            // In case of insufficient free space
            if (freeByteSize < addDataSize) {
                addDataFlag = false;
                // When the number of log data is greater than the maximum
            } else if(logDataNum >= DEFAULT_LOG_COUNT ) {
                addDataFlag = deleteOldestLogData(data, editor);
            }

            if (addDataFlag) {
                // Save it
                this.logDataList.add(0, dwQrLogData);
                editor.putString(key, dwQrLogData.getLogData() + DWQR_SEPARATE + dwQrLogData.isQRCode);
                editor.commit();
            }
        } catch ( JSONException e ) {
            e.printStackTrace();
        }
    }

    /**
     * Get log data stored in the terminal
     */
    public void setLogData() {
        DWQRLogData data;
        SharedPreferences shareData = this.context.getSharedPreferences(LOG_DATA_NAME, Context.MODE_PRIVATE);
        Map<String,?> map = shareData.getAll();
        logDataList.clear();

        // Get log data from a Storage Area
        for(String key : map.keySet()) {
            data = new DWQRLogData();
            data.setDate(key);
            String tmp[] = shareData.getString(key, "").split(DWQR_SEPARATE);
            // If the element is not two, it is considered invalid data
            if (tmp.length == 2) {
                data.setLogData(tmp[0]);
                // when QR code
                if (tmp[1] == "true") {
                    data.isQRCode = true;
                }
                logDataList.add(data);
            }
        }
        // sort in descending order
        descendLogData();
    }

    /**
     * Delete Log Data
     */
    public void deleteLogData() {
        SharedPreferences data = context.getSharedPreferences(LOG_DATA_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = data.edit();
        Map<String,?> map = data.getAll();

        // If the data is in a key or object, delete it.
        for( Map.Entry<String, ?> entry : map.entrySet() ){
            String key = entry.getKey();
            // Searches for the log data to be deleted and deletes it when it matches
            for (int index = 0; index < this.deleteTargetList.size(); index++) {
                DWQRLogData log = this.deleteTargetList.get(index);
                if (log.getDate().equals(key)) {
                    editor.remove(key).commit();
                    break;
                }
            }
        }
        // Clearing the list for deletion
        this.deleteTargetList.clear();

        // Resetting the log data
        setLogData();
    }

    /**
     * Create decode data
     * @param cellDataArrays cell information
     * @return decoded data
     */
    public String createDecodeData(String cellDataArrays[]) {
        String decodeData = "";
        JSONObject jsonObject = new JSONObject();                   // JSON object
        String version = DWQR_DECODE_VERSION;                       // data format version
        String symbol = cellDataArrays[0];                          // code type
        String row = cellDataArrays[1];                             // Number of cells per side of the code (horizontal)
        String column = cellDataArrays[2];                          // Number of cells per side of code (vertical) * Horizontal data is also used as vertical
        String cell = cellDataArrays[3];                            // B/W information on the cell
        String tmpAppID = this.requestAppID;                        // AppID
        String tmpServiceID = this.requestServiceID;                // service ID


        // Set the app ID
        if (tmpAppID == null || tmpAppID.length() < 1) {
            tmpAppID = "(null)";
        }
        tmpAppID = changeAppID(this.requestAppID, symbol);

        // Set a service ID
        if (tmpServiceID == null || tmpServiceID.length() < 1) {
            tmpServiceID = "(null)";
        }

        try {
            // Create data for transmission
            jsonObject.put("appid", tmpAppID);
            jsonObject.put("srvid", tmpServiceID);
            jsonObject.put("version", version);
            jsonObject.put("symbol", symbol);
            jsonObject.put("row_num", row);
            jsonObject.put("column_num", column);
            jsonObject.put("cell", cell);
        	jsonObject.put("key", DWDecodeConstants.SQRC_KEY);
            jsonObject.put("optd", this.requestOption);                     // Specify the option
            jsonObject.put("cli_id", this.getRequestDeviceID());            // Specify the terminal ID
            jsonObject.put("cli_lat", this.requestLatitude);                     // Specify the latitude
            jsonObject.put("cli_lon", this.requestLongitude);                    // Specify longitude
            jsonObject.put("cli_lang", this.getRequestDeviceLanguage());    // Specify the terminal language
            jsonObject.put("cli_os", this.getRequestDeviceOS());            // Specify the device OS
            jsonObject.put("cli_model", this.getRequestDeviceModel());      // Specify the terminal model
            decodeData = jsonObject.toString();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return decodeData;
    }

    /**
     * Create Log Data
     * @return log data
     */
    public String createLogData() {
        String logData = "";
        List<String> tmpList = new ArrayList<String>();
        boolean isRequestEnable = false;

        descendLogData();
        deleteTargetList.clear();
        for (int index = 0; index < logDataList.size(); index++) {
            DWQRLogData log = logDataList.get(index);
            // When a QR Code is the output target and the log data is a QR Code
            if (log != null && log.isQRCode && this.isSendQRLogDataEnable) {
                tmpList.add(log.getLogData());
                deleteTargetList.add(log);
                isRequestEnable = true;
            }
            // When the barcode is the output target and the log data is a barcode
            if (log != null && !log.isQRCode && this.isSendBarcodeLogDataEnable) {
                tmpList.add(log.getLogData());
                deleteTargetList.add(log);
                isRequestEnable = true;
            }
        }
        // If you have data to send
        if (isRequestEnable) {
            // Creating JSON format data
            logData += "{\"log\":[";
            for (int index = 0; index < tmpList.size(); index++) {
                logData += tmpList.get(index);
                // Except at the end
                if (index != tmpList.size() - 1) {
                    logData += ",";
                }
            }
            logData += "]}";
        }

        return logData;
    }

    /**
     * Change the app ID to be sent at the time of request depending on the code type
     * @param appid app ID
     * @param codeType code type
     * @return	Modified app ID
     */
    private String changeAppID(String appid, String codeType){
        String editAppID = appid;

        // When the appID is not "(null)"
        if( !editAppID.equals("(null)") ){
            // When the appid is more than 5 characters
            if( editAppID.length() >= DWQR_TARGET_APPID_LENGTH ){
                // Get the string as a char array
                char[] appidString = editAppID.toCharArray();

                // When frameQR
                if( codeType.equals(DWDecodeConstants.CODEMARK_FQR) ){
                    // Change the fifth letter to '2'
                    appidString[DWQR_TARGET_APPID_LENGTH - 1] = DWQR_FQR_REPLACE_PARAM;
                    // When the SQRC
                }else if( codeType.equals(DWDecodeConstants.CODEMARK_SQRC)  ){
                    // Change the fifth letter to '3'
                    appidString[DWQR_TARGET_APPID_LENGTH - 1] = DWQR_SQRC_REPLACE_PARAM;
                    // other than that
                }else{
                    // No change
                }
                // Make the char array a string
                editAppID = String.valueOf(appidString);
            }
        }
        return editAppID;
    }

    /**
     * Sort the log data in descending order
     */
    private void descendLogData() {
        // sort in descending order
        Collections.sort(this.logDataList, new Comparator<DWQRLogData>() {
            @Override
            public int compare(DWQRLogData lld, DWQRLogData rld) {
                if (lld == null || rld == null || lld.getDate() == null || rld.getDate() == null){
                    return 0;
                }
                // Comparison of two data objects
                int result = lld.getDate().compareTo(rld.getDate()) * -1;
                return result;
            }
        });
    }

    /**
     * Deletion of oldest log data
     * @param data App configuration data
     * @param editor data information
     * @return addDataFlg log addition flag
     */
    private boolean deleteOldestLogData(SharedPreferences data, SharedPreferences.Editor editor) {
        boolean addDataFlg = true;                             // Data addition flag
        List<String> deleteLogDataList = new ArrayList<String>();   // Temporary list of log data storage
        int size = this.logDataList.size();                    // Number of log data

        // If the maximum number is exceeded, the excess data and the oldest data are deleted
        if (size > DEFAULT_LOG_COUNT) {
            for (int index = size; index >= DEFAULT_LOG_COUNT; index--) {
                deleteLogDataList.add(0, this.logDataList.get(index-1).getDate());
                this.logDataList.remove(index-1);
            }
        } else {
            deleteLogDataList.add(0, this.logDataList.get(size-1).getDate());
            this.logDataList.remove(size-1);
        }

        Map<String,?> map = data.getAll();
        // Delete the key if it exists
        for( Map.Entry<String, ?> entry : map.entrySet() ) {
            String key = entry.getKey();
            for (int index = 0; index < deleteLogDataList.size(); index++) {
                String date = deleteLogDataList.get(index);
                if (date.equals(key)) {
                    editor.remove(key).commit();
                    break;
                }
            }
        }
        return addDataFlg;
    }
}
