package com.densowave.dwqrkit;

import com.densowave.dwqrkit.listener.DWQRCodeNoticeExListener;
import com.densowave.dwqrkit.listener.DWQRCodeNoticeListener;

/**
 * Interface that notifies the listener of the decoding result
 */
interface DWQRCodeNoticePublisher {
    public void setOnQRCodeFoundNoticeListener( DWQRCodeNoticeListener listener );
    public void setOnQRCodeFoundNoticeListener( DWQRCodeNoticeExListener listener );
}
