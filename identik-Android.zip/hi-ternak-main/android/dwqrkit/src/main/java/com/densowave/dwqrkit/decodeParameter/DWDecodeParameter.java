package com.densowave.dwqrkit.decodeParameter;

/**
 * QR Code Decode Parameter Class
 */
public class DWDecodeParameter {
	/**
	 * QR Code Setting
	 */
	public static class DWDecodeQRType {
		public static final int PARAM_INDEX = 0;
		public static final int NONE = 0;
		public static final int ALL = 0x000f;
		public static final int QR = 0x0001;
		public static final int MICRO_QR = 0x0002;
		public static final int SQRC = 0x0004;
		public static final int FQR = 0x0008;
	}

	/**
	 * Barcode setting
	 */
	public static class DWDecodeBarcodeType {
		public static final int PARAM_INDEX = 1;
		public static final int NONE = 0;
		public static final int ALL = 0x0007;
		public static final int UPCA = 0x0001;
		public static final int UPCE = 0x0002;
		public static final int EAN8 = 0x0004;
	}

	/**
	 * Barcode Setting (UPCAddon)
	 */
	public static class DWDecodeUPCAddonType {
		public static final int PARAM_INDEX = 2;
		public static final int NONE = 0;
		public static final int ALL = 0x0003;
		public static final int ADDON2 = 0x0001;
		public static final int ADDON5 = 0x0002;
		public static final int ADDON_ONLY = 0x0004;
	}

	/**
	 * Multiple Code Batch Decode Setting
	 */
	public static class DWDecodeMultipleQR {
		public static final int PARAM_INDEX = 3;
		public static final int OFF = 0;
		public static final int ON = 0x0001;
	}

	/**
	 * QR consolidated code decode mode Setting
	 */
	public static class DWDecodeCombinedQR {
		public static final int PARAM_INDEX = 4;
		public static final int OFF = 0;
		public static final int ON = 0x0001;
	}

	/**
	 * Point-scan mode Setting
	 */
	public static class DWDecodePointScanQR {
		public static final int PARAM_INDEX = 3;
		public static final int OFF = 0;
		public static final int ON = 0x0002;
	}

	/**
	 * Black and White Inversion Code Setting
	 */
	public static class DWDecodeReversalCode {
		public static final int PARAM_INDEX = 3;
		public static final int OFF = 0;
		public static final int ON = 0x0004;
	}

}
