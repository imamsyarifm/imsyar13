package com.densowave.dwqrkit;

import android.os.AsyncTask;

import com.densowave.dwqrkit.data.DWQRRequestData;
import com.densowave.dwqrkit.decodeParameter.DWDecodeConstants;

import okhttp3.Credentials;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

/**
 * Class for accessing the decoding server
 */
public class DWQRDecodeServerConnection extends AsyncTask<String, Integer, String> {
	/**
	 * log settings
	 */
	private static final String DWQR_TAG = DWQRDecodeServerConnection.class.getSimpleName();

	private final byte[] DWQR_SERVERURL = {104,116,116,112,115,58,47,47,97,112,105,50,46,100,110,45,113,45,112,108,97,116,102,111,114,109,46,99,111,109};
	private final byte[] DWQR_SERVERURL_SQRC = {47,97,112,105,47,83,81,82,67,100,101,99,111,100,101};
	private final byte[] DWQR_SERVERURL_FRAMEQR = {47,97,112,105,47,70,81,82,100,101,99,111,100,101};

	/**
	 * Character string for error judgment
	 */
	private static final String DWQR_SERVER_ERROR_TIMEOUT = "DWQR_SERVER_ERROR_TIMEOUT";	// time out
	private static final String DWQR_SERVER_ERROR_FAILED = "DWQR_SERVER_ERROR_FAILED";		// failure

	/**
	 * For server communication result
	 */
	private static final int DWQR_SERVER_SUCCESS = DWQRStatusCode.DWQR_SUCCESS.ordinal();	// success
	private static final int DWQR_SERVER_TIMEOUT = DWQRStatusCode.DWQR_TIMEOUT.ordinal();	// time out
	private static final int DWQR_SERVER_FAILED = DWQRStatusCode.DWQR_FAILED.ordinal();		// failure
	private static final int DWQR_SERVER_DISABLE = DWQRStatusCode.DWQR_DISABLE.ordinal();	// Server connection prohibition

	private ResponseServerCallback responseServerCallback = null;							// callback
	private String codeType;																// code type

	private DWQRRequestData dwQrRequestData = DWQRRequestData.sharedManager();				// request data

	private final OkHttpClient httpClient = new OkHttpClient.Builder()
			.connectTimeout(5000, TimeUnit.MILLISECONDS)    // Timeout before establishing connection
			.writeTimeout(5000, TimeUnit.MILLISECONDS)      // Timeout after establishing connection(write)
			.readTimeout(5000, TimeUnit.MILLISECONDS)       // Timeout after establishing connection(read)
			.hostnameVerifier(new HostnameVerifier() {
				@Override
				public boolean verify(String s, SSLSession sslSession) {
					// Allow all hosts to skip hostname verification
					return true;
				}
			})
			.build();

	/**
	 * interface
	 */
	public interface ResponseServerCallback {
		void onPreExecute();
		void onPostExecute( String decodeData, String codeType, String decodePrivateData, int statusCode, String srvAppData);	// デコード結果
		void onProgressUpdate( int progress );
		void onCancelled();
	}

	/**
	 * DWQRDecodeServerConnection
	 * @param responseServerCallback　Response server callback（Asynchronous）
	 */
	public DWQRDecodeServerConnection( ResponseServerCallback responseServerCallback ) {
		this.responseServerCallback = responseServerCallback;
	}

	/**
	 * decode request
	 * @param celldata	request data
	 * @return The string of the request result
	 */
	public String requestDecode( String celldata ) {
		DWQRKit.setLog(DWQR_TAG,"requestDecode");
		String resultString;										// Communication result
		String url = null;											// URL
		DWQRKit dwqrKit = DWQRKit.sharedManager();

		// If the request data is Null, do nothing
		if (celldata == null) {
			return "";
		}

		// Split the contents of celldata
		String arrays[] = celldata.split( "," );			// cSplit the celldata into commas and store them in an array
		String symbol = arrays[0];									// code type
		codeType = symbol;											// Get the code type


		try {
			DWQRRequestData dwqrRequestData = DWQRRequestData.sharedManager();
			String decodeData = dwqrRequestData.createDecodeData(arrays);

			if ( !dwqrKit.isServerConnectionEnable ){ // When communication is prohibited
				resultString = decodeData;
			}else{
				// Get the URL
				url =getUrl(symbol);

				// Perform a POST transmission
				RequestBody body = RequestBody.create(decodeData, MediaType.get("application/json; charset=utf-8"));

				Request httpRequest = new Request.Builder()
						.url(url)
						.addHeader("Authorization",
								Credentials.basic(dwqrRequestData.getRequestID(),dwqrRequestData.getRequestPassword()))
						.post(body)
						.build();
				System.out.println("[IDENTIK PKH] "+decodeData+"|"+dwqrRequestData.getRequestID()+"|"+dwqrRequestData.getRequestPassword());
				dwqrKit.setParamDecode(decodeData);
				Response httpResponse = httpClient.newCall(httpRequest).execute();
				if( httpResponse.code() == 200 ){
					resultString = httpResponse.body().string();
				}else{
					resultString = DWQR_SERVER_ERROR_FAILED;
				}
				httpResponse.close();
			}
		} catch (IOException e) {
			resultString = DWQR_SERVER_ERROR_FAILED;
		}

		return resultString;
	}

	@Override
	protected String doInBackground( String... params ) {
		String result = requestDecode( params[0] );

		// Repeatedly calling the decoding process may cause some models to hang before automatically releasing the connected resources. up.
		// Therefore, we explicitly release the connection resource here
		httpClient.connectionPool().evictAll();

		return result;
	}

	@Override
	protected void onPreExecute() {
        super.onPreExecute();
        if( responseServerCallback != null ){
        	responseServerCallback.onPreExecute();
        }
    }

	@Override
    protected void onProgressUpdate( Integer... values ) {
        super.onProgressUpdate(values);
        if( responseServerCallback != null ){
        	responseServerCallback.onProgressUpdate(values[0]);
        }
    }

	@Override
    protected void onPostExecute( String result ) {
        super.onPostExecute(result);
        if( responseServerCallback != null ){
        	if( result == null ){
        		callResponseServer(DWQR_SERVER_FAILED);
        	}else if( result.equals(DWQR_SERVER_ERROR_FAILED ) ){
        		callResponseServer(DWQR_SERVER_FAILED);
        	}else if( result.equals(DWQR_SERVER_ERROR_TIMEOUT ) ){
        		callResponseServer(DWQR_SERVER_TIMEOUT);
        	}else{
        		String decodeData = "";						// public data
				String decodePrivateData = null;			// non-public data
				String codeType = "";						// code type
				int statusCode = DWQR_SERVER_SUCCESS;	// status code
				String srvAppData = "";
				DWQRKit dwqrKit = DWQRKit.sharedManager();
				if(!dwqrKit.isServerConnectionEnable){
					// Returns DWQR_DISABLE if server connection is prohibited.
					responseServerCallback.onPostExecute( result, codeType, decodePrivateData, DWQR_SERVER_DISABLE, srvAppData );
				}else{
					try {
						JSONObject json = new JSONObject( result );
						decodeData = json.getString( "Dcd_PublicData" );
						codeType = json.getString("Dcd_Symbol");
						decodePrivateData = json.getString( "Dcd_PrivateData" );
						statusCode = json.getInt( "Dcd_Result" );
						if (! json.isNull("srvApp")) {
							srvAppData = json.getString( "srvApp" );
						}
						// Changing the code type of the SQRC server decode result
						if( statusCode != DWQR_SERVER_SUCCESS ) {// When it's not a success
							statusCode = DWQR_SERVER_FAILED;
						} else {
							// Change code type
							codeType = changeCodeType(codeType, decodeData ,decodePrivateData);
						}
						responseServerCallback.onPostExecute( decodeData, codeType, decodePrivateData, statusCode, srvAppData );
					} catch ( JSONException e ) {
						responseServerCallback.onPostExecute( "", "", "", DWQR_SERVER_FAILED, "" );
					}
				}
        	}
        }
	}

	@Override
    protected void onCancelled() {
        super.onCancelled();
        if( responseServerCallback != null ){
        	responseServerCallback.onCancelled();
        }
    }

	/**
	 * Get the URL
	 * @param code　code type
	 * @return url　URL
	 */
	private String getUrl(String code){
		String url = "";				// For URL storage
		String encoding = "UTF-8";		// Encoding type
		if (dwQrRequestData.getRequestDecodeUrl().equals(DWDecodeConstants.DWQR_SERVER)) {
			// If you specify a DNWA domestic server
			try{
				// Set the destination URL.
				url += new String(DWQR_SERVERURL, encoding);
				if( code.equals( DWDecodeConstants.CODEMARK_FQR ) ){		// For Frame QR
					url += new String(DWQR_SERVERURL_FRAMEQR, encoding);
				}else if( code.equals( DWDecodeConstants.CODEMARK_SQRC ) ){	// For SQRC
					url += new String(DWQR_SERVERURL_SQRC, encoding);
				}
			}catch(UnsupportedEncodingException e){
				e.printStackTrace();
			}
		}
		else {
			// If you specify a user server
			try{
				// Set the destination URL.
				url += dwQrRequestData.getRequestDecodeUrl();
				if( code.equals( DWDecodeConstants.CODEMARK_FQR ) ){		// For Frame QR
					url += new String(DWQR_SERVERURL_FRAMEQR, encoding);
				}else if( code.equals( DWDecodeConstants.CODEMARK_SQRC ) ){	// For SQRC
					url += new String(DWQR_SERVERURL_SQRC, encoding);
				}
			}catch(UnsupportedEncodingException e){
				e.printStackTrace();
			}
		}

		return url;
	}

	/**
	 * Control the method to be called from ResponseServerCallBack for each type of QR be (a person)
	 * @param state status code
	 */
	private void callResponseServer(int state){
		// If you can't read it in time
		if( state == DWQR_SERVER_FAILED || state == DWQR_SERVER_TIMEOUT ) {
			if (codeType.equals(DWDecodeConstants.CODEMARK_FQR)) {
				responseServerCallback.onPostExecute("", "", "", state, "");
			} else if (codeType.equals(DWDecodeConstants.CODEMARK_SQRC)) {
				responseServerCallback.onPostExecute("", DWDecodeConstants.CODEMARK_QR, "", state, "");
			}
		}
	}

	/**
	 * Check for the existence of public and secret data and change the code type
	 * @param codeType code type
	 * @param decodePublicData public data
	 * @param decodePrivateData non-public data
	 * @return Modified code type
	 */
	private String changeCodeType(String codeType, String decodePublicData, String decodePrivateData){
		// When the SQRC
		if( codeType.equals(DWDecodeConstants.CODEMARK_SQRC) ){
			// When public data exists and non-public data does not exist
			if( !(decodePublicData.equals("null") || decodePublicData.equals("")) &&
					(decodePrivateData.equals("null") || decodePrivateData.equals("")) ){
				// Change to "Q0"
				codeType = DWDecodeConstants.CODEMARK_QR;
			}
		} else {
			// No changes except for the SQRC.
		}
		return codeType;
	}
}
