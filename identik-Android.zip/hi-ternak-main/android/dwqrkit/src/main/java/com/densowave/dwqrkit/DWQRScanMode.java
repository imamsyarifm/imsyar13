package com.densowave.dwqrkit;

/**
 * QRの読み取りモード
 */
public enum DWQRScanMode {
	DWQR_NOMALMODE(0),		// 通常モード
	DWQR_SELECTMODE1(1),		// 選択モード1
	DWQR_SELECTMODE2(2),		// 選択モード2
	DWQR_POINTSCANMODE(3);	// ポイントスキャンモード

	private int scanMode;	// QR読み取りモード

	/**
	 * コンストラクタ
	 * @param scanMode QR読み取りモード初期値
	 */
	DWQRScanMode(int scanMode){
		this.scanMode = scanMode;
	}

	/**
	 * QR読み取りモードの値を返す
	 * @return QR読み取りモード
	 */
	public int getValue(){
		return this.scanMode;
	}
};
