package com.densowave.dwqrkit;

import android.app.Activity;
import android.app.Service;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.ImageFormat;
import android.graphics.Point;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.AudioAttributes;
import android.media.Image;
import android.media.ImageReader;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.VibrationEffect;
import androidx.annotation.NonNull;
import android.util.Size;
import android.media.AudioManager;
import android.media.SoundPool;
import android.media.ToneGenerator;
import android.os.Handler;
import android.os.Message;
import android.os.Vibrator;
import androidx.fragment.app.FragmentActivity;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.ViewGroup.LayoutParams;

import com.densowave.dwqrkit.common.DWQRCommon;
import com.densowave.dwqrkit.data.DWQRRequestData;
import com.densowave.dwqrkit.decodeParameter.DWDecodeConstants;
import com.densowave.dwqrkit.decodeParameter.DWDecodeResult;
import com.densowave.dwqrkit.decodeParameter.DWDecoder;
import com.densowave.dwqrkit.listener.DWQRCodeNoticeListener;
import com.densowave.dwqrkit.listener.DWQRCodeNoticeExListener;
import com.densowave.dwqrkit.decodeParameter.DWDecodeParameter;

import java.nio.ByteBuffer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/**
 * Class to control the camera preview
 */
public class DWQRCameraSurfaceView extends SurfaceView implements SurfaceHolder.Callback, DWQRCodeNoticePublisher {

	/**
	 * For Logging
	 */
	private static final String DWQR_TAG = DWQRCameraSurfaceView.class.getSimpleName();		// Tag settings

	private static final int DWQR_AUDIO_TIMER = 50;							// Sound buzzing time (ms)
	private static final int DWQR_VIBRATION_TIMER = 300;						// Vibration sounding time (ms)
	private static final int DWQR_HANDLEMESSAGE_DEFAULT = 0;				// Set the color of the outline frame before decoding is complete
	private static final int DWQR_HANDLEMESSAGE_DECODED = 1;				// Set the color of the outline frame when decoding is complete
	private static final int DWQR_HANDLEMESSAGE_MULTIDQRCODE_ECODED = 2;	// Set the color of the outline frame for reading multiple QR Codes
	private static final int DWQR_HANDLEMESSAGE_STOP_ANIMATION = 3;		// Forced termination of the animation
	private static final int DWQR_HISTORYDATA_NUM_MAX = 1000;				// Maximum number of historical data stored (1000)
	private static final int DWQR_INVALID_DECODE = 0;						// QR to be decoded (none)
	private static final int DWQR_MAX_DECODE = 3;								// QR to be decoded (2 pieces)
	private static final int DWQR_VGA_SIZE = 640 * 480;						// VGA size size

	/**
	 * listener
	 */
	private DWQRCodeNoticeListenerProxy qrCodeNoticeListener;

	/**
	 * Instance Settings
	 */
	private String cameraId;								// camera ID
	private Context context;								// context
	private SurfaceHolder holder;							// Surface Access and Monitoring
	private CameraSettings cameraSettings;				// Camera Information
	private ToneGenerator toneGenerator;					// sound effects
	private Vibrator vibrator;							// vibration
	private Size previewSize;							// Preview height and width in pixels
	private DWDecoder decoder;							// decode
	private DWQRIndicator indicator;						// indicator
	private DWQRARView arViewRect;						// External frame indication
	private DWQRARCrossView arViewCross;					// Aiming Display
	private DWDecodeResult result = null;				// decode results
	private DWQRKit dwqrkit = DWQRKit.sharedManager();	// Singleton's DWQRKit class
	private handlerARView handlerAR = null;				// Color indication of the exterior frame
	private int format;									// Camera formats retrieved from SurfaceChange
	private int viewWidth;								// Preview size taken from SurfaceChange (Width)
	private int viewHeight;								// Preview size taken from SurfaceChange (Height)

	public boolean isCalledDestroy = true;				// The running state of SurfaceDestroyed
	private byte[] saveBinaryData;						// decoded binary data
	private int saveBinaryLength = 0;					// Data length of decoded binary data
	private String saveLocalDecodeData;                 // local decoded data
	private String saveCodeType;							// code type
	private DWQRRequestData dwQrRequestData = DWQRRequestData.sharedManager();	// request data

	/**
	 * For checking device functions
	 */
	private static final int DWQR_NOTSUPPORT_FLASHMODE_NUM = 1;	// Number of flash types supported by devices without flash
	private int[] hardwareChecked;									// Device Function Check Results

	/**
	 * For external frame and sighting display
	 */
	private static final int DWQR_HALF = 2;						// For calculating the sighting center position for point scanning
	private static final double DWQR_LINE = 0.2;					// For calculating sighting length for point scanning
	private static final int DWQR_DECODE_BITMAP_WIDTH = 640;	// Width of the image used for decoding
	private static final int DWQR_DECODE_BITMAP_HEIGHT = 480;	// Height of the image used for decoding
	private Point[] codeOutlineTopLeft = new Point[DWDecodeConstants.DWQR_MAX_CODENUM];		// Code Outline Top Left
	private Point[] codeOutlineTopRight = new Point[DWDecodeConstants.DWQR_MAX_CODENUM];	// Code Outline Top Right
	private Point[] codeOutlineBottomRight = new Point[DWDecodeConstants.DWQR_MAX_CODENUM];	// Code Outline Bottom Right
	private Point[] codeOutlineBottomLeft = new Point[DWDecodeConstants.DWQR_MAX_CODENUM];	// Code Outline Bottom Left
	private Point[] dispPosTopLeft = new Point[DWDecodeConstants.DWQR_MAX_CODENUM];			// Code Outline Top Left For display
	private Point[] dispPosTopRight = new Point[DWDecodeConstants.DWQR_MAX_CODENUM];			// Code Outline Top Right Display
	private Point[] dispPosBottomRight = new Point[DWDecodeConstants.DWQR_MAX_CODENUM];		// Code Outline Bottom Right Display
	private Point[] dispPosBottomLeft = new Point[DWDecodeConstants.DWQR_MAX_CODENUM];		// Code Outline Bottom Left For display

	/**
	 * In case of Selection Mode 1 and 2, used when the QR Code is selected
	 */
	private static final int DWQR_DECODE_OUTLINE_NUMBER = 4;	// Number of sides of the outer frame
	private static final int DWQR_TOPLEFT = 0;					// Outline frame apex: Top left
    private static final int DWQR_TOPRIGHT = 1;					// Outline frame apex: Upper right
    private static final int DWQR_BOTTOMRIGHT = 2;				// Outline frame apex: lower right
    private static final int DWQR_BOTTOMLEFT = 3;					// Outline frame apex: Lower left
    private int decodeNum;											// Number of QR codes detected
    private int selectDecodeNum;									// QR Code Identification Value to be decoded

	/**
	 * For screen display
	 */
	private int displayWidth;							// Display Size Width
	private int displayHeight;							// Display Size Height
	public Point selectQrCode = new Point();			// selection coordinates

	private boolean isCodeMark2d = false;				// 2D barcode code type flag
	private boolean isSendRequest = false;				// Request being sent flag
	public boolean isBackground = false;				// background wait flag

	/**
	 * For image data decoding
	 */
	private DWQRImageSurfaceView imageSurfaceView;				// Decoded Image Display
	private byte[] decodeImageData = null;						// For storing image data to be decoded
	private int beforeScanMode;									// Retains scan mode settings
	private boolean isBitmapDecord = false;					// Image data decode flag

	/**
	 * For sound playback
	 */
	private static final int DWQR_LOAD_SOUND_DEFAULT = -1;		// The default sound ID to use when a sound fails to load
	// Sound source to be used for sound playback when decoding is successful
	private SoundPool soundSource = new SoundPool.Builder()
			.setMaxStreams(1)
			.setAudioAttributes(new AudioAttributes.Builder().setLegacyStreamType(AudioManager.STREAM_MUSIC).build())
			.build();
	private int soundID;												// sound ID
	private int loadSoundResourceID = DWQR_LOAD_SOUND_DEFAULT;	// The resource ID of the sound used when loading the sound

	/**
	 * For camera control
	 */
	private ImageReader captureImageReader;								// Reader to receive captured images
	private Size captureImageSize;										// Size of the captured image
	private CameraDevice cameraDevice;									// camera device
	private CameraCaptureSession captureSession;						// capture session
	private CaptureRequest captureRequest;								// capture request
	private Semaphore cameraOpenCloseLock = new Semaphore(1);	// For exclusive control of the connection-disconnection process to the camera device
	private HandlerThread captureBackgroundThread;						// Threads for performing capture and decode operations
	private Handler captureBackgroundThreadHandler;						// The handler of mBackgroundThread

	/**
	 * Camera Settings
	 * */
	public class CameraSettings {
		public int format;			// Format（keep default）
		public int previewWidth;	// Camera preview size：width
		public int previewHeight;	// Camera preview size：height
		public int angle;			// Camera orientation
	}

	/**
	 * constructor
	 * @param context	context
	 */
	public DWQRCameraSurfaceView(Context context) {
		super(context);
		this.context = context;
		init();
	}

	/**
	 * constructor
	 * @param context　context
	 * @param attrs　Layout Parameters
	 * @param defStyle　Style Information
	 */
	public DWQRCameraSurfaceView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		this.context = context;
		init();
	}

	/**
	 * constructor
	 * @param context　context
	 * @param attrs　Layout Parameters
	 */
	public DWQRCameraSurfaceView(Context context, AttributeSet attrs) {
		super(context, attrs);
		this.context = context;
		init();
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		DWQRKit.setLog(DWQR_TAG, "surfaceCreated");		// log settings
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int surfaceWidth, int surfaceHeight) {
		DWQRKit.setLog(DWQR_TAG, "surfaceChanged() surfaceWidth = " + surfaceWidth + " surfaceHeight = " + surfaceHeight);		// log settings

		// Save the previous preview size
		int oldWidth = this.viewWidth;
		int oldHeight = this.viewHeight;

		// Get the format and width from surfaceChanged
		this.format = format;
		this.viewWidth = surfaceHeight;
		this.viewHeight = surfaceWidth;

		// When surfaceDestroyed is running
		if (this.isCalledDestroy) {
			// Since surfaceChanged may be executed twice when returning after background transition by back key,
			// Configure the camera settings only if the view has not been resized or is being run for the first time.
			if (((oldWidth == this.viewWidth) && (oldHeight == this.viewHeight)) ||
					((oldWidth == 0) && (oldHeight == 0))) {
				decodeBitmapImage();
			}
			this.isCalledDestroy = false;
		}
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		DWQRKit.setLog(DWQR_TAG, "surfaceDestroyed()");		// log settings

		// Clearing Camera Settings
		closeCamera();

		isCalledDestroy = true;
	}

	/**
	 * Get coordinates of the screen tap position
	 * @return true　onTouchEvent finished
	 */
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		boolean isCheckFlg = false;		// Flag for checking whether the detected QR Code is in the specified area
		selectQrCode.x = 0;				// Specified position X coordinate Initialization
		selectQrCode.y = 0;				// Specified Position Y Coordinate Initialization

		int mode = dwqrkit.getMode();
		// Decode the QR code when the tap position is within the readable QR code rectangle.
		if( ( mode == DWQRScanMode.DWQR_SELECTMODE1.ordinal() ) && ( dwqrkit.isStopCapture == true ) ) {	// In the selection mode 1 and when the screen preview is stopped
			selectQrCode.x = (int) event.getX();
			selectQrCode.y = (int) event.getY();
			isCheckFlg = isCheckInFrame();
		} else if ( mode == DWQRScanMode.DWQR_SELECTMODE2.ordinal() ){										// Selection Mode 2
			selectQrCode.x = (int) event.getX();
			selectQrCode.y = (int) event.getY();
			isCheckFlg = isCheckInFrame();
		}

		if( isCheckFlg == true){
			DWDecodeResult result = new DWDecodeResult();	// decode results
			if( isBitmapDecord ) { // When decoding with images
				startDecodeForBitmap( mode, result );		// Start decoding
				decodeImageData = null;					// Delete the image data to be decoded
				dwqrkit.setMode(beforeScanMode);		// Set the saved scan mode.
			}else{
				startDecode( mode, result );
			}
		}
		return false;	// onTouchEvent finished
	}

	/**
	 * Set the interface to notify the decoding result of a QR Code
	 * @param onQRCodeFoundNoticeListener　Local Decode and Server Decode Interface
	 */
	public void setOnQRCodeFoundNoticeListener( DWQRCodeNoticeListener onQRCodeFoundNoticeListener ) {
		this.qrCodeNoticeListener = new DWQRCodeNoticeListenerProxy(onQRCodeFoundNoticeListener);
	}
	public void setOnQRCodeFoundNoticeListener( DWQRCodeNoticeExListener onQRCodeFoundNoticeListener ) {
		this.qrCodeNoticeListener = new DWQRCodeNoticeListenerProxy(onQRCodeFoundNoticeListener);
	}

	/**
	 * Create image data for decoding and set the binary data for decoding images.
	 * @param decodeImage		Image data for decoding
	 * @param imageSurfaceView 	instance
	 */
	public void setDecodeImage(Bitmap decodeImage, DWQRImageSurfaceView imageSurfaceView){
		this.decodeImageData = imageSurfaceView.createDecodeImage(decodeImage, displayWidth, displayHeight);
		this.imageSurfaceView = imageSurfaceView;
	}

	/**
	 * Set device screen size
	 * @param width　width
	 * @param height　height
	 */
	public void setDisplaySize(int width, int height) throws CameraAccessException
	{
		// Size of the display area
		displayWidth = width;
		displayHeight = height;

		// Determine the size of the image received from the Camera2 API
		// The maximum size guaranteed by the Camera2 API for any device is 1920 x 1080
		// Closest display area to aspect ratio between 640x480 and 1920x1080 Select Size
		CameraManager manager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
		CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraId);
		StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);

		// captured image
		List<Size> imageSupportedSizes =  Arrays.asList(map.getOutputSizes(ImageFormat.YUV_420_888));
		captureImageSize = choosePreviewSize(imageSupportedSizes, 640, 480, 1920, 1080);

		// preview
		List<Size> previewSupportedSizes =  Arrays.asList(map.getOutputSizes(SurfaceHolder.class));
		previewSize = choosePreviewSize(previewSupportedSizes, 640, 480, 1920, 1080);
		holder.setFixedSize(previewSize.getWidth(), previewSize.getHeight());
	}

	/**
	 * Get decode information
	 * @return Decode Information
	 */
	public DWDecoder getDwDecoder() {
		// If no decode information is generated
		if (decoder == null) {
			initQRDecoder();
		}
		return this.decoder;
	}

	/**
	 * Load a sound from the resource ID of a specified sound
	 */
	public void loadSoundResourceID(){
		try{
			int soundResourceID = dwqrkit.getSoundResourceID();

			// If the resource ID of the sound is different from the previously loaded resource ID
			if( soundResourceID != loadSoundResourceID ){
				// Get a sound from a sound's resource ID
				this.soundID = soundSource.load(getContext(), soundResourceID, 0);
				loadSoundResourceID = soundResourceID;
			}
		} catch(Exception e){
			// In case of failure, set the default value
			this.soundID = DWQR_LOAD_SOUND_DEFAULT;
		}
	}

	/**
	 * Get the camera settings
	 * @return	Camera Settings
	 */
	public CameraSettings getCameraSettings() {
		return this.cameraSettings;
	}

	/**
	 * Get the results of the installation of the functions of the devices used
	 * @return hardwareChecked　Check results
	 */
	public int[] getHardwareChecked() {
		return hardwareChecked;
	}

	/**
	 * Deleting Indicators
	 */
	public void clearIndicator(){
		// In the background and when a request is being processed and an indicator is being generated
		if (!isBackground && !isSendRequest && indicator != null){
			// Deleting Indicators
			indicator.deleteIndicator();
			indicator = null;
		}
	}

	/**
	 * Start decoding the image data.
	 */
	public void decodeBitmapImage(){
		// When the binary data of the decoded image is available
		if( decodeImageData != null ){
			initQRDecoder();
			dwqrkit.isStopCapture = true;									// Stop the capture
			isBitmapDecord = true;											// Decoding from image data
			beforeScanMode = dwqrkit.getMode();								// Keep the current scan mode setting.
			dwqrkit.setMode(DWQRScanMode.DWQR_SELECTMODE1.ordinal());		// Set to Selection Mode 1
			setQrMode();													// Reflects the scan mode

			DWDecodeResult result = decoder.decodeBitmap( decodeImageData );
			if (result.isSuccess()){// success
				decodeNum = result.getCodeNum();			// Number of QR codes detected
				if( decodeNum > 1 ) {// When there is more than one code detection
					displayCodeOutlineForBitmap( result );
					if(( dwqrkit.isQRFrameEnable == true)) {				// Code outline position display. Set only when setting the outline frame.
						handlerAR.sleep(10, DWQR_HANDLEMESSAGE_DEFAULT);
					}
					dwqrkit.isStopCapture = true;							// When multiple QR codes are detected, the preview display is temporarily stopped
					if( dwqrkit.isQRFrameEnable == true ) {
						handlerAR.sleep(0, DWQR_HANDLEMESSAGE_STOP_ANIMATION);
					}
					// Set the coordinates and color for redrawing the outer frame
					imageSurfaceView.setArParameter(dispPosTopLeft,
							dispPosTopRight,
							dispPosBottomRight,
							dispPosBottomLeft,
							arViewRect.paintColor);
				}else{
					selectDecodeNum = decodeNum;						// QR Code Identification Value to be decoded
					int mode = dwqrkit.getMode();							// Get the current scan mode.
					startDecodeForBitmap( mode, result );					// Start decoding
					decodeImageData = null;								// Delete the image data to be decoded
				}
			}else{
				// If the image is decoded with all decode types disabled, the camera may be opened at certain times. is not called.
				// Problems such as exceptions occur when drawing images.
				// Therefore, a thread sleep process is added to prevent the above problems from occurring.
				try{
					Thread.sleep(50);
				}catch(InterruptedException e){
					e.printStackTrace();
				}
				dwqrkit.isStopCapture = false;								// Start capturing.
				decodeImageData = null;										// Delete the image data to be decoded
				imageSurfaceView.releaseDecodeImage();						// Image released for display
				dwqrkit.setMode(beforeScanMode);							// Set the scan mode.
				DWQRKit.setLog(DWQR_TAG,"Failed to get a canvas");			// log settings
			}
		}else{
			// Scanning of QR using the rear camera
			setCameraInformation(this.format, this.viewWidth, this.viewHeight); // Setting up the camera
		}
		DWQRKit.setLog(DWQR_TAG,"Preview : this.getWidth()=" + this.getWidth() + ", this.getHeight()=" + this.getHeight());		// log settings
	}

	/**
	 * Restarting the camera preview
	 * Called periodically by the ObserverTask, a timer for monitoring DWQRScanView.
	 */
	public void resumeCameraPreview() {
		try{
			if (isBitmapDecord ){	// When the image data is decoded
				selectDecodeNum = 0;												// Initialization of QR Code Values for Decoding
				setCameraInformation(-1, -1, -1);	// Setting up the camera
				dwqrkit.setMode(beforeScanMode);								// Setting up the camera
				isBitmapDecord = false;											// End image recognition.
				imageSurfaceView.clearDecodeImage();								// Clear the image for display
				imageSurfaceView.releaseDecodeImage();							// Release the image for display
			}
			arViewRect.startFadeoutAnimation(dwqrkit.isQRFrameAnimation);	// Deletion of external frame
			requestPreview();													// QR reading process begins.
		}catch(NullPointerException e ){
			DWQRKit.setLog(DWQR_TAG,"ObserverTask NullPointerException");
		}catch(Exception e){
			DWQRKit.setLog(DWQR_TAG,"ObserverTask Exception");
		}
	}


	/**
	 * Receiving a Server Response
	 */
	private final DWQRDecodeServerConnection.ResponseServerCallback responseDecodeServerCallback = new DWQRDecodeServerConnection.ResponseServerCallback() {
		@Override
		public void onProgressUpdate( int progress ) {
		}

		@Override
		public void onPreExecute() {
		}

		@Override
		public void onPostExecute( String decodeData, String codeType, String decodePrivateData, int statusCode, String srvAppData ) {
			// When QR is disabled or SQRC is enabled, public data is not output if the key is not matched.
			if (decoder.checkSQRConly() && codeType.equals(DWDecodeConstants.CODEMARK_QR) && (decodePrivateData.equals("null") || decodePrivateData.equals(""))) {
				isSendRequest = false;	// Request sent
				clearIndicator();			// Deleting Indicators
				return;
			}
			if(!(decodeData.equals("null") || decodeData.equals(""))){
				addHisoryData(decodeData);
			}

			if( qrCodeNoticeListener != null ) {
				if (dwqrkit.isQRFrameEnable == true) {
					if ((dwqrkit.getMode() == DWQRScanMode.DWQR_SELECTMODE2.ordinal())
							|| ((dwqrkit.getMode() == DWQRScanMode.DWQR_SELECTMODE1.ordinal()) && (decodeNum == DWDecodeConstants.DWQR_MAX_CODENUM))) {
						checkCodeOutline(result.getCodeNum());											// Confirmation of the coordinates of the outline frame
						handlerAR.sleep(500, DWQR_HANDLEMESSAGE_MULTIDQRCODE_ECODED);	// Color setting of the outline frame
						decodeNum = 0;																// Initialization of QR Code identification value for decoding
					} else if ((dwqrkit.getMode() != DWQRScanMode.DWQR_POINTSCANMODE.ordinal())
							|| ((dwqrkit.getMode() == DWQRScanMode.DWQR_POINTSCANMODE.ordinal()) && (isCodeMark2d == true))) {
						handlerAR.sleep(500, DWQR_HANDLEMESSAGE_DECODED);                	// Color setting of the outline frame
					}
				}
			}

			isSendRequest = false;		// Request sent
			clearIndicator();				// Delete the indicator

			if(qrCodeNoticeListener != null) {
				if (statusCode == DWQRStatusCode.DWQR_DISABLE.ordinal()) {
					// Sound and vibration processing
					startVibrationSound();

					// In the case of SQRC, if the server connection fails, the code type is set to Q0, so SQRC and FQR can operate in the same way. sort out
					if (saveCodeType.equals(DWDecodeConstants.CODEMARK_SQRC)) {
						qrCodeNoticeListener.onNoticeDecodeResult(saveLocalDecodeData, DWDecodeConstants.CODEMARK_QR, saveBinaryData, saveBinaryLength, decodeData, statusCode, srvAppData);
					} else if (saveCodeType.equals(DWDecodeConstants.CODEMARK_FQR)) {
						// Notify decodePrivateData of the data to be sent
						qrCodeNoticeListener.onNoticeDecodeResult("", codeType, saveBinaryData, saveBinaryLength, decodeData, statusCode, srvAppData);
					}
				} else {
					// Sound and vibration processing
					if (statusCode == DWQRStatusCode.DWQR_SUCCESS.ordinal() ||
						codeType.equals(DWDecodeConstants.CODEMARK_QR)) {
						startVibrationSound();
						if (!codeType.equals(DWDecodeConstants.CODEMARK_SQRC) &&
							!codeType.equals(DWDecodeConstants.CODEMARK_FQR)) {
							dwQrRequestData.saveLogData(codeType);
						}
					}

					// In case of SQRC failure
					if (codeType.equals(DWDecodeConstants.CODEMARK_QR)) {
						qrCodeNoticeListener.onNoticeDecodeResult(saveLocalDecodeData, codeType, saveBinaryData, saveBinaryLength, null, statusCode, srvAppData);
					} else {
						qrCodeNoticeListener.onNoticeDecodeResult(decodeData, codeType, saveBinaryData, saveBinaryLength, decodePrivateData, statusCode, srvAppData);
					}
				}
			}

			// Clearing Saved Decode Information
			saveBinaryData = null;
			saveBinaryLength = 0;
			saveCodeType = null;
			saveLocalDecodeData = null;
		}

		@Override
		public void onCancelled() {
			isSendRequest = false;		// Request sent
			clearIndicator();				// Delete the indicator
		}
	};

	/**
	 * Callbacks to be called for each capture
	 */
	private final ImageReader.OnImageAvailableListener mOnImageAvailableListener
			= new ImageReader.OnImageAvailableListener() {

		@Override
		public void onImageAvailable(ImageReader reader) {
			if (reader == null) {
				return;
			}

			Image captureImage = reader.acquireLatestImage();
			if (captureImage == null) {
				return;
			}

			final byte[] yuvBytes = new byte[(captureImage.getWidth() * captureImage.getHeight()) + (captureImage.getWidth() * captureImage.getHeight()) / 2];
			int offset = 0;
			for (Image.Plane plane : captureImage.getPlanes()) {
				ByteBuffer buffer = plane.getBuffer();
				int rowStride = plane.getRowStride();
				int pixelStride = plane.getPixelStride();
				int width = captureImage.getWidth() / pixelStride;
				int height = captureImage.getHeight() / pixelStride;
				for (int row = 0; row < height; row++) {
					buffer.position(row * (rowStride / pixelStride));
					buffer.get(yuvBytes, offset, width);
					offset += width;
				}
			}

			onPreviewFrame(yuvBytes);

			captureImage.close();
		}
	};

	/**
	 *　Detection of QR Code from captured images
	 * @param data Captured image（YUV_420_888 format）
	 */
	private void onPreviewFrame(byte[] data) {
		initQRDecoder();				// Decode Initial Settings
		int mode = dwqrkit.getMode();	// Get QR reading mode
		setQrMode();					// Set the QR reading mode.

		boolean isStopCapture = dwqrkit.isStopCapture;		// Set to stop capturing
		// If the capture is paused, I'll terminate the process.
		if( isStopCapture == true ){
			stopPreview();
			return;
		}

		// During server decoding of QR
		if( isSendRequest ){
			// Get the preview again
			return;
		}

		displayCross();		// Point-scan mode aiming setting

		result = decoder.decodeData( data, captureImageSize.getWidth(), captureImageSize.getHeight(), mode );
		if( result.isSuccess() == true ) {
			String codeMark = result.getCodeMark();				// Get the code type
			isCodeMark2d = codeMark2DCheck(codeMark);				// Confirmation of 2D barcode

			// Stop the animation except in point-scan mode
			// The timing for stopping the animation in point-scan mode is when it is detected in the crosshair region
			if( mode != DWQRScanMode.DWQR_POINTSCANMODE.ordinal() ){
				arViewRect.stopFadeoutAnimation();				// Stop the animation
				arViewRect.isAnimationExetute = false;		// Update animation running flag (false: not running)
			}

			displayCodeOutline( result );

			// Code outline position display. Set only when setting the outline frame.
			if ((dwqrkit.isQRFrameEnable == true) && (mode != DWQRScanMode.DWQR_POINTSCANMODE.ordinal())) {
				handlerAR.sleep(0, DWQR_HANDLEMESSAGE_DEFAULT);
			}

			if( mode == DWQRScanMode.DWQR_SELECTMODE1.ordinal() ){
				decodeNum = result.getCodeNum();		// Number of QR codes detected
				if( decodeNum > 1 ) {
					selectDecodeNum = checkCodeOutline(decodeNum);

					if (selectDecodeNum == DWQR_INVALID_DECODE) {	// Two QRs are out of preview.
						// Nothing.
					} else if(selectDecodeNum == DWQR_MAX_DECODE) {	// Two QRs in the preview
						// Decode (startDecode) at the time of screen tapping (onTouchEvent). Therefore, we do not jump to the decoding process here
						if( dwqrkit.isQRFrameEnable == true ) {
							displayCodeOutline( result );
							handlerAR.sleep(10, DWQR_HANDLEMESSAGE_DEFAULT);
						}
						dwqrkit.isStopCapture = true;		// When multiple QR codes are detected, the preview display is temporarily stopped
						if( dwqrkit.isQRFrameEnable == true ) {
							handlerAR.sleep(0, DWQR_HANDLEMESSAGE_STOP_ANIMATION);
						}
					} else {	// Detected QR is not outside the preview.
						if (checkCodeOutline(decodeNum) != DWQR_INVALID_DECODE) {
							startDecode(mode, result);
						}
					}
				}else{
					selectDecodeNum = decodeNum;	// QR Code Identification Value to be decoded
					startDecode( mode, result );
				}
			}else if( mode == DWQRScanMode.DWQR_POINTSCANMODE.ordinal() ){
				boolean isCheckFlg = isCheckInFrame();					// Check that the QR code is in the sighting position.
				if( isCheckFlg == true ){
					if( isCodeMark2d == true ){
						if (dwqrkit.isQRFrameEnable) {
							handlerAR.sleep(0, DWQR_HANDLEMESSAGE_DEFAULT);
							arViewRect.stopFadeoutAnimation();            // Stop the animation
							arViewRect.isAnimationExetute = false;	// Update animation running flag (false: not running)
						}
					}
					startDecode( mode, result );
				}
			}else if( mode == DWQRScanMode.DWQR_SELECTMODE2.ordinal() ){
				// Verify that the reading was done within the preview to prevent reading outside the preview.
				// In the selection mode 2, decoding is performed at the time of screen tapping (onTouchEvent). No processing.
				checkCodeOutline(result.getCodeNum());
			}else{
				// Verify that the reading was done within the preview to prevent reading outside the preview.
				if (checkCodeOutline(result.getCodeNum()) != DWQR_INVALID_DECODE) {
					startDecode(mode, result);
				}
			}
		}else{
			// Only when the outline frame is not drawn in Selection Mode 2,
			// To address the issue of the app being forced to terminate,
			// Get and clear the exterior coordinates even when decoding fails
			displayCodeOutline( result );	// Set the outline frame
			if( dwqrkit.isQRFrameEnable == true ) {
				if( mode != DWQRScanMode.DWQR_POINTSCANMODE.ordinal() ) {
					handlerAR.sleep(0, DWQR_HANDLEMESSAGE_DEFAULT);		// Set the color of the outline frame
				}
			}
		}
	}

	/**
	 * Initialization process of camera control
	 */
	private void init() {
		hardwareChecked = hardwareCheck(context);						// Device on-board function check (camera-related)
		holder = getHolder();												// Get a SurfaceView holder
		holder.addCallback(this);											// callback processing

		this.cameraSettings = new CameraSettings();						// Camera Settings

		arViewRect = new DWQRARView( context );							// outline frame
		arViewCross = new DWQRARCrossView( context );					// aim
		Activity activity = ( Activity )this.getContext();					// Get the context
		activity.addContentView( arViewRect, new LayoutParams( LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT ) );	// View Display of outline frame
		activity.addContentView( arViewCross, new LayoutParams( LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT ) );	// View of the Aiming
	}

	/**
	 * Decoder Initial Settings
	 */
	private void initQRDecoder() {
		if( decoder == null ){
			decoder = new DWDecoder();			// Creating Objects in Decoder
			handlerAR = new handlerARView();		// Creating the handlerARView object
			initDisplay();
		}
		// パラメータ設定
		int qrType = getQRCodeType();				// Get QR Code decoding permission setting
		int barcodeType = getBarcodeType();		// Get barcode decoding permission setting
		int upcAddonType = getUPCAddonType();		// Get the UPC add-on decode permission setting
		int combinedQRFlag = getCombinedQR();		// Get QR linkage code decoding permission setting
		int reversalCodeFlag = getReversalCode();	// Get the black-and-white inversion code reading permission setting

		decoder.resetDecodeParameterData();

		decoder.setDecodeQRCodeType( qrType );
		decoder.setDecodeBarcodeType( barcodeType );
		decoder.setDecodeUPCAddonType( upcAddonType );
		decoder.setDecodeCombinedQRFlag( combinedQRFlag );
		decoder.setDecodeReversalCodeFlag( reversalCodeFlag );
	}

	/**
	 * Each coordinate value of the outline frame Default setting
	 */
	private void initDisplay() {
		// Initialize the coordinates of each outline frame
		codeOutlineTopLeft[0] = new Point();
		codeOutlineTopLeft[1] = new Point();
		codeOutlineTopRight[0] = new Point();
		codeOutlineTopRight[1] = new Point();
		codeOutlineBottomRight[0] = new Point();
		codeOutlineBottomRight[1] = new Point();
		codeOutlineBottomLeft[0] = new Point();
		codeOutlineBottomLeft[1] = new Point();
		dispPosTopLeft[0] = new Point();
		dispPosTopLeft[1] = new Point();
		dispPosTopRight[0] = new Point();
		dispPosTopRight[1] = new Point();
		dispPosBottomRight[0] = new Point();
		dispPosBottomRight[1] = new Point();
		dispPosBottomLeft[0] = new Point();
		dispPosBottomLeft[1] = new Point();

		for( int i = 0; i < DWDecodeConstants.DWQR_MAX_CODENUM; i++ ) {
			codeOutlineTopLeft[i] = new Point( 0, 0 );
			codeOutlineTopRight[i] = new Point( 0, 0 );
			codeOutlineBottomRight[i] = new Point( 0, 0 );
			codeOutlineBottomLeft[i] = new Point( 0, 0 );
			dispPosTopLeft[i] = new Point( 0, 0 );
			dispPosTopRight[i] = new Point( 0, 0 );
			dispPosBottomRight[i] = new Point( 0, 0 );
			dispPosBottomLeft[i] = new Point( 0, 0 );
		}
	}

	/**
	 * QR code reading mode setting
	 */
	private void setQrMode() {
		int mode = dwqrkit.getMode();		// Get QR reading mode
		if( ( mode == DWQRScanMode.DWQR_NOMALMODE.ordinal() ) || ( mode == DWQRScanMode.DWQR_POINTSCANMODE.ordinal() ) ) {
			decoder.setDecodeMultipleQRFlag( DWDecodeParameter.DWDecodeMultipleQR.OFF );		// Multi-code batch decoding OFF
			// In point-scanning mode, the sighting position is not correct. Instead of using DWDecodeMultipleQR.ON, you can aim internally at the terminal screen Make sure it is centered.
			decoder.setDecodePointScanFlag( DWDecodeParameter.DWDecodePointScanQR.OFF );		// Point Scan Mode OFF
		} else if ( ( mode == DWQRScanMode.DWQR_SELECTMODE1.ordinal() ) || ( mode == DWQRScanMode.DWQR_SELECTMODE2.ordinal() ) ) {
			decoder.setDecodePointScanFlag( DWDecodeParameter.DWDecodePointScanQR.OFF );		// Point Scan Mode OFF
			decoder.setDecodeMultipleQRFlag( DWDecodeParameter.DWDecodeMultipleQR.ON );			// Multi-code batch decode ON
		} else {
			decoder.setDecodeQRCodeType( DWDecodeParameter.DWDecodeCombinedQR.OFF);				// QR code reading OFF
			decoder.setDecodeMultipleQRFlag( DWDecodeParameter.DWDecodeMultipleQR.OFF );		// Multi-code batch decoding OFF
			decoder.setDecodeCombinedQRFlag( DWDecodeParameter.DWDecodeCombinedQR.OFF );		// QR linkage code decode OFF
			decoder.setDecodeBarcodeType( DWDecodeParameter.DWDecodeBarcodeType.NONE );			// Barcode decode OFF
			decoder.setDecodeUPCAddonType( DWDecodeParameter.DWDecodeUPCAddonType.NONE );		// Barcode decoding with add-ons OFF
			decoder.setDecodeReversalCodeFlag( DWDecodeParameter.DWDecodeReversalCode.OFF);		// Black and white reversal code OFF
		}
	}

	/**
	 * QR Code reading time (for storing historical data)
	 * @return date date Date and time (format "yyyy/MM/dd HH:mm:ss")
	 */
	private String setNowDate() {
		DateFormat dateObject = new SimpleDateFormat( "yyyy/MM/dd HH:mm:ss" );	// Formatting of Date Data
	    Date date = new Date( System.currentTimeMillis() );								// Get the current time in ms
	    return dateObject.format( date );
	}


	/**
	 * Start a thread to do the capture reading & decoding process
	 */
	private void startBackgroundThread() {
		captureBackgroundThread = new HandlerThread("CameraBackground");
		captureBackgroundThread.start();
		captureBackgroundThreadHandler = new Handler(Looper.getMainLooper());
	}

	/**
	 * Stop the thread to do the capture reading and decoding process
	 */
	private void stopBackgroundThread() {
		if (captureBackgroundThread != null) {
			captureBackgroundThread.quitSafely();
			try {
				captureBackgroundThread.join();
				captureBackgroundThread = null;
				captureBackgroundThreadHandler = null;
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Creating a Capture Session
	 */
	private void createCameraPreviewSession() {
		try {
			List<Surface> surfaces = Arrays.asList(holder.getSurface(), captureImageReader.getSurface());
			cameraDevice.createCaptureSession(surfaces, mCaptureSessionStateCallback, null);
		} catch (CameraAccessException e) {
			DWQRKit.setLog(DWQR_TAG,"Failed to create a capture session");
		}
	}

	private final CameraCaptureSession.StateCallback mCaptureSessionStateCallback = new CameraCaptureSession.StateCallback() {
		@Override
		public void onConfigured(@NonNull CameraCaptureSession cameraCaptureSession) {
			// Abort the process if it has already been disconnected from the camera
			if (cameraDevice == null) {
				return;
			}

			try {
				CaptureRequest.Builder previewRequestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
				previewRequestBuilder.addTarget(holder.getSurface());
				previewRequestBuilder.addTarget(captureImageReader.getSurface());

				captureSession = cameraCaptureSession;
				if (hardwareChecked[1] == 0) {
					// Use autofocus
					previewRequestBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
				}
				if (hardwareChecked[2] == 0) {
					if (dwqrkit.isFlashEnable) {
						// Use the flash
						previewRequestBuilder.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_TORCH);
					} else {
						previewRequestBuilder.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
					}
				}

				captureRequest = previewRequestBuilder.build();

				requestPreview();
			} catch (CameraAccessException e) {
				DWQRKit.setLog(DWQR_TAG,"Failed to create a capture session request");
			}
		}

		@Override
		public void onConfigureFailed(
				@NonNull CameraCaptureSession cameraCaptureSession) {
			DWQRKit.setLog(DWQR_TAG,"Failed to configure a capture session\n");
		}
	};

	/**
	 * Connecting to Camera Devices
	 */
	private void openCamera() {
		try {
			if (!cameraOpenCloseLock.tryAcquire(2500, TimeUnit.MILLISECONDS)) {
				DWQRKit.setLog(DWQR_TAG,"Timeout waiting for lock while the camera is connected");
				return;
			}

			startBackgroundThread();

			// Connect to the camera device
			CameraManager manager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
			manager.openCamera(cameraId, mCameraDeviceStateCallback, captureBackgroundThreadHandler);
		} catch (CameraAccessException | SecurityException | NullPointerException | InterruptedException e) {
			DWQRKit.setLog(DWQR_TAG,"Camera connection failed");
		}
	}

	private final CameraDevice.StateCallback mCameraDeviceStateCallback = new CameraDevice.StateCallback() {
		@Override
		public void onOpened(@NonNull CameraDevice cameraDevice) {
			cameraOpenCloseLock.release();
			DWQRCameraSurfaceView.this.cameraDevice = cameraDevice;

			// Generate the leader of the capture
			captureImageReader = ImageReader.newInstance(captureImageSize.getWidth(), captureImageSize.getHeight(), ImageFormat.YUV_420_888, /*maxImages*/2);
			captureImageReader.setOnImageAvailableListener(mOnImageAvailableListener, captureBackgroundThreadHandler);
			createCameraPreviewSession();
		}

		@Override
		public void onDisconnected(@NonNull CameraDevice cameraDevice) {
			cameraOpenCloseLock.release();

			captureImageReader.close();
			captureImageReader = null;

			cameraDevice.close();
			DWQRCameraSurfaceView.this.cameraDevice = null;
		}

		@Override
		public void onError(@NonNull CameraDevice cameraDevice, int error) {
			cameraOpenCloseLock.release();

			captureImageReader.close();
			captureImageReader = null;

			cameraDevice.close();
			DWQRCameraSurfaceView.this.cameraDevice = null;
		}
	};

	/**
	 * Disconnect from the camera device
	 */
	private void closeCamera() {
		try {
			cameraOpenCloseLock.acquire();
			if (null != captureSession) {
				captureSession.close();
				captureSession = null;
			}
			if (null != cameraDevice) {
				cameraDevice.close();
				cameraDevice = null;
			}
			if (null != captureImageReader) {
				captureImageReader.close();
				captureImageReader = null;
			}
			stopBackgroundThread();
		} catch (InterruptedException e) {
			DWQRKit.setLog(DWQR_TAG,"Time out waiting for lock while the camera is off");
		} finally {
			cameraOpenCloseLock.release();
		}
	}

	/**
	 * Configure the camera settings
	 * @return cameraSettings Camera Configuration Information
	 * @param format		format
	 * @param viewWidth		Width
	 * @param viewHeight	Height
	 */
	private void setCameraInformation(int format, int viewWidth, int viewHeight){
		CameraSettings cameraSettings = getCameraSettings();			// Get Camera Settings
		// Updating Camera Settings
		if( format != -1){ // When the formatting is set
			cameraSettings.format = format;								// Set the format
		}
		if( viewWidth != -1) { // When the width is set
			cameraSettings.previewWidth = viewWidth;					// Set the width
		}
		if( viewHeight != -1) { // When the height is set
			cameraSettings.previewHeight = viewHeight;					// Set the height
		}

		// Check which angle the camera sensor is aligned with the device
		cameraSettings.angle = 90;

		CameraManager manager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
		try {
			CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraId);
			int displayRotation = ((Activity)context).getWindowManager().getDefaultDisplay().getRotation();
			Integer sensorOrientation = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
			if (sensorOrientation != null) {
				switch (displayRotation) {
					case Surface.ROTATION_0:
						switch (sensorOrientation) {
							case 0:
								cameraSettings.angle = 0; break;
							case 90:
								cameraSettings.angle = 90; break;
							case 180:
								cameraSettings.angle = 180; break;
							case 270:
								cameraSettings.angle = 270; break;
						}
						break;
					case Surface.ROTATION_180:
						switch (sensorOrientation) {
							case 0:
								cameraSettings.angle = 180; break;
							case 90:
								cameraSettings.angle = 270; break;
							case 180:
								cameraSettings.angle = 0; break;
							case 270:
								cameraSettings.angle = 90; break;
						}
						break;
					case Surface.ROTATION_90:
						switch (sensorOrientation) {
							case 0:
								cameraSettings.angle = 270; break;
							case 90:
								cameraSettings.angle = 0; break;
							case 180:
								cameraSettings.angle = 90; break;
							case 270:
								cameraSettings.angle = 180; break;
						}
						break;
					case Surface.ROTATION_270:
						switch (sensorOrientation) {
							case 0:
								cameraSettings.angle = 90; break;
							case 90:
								cameraSettings.angle = 180; break;
							case 180:
								cameraSettings.angle = 270; break;
							case 270:
								cameraSettings.angle = 0; break;
						}
						break;
				}
			}
		} catch (CameraAccessException e) {
			e.printStackTrace();
		}

		// Connect to the camera
		openCamera();
	}

	/**
	 * Decoding target QR code Decoding process
	 * @param mode　QR reading mode
	 * @param result　decode results
	 */
	private void startDecode(int mode, DWDecodeResult result) {
		// Get decode results
		DWDecodeResult decodeResult = decoder.getDecodeData( selectDecodeNum, result );
		if( decodeResult.isSuccess() == true ) {
			arViewRect.stopFadeoutAnimation();			// Stop the animation
			arViewRect.isAnimationExetute = false;		// Update animation running flag (false: not running)

            if (!decodeResult.getCodeMark().equals(DWDecodeConstants.CODEMARK_FQR) &&
                !decodeResult.getCodeMark().equals(DWDecodeConstants.CODEMARK_SQRC)) {
                // Sound and vibration
				startVibrationSound();
				// Creating Log Data
				dwQrRequestData.saveLogData(decodeResult.getCodeMark());
            }

			// Get the QR code string
            saveLocalDecodeData = decodeResult.getFoundQRCodeString();
			String resultCell = decodeResult.getFoundQRCodeCellString();

			// server decode
			if( decodeResult.isLocalDecode() == false ) {
				DWQRDecodeServerConnection serverConnection = new DWQRDecodeServerConnection( responseDecodeServerCallback );
				isSendRequest = true;			// Sending request in progress
				serverConnection.execute( resultCell );

				// For frame QR, display the indicator
				if(decodeResult.getCodeMark().equals(DWDecodeConstants.CODEMARK_FQR)){
					indicator = new DWQRIndicator();
					indicator.showIndicator(context);
				}
			}else{
				// Add history data
				addHisoryData(saveLocalDecodeData);
			}

			saveCodeType = decodeResult.getCodeMark();
			saveBinaryData = decodeResult.getBinaryData();
			saveBinaryLength = 0;
			if(saveBinaryData != null){		//When binary data is present
				saveBinaryLength = saveBinaryData.length;
			}

			// Notification of decode results
			if(qrCodeNoticeListener != null) {
				if( !saveCodeType.equals(DWDecodeConstants.CODEMARK_FQR) && !saveCodeType.equals(DWDecodeConstants.CODEMARK_SQRC) ){
					qrCodeNoticeListener.onNoticeDecodeResult(saveLocalDecodeData, saveCodeType, saveBinaryData, saveBinaryLength, "", DWQREncodeResult.DWQR_ENCODE_UTF8_SUCCESS.getValue(), "");
				}
			}

            // Code outline position display. Set for external frame display and 2D code
            if (dwqrkit.isQRFrameEnable == true) {
                if (decodeResult.isSuccess() == true) {
                    if ((dwqrkit.getMode() == DWQRScanMode.DWQR_SELECTMODE2.ordinal()) ||
                        ((dwqrkit.getMode() == DWQRScanMode.DWQR_SELECTMODE1.ordinal()) &&
                        (decodeNum == DWDecodeConstants.DWQR_MAX_CODENUM))) {
                        displayCodeOutline(decodeResult);                                			// Set the outline frame
                        checkCodeOutline(result.getCodeNum());                            			// Determine if the acquired outline frame is outside the preview
                        handlerAR.sleep(5, DWQR_HANDLEMESSAGE_MULTIDQRCODE_ECODED);	// Set the color of the outline frame
                        decodeNum = 0;															// Initialization of QR Code identification value for decoding
                    } else if ((dwqrkit.getMode() != DWQRScanMode.DWQR_POINTSCANMODE.ordinal())
                            || ((dwqrkit.getMode() == DWQRScanMode.DWQR_POINTSCANMODE.ordinal()) && (isCodeMark2d == true))) {
                        displayCodeOutline(decodeResult);								// Set the outline frame
                        handlerAR.sleep(500, DWQR_HANDLEMESSAGE_DECODED);	// Set the color of the outline frame
                    }
                }
            }

            // initialization
            if((qrCodeNoticeListener != null &&
				!saveCodeType.equals(DWDecodeConstants.CODEMARK_FQR) &&
				!saveCodeType.equals(DWDecodeConstants.CODEMARK_SQRC))) {
                saveBinaryData = null;
                saveBinaryLength = 0;
                saveLocalDecodeData = "";
                saveCodeType = "";
            }
        }
    }

	/**
	 * QR code for decoding acquired images Decoding process
	 * @param mode　QR reading mode
	 */
	private void startDecodeForBitmap(int mode, DWDecodeResult result) {
		DWDecodeResult bitmapDecodeResult = decoder.decodeBitmap(decodeImageData, selectDecodeNum, result );
		decodeNum = bitmapDecodeResult.getCodeNum();
		if( bitmapDecodeResult.isSuccess() ) {
			arViewRect.stopFadeoutAnimation();
			arViewRect.isAnimationExetute = false;

			// In the case of SQRC and Frame QR, the buzzer and vibrator are activated on server response.
			if (!bitmapDecodeResult.getCodeMark().equals(DWDecodeConstants.CODEMARK_FQR) &&
				!bitmapDecodeResult.getCodeMark().equals(DWDecodeConstants.CODEMARK_SQRC)) {
				// Sound and vibration.
				startVibrationSound();
				// Creating Log Data
				dwQrRequestData.saveLogData(result.getCodeMark());
			}

			// On success, get a string of QR code
            saveLocalDecodeData = bitmapDecodeResult.getFoundQRCodeString();
			String resultCell = bitmapDecodeResult.getFoundQRCodeCellString();

			// server decode
			if( bitmapDecodeResult.isLocalDecode() == false ) {
				DWQRDecodeServerConnection serverConnection = new DWQRDecodeServerConnection( responseDecodeServerCallback );
				isSendRequest = true;			// Sending request in progress

				serverConnection.execute( resultCell );

				// For frame QR, display the indicator
				if( bitmapDecodeResult.getCodeMark().equals(DWDecodeConstants.CODEMARK_FQR) ){
					indicator = new DWQRIndicator();
					indicator.show(((FragmentActivity)context).getSupportFragmentManager(), "dwqrIndicator");
				}
			}else{
				// Add history data
				addHisoryData(saveLocalDecodeData);
			}
			saveCodeType = bitmapDecodeResult.getCodeMark();
			saveBinaryData = bitmapDecodeResult.getBinaryData();
			saveBinaryLength = 0;
			if(saveBinaryData != null){//When binary data is present
				saveBinaryLength = saveBinaryData.length;
			}
			// Notification of decode results
			if(qrCodeNoticeListener!=null) {
				if( !saveCodeType.equals(DWDecodeConstants.CODEMARK_FQR) && !saveCodeType.equals(DWDecodeConstants.CODEMARK_SQRC) ) {
					qrCodeNoticeListener.onNoticeDecodeResult(saveLocalDecodeData, saveCodeType, saveBinaryData, saveBinaryLength, "", DWQREncodeResult.DWQR_ENCODE_UTF8_SUCCESS.getValue(), "");
				}
			}

			// Code outline position display. Set for outline frame display and 2D code
				if (dwqrkit.isQRFrameEnable == true) {
					if (bitmapDecodeResult.isSuccess() == true) {
						if ((dwqrkit.getMode() == DWQRScanMode.DWQR_SELECTMODE2.ordinal())
							|| ((dwqrkit.getMode() == DWQRScanMode.DWQR_SELECTMODE1.ordinal()) && (decodeNum == DWDecodeConstants.DWQR_MAX_CODENUM))) {
							displayCodeOutlineForBitmap(bitmapDecodeResult);							// Set the outline frame
							handlerAR.sleep(5, DWQR_HANDLEMESSAGE_MULTIDQRCODE_ECODED);	// Set the color of the outline frame
							decodeNum = 0;															// Initialization of QR Code identification value for decoding
						} else if ((dwqrkit.getMode() != DWQRScanMode.DWQR_POINTSCANMODE.ordinal())
								|| ((dwqrkit.getMode() == DWQRScanMode.DWQR_POINTSCANMODE.ordinal()) && (isCodeMark2d == true))) {
							displayCodeOutlineForBitmap(bitmapDecodeResult);				// Set the outline frame
							handlerAR.sleep(500, DWQR_HANDLEMESSAGE_DECODED);	// Set the color of the outline frame
						}
					}
				}


			// initialization
			if((qrCodeNoticeListener != null &&
				!saveCodeType.equals(DWDecodeConstants.CODEMARK_FQR) &&
				!saveCodeType.equals(DWDecodeConstants.CODEMARK_SQRC))) {
				saveBinaryData = null;
				saveBinaryLength = 0;
				saveLocalDecodeData = "";
				saveCodeType = "";
			}
		}
	}

	/**
	 * Setting up permission for QR code decoding
	 * @return qrCodeType　Set decoding permissions
	 */
	private int getQRCodeType() {
		int qrCodeType = 0;	// Set decoding permissions
		int qrCode = 0;		// Set the QR code decoding
		int microQrCode = 0;	// Set the micro QR code decoding
		int sqecCode = 0;		// Set the SQRC decode.
		int frameQrCode = 0;	// Set the Frame QR decode

		qrCodeType = qrCode | microQrCode | sqecCode| frameQrCode;
		return qrCodeType;
	}

	/**
	 * Set permission for barcode decoding
	 * @return barcodeType　Set decoding permissions
	 */
	private int getBarcodeType() {
		int barcodeType = 0;	// Set decoding permissions
		int upca = 0;			// Set the UPC-A and EAN-13 decode
		int upce = 0;			// Set the UPC-E decode
		int ean8 = 0;			// Set the EAN-8 decode

		barcodeType = upca | upce | ean8;
		return barcodeType;
	}

	/**
	 * Set the decode permission for UPC add-ons
	 * @return upcAddonType　Set decoding permissions
	 */
	private int getUPCAddonType() {
		int upcAddonType = 0;	// Set decoding permissions
		int addon2 = 0;		// Set the add-on 2-digit decode
		int addon5 = 0;		// Set the add-on 5-digit decode
		int addonOnly = 0;		// Set the only for codes with add-ons the decode

		upcAddonType = addon2 | addon5 | addonOnly;
		return upcAddonType;
	}

	/**
	 * Set the QR linkage code decoding permission
	 * @return combinedQR　Set decoding permissions
	 */
	private int getCombinedQR() {
		int combinedQR = 0;		// Set decoding permissions
		if( dwqrkit.isParamConnectionQRBatchEnable == true ) {
			combinedQR = DWDecodeParameter.DWDecodeCombinedQR.ON;
		}
		return combinedQR;
	}

	/**
	 * Set the black-and-white reversal code reading
	 * @return
	 */
	private int getReversalCode() {
		int reversalCode = 0;	// Set the black-and-white inversion code
		if (dwqrkit.isParamReversalCodeEnable) {
			reversalCode = DWDecodeParameter.DWDecodeReversalCode.ON;
		}
		return reversalCode;
	}

	/**
	 * Check if the tap position is within the outline frame of the QR Code.
	 * @return select　Check results
	 */
	private boolean isCheckInFrame() {
		float[] qrFrameX = new float[DWQR_DECODE_OUTLINE_NUMBER];	// Outline Frame X coordinate
        float[] qrFrameY = new float[DWQR_DECODE_OUTLINE_NUMBER];	// Outline Frame Y Coordinate
        float lineSide;													// Extrapolation (relationship between touch coordinates and line segment position)
        int qrCodeNum;														// QR code identification value
        boolean isLineSideLeft;											// A flag indicating that the tap coordinates are outside the outline frame
        boolean isSelect = false;											// Check result (true: inside the outline frame, false: outside the outline frame)
        selectDecodeNum = 0;												// Identification value of the QR Code to be decoded

	    // Determine if the tapped coordinates are within the outline frame.
	    for( int qrNumber = 0; qrNumber < DWDecodeConstants.DWQR_MAX_CODENUM; qrNumber++){
	        // Initializing Flags
	        isLineSideLeft = false;
            // Put the coordinates of each vertex of the outline frame into the array in x-coordinate and y-coordinate
	        qrFrameX[DWQR_TOPLEFT] = (float)dispPosTopLeft[qrNumber].x;
            qrFrameY[DWQR_TOPLEFT] = (float)dispPosTopLeft[qrNumber].y;
            qrFrameX[DWQR_TOPRIGHT] = (float)dispPosTopRight[qrNumber].x;
            qrFrameY[DWQR_TOPRIGHT] = (float)dispPosTopRight[qrNumber].y;
            qrFrameX[DWQR_BOTTOMRIGHT] = (float)dispPosBottomRight[qrNumber].x;
            qrFrameY[DWQR_BOTTOMRIGHT] = (float)dispPosBottomRight[qrNumber].y;
            qrFrameX[DWQR_BOTTOMLEFT] = (float)dispPosBottomLeft[qrNumber].x;
            qrFrameY[DWQR_BOTTOMLEFT] = (float)dispPosBottomLeft[qrNumber].y;

            // If qrFrameX and qrFrameY are all zero, the decoding target is excluded.
            int checkFrameX = 0;
            int checkFrameY = 0;
            for(int checkCnt = 0; checkCnt < DWQR_DECODE_OUTLINE_NUMBER; checkCnt++) {
            	if(qrFrameX[checkCnt] == 0 ) {
            		checkFrameX++;
            	}
            	if(qrFrameY[checkCnt] == 0 ) {
            		checkFrameY++;
            	}
            }
            if( checkFrameX == DWQR_DECODE_OUTLINE_NUMBER ){
            	isLineSideLeft = true;		// Not for decoding
            }
            if( checkFrameY == DWQR_DECODE_OUTLINE_NUMBER ){
            	isLineSideLeft = true;		// Not for decoding
            }

            if( isLineSideLeft == false ) {
	            // For QR Code identification (to identify which QR Code is being used when multiple QR Codes are detected)
	            qrCodeNum = qrNumber + 1;

	            // Think of the lines of the frame as four directed line segments drawn clockwise, and
	            // Find the outliers of the directed line segments where the tap coordinates are on each of the four sides
	            for( int line = 0; line < DWQR_DECODE_OUTLINE_NUMBER; line++ ){
	                // Changing the formatting of the last line to be in the first corner position when loading the last line
	                if( line == DWQR_DECODE_OUTLINE_NUMBER - 1 ){
	                    lineSide = selectQrCode.x * (qrFrameY[line] - qrFrameY[0])
	                                + qrFrameX[line] * (qrFrameY[0] - selectQrCode.y)
	                                + qrFrameX[0] * (selectQrCode.y - qrFrameY[line]);
	                }else{
	                    lineSide = selectQrCode.x * (qrFrameY[line] - qrFrameY[line+1])
	                                + qrFrameX[line] * (qrFrameY[line+1] - selectQrCode.y)
	                                + qrFrameX[line+1] * (selectQrCode.y - qrFrameY[line]);
	                }

	                // If the result of the outer product is less than 0, it identifies the tap position as the left side of the directed line segment (outside the outer frame).
	                if( lineSide < 0 ){
	                    isLineSideLeft = true;
	                    break;
	                }
	            }

	            if( isLineSideLeft == false ){
	                selectDecodeNum = qrCodeNum;			// Identification value setting for decoding target QR Code to be used for decoding
	                isSelect = true;
	                break;
	            } else {
	            	isSelect = false;						// No decoding (judging that you tapped outside the outline frame)
	            }
            } else {
            	isSelect = false;							// No decoding (judging that you tapped outside the outline frame)
            }
	    }
		return isSelect;
	}

	/**
	 * Check that the position of the acquired outline frame is within the display size.
	 * @return QR to be decoded
	 */
	private int checkCodeOutline(int decodeNum) {
		int recodeNum = DWQR_INVALID_DECODE;
		for( int i = 0; i < decodeNum; i++ ) {
			// When the coordinates of the outline frame are being acquired outside the display
			if (dispPosTopLeft[i].x > displayWidth || dispPosTopLeft[i].y > displayHeight ||
					dispPosTopRight[i].x > displayWidth || dispPosTopRight[i].y > displayHeight ||
					dispPosBottomRight[i].x > displayWidth || dispPosBottomRight[i].y > displayHeight ||
					dispPosBottomLeft[i].x > displayWidth || dispPosBottomLeft[i].y > displayHeight ) {
				// I'm going to mark it as unclaimed.
				dispPosTopLeft[i].x = 0;
				dispPosTopLeft[i].y = 0;
				dispPosTopRight[i].x = 0;
				dispPosTopRight[i].y = 0;
				dispPosBottomRight[i].x = 0;
				dispPosBottomRight[i].y = 0;
				dispPosBottomLeft[i].x = 0;
				dispPosBottomLeft[i].y = 0;
			} else {
				recodeNum += i + 1;
			}
		}
		return recodeNum;
	}

	/**
	 * Indication of the code outline
	 * @param result	decode results
	 */
	private void displayCodeOutline( DWDecodeResult result ) {
		// Get the position of the code outline
		for( int i = 0; i < DWDecodeConstants.DWQR_MAX_CODENUM; i++ ) {
			codeOutlineTopLeft[i] = result.getCodeOutline( 0, i );
			codeOutlineTopRight[i] = result.getCodeOutline( 1, i );
			codeOutlineBottomRight[i] = result.getCodeOutline( 2, i );
			codeOutlineBottomLeft[i] = result.getCodeOutline( 3, i );
		}

		// Display the code outline frame
		if( arViewRect != null ) {
			// Conversion to display size coordinates
			float factW = ( float )( displayWidth ) / captureImageSize.getHeight();
			float factH = ( float )( displayHeight ) / captureImageSize.getWidth();

			if (cameraSettings.angle == 270) {
				// Some Nexus devices have angle == 270
				for( int i = 0; i < DWDecodeConstants.DWQR_MAX_CODENUM; i++ ) {
					// When the position of the outline frame is not get
					if (codeOutlineTopLeft[i].x == 0 && codeOutlineTopLeft[i].y == 0 &&
						codeOutlineTopRight[i].x == 0 && codeOutlineTopRight[i].y == 0 &&
						codeOutlineBottomRight[i].x == 0 && codeOutlineBottomRight[i].y == 0 &&
						codeOutlineBottomLeft[i].x == 0 && codeOutlineBottomLeft[i].y == 0 ) {
						dispPosTopLeft[i].x = 0;
						dispPosTopLeft[i].y = 0;
						dispPosTopRight[i].x = 0;
						dispPosTopRight[i].y = 0;
						dispPosBottomRight[i].x = 0;
						dispPosBottomRight[i].y = 0;
						dispPosBottomLeft[i].x = 0;
						dispPosBottomLeft[i].y = 0;
					} else {
						dispPosTopLeft[i].x = ( int ) ((captureImageSize.getHeight() - codeOutlineTopLeft[i].x) * factW);
						dispPosTopLeft[i].y = ( int ) ((captureImageSize.getWidth() - codeOutlineTopLeft[i].y) * factH);
						dispPosTopRight[i].x = ( int ) ((captureImageSize.getHeight() - codeOutlineTopRight[i].x) * factW );
						dispPosTopRight[i].y = ( int ) ((captureImageSize.getWidth() - codeOutlineTopRight[i].y) * factH );
						dispPosBottomRight[i].x = ( int ) ((captureImageSize.getHeight() - codeOutlineBottomRight[i].x) * factW );
						dispPosBottomRight[i].y = ( int ) ((captureImageSize.getWidth() - codeOutlineBottomRight[i].y) * factH );
						dispPosBottomLeft[i].x = ( int ) ((captureImageSize.getHeight() - codeOutlineBottomLeft[i].x) * factW );
						dispPosBottomLeft[i].y = ( int ) ((captureImageSize.getWidth() - codeOutlineBottomLeft[i].y) * factH );
					}
				}
			} else {
				// Most Android devices have an angle == 90
				for( int i = 0; i < DWDecodeConstants.DWQR_MAX_CODENUM; i++ ) {
					dispPosTopLeft[i].x = ( int ) ( codeOutlineTopLeft[i].x * factW );
					dispPosTopLeft[i].y = ( int ) ( codeOutlineTopLeft[i].y * factH );
					dispPosTopRight[i].x = ( int ) ( codeOutlineTopRight[i].x * factW );
					dispPosTopRight[i].y = ( int ) ( codeOutlineTopRight[i].y * factH );
					dispPosBottomRight[i].x = ( int ) ( codeOutlineBottomRight[i].x * factW );
					dispPosBottomRight[i].y = ( int ) ( codeOutlineBottomRight[i].y * factH );
					dispPosBottomLeft[i].x = ( int ) ( codeOutlineBottomLeft[i].x * factW );
					dispPosBottomLeft[i].y = ( int ) ( codeOutlineBottomLeft[i].y * factH );
				}
			}
		}
	}

	/**
	 * Display of the code outline for images loaded from the gallery
	 * @param result	decode results
	 */
	private void displayCodeOutlineForBitmap( DWDecodeResult result ) {
		// Get the position of the code outline
		for( int i = 0; i < DWDecodeConstants.DWQR_MAX_CODENUM; i++ ) {
			codeOutlineTopLeft[i] = result.getCodeOutline( 0, i );
			codeOutlineTopRight[i] = result.getCodeOutline( 1, i );
			codeOutlineBottomRight[i] = result.getCodeOutline( 2, i );
			codeOutlineBottomLeft[i] = result.getCodeOutline( 3, i );
		}
		// code outline frame indication
		if( arViewRect != null ) {
			// Conversion to display size coordinates
			Point imageSize = imageSurfaceView.getColorImageSize();
			float factWidth = (float)DWQR_DECODE_BITMAP_WIDTH / (float)imageSize.x;
			float factHeight = (float)DWQR_DECODE_BITMAP_HEIGHT / (float)imageSize.y;
			// Since the size of the image to be displayed will always be a horizontal image, the aspect ratio calculation has been removed and
			// Add the process of getting the height of the image placement coordinates
			float addHeight = ((this.displayHeight / 2) - (float)(imageSize.y / 2));

			for( int i = 0; i < DWDecodeConstants.DWQR_MAX_CODENUM; i++ ) {
				// Because the position of the image is now at the center of the image, the y-coordinate of the outline frame is adjusted.
				dispPosTopLeft[i].x = (int)(codeOutlineTopLeft[i].y / factWidth);
				dispPosTopLeft[i].y = (int)(((DWQR_DECODE_BITMAP_HEIGHT - codeOutlineTopLeft[i].x) / factHeight) + addHeight);
				dispPosTopRight[i].x = (int)(codeOutlineTopRight[i].y / factWidth);
				dispPosTopRight[i].y = (int)(((DWQR_DECODE_BITMAP_HEIGHT - codeOutlineTopRight[i].x) / factHeight) + addHeight);
				dispPosBottomRight[i].x = (int)(codeOutlineBottomRight[i].y / factWidth);
				dispPosBottomRight[i].y = (int)(((DWQR_DECODE_BITMAP_HEIGHT - codeOutlineBottomRight[i].x) / factHeight) + addHeight);
				dispPosBottomLeft[i].x = (int)(codeOutlineBottomLeft[i].y / factWidth);
				dispPosBottomLeft[i].y = (int)(((DWQR_DECODE_BITMAP_HEIGHT - codeOutlineBottomLeft[i].x) / factHeight) + addHeight);
			}
		}
	}

	/**
	 * Draw a crosshair in point-scan mode
	 */
	private void displayCross(){
		int mode = dwqrkit.getMode();				// Get QR reading mode
		Point posT = new Point( 0, 0 );		// up
		Point posB = new Point( 0, 0 );		// bottom
		Point posL = new Point( 0, 0 );		// left
		Point posR = new Point( 0, 0 );		// right
		// Aiming display only for point scanning
		if( mode == DWQRScanMode.DWQR_POINTSCANMODE.ordinal() ) {
			// Calculating the Center Coordinates
			float factAimLineW = ( float )( displayWidth ) / DWQR_HALF;	// x-coordinate: half the width of the terminal screen
			float factAimLineH = ( float )( displayHeight ) / DWQR_HALF;	// y-coordinate: half the height of the terminal screen
			int aimLineW = Math.round(factAimLineW);							// Rounded x-coordinates, rounded to the nearest whole number
			int aimLineH = Math.round(factAimLineH);							// Rounded y-coordinate, rounded to the nearest whole number
			int wAimLine = ( int )( aimLineW * DWQR_LINE );					// Calculating the length of the sighting line (20% of the length from the edge of the width to the center)

			// Set the center coordinates. Decoding is performed when the QR Code touches these coordinates.
			selectQrCode.x = aimLineW;
			selectQrCode.y = aimLineH;

			// Set the coordinates for sight drawing
			posT = new Point( aimLineW - wAimLine, aimLineH);			// up
			posB = new Point( aimLineW + wAimLine, aimLineH);			// bottom
			posL = new Point( aimLineW, aimLineH - wAimLine);			// left
			posR = new Point( aimLineW, aimLineH + wAimLine);			// right
		}
		arViewCross.drawScreen(posT, posB, posL, posR);
	}

	/**
	 * Checking whether the code type is 2D code
	 * @param codeMark
	 * @return isResult　Code type confirmation result (true: 2-dimensional code, false: not 2-dimensional code)
	 */
	private boolean codeMark2DCheck(String codeMark){
		boolean isResult = false;		// Confirmation Results
		isResult = Arrays.asList(DWDecodeConstants.DWQR_CODEMARK_QR).contains(codeMark);			// true: two-dimensional code, false: not two-dimensional code
		return isResult;
	}

	/**
	 * Releasing a previously created object
	 */
	public void releaseObject() {
		if (toneGenerator != null) {
			toneGenerator.stopTone();
			toneGenerator.release();
			toneGenerator = null;
		}
	}

	/**
	 * Get the best (near-minimum) image size for decoding
	 * @param supported	Supported Image Sizes
	 * @param minWidth		Minimum Image Size(W)
	 * @param minHeight	Minimum Image Size(H)
	 * @param maxWidth		Minimum Image Size(W)
	 * @param maxHeight	Minimum Image Size(H)
	 * @return	Optimal Image Size
	 */
	private Size choosePreviewSize(List<Size> supported, int minWidth, int minHeight, int maxWidth, int maxHeight) {
		float displayAspect = (float)displayHeight / (float)displayWidth;
		float minAspectDifference = Float.MAX_VALUE;
		Size selectedSize = null;
		for ( Size size : supported ) {
			if ( ( minWidth <= size.getWidth() ) && ( minHeight <= size.getHeight() ) && ( size.getWidth() <= maxWidth )
					&& ( size.getHeight() <= maxHeight ) ) {
				float previewAspect = (float)size.getWidth() / (float)size.getHeight();
				float aspectDifference = Math.abs(displayAspect - previewAspect);
				if (aspectDifference < minAspectDifference) {
					minAspectDifference = aspectDifference;
					selectedSize = size;
				}
			}
		}
		return selectedSize;
	}

	private CameraCaptureSession.CaptureCallback mCaptureCallback = new CameraCaptureSession.CaptureCallback() {
		@Override
		public void onCaptureProgressed(@NonNull CameraCaptureSession session, @NonNull CaptureRequest request, @NonNull CaptureResult partialResult) {
			super.onCaptureProgressed(session, request, partialResult);
		}

		@Override
		public void onCaptureCompleted(@NonNull CameraCaptureSession session, @NonNull CaptureRequest request, @NonNull TotalCaptureResult result) {
			super.onCaptureCompleted(session, request, result);
		}
	};

	/**
	 * preview process
	 */
	private void requestPreview() {
		if (captureSession != null && captureRequest != null) {
			try {
				captureSession.setRepeatingRequest(captureRequest,
						mCaptureCallback, captureBackgroundThreadHandler);
				dwqrkit.isStopCapture = false;
			} catch (CameraAccessException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Stop previewing
	 */
	private void stopPreview() {
		if (captureSession != null && captureRequest != null) {
			try {
				captureSession.stopRepeating();
			} catch (CameraAccessException e) {
				e.printStackTrace();
			}
		}
	}


	/**
	 * Confirmation of functional installation of the device used
	 * @param context context
	 * @return statusCode[] Confirmation Results
	 */
	private int[] hardwareCheck( Context context ) {
		int hardwareStatusCode[] = {
				DWQRStatusCode.DWQR_NO_FEATURECAMERA.ordinal(),
				DWQRStatusCode.DWQR_NO_FEATURECAMERA_AUTOFOCUS.ordinal(),
				DWQRStatusCode.DWQR_NO_FEATURECAMERA_FLASH.ordinal(),
				DWQRStatusCode.DWQR_NO_FEATURELOCATION.ordinal(),
				DWQRStatusCode.DWQR_NO_FEATURELOCATION_GPS.ordinal(),
				DWQRStatusCode.DWQR_NO_FEATURELOCATION_NETWORK.ordinal()
		};
		PackageManager packageManager = context.getPackageManager();

		// Set the readout sound
		toneGenerator = new ToneGenerator( AudioManager.STREAM_NOTIFICATION, ToneGenerator.MAX_VOLUME );

		// Set the vibrator
		vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);

		CameraManager cameraManager = (CameraManager)context.getSystemService(Service.CAMERA_SERVICE);
		try {
			for (String id : cameraManager.getCameraIdList()) {
				CameraCharacteristics characteristics = cameraManager.getCameraCharacteristics(id);
				Integer facing = characteristics.get(CameraCharacteristics.LENS_FACING);
				if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
					// Rear View Camera
					cameraId = id;
					hardwareStatusCode[0] = 0;

					// auto focus
					int[] afModeList = characteristics.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES);
					for (int afMode : afModeList) {
						if (afMode == CameraCharacteristics.CONTROL_AF_MODE_CONTINUOUS_PICTURE) {
							hardwareStatusCode[1] = 0;
							break;
						}
					}

					// flush
					Boolean flashAvailable = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
					if (flashAvailable != null && flashAvailable) {
						hardwareStatusCode[2] = 0;
					}
					break;
				}
			}
		} catch (CameraAccessException e) {
			// No rear camera
		}

		// Function to obtain location information
		if( packageManager.hasSystemFeature( PackageManager.FEATURE_LOCATION ) ) {
			hardwareStatusCode[3] = 0;
		}
		// Get GPS location information
		if( packageManager.hasSystemFeature( PackageManager.FEATURE_LOCATION_GPS ) ) {
			hardwareStatusCode[4] = 0;
		}
		// Get network location information
		if( packageManager.hasSystemFeature( PackageManager.FEATURE_LOCATION_NETWORK ) ) {
			hardwareStatusCode[5] = 0;
		}

		return hardwareStatusCode;
	}

	/**
	 * Add history data
	 * @param resultCode　Additional data
	 */
	private void addHisoryData(String resultCode) {
		ArrayList<DWQRHistory> historyList = dwqrkit.getHistoryData(context);	// Get History data
		long freeByteSize = DWQRCommon.getExternalStorage();					// Get free space in the storage area
		int historyNum = historyList.size();									// Number of history data
		int addDataSize = resultCode.getBytes().length;							// Get the data size of the additional data.
		boolean addDataFlg = true;												// Data addition flag

		// In case of insufficient free space (less free space than additional data, or the number of historical data saved In the case of MAX
		// Deleting the oldest data
		if( ( freeByteSize < addDataSize ) || ( historyNum == DWQR_HISTORYDATA_NUM_MAX )) {
			addDataFlg = oldestDataDelete();
		}

		if(addDataFlg == true) {
			boolean isSearchResult = false;						// History data search results
			String nowDate = setNowDate();						// QRコード読取時刻
			SharedPreferences sharedPreferences = context.getSharedPreferences(DWQRKit.DWQR_HISTORY_NAME, Context.MODE_PRIVATE);	// History data saved in the terminal
			Editor editor = sharedPreferences.edit();			// History data saved in the terminal for editing
			DWQRHistory history = null;							// History data for comparison
			historyList = dwqrkit.getHistoryData(context);		// Get History data

			// Search all history data
			for(int i=0; i < historyList.size(); i++ ){
				history = historyList.get(i);
				if( history.history.equals(resultCode) ){		// Compare additional data with stored history data
					isSearchResult = true;
					break;
				}
			}

			if( !isSearchResult ){
				// No data in history data = Add and save if new
				editor.putString(resultCode, nowDate).commit();
			}else{
				// Data in historical data = delete existing data and then register a new one if you want to update
				editor.remove(history.history);
				editor.putString(resultCode, nowDate);
				editor.commit();
			}
		}
	}

	/**
	 * Delete oldest historical data
	 * @return addDataFlg　add history flag
	 */
	private boolean oldestDataDelete() {
		ArrayList<DWQRHistory> historyList = dwqrkit.getHistoryData(context);	// Get history data
		ArrayList<String> historyDates = new ArrayList<String>();					// Date of history data
		boolean addDataFlg = true;												// Data addition flag
		int size = historyList.size();											// Number of history data

		if( size > 0) {
			for (int i = 0; i < size; i++){
				historyDates.add(historyList.get(i).date);
			}
			Collections.sort( historyDates );									// Sort the extracted data in ascending order
			String oldDate = historyDates.get(0);								// oldest data extraction
			dwqrkit.deleteHistoryData(getContext(), oldDate);					// delete
		} else {
			addDataFlg = false;		// When the number of history data is zero, the history data is not done. (For not doing)
		}
		return addDataFlg;
	}

    /**
     * Operation for QR/barcode scanning
     */
	private void startVibrationSound() {
        // Playing Sound
        if (true == dwqrkit.isAudioEnable) {
            // When the sound ID is not the default value
            if (this.soundID != DWQR_LOAD_SOUND_DEFAULT) {
                // Set left and right playback sound to 1.0F (maximum), play one time, and playback rate to 1.0F (normal).
                soundSource.play(this.soundID, 1.0F, 1.0F, 0, 0, 1.0F);
            } else {
                // Playing Tones
                toneGenerator.startTone(ToneGenerator.TONE_PROP_ACK, DWQR_AUDIO_TIMER);
            }
        }
        // Activate the vibrations
        if (true == dwqrkit.isVibrationEnable) {
			vibrator.vibrate(VibrationEffect.createOneShot(DWQR_VIBRATION_TIMER, VibrationEffect.DEFAULT_AMPLITUDE));
        }
    }

	/**
	 * Handler for setting the outline frame and display color
	 */
	public class handlerARView extends Handler{
		@Override
		public void handleMessage(Message msg) {
			int[] paintColor = {0x00000000,0x00000000};
			// Change the color of the outer frame depending on the msg value
			if( msg.what == DWQR_HANDLEMESSAGE_DEFAULT ){
				paintColor[0] = dwqrkit.getQrFrameColor();
				paintColor[1] = dwqrkit.getQrFrameColor();
			}else if( msg.what == DWQR_HANDLEMESSAGE_MULTIDQRCODE_ECODED ){
				if( selectDecodeNum == 2 ){
					paintColor[0] = dwqrkit.getQrFrameColor();
					paintColor[1] = dwqrkit.getQrFrameDecodedColor();
				}else{
					paintColor[0] = dwqrkit.getQrFrameDecodedColor();
					paintColor[1] = dwqrkit.getQrFrameColor();
				}
			}else if( msg.what == DWQR_HANDLEMESSAGE_DECODED ){
				paintColor[0] = dwqrkit.getQrFrameDecodedColor();
				paintColor[1] = dwqrkit.getQrFrameDecodedColor();
			}else if( msg.what == DWQR_HANDLEMESSAGE_STOP_ANIMATION ){
				paintColor[0] = dwqrkit.getQrFrameColor();
				paintColor[1] = dwqrkit.getQrFrameColor();
				arViewRect.isAnimationExetute = false;		// De-animation
				arViewRect.stopFadeoutAnimation();			// Stop the animation
			}
			arViewRect.setPaintColor( paintColor );

	    	// Does not redraw during animation.
			if( arViewRect.isAnimationExetute == false ){
				arViewRect.drawScreen(dispPosTopLeft, dispPosTopRight, dispPosBottomRight, dispPosBottomLeft);
				arViewRect.invalidate();
			}
		}

		/**
		 * Sleep processing for displaying the outline frame
		 * After a specified time, the outline frame is displayed
		 * @param delay　Sleep time
		 * @param what　The value of handleMessage
		 */
		public void sleep(long delay, int what){
			sendMessageDelayed(obtainMessage(what), delay); //Sleep for time delay value and issue a Message.
		}
	}
}
