package com.densowave.dwqrkit.decodeParameter;

/**
 * Constants output from the decoder
 */
public class DWDecodeConstants {
	
	public static final String SQRC_KEY = "";	// SQRC decode key
	
	public static final int DWQR_MAX_CODENUM = 2;	// decode key
	
	public static final int ERROR = 1;				// error
	public static final int SUCCESS = 0;			// success

	// decode type
	public static final String CODEMARK_QR = "Q0";
	public static final String CODEMARK_QR_GS1 = "Q1";
	public static final String CODEMARK_QR_COMBINE_EDIT_ALL = "Q0";
	public static final String CODEMARK_QR_COMBINE_EDIT_ALL_GS1 = "Q1";
	public static final String CODEMARK_QR_COMBINE_EDIT_NONE = "S0";
	public static final String CODEMARK_QR_COMBINE_EDIT_NONE_GS1 = "S1";
	public static final String CODEMARK_MICRO_QR = "Q2";
	public static final String CODEMARK_SQRC = "Q3";
	public static final String CODEMARK_SQRC_GS1 = "Q4";
	public static final String CODEMARK_FQR = "Q5";
	public static final String CODEMARK_UPC_A_NO_ADDON = "A0";
	public static final String CODEMARK_UPC_A_ADDON2 = "A1";
	public static final String CODEMARK_UPC_A_ADDON5 = "A2";
	public static final String CODEMARK_UPC_E_NO_ADDON = "C0";
	public static final String CODEMARK_UPC_E_ADDON2 = "C1";
	public static final String CODEMARK_UPC_E_ADDON5 = "C2";
	public static final String CODEMARK_EAN_13_NO_ADDON = "A0";
	public static final String CODEMARK_EAN_13_ADDON2 = "A1";
	public static final String CODEMARK_EAN_13_ADDON5 = "A2";
	public static final String CODEMARK_EAN_8_NO_ADDON = "B0";
	public static final String CODEMARK_EAN_8_ADDON2 = "B1";
	public static final String CODEMARK_EAN_8_ADDON5 = "B2";

	public static final String DECODE_MODE_RESULT_AUTH = "A";
	public static final String DECODE_MODE_RESULT_NORMAL = "F";
	public static final String DECODE_MODE_RESULT_SQRC = "S";
	public static final String DECODE_MODE_RESULT_SQRC_GS1 = "G";

	public static final int DCD_SUCCESS = 0;
	public static final int DCD_FAILURE = 1;
	public static final int DCD_NOTEXIST = 0;
	public static final int DCD_EXIST = 1;

	// Status code for the results of the expiration determination
	public static final int DCD_NOT_EXPIRED = 0x0000;		// It's not overdue
	public static final int DCD_EXPIRED = 0x0001;			// expiration date
	public static final int DCD_WARNING_EXPIRED = 0x0002;	// Expired warning

	public static final int DEC_BUFFNUM0 = 0;
	public static final int DEC_BUFFNUM1 = 1;

	// 2D code type
	public static final String[] DWQR_CODEMARK_QR =	{
		CODEMARK_QR,
		CODEMARK_QR_GS1,
		CODEMARK_MICRO_QR,
		CODEMARK_SQRC,
		CODEMARK_FQR,
		CODEMARK_QR_COMBINE_EDIT_NONE,
		CODEMARK_QR_COMBINE_EDIT_NONE_GS1
	};

	// DNWA Decode Server
	public static final String DWQR_SERVER = "DENSO WAVE JP SERVER";
}
